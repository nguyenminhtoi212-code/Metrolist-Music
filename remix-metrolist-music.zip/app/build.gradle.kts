plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    alias(libs.plugins.kotlin.ksp)
    alias(libs.plugins.hilt.android)
    alias(libs.plugins.kotlin.serialization)
}

android {
    namespace = "com.metrolist.music"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.metrolist.music.dev"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.0.1"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Cấu hình MultiDex
        multiDexEnabled = false

        // Cấu hình ABI hỗ trợ đầy đủ 32-bit và 64-bit
        ndk {
            abiFilters.clear()
            abiFilters.addAll(setOf("arm64-v8a", "armeabi-v7a", "x86", "x86_64"))
        }

        buildConfigField("Boolean", "CAST_AVAILABLE", "true")
        buildConfigField("String", "ARCHITECTURE", "\"universal\"")
        buildConfigField("Boolean", "UPDATER_AVAILABLE", "false")
        buildConfigField("String", "LASTFM_API_KEY", "\"\"")
        buildConfigField("String", "LASTFM_SECRET", "\"\"")
        buildConfigField("String", "DISCORD_APP_ID", "\"\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }

    sourceSets {
        getByName("main") {
            java.srcDirs("src/main/java", "src/main/kotlin")
        }
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = false
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-Xjsr305=strict",
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
            "-opt-in=androidx.compose.foundation.ExperimentalFoundationApi",
            "-opt-in=androidx.compose.foundation.layout.ExperimentalLayoutApi",
            "-opt-in=androidx.compose.ui.ExperimentalComposeUiApi",
            "-opt-in=kotlinx.coroutines.ExperimentalCoroutinesApi",
            "-opt-in=kotlinx.coroutines.FlowPreview"
        )
    }

    buildFeatures {
        compose = true
        buildConfig = true
        viewBinding = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }

    packaging {
        resources {
            pickFirsts += setOf("**/kotlin/**", "**/org/**")
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/CONTRIBUTORS.md",
                "/META-INF/LICENSE*",
                "/META-INF/NOTICE*",
                "/META-INF/INDEX.LIST",
                "/META-INF/DEPENDENCIES",
                "/META-INF/*.kotlin_module"
            )
        }
        jniLibs {
            useLegacyPackaging = true
            pickFirsts += setOf("**/lib*.so")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    // --- Desugaring Core (Disabled for minSdk 26+ and multiDexEnabled=false) ---
    // coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")

    // --- AndroidX Core & Lifecycle ---
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.7.0")
    implementation("androidx.lifecycle:lifecycle-process:2.7.0")
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.datastore.preferences)

    // --- Jetpack Compose UI ---
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons.extended)
    implementation(libs.androidx.navigation.compose)

    // --- Dependency Injection (Hilt) ---
    implementation("com.google.dagger:hilt-android:2.51")
    ksp("com.google.dagger:hilt-compiler:2.51")
    implementation("androidx.hilt:hilt-navigation-compose:1.1.0")

    // --- Database (Room) ---
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // --- Media3 Engine ---
    implementation("androidx.media3:media3-exoplayer:1.2.1")
    implementation("androidx.media3:media3-session:1.2.1")
    implementation("androidx.media3:media3-common:1.2.1")
    implementation("androidx.media3:media3-datasource:1.2.1")
    implementation("androidx.media3:media3-datasource-okhttp:1.2.1")
    implementation("androidx.media3:media3-extractor:1.2.1")
    implementation("androidx.media3:media3-ui:1.2.1")
    implementation("androidx.media3:media3-cast:1.2.1")

    // --- Network & Ktor ---
    implementation("io.ktor:ktor-client-core:2.3.8")
    implementation("io.ktor:ktor-client-okhttp:2.3.8")
    implementation("io.ktor:ktor-client-cio:2.3.8")
    implementation("io.ktor:ktor-client-content-negotiation:2.3.8")
    implementation("io.ktor:ktor-serialization-kotlinx-json:2.3.8")
    implementation("io.ktor:ktor-client-encoding:2.3.8")
    implementation("io.ktor:ktor-client-websockets:2.3.8")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // --- Image Loading (Coil3) ---
    implementation("io.coil-kt.coil3:coil-compose:3.0.0-alpha06")
    implementation("io.coil-kt.coil3:coil-network-okhttp:3.0.0-alpha06")

    // --- Google Services & Cast ---
    implementation("com.google.android.gms:play-services-cast-framework:21.4.0")
    implementation("com.google.guava:guava:33.0.0-android")

    // --- Serialization, Protobuf & Logging ---
    implementation("com.google.protobuf:protobuf-javalite:3.25.2")
    implementation("com.google.protobuf:protobuf-kotlin-lite:3.25.2")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-guava:1.8.0")
    implementation("com.jakewharton.timber:timber:5.0.1")

    // --- UI Helpers & Utilities ---
    implementation("com.materialkolor:material-kolor:1.4.0")
    implementation("com.valentinilk.shimmer:compose-shimmer:1.2.0")
    implementation("sh.calvin.reorderable:reorderable:1.3.2")
    implementation("com.atilika.kuromoji:kuromoji-ipadic:0.9.0")
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.22.6")
    implementation("com.github.yalantis:ucrop:2.2.8")
    implementation("org.apache.commons:commons-lang3:3.14.0")

    // --- AndroidX System Extras ---
    implementation("androidx.palette:palette-ktx:1.0.0")
    implementation("androidx.graphics:graphics-shapes:1.0.0-alpha05")
    implementation("androidx.mediarouter:mediarouter:1.7.0")
    implementation("androidx.browser:browser:1.8.0")

    // --- Firebase Platform ---
    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.crashlytics)
    implementation(libs.firebase.analytics)
    implementation(libs.firebase.perf)

    // --- Testing ---
    testImplementation(libs.junit)
    testImplementation("org.robolectric:robolectric:4.12.2")
    testImplementation("androidx.test:core-ktx:1.5.0")
    testImplementation("io.ktor:ktor-client-mock:2.3.8")
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    debugImplementation(libs.androidx.ui.tooling)
}
