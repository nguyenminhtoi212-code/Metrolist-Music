/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.api

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object OpenRouterService {
    private val client =
        OkHttpClient
            .Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    suspend fun translate(
        text: String,
        targetLanguage: String,
        apiKey: String,
        baseUrl: String,
        model: String,
        mode: String,
        maxRetries: Int = 3,
        sourceLanguage: String? = null,
        customSystemPrompt: String = "",
    ): Result<List<String>> =
        withContext(Dispatchers.IO) {
            var currentAttempt = 0

            // Validate input
            if (text.isBlank()) {
                return@withContext Result.failure(Exception("Input text is empty"))
            }

            val lines = text.lines()
            val lineCount = lines.size

            while (currentAttempt < maxRetries) {
                try {
                    // Use custom system prompt if provided, otherwise use the default
                    val systemPrompt =
                        if (customSystemPrompt.isNotBlank()) {
                            customSystemPrompt.replace("{lineCount}", lineCount.toString())
                        } else {
                            """You are a precise lyrics translation assistant. Your output must ALWAYS be a valid JSON array of strings.

CRITICAL RULES:
1. Output ONLY a JSON array: ["line1", "line2", "line3"]
2. NO explanations, NO questions, NO additional text
3. Each input line maps to exactly one output line
4. Preserve empty lines as empty strings ""
5. Return EXACTLY $lineCount items in the array
6. If uncertain, provide best approximation but maintain line count"""
                        }

                    val userPrompt =
                        when (mode) {
                            "Romanized" -> {
                                """Romanize/transliterate the following $lineCount lines into simple Latin script using ONLY basic English letters (a-z, A-Z).

CRITICAL REQUIREMENTS:
- Use ONLY simple ASCII characters (a-z, A-Z, 0-9, basic punctuation)
- NO special characters like ā, ī, ū, ñ, ç, etc.
- NO diacritics or accent marks
- If text is already in Latin script, return it UNCHANGED
- For non-Latin scripts (Hindi, Chinese, Japanese, Korean, Cyrillic, etc.), provide simple romanization
- DO NOT translate meaning, only convert script to simple English letters
- Keep all punctuation and formatting
- Preserve line-by-line structure exactly

Examples of correct simple romanization:
- Sanskrit/Hindi "आ" → "aa" (not "ā")
- Japanese "東京" → "toukyou" or "tokyo" (not "tōkyō")
- Korean "서울" → "seoul" (not "sŏul")

Input ($lineCount lines):
$text

Output MUST be a JSON array with EXACTLY $lineCount strings using ONLY simple ASCII characters."""
                            }

                            "Transcribed" -> {
                                """Transcribe/transliterate the following $lineCount lines phonetically into $targetLanguage script.

CRITICAL REQUIREMENTS:
- Convert the SOUND/PRONUNCIATION of the original text into $targetLanguage script
- DO NOT translate the meaning - only represent how the original words SOUND
- Use the native script of $targetLanguage (e.g., Devanagari for Hindi, Hangul for Korean, etc.)
- Preserve the original pronunciation as closely as possible in the target script
- Keep punctuation and formatting
- Preserve line-by-line structure exactly
- If text is already in $targetLanguage script, return it UNCHANGED

Examples:
- Japanese "こんにちは" to Hindi → "कोन्निचिवा" (phonetic, not translation)
- English "Hello" to Hindi → "हेलो" (phonetic)
- Korean "안녕하세요" to Hindi → "अन्न्योंग हासेयो" (phonetic)

Input ($lineCount lines):
$text

Output MUST be a JSON array with EXACTLY $lineCount strings in $targetLanguage script."""
                            }

                            else -> {
                                """Translate the following $lineCount lines to $targetLanguage.

IMPORTANT:
- Provide natural, accurate translation
- Maintain poetic flow and meaning
- Keep punctuation appropriate for target language
- Preserve line-by-line structure exactly
- For song lyrics, prioritize singability

Input ($lineCount lines):
$text

Output MUST be a JSON array with EXACTLY $lineCount strings."""
                            }
                        }

                    val messages =
                        JSONArray().apply {
                            put(
                                JSONObject().apply {
                                    put("role", "system")
                                    put("content", systemPrompt)
                                },
                            )
                            put(
                                JSONObject().apply {
                                    put("role", "user")
                                    put("content", userPrompt)
                                },
                            )
                        }

                    val jsonBody =
                        JSONObject().apply {
                            if (model.isNotBlank()) {
                                put("model", model)
                            }
                            put("messages", messages)
                            put("temperature", 0.3) // Lower temperature for more consistent output
                            put("max_tokens", lineCount * 100) // Adequate tokens for translation
                        }

                    val request =
                        Request
                            .Builder()
                            .url(baseUrl.ifBlank { "https://openrouter.ai/api/v1/chat/completions" })
                            .apply {
                                if (apiKey.isNotBlank()) {
                                    addHeader("Authorization", "Bearer ${apiKey.trim()}")
                                }
                            }.addHeader("Content-Type", "application/json")
                            .addHeader("HTTP-Referer", "https://github.com/MetrolistGroup/Metrolist")
                            .addHeader("X-Title", "Metrolist")
                            .post(jsonBody.toString().toRequestBody(JSON))
                            .build()

                    val response = client.newCall(request).execute()
                    val responseBody = response.body?.string()

                    if (!response.isSuccessful) {
                        // Retry on server errors (5xx)
                        if (response.code >= 500) {
                            currentAttempt++
                            kotlinx.coroutines.delay(1000L * currentAttempt)
                            continue
                        }

                        val errorMsg =
                            try {
                                JSONObject(responseBody ?: "").optJSONObject("error")?.optString("message")
                                    ?: "HTTP ${response.code}: ${response.message}"
                            } catch (e: Exception) {
                                "HTTP ${response.code}: ${response.message}"
                            }
                        return@withContext Result.failure(Exception("Translation failed: $errorMsg"))
                    }

                    if (responseBody == null) {
                        currentAttempt++
                        continue
                    }

                    val jsonResponse = JSONObject(responseBody)
                    val choices = jsonResponse.optJSONArray("choices")
                    if (choices != null && choices.length() > 0) {
                        val message = choices.getJSONObject(0).optJSONObject("message")
                        var content = message?.optString("content")?.trim()

                        if (!content.isNullOrBlank()) {
                            // Enhanced JSON extraction with multiple fallback strategies
                            var translatedLines: List<String>? = null

                            // Strategy 1: Try direct JSON parsing
                            try {
                                val jsonArray = JSONArray(content)
                                translatedLines = (0 until jsonArray.length()).map { jsonArray.optString(it) }
                            } catch (e: Exception) {
                                // Strategy 2: Extract JSON from markdown code blocks
                                content = content.replace("```json", "").replace("```", "").trim()

                                try {
                                    val jsonArray = JSONArray(content)
                                    translatedLines = (0 until jsonArray.length()).map { jsonArray.optString(it) }
                                } catch (e2: Exception) {
                                    // Strategy 3: Find first [ and last ]
                                    val startIdx = content.indexOf('[')
                                    val endIdx = content.lastIndexOf(']')

                                    if (startIdx != -1 && endIdx != -1 && endIdx > startIdx) {
                                        val jsonString = content.substring(startIdx, endIdx + 1)
                                        try {
                                            val jsonArray = JSONArray(jsonString)
                                            translatedLines = (0 until jsonArray.length()).map { jsonArray.optString(it) }
                                        } catch (e3: Exception) {
                                            // Strategy 4: Manual line-by-line parsing as last resort
                                            translatedLines =
                                                content
                                                    .lines()
                                                    .filter { it.trim().isNotEmpty() }
                                                    .map { it.trim().removeSurrounding("\"").removeSurrounding("'") }
                                        }
                                    }
                                }
                            }

                            if (translatedLines != null) {
                                // Validate line count matches
                                if (translatedLines.size == lineCount) {
                                    return@withContext Result.success(translatedLines)
                                } else if (translatedLines.size > lineCount) {
                                    // If we got more lines, take first N
                                    return@withContext Result.success(translatedLines.take(lineCount))
                                } else {
                                    // If we got fewer lines, pad with empty strings
                                    val paddedLines = translatedLines.toMutableList()
                                    while (paddedLines.size < lineCount) {
                                        paddedLines.add("")
                                    }
                                    return@withContext Result.success(paddedLines)
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    if (currentAttempt == maxRetries - 1) {
                        return@withContext Result.failure(e)
                    }
                }
                currentAttempt++
                kotlinx.coroutines.delay(1000L * currentAttempt)
            }
            return@withContext Result.failure(Exception("Max retries exceeded"))
        }

    data class AssistantResponse(
        val reply: String,
        val suggestedQuery: String? = null,
        val isMusicAction: Boolean = false,
    )

    suspend fun chatAssistant(
        prompt: String,
        history: List<Pair<String, String>> = emptyList(),
        apiKey: String = "",
        baseUrl: String = "https://openrouter.ai/api/v1/chat/completions",
        model: String = "google/gemini-2.5-flash-lite",
        provider: String = "OpenRouter",
    ): Result<AssistantResponse> =
        withContext(Dispatchers.IO) {
            val cleanPrompt = prompt.trim()
            if (cleanPrompt.isBlank()) {
                return@withContext Result.failure(Exception("Tin nhắn không được để trống"))
            }

            // Detect if prompt is a music command (Voice / Text)
            val lowerPrompt = cleanPrompt.lowercase()
            val musicKeywords = listOf(
                "bật bài", "phát bài", "tìm bài", "mở bài", "nghe bài",
                "tìm nhạc", "nghe nhạc", "bật nhạc", "mở nhạc", "hát bài",
                "play song ", "play music ", "play ", "listen to ", "find song ", "find music ", "find ",
                "search for ", "search song ", "search "
            )
            var extractedQuery: String? = null
            for (kw in musicKeywords) {
                if (lowerPrompt.startsWith(kw)) {
                    extractedQuery = cleanPrompt.substring(kw.length).trim().removePrefix(":").removePrefix("-").trim()
                    break
                }
            }

            // If API key is available, call the configured AI provider
            if (apiKey.isNotBlank()) {
                try {
                    val messages = JSONArray()

                    // System prompt tailored for a smart, bilingual/multilingual music assistant
                    val systemMsg = JSONObject()
                    systemMsg.put("role", "system")
                    systemMsg.put(
                        "content",
                        """You are 'Mini Assistant' (Trợ lý Mini), a smart, compact, and friendly AI music companion in the Metrolist music app.
You fluently understand and reply in English, Vietnamese, and all other languages.
Rules:
1. Always reply in the EXACT SAME language that the user spoke or typed in (Vietnamese for Vietnamese queries, English for English queries, etc.).
2. Keep your answers concise, engaging, helpful, and directly focused on music, tracks, artists, genres, moods, lyrics, and playlists.
3. Whenever you recommend or mention specific songs/tracks, ALWAYS write them in brackets like [Song Title - Artist] (for example: [Shape of You - Ed Sheeran] or [Chúng Ta Của Tương Lai - Sơn Tùng M-TP]). This allows the app to display a one-tap direct play button for the user!
4. Keep the message compact, clear, and perfectly formatted for mobile screens."""
                    )
                    messages.put(systemMsg)

                    // Add conversation history
                    for ((role, content) in history.takeLast(6)) {
                        val msg = JSONObject()
                        msg.put("role", if (role == "user") "user" else "assistant")
                        msg.put("content", content)
                        messages.put(msg)
                    }

                    // Add current user prompt
                    val userMsg = JSONObject()
                    userMsg.put("role", "user")
                    userMsg.put("content", cleanPrompt)
                    messages.put(userMsg)

                    val requestBodyJson = JSONObject()
                    val actualModel = if (model.isBlank()) "google/gemini-2.5-flash-lite" else model
                    requestBodyJson.put("model", actualModel)
                    requestBodyJson.put("messages", messages)
                    requestBodyJson.put("temperature", 0.7)
                    requestBodyJson.put("max_tokens", 600)

                    val effectiveUrl =
                        if (baseUrl.isBlank()) {
                            when (provider) {
                                "OpenAI" -> "https://api.openai.com/v1/chat/completions"
                                "Gemini" -> "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"
                                "Perplexity" -> "https://api.perplexity.ai/chat/completions"
                                "Claude" -> "https://api.anthropic.com/v1/messages"
                                else -> "https://openrouter.ai/api/v1/chat/completions"
                            }
                        } else {
                            baseUrl
                        }

                    val requestBuilder =
                        Request.Builder()
                            .url(effectiveUrl)
                            .post(requestBodyJson.toString().toRequestBody(JSON))
                            .addHeader("Content-Type", "application/json")

                    if (provider == "Claude") {
                        requestBuilder.addHeader("x-api-key", apiKey)
                        requestBuilder.addHeader("anthropic-version", "2023-06-01")
                    } else {
                        requestBuilder.addHeader("Authorization", "Bearer $apiKey")
                    }

                    if (provider == "OpenRouter") {
                        requestBuilder.addHeader("HTTP-Referer", "https://github.com/metrolistgroup/metrolist")
                        requestBuilder.addHeader("X-Title", "Metrolist Music")
                    }

                    val response = client.newCall(requestBuilder.build()).execute()
                    val responseBody = response.body?.string()

                    if (response.isSuccessful && !responseBody.isNullOrBlank()) {
                        val jsonResponse = JSONObject(responseBody)
                        val choices = jsonResponse.optJSONArray("choices")
                        if (choices != null && choices.length() > 0) {
                            val msgObj = choices.getJSONObject(0).optJSONObject("message")
                            val replyText = msgObj?.optString("content")?.trim() ?: ""
                            if (replyText.isNotEmpty()) {
                                // Check if reply contains song recommendation
                                val songPattern = Regex("\\[(.*?)\\]")
                                val matchedSong = songPattern.find(replyText)?.groupValues?.getOrNull(1)
                                val finalQuery = extractedQuery ?: matchedSong

                                return@withContext Result.success(
                                    AssistantResponse(
                                        reply = replyText,
                                        suggestedQuery = finalQuery,
                                        isMusicAction = extractedQuery != null,
                                    )
                                )
                            }
                        }
                    }
                } catch (e: Exception) {
                    // Fall back to local assistant response below
                }
            }

            // Smart Instant Local Assistant for music queries (zero latency, offline & no API key required)
            val isVietnamese = java.util.Locale.getDefault().language.equals("vi", ignoreCase = true) ||
                cleanPrompt.any { "àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ".contains(it, ignoreCase = true) } ||
                listOf("bài", "nhạc", "hát", "gợi ý", "thư giãn", "thịnh hành", "tìm", "mở", "bật").any { lowerPrompt.contains(it) }

            val fallbackReply = if (isVietnamese) {
                if (extractedQuery != null && extractedQuery.isNotBlank()) {
                    "Tôi đã nhận diện bài hát: \"$extractedQuery\". Đang chuẩn bị phát hoặc tìm kiếm cho bạn!"
                } else if (lowerPrompt.contains("gợi ý") || lowerPrompt.contains("nhạc hay") || lowerPrompt.contains("recommend")) {
                    "Dưới đây là một số bài hát tuyệt vời bạn có thể nghe ngay:\n• [Chúng Ta Của Tương Lai - Sơn Tùng M-TP]\n• [Nơi Này Có Anh - Sơn Tùng M-TP]\n• [Đừng Làm Trái Tim Anh Đau - Sơn Tùng M-TP]\n• [Chuyện Đôi Ta - Emcee L]\n\nChạm vào bất kỳ bài nào để phát ngay nhé!"
                } else if (lowerPrompt.contains("chill") || lowerPrompt.contains("thư giãn") || lowerPrompt.contains("buồn")) {
                    "Danh sách nhạc nhẹ nhàng, thư giãn dành riêng cho bạn:\n• [Lofi Hip Hop Chill Beats]\n• [Ghé Qua - Dick, PC, Tofu]\n• [Bao Tiền Một Mớ Bình Yên - 14 Casper]\n• [Dấu Mưa - Trung Quân Idol]\n\nBạn muốn nghe bài nào?"
                } else if (lowerPrompt.contains("hot") || lowerPrompt.contains("thịnh hành") || lowerPrompt.contains("trend")) {
                    "Các ca khúc đang thịnh hành hàng đầu:\n• [Đừng Làm Trái Tim Anh Đau - Sơn Tùng M-TP]\n• [Cắt Đôi Nỗi Sầu - Tăng Duy Tân]\n• [Hit Me Up - Binz, Touliver]\n• [Ánh Đèn Sân Khấu - Khắc Hưng]"
                } else if (apiKey.isBlank()) {
                    "Xin chào! Bạn có thể nói hoặc gõ: 'Bật bài [Tên bài hát]', 'Gợi ý nhạc chill', hoặc vào Cài đặt -> Cài đặt AI để nhập API Key (Gemini, OpenRouter...) để mở khóa toàn bộ trí tuệ nhân tạo trò chuyện không giới hạn."
                } else {
                    "Tôi đã sẵn sàng hỗ trợ! Hãy nói hoặc hỏi tôi về bất kỳ bài hát, nghệ sĩ hoặc thể loại âm nhạc nào."
                }
            } else {
                if (extractedQuery != null && extractedQuery.isNotBlank()) {
                    "Recognized track: \"$extractedQuery\". Ready to play and search for you!"
                } else if (lowerPrompt.contains("recommend") || lowerPrompt.contains("suggest") || lowerPrompt.contains("good song") || lowerPrompt.contains("best song")) {
                    "Here are some great tracks you can enjoy right now:\n• [Shape of You - Ed Sheeran]\n• [Blinding Lights - The Weeknd]\n• [Stay - The Kid LAROI & Justin Bieber]\n• [As It Was - Harry Styles]\n\nTap any song to play instantly!"
                } else if (lowerPrompt.contains("chill") || lowerPrompt.contains("relax") || lowerPrompt.contains("lofi") || lowerPrompt.contains("calm")) {
                    "Relaxing and calming playlist for you:\n• [Lofi Hip Hop Chill Beats]\n• [Sunset Lover - Petit Biscuit]\n• [Someone You Loved - Lewis Capaldi]\n• [Daylight - David Kushner]\n\nWhich song would you like to hear?"
                } else if (lowerPrompt.contains("hot") || lowerPrompt.contains("trending") || lowerPrompt.contains("popular") || lowerPrompt.contains("top")) {
                    "Top trending tracks on the charts right now:\n• [Espresso - Sabrina Carpenter]\n• [Birds of a Feather - Billie Eilish]\n• [Good Luck, Babe! - Chappell Roan]\n• [Cruel Summer - Taylor Swift]"
                } else if (apiKey.isBlank()) {
                    "Hello! You can speak or type: 'Play [Song Name]', 'Recommend chill music', or go to Settings -> AI Settings to enter your API Key (Gemini, OpenRouter...) for unlimited smart conversation."
                } else {
                    "I am ready to assist! Ask me anything about music, songs, artists, or genres."
                }
            }

            return@withContext Result.success(
                AssistantResponse(
                    reply = fallbackReply,
                    suggestedQuery = extractedQuery,
                    isMusicAction = extractedQuery != null,
                )
            )
        }
}
