/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.FilterChip
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.constants.AutoplayKey
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.rememberPreference
import androidx.datastore.preferences.core.booleanPreferencesKey

val SmartMusicRecsKey = booleanPreferencesKey("smartMusicRecs")
val DiscoverNewPlaylistsKey = booleanPreferencesKey("discoverNewPlaylists")
val FavArtistRecsKey = booleanPreferencesKey("favArtistRecs")
val AllowAiRecsKey = booleanPreferencesKey("allowAiRecs")

val ShowLikedMusicOnKey = booleanPreferencesKey("showLikedMusicOn")
val SaveRecentPlaylistsKey = booleanPreferencesKey("saveRecentPlaylists")
val UniformVolumeRecsKey = booleanPreferencesKey("uniformVolumeRecs")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecommendationsSettings(
    navController: NavController
) {
    val (smartMusicRecs, onSmartMusicRecsChange) = rememberPreference(key = SmartMusicRecsKey, defaultValue = true)
    val (discoverNewPlaylists, onDiscoverNewPlaylistsChange) = rememberPreference(key = DiscoverNewPlaylistsKey, defaultValue = true)
    val (favArtistRecs, onFavArtistRecsChange) = rememberPreference(key = FavArtistRecsKey, defaultValue = true)
    val (autoplay, onAutoplayChange) = rememberPreference(key = AutoplayKey, defaultValue = false)
    val (allowAiRecs, onAllowAiRecsChange) = rememberPreference(key = AllowAiRecsKey, defaultValue = false)

    val (showLikedMusicOn, onShowLikedMusicOnChange) = rememberPreference(key = ShowLikedMusicOnKey, defaultValue = true)
    val (saveRecentPlaylists, onSaveRecentPlaylistsChange) = rememberPreference(key = SaveRecentPlaylistsKey, defaultValue = true)
    val (uniformVolume, onUniformVolumeChange) = rememberPreference(key = UniformVolumeRecsKey, defaultValue = false)

    val (improvedArtists, onImprovedArtistsChange) = rememberPreference(key = com.metrolist.music.constants.ImprovedArtistsKey, defaultValue = "Sơn Tùng M-TP, Đen Vâu, Taylor Swift")
    val (improvedPodcasts, onImprovedPodcastsChange) = rememberPreference(key = com.metrolist.music.constants.ImprovedPodcastsKey, defaultValue = "Have A Sip, Tri Kỷ Cảm Xúc, Giang Ơi")

    var showImproveMusicDialog by remember { mutableStateOf(false) }
    var showImprovePodcastDialog by remember { mutableStateOf(false) }

    Column(
        Modifier
            .windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top
                )
            )
        )

        Material3SettingsGroup(
            title = stringResource(R.string.recs_options_group_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.radio),
                    title = { Text(stringResource(R.string.recs_smart_music_title)) },
                    trailingContent = {
                        Switch(
                            checked = smartMusicRecs,
                            onCheckedChange = onSmartMusicRecsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (smartMusicRecs) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onSmartMusicRecsChange(!smartMusicRecs) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.queue_music),
                    title = { Text(stringResource(R.string.recs_discover_new_playlists_title)) },
                    trailingContent = {
                        Switch(
                            checked = discoverNewPlaylists,
                            onCheckedChange = onDiscoverNewPlaylistsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (discoverNewPlaylists) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onDiscoverNewPlaylistsChange(!discoverNewPlaylists) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.person),
                    title = { Text(stringResource(R.string.recs_fav_artist_title)) },
                    trailingContent = {
                        Switch(
                            checked = favArtistRecs,
                            onCheckedChange = onFavArtistRecsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (favArtistRecs) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onFavArtistRecsChange(!favArtistRecs) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.play),
                    title = { Text(stringResource(R.string.recs_autoplay_title)) },
                    trailingContent = {
                        Switch(
                            checked = autoplay,
                            onCheckedChange = onAutoplayChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (autoplay) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAutoplayChange(!autoplay) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.translate),
                    title = { Text(stringResource(R.string.recs_allow_ai_title)) },
                    trailingContent = {
                        Switch(
                            checked = allowAiRecs,
                            onCheckedChange = onAllowAiRecsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (allowAiRecs) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAllowAiRecsChange(!allowAiRecs) }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.recs_additional_group_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.favorite),
                    title = { Text(stringResource(R.string.recs_show_liked_music_title)) },
                    description = { Text(stringResource(R.string.recs_show_liked_music_desc)) },
                    trailingContent = {
                        Switch(
                            checked = showLikedMusicOn,
                            onCheckedChange = onShowLikedMusicOnChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (showLikedMusicOn) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onShowLikedMusicOnChange(!showLikedMusicOn) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.queue_music),
                    title = { Text(stringResource(R.string.recs_save_recent_playlists_title)) },
                    description = { Text(stringResource(R.string.recs_save_recent_playlists_desc)) },
                    trailingContent = {
                        Switch(
                            checked = saveRecentPlaylists,
                            onCheckedChange = onSaveRecentPlaylistsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (saveRecentPlaylists) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onSaveRecentPlaylistsChange(!saveRecentPlaylists) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.volume_off_pause),
                    title = { Text(stringResource(R.string.recs_uniform_volume_title)) },
                    description = { Text(stringResource(R.string.recs_uniform_volume_desc)) },
                    trailingContent = {
                        Switch(
                            checked = uniformVolume,
                            onCheckedChange = onUniformVolumeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (uniformVolume) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onUniformVolumeChange(!uniformVolume) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.person),
                    title = { Text(stringResource(R.string.recs_improve_music_title)) },
                    description = { Text(stringResource(R.string.recs_improve_music_desc)) },
                    onClick = { showImproveMusicDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.radio),
                    title = { Text(stringResource(R.string.recs_improve_podcast_title)) },
                    description = { Text(stringResource(R.string.recs_improve_podcast_desc)) },
                    onClick = { showImprovePodcastDialog = true }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))
    }

    if (showImproveMusicDialog) {
        var newArtist by remember { mutableStateOf("") }
        val artistList = remember(improvedArtists) {
            improvedArtists.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        }
        val popularArtists = listOf("Sơn Tùng M-TP", "Đen Vâu", "Vũ.", "Taylor Swift", "Billie Eilish", "BTS", "Bruno Mars", "Olivia Rodrigo")

        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showImproveMusicDialog = false },
            title = { Text(stringResource(R.string.recs_improve_music_title)) },
            text = {
                Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = stringResource(R.string.recs_improve_music_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Input to add a new artist
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newArtist,
                            onValueChange = { newArtist = it },
                            placeholder = { Text("Thêm nghệ sĩ mới...") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        androidx.compose.material3.Button(
                            onClick = {
                                if (newArtist.isNotBlank() && !artistList.contains(newArtist.trim())) {
                                    val updated = (artistList + newArtist.trim()).joinToString(", ")
                                    onImprovedArtistsChange(updated)
                                    newArtist = ""
                                }
                            }
                        ) {
                            Text("Thêm")
                        }
                    }

                    // Popular suggestions to quickly tap and add
                    Text(
                        text = "Gợi ý nghệ sĩ phổ biến:",
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                        modifier = Modifier.height(100.dp)
                    ) {
                        items(popularArtists.size) { index ->
                            val artist = popularArtists[index]
                            val isSelected = artistList.contains(artist)
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    val updatedList = if (isSelected) {
                                        artistList - artist
                                    } else {
                                        artistList + artist
                                    }
                                    onImprovedArtistsChange(updatedList.joinToString(", "))
                                },
                                label = { Text(artist) }
                            )
                        }
                    }

                    // Currently selected artists
                    Text(
                        text = "Danh sách đã chọn của bạn:",
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        artistList.forEach { artist ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
                                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                            ) {
                                Text(artist, style = MaterialTheme.typography.bodyLarge)
                                androidx.compose.material3.IconButton(
                                    onClick = {
                                        val updated = (artistList - artist).joinToString(", ")
                                        onImprovedArtistsChange(updated)
                                    }
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.close),
                                        contentDescription = "Xóa",
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showImproveMusicDialog = false }) {
                    Text(stringResource(R.string.close))
                }
            }
        )
    }

    if (showImprovePodcastDialog) {
        var newPodcast by remember { mutableStateOf("") }
        val podcastList = remember(improvedPodcasts) {
            improvedPodcasts.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        }
        val popularPodcasts = listOf("Have A Sip", "Tri Kỷ Cảm Xúc", "Giang Ơi", "Vietcetera", "The Present Writer", "Spiderum", "Web5ngay", "Sunhuyn Podcast")

        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showImprovePodcastDialog = false },
            title = { Text(stringResource(R.string.recs_improve_podcast_title)) },
            text = {
                Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = stringResource(R.string.recs_improve_podcast_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Input to add a new podcast
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newPodcast,
                            onValueChange = { newPodcast = it },
                            placeholder = { Text("Thêm podcast mới...") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        androidx.compose.material3.Button(
                            onClick = {
                                if (newPodcast.isNotBlank() && !podcastList.contains(newPodcast.trim())) {
                                    val updated = (podcastList + newPodcast.trim()).joinToString(", ")
                                    onImprovedPodcastsChange(updated)
                                    newPodcast = ""
                                }
                            }
                        ) {
                            Text("Thêm")
                        }
                    }

                    // Popular suggestions to quickly tap and add
                    Text(
                        text = "Chương trình phổ biến gợi ý:",
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                        modifier = Modifier.height(100.dp)
                    ) {
                        items(popularPodcasts.size) { index ->
                            val podcast = popularPodcasts[index]
                            val isSelected = podcastList.contains(podcast)
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    val updatedList = if (isSelected) {
                                        podcastList - podcast
                                    } else {
                                        podcastList + podcast
                                    }
                                    onImprovedPodcastsChange(updatedList.joinToString(", "))
                                },
                                label = { Text(podcast) }
                            )
                        }
                    }

                    // Currently selected podcasts
                    Text(
                        text = "Danh sách đã chọn của bạn:",
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        podcastList.forEach { podcast ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
                                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                            ) {
                                Text(podcast, style = MaterialTheme.typography.bodyLarge)
                                androidx.compose.material3.IconButton(
                                    onClick = {
                                        val updated = (podcastList - podcast).joinToString(", ")
                                        onImprovedPodcastsChange(updated)
                                    }
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.close),
                                        contentDescription = "Xóa",
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showImprovePodcastDialog = false }) {
                    Text(stringResource(R.string.close))
                }
            }
        )
    }

    TopAppBar(
        title = { Text(stringResource(R.string.recommendations_title)) },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain,
            ) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                )
            }
        }
    )
}
