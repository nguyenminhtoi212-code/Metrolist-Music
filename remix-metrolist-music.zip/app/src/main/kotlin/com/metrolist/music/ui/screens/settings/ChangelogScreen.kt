/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metrolist.music.BuildConfig
import com.metrolist.music.MainActivity
import com.metrolist.music.LocalDatabase
import com.metrolist.music.R
import com.metrolist.music.db.entities.VersionHistoryEntity
import com.metrolist.music.db.repositories.VersionHistoryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val markdownLinkRegex = Regex("(@[a-zA-Z0-9_-]+)|(https?://[\\w-]+(\\.[\\w-]+)+[\\w.,@?^=%&:/~+#-]*[\\w@?^=%&/~+#-])")

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun ChangelogScreen(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val database = LocalDatabase.current
    val repository = remember(database) { VersionHistoryRepository(database.versionHistoryDao) }
    val coroutineScope = rememberCoroutineScope()

    val versions by repository.allVersions.collectAsStateWithLifecycle(initialValue = emptyList())
    var isSyncing by remember { mutableStateOf(false) }

    // Seed database if empty on first load
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val count = database.versionHistoryDao.getCount()
            if (count == 0) {
                isSyncing = true
                repository.syncVersionHistory(context)
                isSyncing = false
            }
        }
    }

    val sheetState = rememberModalBottomSheetState(
        skipPartiallyExpanded = false
    )

    val listState = rememberLazyListState()
    var hasScrolledToLatest by rememberSaveable { mutableStateOf(false) }

    var isCompareMode by rememberSaveable { mutableStateOf(false) }
    var selectedVersionA by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedVersionB by rememberSaveable { mutableStateOf<String?>(null) }
    var showSideBySideSheet by remember { mutableStateOf(false) }

    // Auto-scroll to the most recent version entry when versions list is loaded
    LaunchedEffect(versions) {
        if (versions.isNotEmpty() && !hasScrolledToLatest) {
            val mostRecentIndex = versions.indexOfFirst {
                it.isCurrent || it.versionName == BuildConfig.VERSION_NAME || it.version == "v${BuildConfig.VERSION_NAME}"
            }.let { if (it >= 0) it else 0 }

            // Item 0 is title row, Item 1 is divider, items start at index 2
            val targetScrollIndex = (2 + mostRecentIndex).coerceIn(0, (2 + versions.size - 1).coerceAtLeast(0))
            listState.animateScrollToItem(targetScrollIndex)
            hasScrolledToLatest = true
        }
    }

    val entityA = remember(versions, selectedVersionA) { versions.find { it.version == selectedVersionA } }
    val entityB = remember(versions, selectedVersionB) { versions.find { it.version == selectedVersionB } }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = { BottomSheetDefaults.DragHandle() }
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(top = 4.dp, bottom = if (isCompareMode) 96.dp else 24.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = if (isCompareMode) stringResource(R.string.release_diff_compare_title) else stringResource(R.string.version_history_title),
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold
                            )
                            if (isCompareMode) {
                                val selectedCount = (if (selectedVersionA != null) 1 else 0) + (if (selectedVersionB != null) 1 else 0)
                                Text(
                                    text = stringResource(R.string.release_compare_select_hint),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            // Toggle Compare Mode Button
                            FilledTonalIconButton(
                                onClick = {
                                    isCompareMode = !isCompareMode
                                    if (isCompareMode && versions.size >= 2) {
                                        if (selectedVersionA == null) selectedVersionA = versions[0].version
                                        if (selectedVersionB == null) selectedVersionB = versions[1].version
                                    } else if (!isCompareMode) {
                                        selectedVersionA = null
                                        selectedVersionB = null
                                    }
                                }
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_compare_arrows),
                                    contentDescription = stringResource(R.string.release_compare_button),
                                    tint = if (isCompareMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            IconButton(
                                onClick = {
                                    coroutineScope.launch {
                                        isSyncing = true
                                        val count = repository.syncVersionHistory(context)
                                        isSyncing = false
                                        Toast.makeText(
                                            context,
                                            context.getString(R.string.version_history_synced_toast, count),
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            ) {
                                if (isSyncing) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(
                                        painter = painterResource(R.drawable.sync),
                                        contentDescription = stringResource(R.string.version_history_sync),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    val density = LocalDensity.current
                    val stroke = remember(density) {
                        Stroke(width = with(density) { 3.dp.toPx() }, cap = StrokeCap.Round)
                    }
                    LinearWavyProgressIndicator(
                        progress = { 1f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = Color.Transparent,
                        stroke = stroke,
                        trackStroke = stroke,
                        amplitude = { 1f }
                    )
                }

                if (isSyncing && versions.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    }
                } else if (versions.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = stringResource(R.string.version_history_empty))
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            isSyncing = true
                                            repository.syncVersionHistory(context)
                                            isSyncing = false
                                        }
                                    }
                                ) {
                                    Text(text = stringResource(R.string.version_history_sync))
                                }
                            }
                        }
                    }
                } else {
                    items(versions, key = { it.version }) { item ->
                        val selectionBadge = when (item.version) {
                            selectedVersionA -> "A"
                            selectedVersionB -> "B"
                            else -> null
                        }

                        VersionHistoryItem(
                            entity = item,
                            isCompareMode = isCompareMode,
                            selectionBadge = selectionBadge,
                            onToggleSelection = {
                                if (selectedVersionA == item.version) {
                                    selectedVersionA = null
                                } else if (selectedVersionB == item.version) {
                                    selectedVersionB = null
                                } else if (selectedVersionA == null) {
                                    selectedVersionA = item.version
                                } else if (selectedVersionB == null) {
                                    selectedVersionB = item.version
                                } else {
                                    // Replace B if both already set
                                    selectedVersionB = item.version
                                }
                            }
                        )
                    }
                }
            }

            // Bottom Floating Action Card in Compare Mode
            if (isCompareMode) {
                val canCompare = selectedVersionA != null && selectedVersionB != null
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHighest,
                    shadowElevation = 8.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (canCompare) {
                                    stringResource(R.string.release_compare_action, selectedVersionA ?: "", selectedVersionB ?: "")
                                } else {
                                    stringResource(R.string.release_compare_select_hint)
                                },
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (canCompare) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                if (canCompare && entityA != null && entityB != null) {
                                    showSideBySideSheet = true
                                }
                            },
                            enabled = canCompare,
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.ic_compare_arrows),
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = stringResource(R.string.release_compare_button))
                        }
                    }
                }
            }
        }
    }

    if (showSideBySideSheet && entityA != null && entityB != null) {
        SideBySideComparisonSheet(
            versionA = entityA,
            versionB = entityB,
            onDismiss = { showSideBySideSheet = false }
        )
    }
}

@Composable
fun VersionHistoryItem(
    entity: VersionHistoryEntity,
    isCompareMode: Boolean = false,
    selectionBadge: String? = null,
    onToggleSelection: (() -> Unit)? = null
) {
    val isVietnamese = remember {
        java.util.Locale.getDefault().language.equals("vi", ignoreCase = true)
    }
    val descriptionText = if (isVietnamese) {
        entity.descriptionVi.ifBlank { entity.description }
    } else {
        entity.descriptionEn.ifBlank { entity.description }
    }

    val isCurrent = entity.isCurrent || entity.versionName == BuildConfig.VERSION_NAME || entity.version == "v${BuildConfig.VERSION_NAME}"
    val isSelected = selectionBadge != null

    val cardBorder = if (isSelected) {
        androidx.compose.foundation.BorderStroke(
            2.dp,
            if (selectionBadge == "A") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary
        )
    } else null

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (isCompareMode && onToggleSelection != null) {
                    Modifier.clickable { onToggleSelection() }
                } else Modifier
            )
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (isCompareMode) {
                    Surface(
                        shape = CircleShape,
                        color = if (isSelected) {
                            if (selectionBadge == "A") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary
                        } else MaterialTheme.colorScheme.surfaceContainerHighest,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = selectionBadge ?: "○",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) {
                                    if (selectionBadge == "A") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onTertiary
                                } else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Surface(
                    color = if (isCurrent) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer,
                    shape = CircleShape
                ) {
                    Text(
                        text = entity.version,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = if (isCurrent) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }

                if (isCurrent) {
                    Surface(
                        color = MaterialTheme.colorScheme.primary,
                        shape = CircleShape
                    ) {
                        Text(
                            text = stringResource(R.string.version_history_current),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }

            if (entity.releaseDate.isNotBlank()) {
                Text(
                    text = entity.releaseDate.split("T").firstOrNull() ?: entity.releaseDate,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = if (isSelected) {
                    if (selectionBadge == "A") MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                    else MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.35f)
                } else MaterialTheme.colorScheme.surfaceContainer
            ),
            border = cardBorder,
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                if (descriptionText.isNotBlank()) {
                    MarkdownText(descriptionText)
                } else {
                    Text(
                        text = stringResource(R.string.app_is_up_to_date, entity.version),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Suppress("DEPRECATION")
@Composable
fun MarkdownText(text: String) {
    val lines = text.split("\n")
    val uriHandler = LocalUriHandler.current

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        lines.filter { it.isNotBlank() }.forEach { line ->
            val trimmedLine = line.trim()

            if (trimmedLine.startsWith("#")) {
                val level = trimmedLine.takeWhile { it == '#' }.length
                val headerText = trimmedLine.substring(level).trim()
                Box(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                    Text(
                        text = headerText,
                        style = when (level) {
                            1 -> MaterialTheme.typography.headlineMedium
                            2 -> MaterialTheme.typography.headlineSmall
                            else -> MaterialTheme.typography.titleMedium
                        },
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                val isListItem = trimmedLine.startsWith("- ") || trimmedLine.startsWith("* ")
                val contentText = if (isListItem) {
                    trimmedLine.substring(2).trim()
                } else {
                    trimmedLine
                }

                val annotatedString = buildAnnotatedString {
                    var lastIndex = 0
                    markdownLinkRegex.findAll(contentText).forEach { result ->
                        append(contentText.substring(lastIndex, result.range.first))
                        
                        val match = result.value
                        val link = if (match.startsWith("@")) "https://github.com/${match.substring(1)}" else match
                        
                        pushStringAnnotation(tag = "URL", annotation = link)
                        withStyle(style = SpanStyle(
                            color = MaterialTheme.colorScheme.primary, 
                            fontWeight = if (match.startsWith("@")) FontWeight.Bold else FontWeight.Normal,
                            textDecoration = if (match.startsWith("@")) TextDecoration.None else TextDecoration.Underline
                        )) {
                            append(match)
                        }
                        pop()
                        lastIndex = result.range.last + 1
                    }
                    append(contentText.substring(lastIndex))
                }

                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier.fillMaxWidth()) {
                        if (isListItem) {
                            Text(
                                text = stringResource(R.string.list_bullet),
                                modifier = Modifier.padding(end = 8.dp),
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                        ClickableText(
                            text = annotatedString,
                            style = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface),
                            onClick = { offset ->
                                annotatedString.getStringAnnotations(tag = "URL", start = offset, end = offset)
                                    .firstOrNull()?.let { annotation ->
                                        uriHandler.openUri(annotation.item)
                                    }
                            }
                        )
                    }
                    
                    if (isListItem) {
                        Spacer(modifier = Modifier.height(4.dp))
                        HorizontalDivider(
                            thickness = 0.5.dp,
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                        )
                    }
                }
            }
        }
    }
}
