/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.db.entities.ArtistEntity
import com.metrolist.music.db.entities.Song
import com.metrolist.music.db.entities.SongEntity
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.menu.AddToPlaylistDialogOnline
import com.metrolist.music.ui.menu.LoadingScreen
import com.metrolist.music.ui.utils.backToMain
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpotifyImportScreen(
    navController: NavController
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var isConnected by rememberSaveable { mutableStateOf(false) }
    var isConnecting by remember { mutableStateOf(false) }
    var playlistUrl by rememberSaveable { mutableStateOf("") }
    var isFetching by remember { mutableStateOf(false) }

    // Navigation and AddToPlaylist states
    var importedTitle by remember { mutableStateOf("") }
    val importedSongs = remember { mutableStateListOf<Song>() }
    var showChoosePlaylistDialogOnline by rememberSaveable { mutableStateOf(false) }

    var currentImportSong by rememberSaveable { mutableStateOf("") }
    var isProgressStarted by rememberSaveable { mutableStateOf(false) }
    var progressPercentage by rememberSaveable { mutableIntStateOf(0) }

    fun handleConnect() {
        if (isConnected) {
            isConnected = false
            android.widget.Toast.makeText(context, "Đã ngắt kết nối Spotify", android.widget.Toast.LENGTH_SHORT).show()
        } else {
            coroutineScope.launch {
                isConnecting = true
                kotlinx.coroutines.delay(1000)
                isConnected = true
                isConnecting = false
                android.widget.Toast.makeText(context, "Kết nối Spotify thành công!", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    suspend fun fetchSpotifyPlaylist(playlistId: String): List<Song> {
        val client = OkHttpClient()
        val songs = mutableListOf<Song>()

        // Attempt 1: api.spotifydown.com
        try {
            val request = Request.Builder()
                .url("https://api.spotifydown.com/playlist/$playlistId")
                .build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()
                    if (!body.isNullOrBlank()) {
                        val json = Json.parseToJsonElement(body).jsonObject
                        val success = json["success"]?.jsonPrimitive?.content?.toBoolean() ?: false
                        if (success) {
                            val tracks = json["trackList"]?.jsonArray
                            if (tracks != null) {
                                for (trackElement in tracks) {
                                    val trackObj = trackElement.jsonObject
                                    val title = trackObj["title"]?.jsonPrimitive?.content ?: ""
                                    val artistsStr = trackObj["artists"]?.jsonPrimitive?.content ?: ""
                                    val artists = artistsStr.split(",").map { it.trim() }

                                    val mockSong = Song(
                                        song = SongEntity(
                                            id = "",
                                            title = title,
                                        ),
                                        artists = artists.map { ArtistEntity("", it) }
                                    )
                                    songs.add(mockSong)
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "SpotifyDown API failed, attempting embed scraping fallback")
        }

        // Attempt 2: fallback to scraping open.spotify.com/embed/playlist/<playlistId>
        if (songs.isEmpty()) {
            try {
                val request = Request.Builder()
                    .url("https://open.spotify.com/embed/playlist/$playlistId")
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                    .build()
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val html = response.body?.string() ?: ""
                        val resourceJson = html.substringAfter("<script id=\"resource\" type=\"application/json\">").substringBefore("</script>")
                        if (resourceJson.length < html.length) {
                            val json = Json.parseToJsonElement(resourceJson).jsonObject
                            val tracksObj = json["tracks"]?.jsonObject ?: json["trackList"]?.jsonObject
                            val items = tracksObj?.get("items")?.jsonArray
                            if (items != null) {
                                for (item in items) {
                                    val track = item.jsonObject["track"]?.jsonObject ?: item.jsonObject
                                    val name = track["name"]?.jsonPrimitive?.content ?: ""
                                    val artistsArray = track["artists"]?.jsonArray
                                    val artists = artistsArray?.mapNotNull { it.jsonObject["name"]?.jsonPrimitive?.content } ?: emptyList()

                                    if (name.isNotBlank()) {
                                        val mockSong = Song(
                                            song = SongEntity(
                                                id = "",
                                                title = name,
                                            ),
                                            artists = artists.map { ArtistEntity("", it) }
                                        )
                                        songs.add(mockSong)
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.e(e, "Embed scraping fallback failed")
            }
        }

        return songs
    }

    fun handleImport() {
        val trimmed = playlistUrl.trim()
        if (trimmed.isBlank()) {
            android.widget.Toast.makeText(context, "Vui lòng nhập liên kết danh sách phát Spotify", android.widget.Toast.LENGTH_SHORT).show()
            return
        }

        val playlistId = if (trimmed.contains("playlist/")) {
            trimmed.substringAfter("playlist/").substringBefore("?").substringBefore("/")
        } else {
            trimmed
        }

        if (playlistId.length < 10) {
            android.widget.Toast.makeText(context, "Liên kết không hợp lệ", android.widget.Toast.LENGTH_SHORT).show()
            return
        }

        coroutineScope.launch {
            isFetching = true
            val results = withContext(Dispatchers.IO) {
                fetchSpotifyPlaylist(playlistId)
            }
            isFetching = false

            if (results.isNotEmpty()) {
                importedSongs.clear()
                importedSongs.addAll(results)
                importedTitle = "Spotify Playlist Import"
                showChoosePlaylistDialogOnline = true
            } else {
                android.widget.Toast.makeText(context, "Không tìm thấy bài hát nào hoặc danh sách phát không công khai", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom,
                ),
            )
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top,
                ),
            ),
        )

        Spacer(Modifier.height(4.dp))

        Material3SettingsGroup(
            title = "Spotify Import",
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.person),
                    title = { Text("Kết nối Spotify") },
                    description = {
                        Text(
                            if (isConnecting) "Đang kết nối..."
                            else if (isConnected) "Spotify đã được kết nối (MetroUser)"
                            else "Spotify chưa được kết nối"
                        )
                    },
                    trailingContent = {
                        Button(onClick = { handleConnect() }, enabled = !isConnecting) {
                            Text(if (isConnected) "Đứt kết nối" else "Kết nối")
                        }
                    },
                    onClick = { if (!isConnecting) handleConnect() }
                )
            )
        )

        Spacer(Modifier.height(16.dp))

        Material3SettingsGroup(
            title = "Nhập danh sách phát bằng liên kết",
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.playlist_add),
                    title = { Text("Nhập danh sách phát bằng liên kết") },
                    description = { Text("Dán liên kết danh sách phát Spotify để nhập, kể cả danh sách phát không thuộc sở hữu của bạn") }
                )
            )
        )

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = playlistUrl,
            onValueChange = { playlistUrl = it },
            label = { Text("Dán liên kết danh sách phát Spotify") },
            placeholder = { Text("https://open.spotify.com/playlist/...") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            singleLine = true,
            enabled = !isFetching
        )

        Spacer(Modifier.height(16.dp))

        Button(
            onClick = { handleImport() },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            enabled = !isFetching && playlistUrl.isNotBlank()
        ) {
            if (isFetching) {
                Text("Đang tải danh sách bài hát...")
            } else {
                Text("Nhập (Import)")
            }
        }

        Spacer(Modifier.height(32.dp))
    }

    TopAppBar(
        title = { Text("Spotify Import") },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain,
            ) {
                Icon(
                    painter = painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                )
            }
        },
    )

    AddToPlaylistDialogOnline(
        isVisible = showChoosePlaylistDialogOnline,
        allowSyncing = false,
        initialTextFieldValue = importedTitle,
        songs = importedSongs,
        onDismiss = { showChoosePlaylistDialogOnline = false },
        onProgressStart = { newVal -> isProgressStarted = newVal },
        onPercentageChange = { newPercentage -> progressPercentage = newPercentage },
        onSongChange = { currentImportSong = it },
    )

    LoadingScreen(
        isVisible = isProgressStarted,
        value = progressPercentage,
        songTitle = currentImportSong,
    )
}
