/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.component

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.mediarouter.media.MediaRouteSelector
import androidx.mediarouter.media.MediaRouter
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.framework.CastContext
import com.metrolist.music.LocalPlayerConnection
import com.metrolist.music.R
import com.metrolist.music.constants.EnableGoogleCastKey
import com.metrolist.music.utils.rememberPreference
import timber.log.Timber

/**
 * A Composable Cast button that shows available Cast devices.
 * Uses the app's MenuState to show a styled bottom sheet.
 */
@Composable
fun CastButton(
    modifier: Modifier = Modifier,
    tintColor: Color = MaterialTheme.colorScheme.onSurface,
) {
    val context = LocalContext.current
    val playerConnection = LocalPlayerConnection.current
    val menuState = LocalMenuState.current
    
    var castAvailable by remember { mutableStateOf(false) }
    var mediaRouter by remember { mutableStateOf<MediaRouter?>(null) }
    var routeSelector by remember { mutableStateOf<MediaRouteSelector?>(null) }
    var availableRoutes by remember { mutableStateOf<List<MediaRouter.RouteInfo>>(emptyList()) }
    
    val (enableGoogleCast) = rememberPreference(
        key = EnableGoogleCastKey,
        defaultValue = true
    )
    
    // Get cast state from service
    val castHandler = playerConnection?.service?.castConnectionHandler
    val isCasting = castHandler?.isCasting?.collectAsStateWithLifecycle(initialValue = false)?.value ?: false
    val isConnecting = castHandler?.isConnecting?.collectAsStateWithLifecycle(initialValue = false)?.value ?: false
    val connectionStatusMessage = castHandler?.connectionStatusMessage?.collectAsStateWithLifecycle(initialValue = null)?.value
    val castDeviceName = castHandler?.castDeviceName?.collectAsStateWithLifecycle(initialValue = null)?.value

    var isScanning by remember { mutableStateOf(false) }
    var scanRemainingSeconds by remember { mutableStateOf(0) }
    val coroutineScope = rememberCoroutineScope()
    var scanJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    
    // Get current media metadata
    val currentMetadata = playerConnection?.mediaMetadata?.collectAsStateWithLifecycle(initialValue = null)?.value

    val callback = remember {
        object : MediaRouter.Callback() {
            override fun onRouteAdded(router: MediaRouter, route: MediaRouter.RouteInfo) {
                updateRoutes(router, routeSelector) { availableRoutes = it }
            }
            
            override fun onRouteRemoved(router: MediaRouter, route: MediaRouter.RouteInfo) {
                updateRoutes(router, routeSelector) { availableRoutes = it }
            }
            
            override fun onRouteChanged(router: MediaRouter, route: MediaRouter.RouteInfo) {
                updateRoutes(router, routeSelector) { availableRoutes = it }
            }
        }
    }

    val triggerActiveScan = remember(mediaRouter, routeSelector) {
        {
            scanJob?.cancel()
            scanJob = coroutineScope.launch {
                isScanning = true
                routeSelector?.let { selector ->
                    mediaRouter?.removeCallback(callback)
                    mediaRouter?.addCallback(
                        selector,
                        callback,
                        MediaRouter.CALLBACK_FLAG_PERFORM_ACTIVE_SCAN or MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY
                    )
                    updateRoutes(mediaRouter, selector) { availableRoutes = it }
                }
                for (sec in 15 downTo 1) {
                    scanRemainingSeconds = sec
                    kotlinx.coroutines.delay(1000)
                }
                scanRemainingSeconds = 0
                isScanning = false
                routeSelector?.let { selector ->
                    mediaRouter?.removeCallback(callback)
                    mediaRouter?.addCallback(
                        selector,
                        callback,
                        MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY
                    )
                }
            }
        }
    }

    // Check if Cast is available and disconnect if disabled while casting
    LaunchedEffect(enableGoogleCast) {
        if (!enableGoogleCast) {
            // Disconnect from Cast if currently casting
            if (isCasting) {
                playerConnection?.service?.castConnectionHandler?.disconnect()
            }
            castAvailable = false
            mediaRouter = null
            routeSelector = null
            availableRoutes = emptyList()
            return@LaunchedEffect
        }
        try {
            CastContext.getSharedInstance(context)
            mediaRouter = MediaRouter.getInstance(context)
            routeSelector = MediaRouteSelector.Builder()
                .addControlCategory(CastMediaControlIntent.categoryForCast(CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID))
                .build()
            // Reinitialize the Cast handler to ensure it's ready
            playerConnection?.service?.castConnectionHandler?.initialize()
            castAvailable = true
        } catch (e: Exception) {
            Timber.d("Cast not available: ${e.message}")
            castAvailable = false
        }
    }
    
    // Listen for route changes to discover devices
    DisposableEffect(mediaRouter, routeSelector) {
        routeSelector?.let { selector ->
            mediaRouter?.addCallback(selector, callback, MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY)
            // Initial update
            updateRoutes(mediaRouter, selector) { availableRoutes = it }
        }
        
        onDispose {
            scanJob?.cancel()
            mediaRouter?.removeCallback(callback)
        }
    }

    // Show the button if Cast is enabled
    if (enableGoogleCast) {
        Box(
            modifier = modifier
        ) {
            // Shadow background for cast button
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .align(Alignment.Center)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.4f),
                                Color.Transparent
                            )
                        )
                    )
            )
            
            // Cast button
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(40.dp)
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(20.dp))
                    .clickable {
                    if (currentMetadata == null && !isCasting) {
                        Toast.makeText(context, context.getString(R.string.please_play_music_before_casting), Toast.LENGTH_SHORT).show()
                        return@clickable
                    }
                    
                    // Trigger active device recognition scan when sheet opens
                    if (!isCasting) {
                        triggerActiveScan()
                    }

                    // Get current connected route if casting
                    val currentRoute = if (isCasting && castAvailable) {
                        mediaRouter?.routes?.find { route ->
                            routeSelector?.let { selector -> 
                                route.matchesSelector(selector) && route.isSelected
                            } == true
                        }
                    } else null
                    
                    // Show bottom sheet with cast picker
                    menuState.show {
                        CastPickerSheet(
                            routes = if (castAvailable) availableRoutes else emptyList(),
                            isConnecting = isConnecting,
                            connectionStatusMessage = connectionStatusMessage,
                            currentlyConnectedRoute = currentRoute,
                            isScanning = isScanning,
                            scanRemainingSeconds = scanRemainingSeconds,
                            onRetryScan = { triggerActiveScan() },
                            onRouteSelected = { route ->
                                castHandler?.connectToRoute(route)
                                menuState.dismiss()
                            },
                            onDisconnect = {
                                castHandler?.disconnect()
                                menuState.dismiss()
                            },
                            onCancelConnection = {
                                castHandler?.cancelConnection()
                            },
                            onConnectSequentially = { routes ->
                                castHandler?.connectToRoutesSequentially(routes)
                            }
                        )
                    }
                }
            ) {
                Image(
                    painter = painterResource(
                        if (isCasting) R.drawable.cast_connected else R.drawable.cast
                    ),
                    contentDescription = if (isCasting) "Stop casting" else "Cast",
                    colorFilter = ColorFilter.tint(
                        if (isCasting) MaterialTheme.colorScheme.primary else tintColor
                    ),
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

private fun updateRoutes(
    router: MediaRouter?,
    selector: MediaRouteSelector?,
    onUpdate: (List<MediaRouter.RouteInfo>) -> Unit
) {
    if (router == null || selector == null) {
        onUpdate(emptyList())
        return
    }
    val routes = router.routes.filter { route ->
        route.matchesSelector(selector) && !route.isDefault
    }
    onUpdate(routes)
}
