/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.metrolist.music.BuildConfig
import com.metrolist.music.R
import com.metrolist.music.db.entities.VersionHistoryEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SideBySideComparisonSheet(
    versionA: VersionHistoryEntity,
    versionB: VersionHistoryEntity,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(
        skipPartiallyExpanded = true
    )

    var currentVersionA by remember { mutableStateOf(versionA) }
    var currentVersionB by remember { mutableStateOf(versionB) }
    var selectedCategory by remember { mutableStateOf(ChangeCategory.ALL) }
    var showRawMarkdownSideBySide by remember { mutableStateOf(false) }

    val changesA = remember(currentVersionA) { parseReleaseChanges(currentVersionA) }
    val changesB = remember(currentVersionB) { parseReleaseChanges(currentVersionB) }

    // Compare changes
    val textSetB = remember(changesB) { changesB.map { it.cleanText.lowercase().trim() }.toSet() }
    val textSetA = remember(changesA) { changesA.map { it.cleanText.lowercase().trim() }.toSet() }

    val filteredChangesA = remember(changesA, selectedCategory, textSetB) {
        changesA.filter {
            selectedCategory == ChangeCategory.ALL || it.category == selectedCategory
        }.map { item ->
            item.copy(isHighlighted = !textSetB.contains(item.cleanText.lowercase().trim()))
        }
    }

    val filteredChangesB = remember(changesB, selectedCategory, textSetA) {
        changesB.filter {
            selectedCategory == ChangeCategory.ALL || it.category == selectedCategory
        }.map { item ->
            item.copy(isHighlighted = !textSetA.contains(item.cleanText.lowercase().trim()))
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = { BottomSheetDefaults.DragHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Sheet Header with Swap and Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = stringResource(R.string.release_side_by_side_title),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${currentVersionA.version} ↔ ${currentVersionB.version}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = {
                            val temp = currentVersionA
                            currentVersionA = currentVersionB
                            currentVersionB = temp
                        }
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_swap_horiz),
                            contentDescription = stringResource(R.string.release_diff_swap_versions),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            painter = painterResource(R.drawable.close),
                            contentDescription = stringResource(R.string.close),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Dual Version Header Cards Side-by-Side
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                VersionSideCard(
                    title = stringResource(R.string.release_diff_version_a),
                    entity = currentVersionA,
                    changesCount = changesA.size,
                    newCount = filteredChangesA.count { it.isHighlighted },
                    isPrimary = true,
                    modifier = Modifier.weight(1f)
                )

                VersionSideCard(
                    title = stringResource(R.string.release_diff_version_b),
                    entity = currentVersionB,
                    changesCount = changesB.size,
                    newCount = filteredChangesB.count { it.isHighlighted },
                    isPrimary = false,
                    modifier = Modifier.weight(1f)
                )
            }

            // Category Filter Chips Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ChangeCategory.values().forEach { category ->
                    val isSelected = selectedCategory == category
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = category },
                        label = {
                            Text(
                                text = when (category) {
                                    ChangeCategory.ALL -> stringResource(R.string.release_diff_category_all)
                                    ChangeCategory.FEATURE -> stringResource(R.string.release_diff_category_features)
                                    ChangeCategory.IMPROVEMENT -> stringResource(R.string.release_diff_category_improvements)
                                    ChangeCategory.FIX -> stringResource(R.string.release_diff_category_fixes)
                                    ChangeCategory.OTHER -> stringResource(R.string.release_diff_category_others)
                                },
                                style = MaterialTheme.typography.labelMedium
                            )
                        },
                        leadingIcon = {
                            Icon(
                                painter = painterResource(category.iconRes),
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }

            // Toggle between Side-by-Side bullet points vs Raw Markdown
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (showRawMarkdownSideBySide) stringResource(R.string.release_diff_full_markdown) else stringResource(R.string.release_diff_categorized_side_by_side),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                TextButton(
                    onClick = { showRawMarkdownSideBySide = !showRawMarkdownSideBySide }
                ) {
                    Text(if (showRawMarkdownSideBySide) stringResource(R.string.release_diff_show_bullets) else stringResource(R.string.release_diff_show_full_markdown))
                }
            }

            // Content Area
            if (showRawMarkdownSideBySide) {
                SideBySideRawMarkdownView(
                    versionA = currentVersionA,
                    versionB = currentVersionB,
                    modifier = Modifier.weight(1f)
                )
            } else {
                SideBySideColumnsView(
                    changesA = filteredChangesA,
                    changesB = filteredChangesB,
                    versionNameA = currentVersionA.version,
                    versionNameB = currentVersionB.version,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun VersionSideCard(
    title: String,
    entity: VersionHistoryEntity,
    changesCount: Int,
    newCount: Int,
    isPrimary: Boolean,
    modifier: Modifier = Modifier
) {
    val isCurrent = entity.isCurrent || entity.versionName == BuildConfig.VERSION_NAME || entity.version == "v${BuildConfig.VERSION_NAME}"
    val containerColor = if (isPrimary) {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)
    } else {
        MaterialTheme.colorScheme.surfaceContainer
    }

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isPrimary) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )

                if (isCurrent) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary
                    ) {
                        Text(
                            text = stringResource(R.string.version_history_current),
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            Text(
                text = entity.version,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (entity.releaseDate.isNotBlank()) {
                Text(
                    text = entity.releaseDate.split("T").firstOrNull() ?: entity.releaseDate,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surfaceContainerHighest
                ) {
                    Text(
                        text = stringResource(R.string.release_diff_items_count, changesCount),
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                if (newCount > 0) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFF10B981).copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = stringResource(R.string.release_diff_unique_count, newCount),
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = Color(0xFF10B981),
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SideBySideColumnsView(
    changesA: List<ParsedChangeItem>,
    changesB: List<ParsedChangeItem>,
    versionNameA: String,
    versionNameB: String,
    modifier: Modifier = Modifier
) {
    val maxItems = maxOf(changesA.size, changesB.size)

    if (maxItems == 0) {
        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = stringResource(R.string.release_diff_no_changes),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        items(count = maxItems) { index ->
            val itemA = changesA.getOrNull(index)
            val itemB = changesB.getOrNull(index)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.Top
            ) {
                // Left item (Version A)
                Box(modifier = Modifier.weight(1f)) {
                    if (itemA != null) {
                        SideBySideItemCard(item = itemA)
                    } else {
                        EmptySidePlaceholder()
                    }
                }

                // Right item (Version B)
                Box(modifier = Modifier.weight(1f)) {
                    if (itemB != null) {
                        SideBySideItemCard(item = itemB)
                    } else {
                        EmptySidePlaceholder()
                    }
                }
            }
        }
    }
}

@Composable
fun SideBySideItemCard(
    item: ParsedChangeItem
) {
    val categoryColor = when (item.category) {
        ChangeCategory.FEATURE -> Color(0xFF10B981)
        ChangeCategory.IMPROVEMENT -> Color(0xFF3B82F6)
        ChangeCategory.FIX -> Color(0xFFEF4444)
        ChangeCategory.OTHER, ChangeCategory.ALL -> Color(0xFF8B5CF6)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (item.isHighlighted) {
                categoryColor.copy(alpha = 0.12f)
            } else {
                MaterialTheme.colorScheme.surfaceContainer
            }
        ),
        border = if (item.isHighlighted) {
            androidx.compose.foundation.BorderStroke(1.dp, categoryColor.copy(alpha = 0.4f))
        } else null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = categoryColor.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = when (item.category) {
                            ChangeCategory.ALL -> stringResource(R.string.release_diff_category_all)
                            ChangeCategory.FEATURE -> stringResource(R.string.release_diff_category_features)
                            ChangeCategory.IMPROVEMENT -> stringResource(R.string.release_diff_category_improvements)
                            ChangeCategory.FIX -> stringResource(R.string.release_diff_category_fixes)
                            ChangeCategory.OTHER -> stringResource(R.string.release_diff_category_others)
                        },
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                        fontWeight = FontWeight.Bold,
                        color = categoryColor,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                if (item.isHighlighted) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFF10B981).copy(alpha = 0.25f)
                    ) {
                        Text(
                            text = stringResource(R.string.release_diff_unique_badge),
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.5.sp),
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF10B981),
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            Text(
                text = item.cleanText,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                ),
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun EmptySidePlaceholder() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest.copy(alpha = 0.5f)
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "—",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
            )
        }
    }
}

@Composable
fun SideBySideRawMarkdownView(
    versionA: VersionHistoryEntity,
    versionB: VersionHistoryEntity,
    modifier: Modifier = Modifier
) {
    val isVietnamese = java.util.Locale.getDefault().language.equals("vi", ignoreCase = true)
    val textA = if (isVietnamese) versionA.descriptionVi.ifBlank { versionA.description } else versionA.descriptionEn.ifBlank { versionA.description }
    val textB = if (isVietnamese) versionB.descriptionVi.ifBlank { versionB.description } else versionB.descriptionEn.ifBlank { versionB.description }

    Row(
        modifier = modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Version A column
        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainer
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp)
            ) {
                Text(
                    text = versionA.version,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                MarkdownText(text = textA.ifBlank { stringResource(R.string.release_diff_no_notes) })
            }
        }

        // Version B column
        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainer
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp)
            ) {
                Text(
                    text = versionB.version,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                MarkdownText(text = textB.ifBlank { stringResource(R.string.release_diff_no_notes) })
            }
        }
    }
}
