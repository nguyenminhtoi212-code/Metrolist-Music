/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.api

import android.content.Context
import com.metrolist.innertube.YouTube
import com.metrolist.innertube.models.Album
import com.metrolist.innertube.models.Artist
import com.metrolist.innertube.models.SongItem
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import timber.log.Timber
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

enum class MusicSourceProvider {
    ALL,
    YOUTUBE,
    SPOTIFY,
    APPLE_MUSIC,
    ;

    val displayName: String
        get() = when (this) {
            ALL -> "All"
            YOUTUBE -> "YouTube Music"
            SPOTIFY -> "Spotify"
            APPLE_MUSIC -> "Apple Music"
        }
}

enum class MusicCountry(val code: String, val displayName: String, val flag: String) {
    VIETNAM("vn", "Việt Nam", "🇻🇳"),
    US("us", "Toàn cầu / US", "🇺🇸"),
    UK("gb", "Vương quốc Anh", "🇬🇧"),
    JAPAN("jp", "Nhật Bản", "🇯🇵"),
    KOREA("kr", "Hàn Quốc", "🇰🇷"),
    FRANCE("fr", "Pháp", "🇫🇷"),
}

enum class MusicCategory(val id: String, val title: String, val emoji: String, val isKidsFamily: Boolean = false) {
    ALL("all", "Tất cả", "🌟"),
    KIDS_FAMILY("kids", "Thiếu nhi & Cho Cháu", "👶", isKidsFamily = true),
    VPOP("vpop", "V-Pop & Trữ tình", "🇻🇳"),
    POP_GLOBAL("pop", "Pop & US-UK", "🌍"),
    KPOP_JPOP("asian", "K-Pop & J-Pop", "🌸"),
    CHILL_ACOUSTIC("chill", "Thư giãn & Acoustic", "☕"),
    EDM_DANCE("dance", "Sôi động & EDM", "⚡"),
}

data class ExternalTrack(
    val id: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val thumbnailUrl: String = "",
    val durationSeconds: Int? = null,
    val provider: MusicSourceProvider,
    val previewUrl: String? = null,
    val externalUrl: String? = null,
    val isExplicit: Boolean = false,
    val resolvedVideoId: String? = null,
    val countryCode: String = "vn",
    val categoryId: String = "all",
) {
    val uniqueId: String
        get() {
            val prefix = when (provider) {
                MusicSourceProvider.SPOTIFY -> "sp_"
                MusicSourceProvider.APPLE_MUSIC -> "am_"
                MusicSourceProvider.YOUTUBE -> "yt_"
                else -> "ext_"
            }
            val cleanId = id.replace(Regex("[^a-zA-Z0-9_]"), "")
            return if (cleanId.startsWith("sp_") || cleanId.startsWith("am_") || cleanId.startsWith("yt_")) {
                cleanId
            } else {
                "$prefix$cleanId"
            }
        }

    fun toSongItem(resolvedId: String? = null): SongItem {
        val targetId = resolvedId ?: resolvedVideoId ?: uniqueId
        return SongItem(
            id = targetId,
            title = title,
            artists = listOf(Artist(name = artist, id = null)),
            album = if (album.isNotBlank()) Album(name = album, id = "") else null,
            duration = durationSeconds,
            thumbnail = thumbnailUrl,
            explicit = isExplicit
        )
    }
}

data class ExternalPlaylist(
    val id: String,
    val title: String,
    val description: String = "",
    val thumbnailUrl: String = "",
    val trackCount: Int? = null,
    val provider: MusicSourceProvider,
    val externalUrl: String? = null,
)

data class ExternalArtist(
    val id: String,
    val name: String,
    val thumbnailUrl: String = "",
    val followers: String? = null,
    val genres: List<String> = emptyList(),
    val provider: MusicSourceProvider,
    val externalUrl: String? = null,
)

data class UserComment(
    val id: String,
    val authorName: String,
    val authorAvatarUrl: String = "",
    val content: String,
    val publishedTime: String = "",
    val likeCount: String = "",
)

@Singleton
class ExternalMusicProviderService @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonParser = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    private var spotifyAccessToken: String? = null
    private var tokenExpiryTimeMs: Long = 0L

    /**
     * Obtains an anonymous Spotify client access token from the official web player endpoint.
     */
    private suspend fun getSpotifyToken(): String? = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (spotifyAccessToken != null && now < tokenExpiryTimeMs - 60000) {
            return@withContext spotifyAccessToken
        }

        try {
            val request = Request.Builder()
                .url("https://open.spotify.com/get_access_token?reason=transport&productType=web_player")
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36")
                .header("Referer", "https://open.spotify.com/")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: return@withContext null
                    val json = jsonParser.parseToJsonElement(body).jsonObject
                    val token = json["accessToken"]?.jsonPrimitive?.content
                    val expiry = json["accessTokenExpirationTimestampMs"]?.jsonPrimitive?.content?.toLongOrNull()
                        ?: (now + 3600000L)

                    if (!token.isNullOrBlank()) {
                        spotifyAccessToken = token
                        tokenExpiryTimeMs = expiry
                        return@withContext token
                    }
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "Could not fetch anonymous Spotify access token")
        }
        return@withContext null
    }

    /**
     * Search songs from Spotify API.
     */
    suspend fun searchSpotify(query: String, limit: Int = 25): List<ExternalTrack> = withContext(Dispatchers.IO) {
        val results = mutableListOf<ExternalTrack>()
        val token = getSpotifyToken()

        if (token != null) {
            try {
                val encodedQuery = java.net.URLEncoder.encode(query, "UTF-8")
                val url = "https://api.spotify.com/v1/search?q=$encodedQuery&type=track&limit=$limit"
                val request = Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $token")
                    .header("User-Agent", "Mozilla/5.0")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        val root = jsonParser.parseToJsonElement(body).jsonObject
                        val tracks = root["tracks"]?.jsonObject?.get("items")?.jsonArray
                        tracks?.forEach { trackElem ->
                            val trackObj = trackElem.jsonObject
                            val id = trackObj["id"]?.jsonPrimitive?.content ?: ""
                            val title = trackObj["name"]?.jsonPrimitive?.content ?: ""
                            val durationMs = trackObj["duration_ms"]?.jsonPrimitive?.content?.toIntOrNull()
                            val isExplicit = trackObj["explicit"]?.jsonPrimitive?.content?.toBoolean() ?: false
                            val previewUrl = trackObj["preview_url"]?.jsonPrimitive?.content

                            val artistsArray = trackObj["artists"]?.jsonArray
                            val artistName = artistsArray?.firstOrNull()?.jsonObject?.get("name")?.jsonPrimitive?.content ?: "Unknown Artist"

                            val albumObj = trackObj["album"]?.jsonObject
                            val albumName = albumObj?.get("name")?.jsonPrimitive?.content ?: ""
                            val imagesArray = albumObj?.get("images")?.jsonArray
                            val thumbnailUrl = imagesArray?.firstOrNull()?.jsonObject?.get("url")?.jsonPrimitive?.content ?: ""

                            val externalUrl = trackObj["external_urls"]?.jsonObject?.get("spotify")?.jsonPrimitive?.content

                            if (title.isNotBlank()) {
                                results.add(
                                    ExternalTrack(
                                        id = id,
                                        title = title,
                                        artist = artistName,
                                        album = albumName,
                                        thumbnailUrl = thumbnailUrl,
                                        durationSeconds = durationMs?.let { it / 1000 },
                                        provider = MusicSourceProvider.SPOTIFY,
                                        previewUrl = previewUrl,
                                        externalUrl = externalUrl,
                                        isExplicit = isExplicit
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.e(e, "Spotify search failed")
            }
        }

        if (results.isEmpty()) {
            results.addAll(searchSpotifyFallback(query, limit))
        }

        return@withContext results
    }

    /**
     * Finds the matching Spotify track metadata for any song title and artist.
     */
    suspend fun findSpotifyTrack(title: String, artist: String): ExternalTrack? = withContext(Dispatchers.IO) {
        val cleanTitle = title.replace(Regex("\\(.*?\\)|\\[.*?\\]"), "").trim()
        val query = if (artist.isNotBlank() && !artist.equals("Unknown Artist", ignoreCase = true)) {
            "$cleanTitle $artist"
        } else {
            cleanTitle
        }
        val searchResults = searchSpotify(query, limit = 5)
        if (searchResults.isNotEmpty()) {
            // Find exact or best match
            return@withContext searchResults.firstOrNull {
                it.title.contains(cleanTitle, ignoreCase = true) || cleanTitle.contains(it.title, ignoreCase = true)
            } ?: searchResults.first()
        }
        return@withContext null
    }

    /**
     * Fetches a specific Spotify track by Spotify ID directly from the Spotify Web API.
     */
    suspend fun getSpotifyTrack(spotifyTrackId: String): ExternalTrack? = withContext(Dispatchers.IO) {
        val cleanId = spotifyTrackId.removePrefix("sp_").removePrefix("spotify:track:")
        val token = getSpotifyToken() ?: return@withContext null
        try {
            val url = "https://api.spotify.com/v1/tracks/$cleanId"
            val request = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $token")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: return@withContext null
                    val trackObj = jsonParser.parseToJsonElement(body).jsonObject
                    val id = trackObj["id"]?.jsonPrimitive?.content ?: cleanId
                    val title = trackObj["name"]?.jsonPrimitive?.content ?: ""
                    val durationMs = trackObj["duration_ms"]?.jsonPrimitive?.content?.toIntOrNull()
                    val isExplicit = trackObj["explicit"]?.jsonPrimitive?.content?.toBoolean() ?: false
                    val previewUrl = trackObj["preview_url"]?.jsonPrimitive?.content

                    val artistsArray = trackObj["artists"]?.jsonArray
                    val artistName = artistsArray?.firstOrNull()?.jsonObject?.get("name")?.jsonPrimitive?.content ?: "Unknown Artist"

                    val albumObj = trackObj["album"]?.jsonObject
                    val albumName = albumObj?.get("name")?.jsonPrimitive?.content ?: ""
                    val imagesArray = albumObj?.get("images")?.jsonArray
                    val thumbnailUrl = imagesArray?.firstOrNull()?.jsonObject?.get("url")?.jsonPrimitive?.content ?: ""

                    val externalUrl = trackObj["external_urls"]?.jsonObject?.get("spotify")?.jsonPrimitive?.content

                    return@withContext ExternalTrack(
                        id = id,
                        title = title,
                        artist = artistName,
                        album = albumName,
                        thumbnailUrl = thumbnailUrl,
                        durationSeconds = durationMs?.let { it / 1000 },
                        provider = MusicSourceProvider.SPOTIFY,
                        previewUrl = previewUrl,
                        externalUrl = externalUrl,
                        isExplicit = isExplicit
                    )
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "Could not fetch Spotify track $cleanId")
        }
        return@withContext null
    }

    /**
     * Fallback search for Spotify if token endpoint is throttled.
     */
    private suspend fun searchSpotifyFallback(query: String, limit: Int): List<ExternalTrack> = withContext(Dispatchers.IO) {
        val list = mutableListOf<ExternalTrack>()
        try {
            val encodedQuery = java.net.URLEncoder.encode(query, "UTF-8")
            val url = "https://itunes.apple.com/search?term=$encodedQuery&entity=song&limit=$limit"
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val root = jsonParser.parseToJsonElement(body).jsonObject
                    val results = root["results"]?.jsonArray
                    results?.forEach { item ->
                        val obj = item.jsonObject
                        val trackId = obj["trackId"]?.jsonPrimitive?.content ?: obj["collectionId"]?.jsonPrimitive?.content ?: ""
                        val title = obj["trackName"]?.jsonPrimitive?.content ?: ""
                        val artist = obj["artistName"]?.jsonPrimitive?.content ?: ""
                        val album = obj["collectionName"]?.jsonPrimitive?.content ?: ""
                        val art = (obj["artworkUrl100"]?.jsonPrimitive?.content ?: "").replace("100x100bb.jpg", "600x600bb.jpg")
                        val durationMs = obj["trackTimeMillis"]?.jsonPrimitive?.content?.toIntOrNull()
                        val preview = obj["previewUrl"]?.jsonPrimitive?.content

                        if (title.isNotBlank()) {
                            list.add(
                                ExternalTrack(
                                    id = trackId,
                                    title = title,
                                    artist = artist,
                                    album = album,
                                    thumbnailUrl = art,
                                    durationSeconds = durationMs?.let { it / 1000 },
                                    provider = MusicSourceProvider.SPOTIFY,
                                    previewUrl = preview,
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "Spotify fallback search failed")
        }
        return@withContext list
    }

    /**
     * Search songs from Apple Music / iTunes API.
     */
    suspend fun searchAppleMusic(query: String, limit: Int = 25): List<ExternalTrack> = withContext(Dispatchers.IO) {
        val list = mutableListOf<ExternalTrack>()
        try {
            val encodedQuery = java.net.URLEncoder.encode(query, "UTF-8")
            val url = "https://itunes.apple.com/search?term=$encodedQuery&entity=song&limit=$limit"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val root = jsonParser.parseToJsonElement(body).jsonObject
                    val results = root["results"]?.jsonArray
                    results?.forEach { item ->
                        val obj = item.jsonObject
                        val trackId = obj["trackId"]?.jsonPrimitive?.content ?: ""
                        val title = obj["trackName"]?.jsonPrimitive?.content ?: ""
                        val artist = obj["artistName"]?.jsonPrimitive?.content ?: ""
                        val album = obj["collectionName"]?.jsonPrimitive?.content ?: ""
                        val art = (obj["artworkUrl100"]?.jsonPrimitive?.content ?: "").replace("100x100bb.jpg", "600x600bb.jpg")
                        val durationMs = obj["trackTimeMillis"]?.jsonPrimitive?.content?.toIntOrNull()
                        val previewUrl = obj["previewUrl"]?.jsonPrimitive?.content
                        val trackViewUrl = obj["trackViewUrl"]?.jsonPrimitive?.content
                        val isExplicit = obj["trackExplicitness"]?.jsonPrimitive?.content == "explicit"

                        if (title.isNotBlank()) {
                            list.add(
                                ExternalTrack(
                                    id = trackId,
                                    title = title,
                                    artist = artist,
                                    album = album,
                                    thumbnailUrl = art,
                                    durationSeconds = durationMs?.let { it / 1000 },
                                    provider = MusicSourceProvider.APPLE_MUSIC,
                                    previewUrl = previewUrl,
                                    externalUrl = trackViewUrl,
                                    isExplicit = isExplicit
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Apple Music search failed")
        }
        return@withContext list
    }

    /**
     * Search Artists from Spotify and Apple Music API.
     */
    suspend fun searchArtists(query: String, provider: MusicSourceProvider = MusicSourceProvider.ALL): List<ExternalArtist> = withContext(Dispatchers.IO) {
        val artists = mutableListOf<ExternalArtist>()

        // 1. Search Spotify Artists
        if (provider == MusicSourceProvider.ALL || provider == MusicSourceProvider.SPOTIFY) {
            val token = getSpotifyToken()
            if (token != null) {
                try {
                    val encoded = java.net.URLEncoder.encode(query, "UTF-8")
                    val url = "https://api.spotify.com/v1/search?q=$encoded&type=artist&limit=15"
                    val request = Request.Builder()
                        .url(url)
                        .header("Authorization", "Bearer $token")
                        .build()

                    client.newCall(request).execute().use { response ->
                        if (response.isSuccessful) {
                            val body = response.body?.string() ?: ""
                            val root = jsonParser.parseToJsonElement(body).jsonObject
                            val items = root["artists"]?.jsonObject?.get("items")?.jsonArray
                            items?.forEach { item ->
                                val obj = item.jsonObject
                                val id = obj["id"]?.jsonPrimitive?.content ?: ""
                                val name = obj["name"]?.jsonPrimitive?.content ?: ""
                                val images = obj["images"]?.jsonArray
                                val img = images?.firstOrNull()?.jsonObject?.get("url")?.jsonPrimitive?.content ?: ""
                                val followersCount = obj["followers"]?.jsonObject?.get("total")?.jsonPrimitive?.content
                                val genres = obj["genres"]?.jsonArray?.mapNotNull { it.jsonPrimitive.content } ?: emptyList()
                                val extUrl = obj["external_urls"]?.jsonObject?.get("spotify")?.jsonPrimitive?.content

                                if (name.isNotBlank()) {
                                    artists.add(
                                        ExternalArtist(
                                            id = id,
                                            name = name,
                                            thumbnailUrl = img,
                                            followers = followersCount?.let { "$it người theo dõi" },
                                            genres = genres,
                                            provider = MusicSourceProvider.SPOTIFY,
                                            externalUrl = extUrl
                                        )
                                    )
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Timber.w(e, "Spotify artist search error")
                }
            }
        }

        // 2. Search Apple Music / iTunes Artists
        if (provider == MusicSourceProvider.ALL || provider == MusicSourceProvider.APPLE_MUSIC) {
            try {
                val encoded = java.net.URLEncoder.encode(query, "UTF-8")
                val url = "https://itunes.apple.com/search?term=$encoded&entity=musicArtist&limit=15"
                val request = Request.Builder().url(url).build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        val root = jsonParser.parseToJsonElement(body).jsonObject
                        val results = root["results"]?.jsonArray
                        results?.forEach { item ->
                            val obj = item.jsonObject
                            val id = obj["artistId"]?.jsonPrimitive?.content ?: ""
                            val name = obj["artistName"]?.jsonPrimitive?.content ?: ""
                            val genre = obj["primaryGenreName"]?.jsonPrimitive?.content ?: ""
                            val artistLinkUrl = obj["artistLinkUrl"]?.jsonPrimitive?.content

                            if (name.isNotBlank()) {
                                artists.add(
                                    ExternalArtist(
                                        id = id,
                                        name = name,
                                        genres = if (genre.isNotBlank()) listOf(genre) else emptyList(),
                                        provider = MusicSourceProvider.APPLE_MUSIC,
                                        externalUrl = artistLinkUrl
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Apple Music artist search error")
            }
        }

        return@withContext artists.distinctBy { it.name.lowercase() }
    }

    /**
     * Search Playlists from Spotify and Apple Music API.
     */
    suspend fun searchPlaylists(query: String, provider: MusicSourceProvider = MusicSourceProvider.ALL): List<ExternalPlaylist> = withContext(Dispatchers.IO) {
        val playlists = mutableListOf<ExternalPlaylist>()
        val token = getSpotifyToken()

        if (token != null && (provider == MusicSourceProvider.ALL || provider == MusicSourceProvider.SPOTIFY)) {
            try {
                val encoded = java.net.URLEncoder.encode(query, "UTF-8")
                val url = "https://api.spotify.com/v1/search?q=$encoded&type=playlist&limit=15"
                val request = Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $token")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        val root = jsonParser.parseToJsonElement(body).jsonObject
                        val items = root["playlists"]?.jsonObject?.get("items")?.jsonArray
                        items?.forEach { item ->
                            val obj = item.jsonObject
                            val id = obj["id"]?.jsonPrimitive?.content ?: ""
                            val name = obj["name"]?.jsonPrimitive?.content ?: ""
                            val desc = obj["description"]?.jsonPrimitive?.content ?: ""
                            val images = obj["images"]?.jsonArray
                            val img = images?.firstOrNull()?.jsonObject?.get("url")?.jsonPrimitive?.content ?: ""
                            val trackTotal = obj["tracks"]?.jsonObject?.get("total")?.jsonPrimitive?.content?.toIntOrNull()
                            val extUrl = obj["external_urls"]?.jsonObject?.get("spotify")?.jsonPrimitive?.content

                            if (name.isNotBlank()) {
                                playlists.add(
                                    ExternalPlaylist(
                                        id = id,
                                        title = name,
                                        description = desc,
                                        thumbnailUrl = img,
                                        trackCount = trackTotal,
                                        provider = MusicSourceProvider.SPOTIFY,
                                        externalUrl = extUrl
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Spotify playlist search error")
            }
        }

        return@withContext playlists
    }

    private val resolvedIdCache = java.util.concurrent.ConcurrentHashMap<String, String>()

    private fun getCountrySpotifyPlaylists(country: MusicCountry): List<String> {
        return when (country) {
            MusicCountry.VIETNAM -> listOf("37i9dQZF1DX0F6hwDRnVR4", "37i9dQZEVXbLdGJwSPiV12", "37i9dQZF1DWTwnEm1IYyoj")
            MusicCountry.US -> listOf("37i9dQZF1DXcBWIGoYBM5M", "37i9dQZEVXbLRQDuF5jeBp", "37i9dQZF1DX0XUsuxWHRQd")
            MusicCountry.UK -> listOf("37i9dQZF1DX13ZzXoot6J0", "37i9dQZEVXbLnolsZ8PSNw", "37i9dQZF1DX4JAvHpjipBk")
            MusicCountry.JAPAN -> listOf("37i9dQZF1DXdbXrPNafg9d", "37i9dQZEVXbKXQ4mDTEBXq", "37i9dQZF1DXafb0fqAkHQ1")
            MusicCountry.KOREA -> listOf("37i9dQZF1DX9tPFwDMOaN1", "37i9dQZEVXbNxXF4SkOJ9F", "37i9dQZF1DX4GfiT6pPz9m")
            MusicCountry.FRANCE -> listOf("37i9dQZF1DX1X23ooDVLTh", "37i9dQZEVXbIPWwFssbupI", "37i9dQZF1DX6Xceaa3o0p1")
        }
    }

    private fun getCategorySpotifySearchQuery(country: MusicCountry, category: MusicCategory): String {
        return when (category) {
            MusicCategory.ALL -> when (country) {
                MusicCountry.VIETNAM -> "tag:new vietnam hot hits"
                MusicCountry.US -> "top hits 2026 billboard"
                MusicCountry.UK -> "uk hot hits top charts"
                MusicCountry.JAPAN -> "j-pop top 50 tokyo"
                MusicCountry.KOREA -> "k-pop hot 50 seoul"
                MusicCountry.FRANCE -> "top 50 france hits"
            }
            MusicCategory.KIDS_FAMILY -> when (country) {
                MusicCountry.VIETNAM -> "nhạc thiếu nhi cho bé vui nhộn mầm non"
                else -> "kids songs family friendly lullaby disney children"
            }
            MusicCategory.VPOP -> "v-pop hot hits nhạc trẻ ballad việt nam"
            MusicCategory.POP_GLOBAL -> "top pop hits 2026 global billboard"
            MusicCategory.KPOP_JPOP -> "k-pop top hits j-pop anime songs"
            MusicCategory.CHILL_ACOUSTIC -> "chill lofi acoustic relaxing peaceful"
            MusicCategory.EDM_DANCE -> "edm dance remix festival electro party"
        }
    }

    private fun getCategoryAppleSearchQuery(country: MusicCountry, category: MusicCategory): String {
        return when (category) {
            MusicCategory.ALL -> when (country) {
                MusicCountry.VIETNAM -> "vietnam top hits"
                MusicCountry.US -> "top hits billboard"
                MusicCountry.UK -> "uk top 40"
                MusicCountry.JAPAN -> "j-pop top hits"
                MusicCountry.KOREA -> "k-pop top hits"
                MusicCountry.FRANCE -> "france top hits"
            }
            MusicCategory.KIDS_FAMILY -> when (country) {
                MusicCountry.VIETNAM -> "nhạc thiếu nhi bé yêu"
                else -> "kids songs disney nursery rhymes"
            }
            MusicCategory.VPOP -> "vpop nhac tre"
            MusicCategory.POP_GLOBAL -> "top pop billboard"
            MusicCategory.KPOP_JPOP -> "kpop jpop hits"
            MusicCategory.CHILL_ACOUSTIC -> "chill acoustic lofi"
            MusicCategory.EDM_DANCE -> "edm dance remix"
        }
    }

    /**
     * Fetches Spotify Recommendations based on selected Country & Category.
     */
    suspend fun getSpotifyRecommendations(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
    ): List<ExternalTrack> = withContext(Dispatchers.IO) {
        val tracks = mutableListOf<ExternalTrack>()
        val token = getSpotifyToken()

        if (token != null) {
            if (category == MusicCategory.ALL) {
                val playlistIds = getCountrySpotifyPlaylists(country)
                for (playlistId in playlistIds) {
                    try {
                        val url = "https://api.spotify.com/v1/playlists/$playlistId/tracks?limit=20"
                        val request = Request.Builder()
                            .url(url)
                            .header("Authorization", "Bearer $token")
                            .build()

                        client.newCall(request).execute().use { response ->
                            if (response.isSuccessful) {
                                val body = response.body?.string() ?: ""
                                val root = jsonParser.parseToJsonElement(body).jsonObject
                                val items = root["items"]?.jsonArray
                                items?.forEach { item ->
                                    val trackObj = item.jsonObject["track"]?.jsonObject ?: item.jsonObject
                                    val rawId = trackObj["id"]?.jsonPrimitive?.content ?: ""
                                    val id = "sp_$rawId"
                                    val title = trackObj["name"]?.jsonPrimitive?.content ?: ""
                                    val durationMs = trackObj["duration_ms"]?.jsonPrimitive?.content?.toIntOrNull()
                                    val isExplicit = trackObj["explicit"]?.jsonPrimitive?.content?.toBoolean() ?: false
                                    val previewUrl = trackObj["preview_url"]?.jsonPrimitive?.content
                                    val extUrl = trackObj["external_urls"]?.jsonObject?.get("spotify")?.jsonPrimitive?.content

                                    val artistsArray = trackObj["artists"]?.jsonArray
                                    val artistName = artistsArray?.firstOrNull()?.jsonObject?.get("name")?.jsonPrimitive?.content ?: "Unknown Artist"

                                    val albumObj = trackObj["album"]?.jsonObject
                                    val albumName = albumObj?.get("name")?.jsonPrimitive?.content ?: ""
                                    val imagesArray = albumObj?.get("images")?.jsonArray
                                    val thumbnailUrl = imagesArray?.firstOrNull()?.jsonObject?.get("url")?.jsonPrimitive?.content ?: ""

                                    if (title.isNotBlank()) {
                                        tracks.add(
                                            ExternalTrack(
                                                id = id,
                                                title = title,
                                                artist = artistName,
                                                album = albumName,
                                                thumbnailUrl = thumbnailUrl,
                                                durationSeconds = durationMs?.let { it / 1000 },
                                                provider = MusicSourceProvider.SPOTIFY,
                                                previewUrl = previewUrl,
                                                externalUrl = extUrl,
                                                isExplicit = isExplicit,
                                                countryCode = country.code,
                                                categoryId = category.id,
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Timber.w(e, "Failed fetching Spotify playlist $playlistId for ${country.code}")
                    }
                }
            }

            // Category-specific search or Fallback
            if (tracks.isEmpty() || category != MusicCategory.ALL) {
                try {
                    val query = java.net.URLEncoder.encode(getCategorySpotifySearchQuery(country, category), "UTF-8")
                    val searchUrl = "https://api.spotify.com/v1/search?q=$query&type=track&limit=30"
                    val searchReq = Request.Builder()
                        .url(searchUrl)
                        .header("Authorization", "Bearer $token")
                        .build()

                    client.newCall(searchReq).execute().use { response ->
                        if (response.isSuccessful) {
                            val body = response.body?.string() ?: ""
                            val root = jsonParser.parseToJsonElement(body).jsonObject
                            val items = root["tracks"]?.jsonObject?.get("items")?.jsonArray
                            items?.forEach { item ->
                                val trackObj = item.jsonObject
                                val rawId = trackObj["id"]?.jsonPrimitive?.content ?: ""
                                val id = "sp_$rawId"
                                val title = trackObj["name"]?.jsonPrimitive?.content ?: ""
                                val durationMs = trackObj["duration_ms"]?.jsonPrimitive?.content?.toIntOrNull()
                                val isExplicit = trackObj["explicit"]?.jsonPrimitive?.content?.toBoolean() ?: false
                                val previewUrl = trackObj["preview_url"]?.jsonPrimitive?.content
                                val extUrl = trackObj["external_urls"]?.jsonObject?.get("spotify")?.jsonPrimitive?.content

                                val artistsArray = trackObj["artists"]?.jsonArray
                                val artistName = artistsArray?.firstOrNull()?.jsonObject?.get("name")?.jsonPrimitive?.content ?: "Unknown Artist"

                                val albumObj = trackObj["album"]?.jsonObject
                                val albumName = albumObj?.get("name")?.jsonPrimitive?.content ?: ""
                                val imagesArray = albumObj?.get("images")?.jsonArray
                                val thumbnailUrl = imagesArray?.firstOrNull()?.jsonObject?.get("url")?.jsonPrimitive?.content ?: ""

                                if (title.isNotBlank() && (!category.isKidsFamily || !isExplicit)) {
                                    tracks.add(
                                        ExternalTrack(
                                            id = id,
                                            title = title,
                                            artist = artistName,
                                            album = albumName,
                                            thumbnailUrl = thumbnailUrl,
                                            durationSeconds = durationMs?.let { it / 1000 },
                                            provider = MusicSourceProvider.SPOTIFY,
                                            previewUrl = previewUrl,
                                            externalUrl = extUrl,
                                            isExplicit = isExplicit,
                                            countryCode = country.code,
                                            categoryId = category.id,
                                        )
                                    )
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Timber.w(e, "Spotify category track search failed for ${category.id}")
                }
            }
        }

        return@withContext tracks.distinctBy { "${it.title.lowercase()}_${it.artist.lowercase()}" }
    }

    /**
     * Fetches Apple Music Top Hits & Charts based on selected Country & Category.
     */
    suspend fun getAppleMusicCharts(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
    ): List<ExternalTrack> = withContext(Dispatchers.IO) {
        val tracks = mutableListOf<ExternalTrack>()

        if (category == MusicCategory.ALL) {
            try {
                val url = "https://rss.applemarketingtools.com/api/v2/${country.code}/music/most-played/30/songs.json"
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "Mozilla/5.0")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        val root = jsonParser.parseToJsonElement(body).jsonObject
                        val results = root["feed"]?.jsonObject?.get("results")?.jsonArray
                        results?.forEach { item ->
                            val obj = item.jsonObject
                            val rawId = obj["id"]?.jsonPrimitive?.content ?: ""
                            val id = "am_$rawId"
                            val title = obj["name"]?.jsonPrimitive?.content ?: ""
                            val artist = obj["artistName"]?.jsonPrimitive?.content ?: ""
                            val art = (obj["artworkUrl100"]?.jsonPrimitive?.content ?: "").replace("100x100bb.jpg", "600x600bb.jpg")
                            val externalUrl = obj["url"]?.jsonPrimitive?.content

                            if (title.isNotBlank()) {
                                tracks.add(
                                    ExternalTrack(
                                        id = id,
                                        title = title,
                                        artist = artist,
                                        thumbnailUrl = art,
                                        provider = MusicSourceProvider.APPLE_MUSIC,
                                        externalUrl = externalUrl,
                                        countryCode = country.code,
                                        categoryId = category.id,
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Apple Music RSS fetch failed for ${country.code}")
            }
        }

        // Live iTunes search for Category or fallback
        if (tracks.isEmpty() || category != MusicCategory.ALL) {
            try {
                val searchTerm = java.net.URLEncoder.encode(getCategoryAppleSearchQuery(country, category), "UTF-8")
                val url = "https://itunes.apple.com/search?term=$searchTerm&country=${country.code}&entity=song&limit=30"
                val request = Request.Builder().url(url).build()
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        val root = jsonParser.parseToJsonElement(body).jsonObject
                        val results = root["results"]?.jsonArray
                        results?.forEach { item ->
                            val obj = item.jsonObject
                            val rawId = obj["trackId"]?.jsonPrimitive?.content ?: ""
                            val id = "am_$rawId"
                            val title = obj["trackName"]?.jsonPrimitive?.content ?: ""
                            val artist = obj["artistName"]?.jsonPrimitive?.content ?: ""
                            val album = obj["collectionName"]?.jsonPrimitive?.content ?: ""
                            val art = (obj["artworkUrl100"]?.jsonPrimitive?.content ?: "").replace("100x100bb.jpg", "600x600bb.jpg")
                            val preview = obj["previewUrl"]?.jsonPrimitive?.content
                            val extUrl = obj["trackViewUrl"]?.jsonPrimitive?.content
                            val trackExplicitness = obj["trackExplicitness"]?.jsonPrimitive?.content
                            val isExplicit = trackExplicitness?.equals("explicit", ignoreCase = true) ?: false

                            if (title.isNotBlank() && (!category.isKidsFamily || !isExplicit)) {
                                tracks.add(
                                    ExternalTrack(
                                        id = id,
                                        title = title,
                                        artist = artist,
                                        album = album,
                                        thumbnailUrl = art,
                                        previewUrl = preview,
                                        provider = MusicSourceProvider.APPLE_MUSIC,
                                        externalUrl = extUrl,
                                        isExplicit = isExplicit,
                                        countryCode = country.code,
                                        categoryId = category.id,
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Live iTunes search failed for ${country.code} ${category.id}")
            }
        }

        return@withContext tracks.distinctBy { "${it.title.lowercase()}_${it.artist.lowercase()}" }
    }

    /**
     * Fetches Spotify Featured Playlists based on selected Country & Category.
     */
    suspend fun getSpotifyFeaturedPlaylists(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
    ): List<ExternalPlaylist> = withContext(Dispatchers.IO) {
        val playlists = mutableListOf<ExternalPlaylist>()
        val token = getSpotifyToken()

        if (token != null) {
            try {
                val queryTerm = if (category == MusicCategory.ALL) {
                    "${country.displayName} hits playlist"
                } else {
                    "${getCategorySpotifySearchQuery(country, category)} playlist"
                }
                val query = java.net.URLEncoder.encode(queryTerm, "UTF-8")
                val searchUrl = "https://api.spotify.com/v1/search?q=$query&type=playlist&limit=15"
                val req = Request.Builder().url(searchUrl).header("Authorization", "Bearer $token").build()
                client.newCall(req).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        val root = jsonParser.parseToJsonElement(body).jsonObject
                        val items = root["playlists"]?.jsonObject?.get("items")?.jsonArray
                        items?.forEach { item ->
                            val obj = item.jsonObject
                            val rawId = obj["id"]?.jsonPrimitive?.content ?: ""
                            val id = "sp_pl_$rawId"
                            val name = obj["name"]?.jsonPrimitive?.content ?: ""
                            val desc = obj["description"]?.jsonPrimitive?.content ?: ""
                            val images = obj["images"]?.jsonArray
                            val img = images?.firstOrNull()?.jsonObject?.get("url")?.jsonPrimitive?.content ?: ""
                            val count = obj["tracks"]?.jsonObject?.get("total")?.jsonPrimitive?.content?.toIntOrNull()
                            val extUrl = obj["external_urls"]?.jsonObject?.get("spotify")?.jsonPrimitive?.content
                            if (name.isNotBlank()) {
                                playlists.add(
                                    ExternalPlaylist(
                                        id = id,
                                        title = name,
                                        description = desc,
                                        thumbnailUrl = img,
                                        trackCount = count,
                                        provider = MusicSourceProvider.SPOTIFY,
                                        externalUrl = extUrl
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Spotify playlist search error")
            }
        }

        return@withContext playlists.distinctBy { it.title.lowercase() }
    }

    /**
     * Fetches Apple Music Top Playlists based on selected Country & Category.
     */
    suspend fun getAppleMusicPlaylists(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
    ): List<ExternalPlaylist> = withContext(Dispatchers.IO) {
        val playlists = mutableListOf<ExternalPlaylist>()
        try {
            val url = "https://rss.applemarketingtools.com/api/v2/${country.code}/music/most-played/15/playlists.json"
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val root = jsonParser.parseToJsonElement(body).jsonObject
                    val results = root["feed"]?.jsonObject?.get("results")?.jsonArray
                    results?.forEach { item ->
                        val obj = item.jsonObject
                        val rawId = obj["id"]?.jsonPrimitive?.content ?: ""
                        val id = "am_pl_$rawId"
                        val name = obj["name"]?.jsonPrimitive?.content ?: ""
                        val artist = obj["artistName"]?.jsonPrimitive?.content ?: "Apple Music"
                        val art = (obj["artworkUrl100"]?.jsonPrimitive?.content ?: "").replace("100x100bb.jpg", "600x600bb.jpg")
                        val externalUrl = obj["url"]?.jsonPrimitive?.content

                        if (name.isNotBlank()) {
                            playlists.add(
                                ExternalPlaylist(
                                    id = id,
                                    title = name,
                                    description = artist,
                                    thumbnailUrl = art,
                                    provider = MusicSourceProvider.APPLE_MUSIC,
                                    externalUrl = externalUrl
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "Apple Music playlists error for ${country.code}")
        }

        return@withContext playlists.distinctBy { it.title.lowercase() }
    }

    /**
     * Fetches Top Artists on Spotify based on selected Country & Category.
     */
    suspend fun getTopSpotifyArtists(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
    ): List<ExternalArtist> = withContext(Dispatchers.IO) {
        val artists = mutableListOf<ExternalArtist>()
        val token = getSpotifyToken()

        if (token != null) {
            try {
                val genreQuery = when (category) {
                    MusicCategory.ALL -> when (country) {
                        MusicCountry.VIETNAM -> "genre:vietnamese"
                        MusicCountry.US -> "genre:pop"
                        MusicCountry.UK -> "genre:british"
                        MusicCountry.JAPAN -> "genre:j-pop"
                        MusicCountry.KOREA -> "genre:k-pop"
                        MusicCountry.FRANCE -> "genre:french"
                    }
                    MusicCategory.KIDS_FAMILY -> "children kids"
                    MusicCategory.VPOP -> "genre:vietnamese v-pop"
                    MusicCategory.POP_GLOBAL -> "genre:pop"
                    MusicCategory.KPOP_JPOP -> "genre:k-pop OR genre:j-pop"
                    MusicCategory.CHILL_ACOUSTIC -> "genre:acoustic OR genre:indie"
                    MusicCategory.EDM_DANCE -> "genre:edm OR genre:dance"
                }
                val query = java.net.URLEncoder.encode(genreQuery, "UTF-8")
                val url = "https://api.spotify.com/v1/search?q=$query&type=artist&limit=15"
                val request = Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $token")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        val root = jsonParser.parseToJsonElement(body).jsonObject
                        val items = root["artists"]?.jsonObject?.get("items")?.jsonArray
                        items?.forEach { item ->
                            val obj = item.jsonObject
                            val rawId = obj["id"]?.jsonPrimitive?.content ?: ""
                            val id = "sp_art_$rawId"
                            val name = obj["name"]?.jsonPrimitive?.content ?: ""
                            val images = obj["images"]?.jsonArray
                            val img = images?.firstOrNull()?.jsonObject?.get("url")?.jsonPrimitive?.content ?: ""
                            val followers = obj["followers"]?.jsonObject?.get("total")?.jsonPrimitive?.content
                            val extUrl = obj["external_urls"]?.jsonObject?.get("spotify")?.jsonPrimitive?.content

                            if (name.isNotBlank()) {
                                artists.add(
                                    ExternalArtist(
                                        id = id,
                                        name = name,
                                        thumbnailUrl = img,
                                        followers = followers?.let { "$it followers" },
                                        provider = MusicSourceProvider.SPOTIFY,
                                        externalUrl = extUrl
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Top Spotify artists error")
            }
        }

        return@withContext artists.distinctBy { it.name.lowercase() }
    }

    /**
     * Resolves an external track to a playable YouTube videoId with concurrent thread-safe cache.
     */
    suspend fun resolveToPlayableVideoId(title: String, artist: String): String? = withContext(Dispatchers.IO) {
        val cacheKey = "${title.trim().lowercase()}###${artist.trim().lowercase()}"
        resolvedIdCache[cacheKey]?.let { return@withContext it }

        try {
            val query = "$title $artist"
            val result = YouTube.search(query, YouTube.SearchFilter.FILTER_SONG).getOrNull()
            val song = result?.items?.filterIsInstance<SongItem>()?.firstOrNull()
            if (song != null) {
                resolvedIdCache[cacheKey] = song.id
                return@withContext song.id
            }

            // Secondary fallback search using summary
            val fallbackResult = YouTube.searchSummary(query).getOrNull()
            val fallbackSong = fallbackResult?.summaries?.flatMap { it.items }?.filterIsInstance<SongItem>()?.firstOrNull()
            if (fallbackSong != null) {
                resolvedIdCache[cacheKey] = fallbackSong.id
                return@withContext fallbackSong.id
            }
            return@withContext null
        } catch (e: Exception) {
            Timber.e(e, "Error resolving track: $title - $artist")
            return@withContext null
        }
    }

    /**
     * Fetches real user comments for a song/video in real time using the YouTube Innertube API.
     */
    suspend fun fetchCommentsForVideo(videoId: String): List<UserComment> = withContext(Dispatchers.IO) {
        val comments = mutableListOf<UserComment>()
        try {
            val requestBody = buildJsonObject {
                putJsonObject("context") {
                    putJsonObject("client") {
                        put("clientName", "WEB")
                        put("clientVersion", "2.20240101.00.00")
                        put("hl", "vi")
                        put("gl", "VN")
                    }
                }
                put("videoId", videoId)
            }.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/next")
                .post(requestBody)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val root = jsonParser.parseToJsonElement(body).jsonObject
                    
                    // Search recursively in JSON for commentRenderer
                    fun extractComments(element: kotlinx.serialization.json.JsonElement) {
                        when (element) {
                            is JsonObject -> {
                                if (element.containsKey("commentRenderer")) {
                                    val renderer = element["commentRenderer"]?.jsonObject
                                    if (renderer != null) {
                                        val id = renderer["commentId"]?.jsonPrimitive?.content ?: ""
                                        val authorText = renderer["authorText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                                            ?: renderer["authorText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content ?: "User"
                                        val contentText = renderer["contentText"]?.jsonObject?.get("runs")?.jsonArray?.joinToString("") {
                                             it.jsonObject["text"]?.jsonPrimitive?.content ?: ""
                                        } ?: ""
                                        val timeText = renderer["publishedTimeText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content ?: ""
                                        val voteCount = renderer["voteCount"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content ?: ""
                                        val avatar = renderer["authorThumbnail"]?.jsonObject?.get("thumbnails")?.jsonArray?.lastOrNull()?.jsonObject?.get("url")?.jsonPrimitive?.content ?: ""

                                        if (contentText.isNotBlank()) {
                                            comments.add(
                                                UserComment(
                                                    id = id,
                                                    authorName = authorText,
                                                    authorAvatarUrl = avatar,
                                                    content = contentText,
                                                    publishedTime = timeText,
                                                    likeCount = voteCount
                                                )
                                            )
                                        }
                                    }
                                }
                                element.values.forEach { extractComments(it) }
                            }
                            is JsonArray -> {
                                element.forEach { extractComments(it) }
                            }
                            else -> {}
                        }
                    }
                    extractComments(root)
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to fetch comments for video $videoId")
        }

        return@withContext comments
    }
}
