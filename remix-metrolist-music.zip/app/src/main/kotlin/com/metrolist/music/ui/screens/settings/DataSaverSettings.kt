/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.datastore.preferences.core.booleanPreferencesKey
import android.content.pm.PackageManager.PERMISSION_GRANTED
import androidx.navigation.NavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.LocalPlayerConnection
import com.metrolist.music.R
import com.metrolist.music.constants.*
import com.metrolist.music.ui.component.DefaultDialog
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.rememberPreference
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DataSaverSettings(
    navController: NavController
) {
    val context = LocalContext.current
    val downloadCache = LocalPlayerConnection.current?.service?.downloadCache

    // 1. Data Saver Mode settings
    val (dataSaverBeta, onDataSaverBetaChange) = rememberPreference(DataSaverModeBetaKey, defaultValue = false)
    val (disableLyrics, onDisableLyricsChange) = rememberPreference(DataSaverDisableLyricsKey, defaultValue = false)
    val (disableVideos, onDisableVideosChange) = rememberPreference(DataSaverDisableVideosKey, defaultValue = false)
    val (disablePreloading, onDisablePreloadingChange) = rememberPreference(DataSaverDisablePreloadingKey, defaultValue = false)
    val (disableBackgroundSync, onDisableBackgroundSyncChange) = rememberPreference(DataSaverDisableBackgroundSyncKey, defaultValue = false)
    val (forceOpusAudio, onForceOpusAudioChange) = rememberPreference(DataSaverForceOpusKey, defaultValue = false)

    val (limitMobileData, onLimitMobileDataChange) = rememberPreference(LimitMobileDataUsageKey, defaultValue = false)
    val (onlyPlayHdOnWifi, onOnlyPlayHdOnWifiChange) = rememberPreference(OnlyPlayHdVideoOnWifiKey, defaultValue = false)
    val (onlyPlayOverWifi, onOnlyPlayOverWifiChange) = rememberPreference(OnlyPlayOverWifiKey, defaultValue = false)
    val (streamOverWifiUnmetered, onStreamOverWifiUnmeteredChange) = rememberPreference(StreamOverWifiAndUnmeteredOnlyKey, defaultValue = false)
    val (noPlayPodcastVideo, onNoPlayPodcastVideoChange) = rememberPreference(DoNotPlayPodcastVideosKey, defaultValue = false)
    val (convertPodcastToAudio, onConvertPodcastToAudioChange) = rememberPreference(ConvertVideoPodcastsToAudioOnlyKey, defaultValue = false)

    // 2. Download and Quality settings
    val (downloadOverWifi, onDownloadOverWifiChange) = rememberPreference(DownloadOverWifiOnlyKey, defaultValue = false)
    val (onlyDownloadAudio, onOnlyDownloadAudioChange) = rememberPreference(OnlyDownloadAudioIfPossibleKey, defaultValue = false)
    val (audioQuality, onAudioQualityChange) = rememberPreference(AudioQualityKey, defaultValue = AudioQuality.AUTO.name)
    val (downloadQuality, onDownloadQualityChange) = rememberPreference(DownloadQualityKey, defaultValue = "YTM_AAC")
    val (videoQuality, onVideoQualityChange) = rememberPreference(VideoQualityKey, defaultValue = "STANDARD")

    // 3. Storage and files
    val (showFilesOnDevice, onShowFilesOnDeviceChange) = rememberPreference(booleanPreferencesKey("showFilesOnDevice"), defaultValue = false)
    val (showAllAudioFiles, onShowAllAudioFilesChange) = rememberPreference(booleanPreferencesKey("showAllAudioFiles"), defaultValue = false)

    // 4. Voice & History
    val (voiceInterface, onVoiceInterfaceChange) = rememberPreference(booleanPreferencesKey("voiceInterfaceEnabled"), defaultValue = false)
    val (previousWatched, onPreviousWatchedChange) = rememberPreference(booleanPreferencesKey("previousWatchedEnabled"), defaultValue = true)

    // State for Dialogs
    var showPermissionDialog by rememberSaveable { mutableStateOf(false) }
    var showDeleteConfirmDialog by rememberSaveable { mutableStateOf(false) }
    var audioQualityExpanded by remember { mutableStateOf(false) }
    var downloadQualityExpanded by remember { mutableStateOf(false) }
    var videoQualityExpanded by remember { mutableStateOf(false) }

    // Check storage permission state
    val permissionsToRequest = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(android.Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    var isStoragePermissionGranted by remember {
        mutableStateOf(
            permissionsToRequest.all {
                ContextCompat.checkSelfPermission(context, it) == PERMISSION_GRANTED
            }
        )
    }

    val storagePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions.values.all { it }
        isStoragePermissionGranted = granted
        if (granted) {
            Toast.makeText(context, context.getString(R.string.storage_permission_granted_toast), Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, context.getString(R.string.storage_permission_denied_toast), Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.data_saver_mode)) },
                navigationIcon = {
                    IconButton(
                        onClick = { navController.backToMain() }
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.arrow_back),
                            contentDescription = null
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            Modifier
                .padding(innerPadding)
                .windowInsetsPadding(
                    LocalPlayerAwareWindowInsets.current.only(
                        WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom,
                    ),
                )
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
        ) {
            // Section 1: Data Saver Mode (Beta)
            Material3SettingsGroup(
                title = "Data Saver Mode (Beta)",
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.sliders),
                        title = { Text("Chế độ tiết kiệm dữ liệu (Beta)") },
                        description = { Text("Tự động kích hoạt toàn bộ tính năng tiết kiệm dữ liệu & pin") },
                        trailingContent = {
                            Switch(
                                checked = dataSaverBeta,
                                onCheckedChange = { active ->
                                    onDataSaverBetaChange(active)
                                    if (active) {
                                        onDisableLyricsChange(true)
                                        onDisableVideosChange(true)
                                        onDisablePreloadingChange(true)
                                        onDisableBackgroundSyncChange(true)
                                        onForceOpusAudioChange(true)
                                    }
                                },
                            )
                        },
                        onClick = {
                            val active = !dataSaverBeta
                            onDataSaverBetaChange(active)
                            if (active) {
                                onDisableLyricsChange(true)
                                onDisableVideosChange(true)
                                onDisablePreloadingChange(true)
                                onDisableBackgroundSyncChange(true)
                                onForceOpusAudioChange(true)
                            }
                        }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text("Tắt lời bài hát (Disable lyrics)") },
                        description = { Text("Không tải và hiển thị lời bài hát để tiết kiệm dung lượng") },
                        trailingContent = {
                            Switch(
                                checked = disableLyrics,
                                onCheckedChange = onDisableLyricsChange,
                            )
                        },
                        onClick = { onDisableLyricsChange(!disableLyrics) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.slow_motion_video),
                        title = { Text("Tắt video (Disable videos)") },
                        description = { Text("Chỉ phát âm thanh, chặn luồng phát video") },
                        trailingContent = {
                            Switch(
                                checked = disableVideos,
                                onCheckedChange = onDisableVideosChange,
                            )
                        },
                        onClick = { onDisableVideosChange(!disableVideos) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.cloud),
                        title = { Text("Tắt tải trước (Disable preloading)") },
                        description = { Text("Ngăn chặn tải trước bài hát tiếp theo trên dữ liệu di động") },
                        trailingContent = {
                            Switch(
                                checked = disablePreloading,
                                onCheckedChange = onDisablePreloadingChange,
                            )
                        },
                        onClick = { onDisablePreloadingChange(!disablePreloading) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.restore),
                        title = { Text("Tắt đồng bộ hóa nền (Disable background syncs)") },
                        description = { Text("Tạm dừng các tác vụ đồng bộ chạy ngầm khi dùng mạng di động") },
                        trailingContent = {
                            Switch(
                                checked = disableBackgroundSync,
                                onCheckedChange = onDisableBackgroundSyncChange,
                            )
                        },
                        onClick = { onDisableBackgroundSyncChange(!disableBackgroundSync) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.graphic_eq),
                        title = { Text("Ép định dạng Opus (Force Opus audio)") },
                        description = { Text("Sử dụng mã hóa Opus độ nén cao để tiết kiệm dữ liệu tối đa") },
                        trailingContent = {
                            Switch(
                                checked = forceOpusAudio,
                                onCheckedChange = onForceOpusAudioChange,
                            )
                        },
                        onClick = { onForceOpusAudioChange(!forceOpusAudio) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.sliders),
                        title = { Text(stringResource(R.string.limit_mobile_data)) },
                        trailingContent = {
                            Switch(
                                checked = limitMobileData,
                                onCheckedChange = onLimitMobileDataChange,
                            )
                        },
                        onClick = { onLimitMobileDataChange(!limitMobileData) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.cloud),
                        title = { Text(stringResource(R.string.only_play_over_wifi)) },
                        trailingContent = {
                            Switch(
                                checked = onlyPlayOverWifi,
                                onCheckedChange = onOnlyPlayOverWifiChange,
                            )
                        },
                        onClick = { onOnlyPlayOverWifiChange(!onlyPlayOverWifi) }
                    )
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section 2: Sound Quality & Download Quality
            Material3SettingsGroup(
                title = "Chất lượng âm thanh & Tải xuống",
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.download),
                        title = { Text(stringResource(R.string.download_over_wifi_only)) },
                        trailingContent = {
                            Switch(
                                checked = downloadOverWifi,
                                onCheckedChange = onDownloadOverWifiChange,
                            )
                        },
                        onClick = { onDownloadOverWifiChange(!downloadOverWifi) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.music_note),
                        title = { Text(stringResource(R.string.only_download_audio_if_possible)) },
                        trailingContent = {
                            Switch(
                                checked = onlyDownloadAudio,
                                onCheckedChange = onOnlyDownloadAudioChange,
                            )
                        },
                        onClick = { onOnlyDownloadAudioChange(!onlyDownloadAudio) }
                    ),
                    // Audio Quality / Sound Quality dropdown
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.graphic_eq),
                        title = { Text("Sound quality (Chất lượng âm thanh)") },
                        description = {
                            Text(
                                when (audioQuality) {
                                    "OPUS" -> "Opus (Low Bandwidth)"
                                    "HIGH" -> stringResource(R.string.quality_high)
                                    "LOW" -> stringResource(R.string.quality_low)
                                    else -> stringResource(R.string.quality_auto)
                                }
                            )
                        },
                        onClick = { audioQualityExpanded = true }
                    ),
                    // Download Quality dropdown
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.download),
                        title = { Text("Download Quality (Chất lượng tải xuống)") },
                        description = {
                            Text(
                                when (downloadQuality) {
                                    "YTM_AAC" -> "YouTube Music (AAC/Default)"
                                    "OPUS" -> "Opus (Data Saver)"
                                    "HIGH" -> "Chất lượng cao (256kbps)"
                                    "LOW" -> "Chất lượng thấp (128kbps)"
                                    else -> "Mặc định (YouTube Music AAC)"
                                }
                            )
                        },
                        onClick = { downloadQualityExpanded = true }
                    ),
                    // Clear downloads button
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.delete),
                        title = { Text(stringResource(R.string.clear_downloaded_music_title)) },
                        description = { Text(stringResource(R.string.clear_downloaded_music_desc)) },
                        onClick = { showDeleteConfirmDialog = true }
                    )
                )
            )

            // Audio Quality Dropdown Menu
            Box {
                DropdownMenu(
                    expanded = audioQualityExpanded,
                    onDismissRequest = { audioQualityExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Opus (Low Bandwidth - Data Saver)") },
                        onClick = {
                            onAudioQualityChange("OPUS")
                            audioQualityExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.quality_high) + " (256kbps)") },
                        onClick = {
                            onAudioQualityChange(AudioQuality.HIGH.name)
                            audioQualityExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.audio_quality_standard) + " (160kbps)") },
                        onClick = {
                            onAudioQualityChange(AudioQuality.LOW.name)
                            audioQualityExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.quality_auto)) },
                        onClick = {
                            onAudioQualityChange(AudioQuality.AUTO.name)
                            audioQualityExpanded = false
                        }
                    )
                }
            }

            // Download Quality Dropdown Menu
            Box {
                DropdownMenu(
                    expanded = downloadQualityExpanded,
                    onDismissRequest = { downloadQualityExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("YouTube Music (AAC/Default)") },
                        onClick = {
                            onDownloadQualityChange("YTM_AAC")
                            downloadQualityExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Opus (Data Saver - Low Bandwidth)") },
                        onClick = {
                            onDownloadQualityChange("OPUS")
                            downloadQualityExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("High Quality (256kbps AAC)") },
                        onClick = {
                            onDownloadQualityChange("HIGH")
                            downloadQualityExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Low Quality (128kbps AAC)") },
                        onClick = {
                            onDownloadQualityChange("LOW")
                            downloadQualityExpanded = false
                        }
                    )
                }
            }

            // Video Quality Dropdown Menu
            Box {
                DropdownMenu(
                    expanded = videoQualityExpanded,
                    onDismissRequest = { videoQualityExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("HD") },
                        onClick = {
                            onVideoQualityChange("HD")
                            videoQualityExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.quality_standard)) },
                        onClick = {
                            onVideoQualityChange("STANDARD")
                            videoQualityExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.quality_low)) },
                        onClick = {
                            onVideoQualityChange("LOW")
                            videoQualityExpanded = false
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Section 3: Storage Permissions & Device Files
            Material3SettingsGroup(
                title = stringResource(R.string.storage_permission_device_files_title),
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.security),
                        title = { Text(stringResource(R.string.request_storage_permission_title)) },
                        description = {
                            Text(
                                if (isStoragePermissionGranted) stringResource(R.string.permission_granted_status)
                                else stringResource(R.string.permission_not_granted_status)
                            )
                        },
                        onClick = {
                            if (!isStoragePermissionGranted) {
                                showPermissionDialog = true
                            } else {
                                Toast.makeText(context, context.getString(R.string.storage_permission_granted_toast), Toast.LENGTH_SHORT).show()
                            }
                        }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.list),
                        title = { Text(stringResource(R.string.show_files_on_device)) },
                        trailingContent = {
                            Switch(
                                checked = showFilesOnDevice,
                                onCheckedChange = onShowFilesOnDeviceChange,
                            )
                        },
                        onClick = { onShowFilesOnDeviceChange(!showFilesOnDevice) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.list),
                        title = { Text(stringResource(R.string.show_all_audio_files)) },
                        trailingContent = {
                            Switch(
                                checked = showAllAudioFiles,
                                onCheckedChange = onShowAllAudioFilesChange,
                            )
                        },
                        onClick = { onShowAllAudioFilesChange(!showAllAudioFiles) }
                    )
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section 4: History & Voice
            Material3SettingsGroup(
                title = stringResource(R.string.advanced_features_group_title),
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.mic),
                        title = { Text(stringResource(R.string.voice_interface)) },
                        description = { Text(stringResource(R.string.voice_search_desc)) },
                        trailingContent = {
                            Switch(
                                checked = voiceInterface,
                                onCheckedChange = onVoiceInterfaceChange,
                            )
                        },
                        onClick = { onVoiceInterfaceChange(!voiceInterface) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.history),
                        title = { Text(stringResource(R.string.previous_watched_mode)) },
                        description = { Text(stringResource(R.string.previous_watched_mode_desc)) },
                        trailingContent = {
                            Switch(
                                checked = previousWatched,
                                onCheckedChange = onPreviousWatchedChange,
                            )
                        },
                        onClick = { onPreviousWatchedChange(!previousWatched) }
                    )
                )
            )

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    // Storage permission custom alert dialog
    if (showPermissionDialog) {
        DefaultDialog(
            onDismiss = { showPermissionDialog = false },
            icon = {
                Icon(
                    painter = painterResource(R.drawable.security),
                    contentDescription = null
                )
            },
            title = { Text(stringResource(R.string.request_storage_permission_title)) },
            buttons = {
                TextButton(
                    onClick = { showPermissionDialog = false }
                ) {
                    Text(stringResource(android.R.string.cancel))
                }
                TextButton(
                    onClick = {
                        showPermissionDialog = false
                        storagePermissionLauncher.launch(permissionsToRequest)
                    }
                ) {
                    Text(stringResource(R.string.grant_permission_btn))
                }
            }
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
            ) {
                Text(
                    text = stringResource(R.string.storage_permission_explain_desc),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    // Delete downloads confirmation dialog
    if (showDeleteConfirmDialog) {
        DefaultDialog(
            onDismiss = { showDeleteConfirmDialog = false },
            icon = {
                Icon(
                    painter = painterResource(R.drawable.delete),
                    contentDescription = null
                )
            },
            title = { Text(stringResource(R.string.clear_downloads_confirm_title)) },
            buttons = {
                TextButton(
                    onClick = { showDeleteConfirmDialog = false }
                ) {
                    Text(stringResource(android.R.string.cancel))
                }
                TextButton(
                    onClick = {
                        showDeleteConfirmDialog = false
                        try {
                            downloadCache?.keys?.forEach { key ->
                                downloadCache.removeResource(key)
                            }
                            Toast.makeText(context, context.getString(R.string.clear_downloads_success_toast), Toast.LENGTH_SHORT).show()
                        } catch (e: Exception) {
                            Toast.makeText(context, context.getString(R.string.clear_downloads_error_toast), Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text(stringResource(R.string.clear_btn))
                }
            }
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
            ) {
                Text(
                    text = stringResource(R.string.clear_downloads_explain_desc),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
