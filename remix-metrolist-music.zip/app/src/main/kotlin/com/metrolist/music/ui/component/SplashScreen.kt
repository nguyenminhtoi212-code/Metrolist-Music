package com.metrolist.music.ui.component

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.appcompat.content.res.AppCompatResources
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.metrolist.music.R
import com.metrolist.music.constants.ShowSplashScreenKey
import com.metrolist.music.constants.UseLauncherIconOnSplashKey
import com.metrolist.music.utils.rememberPreference
import kotlinx.coroutines.delay

private fun drawableToPainter(drawable: Drawable): Painter {
    if (drawable is BitmapDrawable && drawable.bitmap != null) {
        return BitmapPainter(drawable.bitmap.asImageBitmap())
    }
    val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 120
    val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 120
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    drawable.setBounds(0, 0, canvas.width, canvas.height)
    drawable.draw(canvas)
    return BitmapPainter(bitmap.asImageBitmap())
}

@Composable
private fun rememberSafePainter(resId: Int, fallbackResId: Int = R.drawable.app_logo): Painter {
    val context = LocalContext.current
    return remember(resId, fallbackResId, context) {
        val drawable = try {
            AppCompatResources.getDrawable(context, resId)
        } catch (e: Throwable) {
            null
        } ?: try {
            AppCompatResources.getDrawable(context, fallbackResId)
        } catch (e: Throwable) {
            null
        }

        if (drawable != null) {
            drawableToPainter(drawable)
        } else {
            BitmapPainter(Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888).asImageBitmap())
        }
    }
}

@Composable
fun SplashScreenOverlay(
    modifier: Modifier = Modifier,
    onFinished: () -> Unit = {}
) {
    val (showSplashScreen) = rememberPreference(ShowSplashScreenKey, defaultValue = true)
    val (useLauncherIcon) = rememberPreference(UseLauncherIconOnSplashKey, defaultValue = false)

    var isVisible by remember { mutableStateOf(showSplashScreen) }

    if (!showSplashScreen) {
        return
    }

    LaunchedEffect(Unit) {
        delay(1100)
        isVisible = false
        delay(350)
        onFinished()
    }

    AnimatedVisibility(
        visible = isVisible,
        enter = fadeIn(animationSpec = tween(250, easing = LinearOutSlowInEasing)) +
                scaleIn(initialScale = 0.95f, animationSpec = tween(250)),
        exit = fadeOut(animationSpec = tween(350, easing = FastOutSlowInEasing)) +
                scaleOut(targetScale = 1.05f, animationSpec = tween(350)),
        modifier = modifier.fillMaxSize()
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            val infiniteTransition = rememberInfiniteTransition(label = "SplashAnimations")
            val pulseScale by infiniteTransition.animateFloat(
                initialValue = 0.97f,
                targetValue = 1.03f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1000, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "SplashLogoScale"
            )
            val ringAlpha by infiniteTransition.animateFloat(
                initialValue = 0.15f,
                targetValue = 0.35f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1000, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "SplashRingAlpha"
            )

            val primaryColor = MaterialTheme.colorScheme.primary
            val backgroundColor = MaterialTheme.colorScheme.background
            val surfaceContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                primaryColor.copy(alpha = 0.18f),
                                backgroundColor
                            ),
                            radius = 1200f
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(32.dp)
                ) {
                    val iconRes = if (useLauncherIcon) R.mipmap.ic_launcher_static else R.drawable.app_logo

                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(140.dp)
                    ) {
                        // Ambient outer glow ring
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .scale(pulseScale * 1.1f)
                                .clip(CircleShape)
                                .background(primaryColor.copy(alpha = ringAlpha))
                        )

                        // Inner container card
                        Box(
                            modifier = Modifier
                                .scale(pulseScale)
                                .size(112.dp)
                                .clip(RoundedCornerShape(28.dp))
                                .background(surfaceContainerColor)
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = rememberSafePainter(resId = iconRes, fallbackResId = R.drawable.app_logo),
                                contentDescription = stringResource(id = R.string.app_name),
                                modifier = Modifier.size(72.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    Text(
                        text = stringResource(id = R.string.app_name),
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 32.sp,
                            letterSpacing = 0.5.sp
                        ),
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Your Music, Unlimited",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp,
                            letterSpacing = 0.2.sp
                        ),
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.65f)
                    )

                    Spacer(modifier = Modifier.height(48.dp))

                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = primaryColor,
                        strokeWidth = 2.5.dp
                    )
                }
            }
        }
    }
}

