/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.artist

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalResources
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import com.metrolist.innertube.YouTube
import com.metrolist.innertube.models.AlbumItem
import com.metrolist.innertube.models.ArtistItem
import com.metrolist.innertube.models.EpisodeItem
import com.metrolist.innertube.models.PlaylistItem
import com.metrolist.innertube.models.PodcastItem
import com.metrolist.innertube.models.SongItem
import com.metrolist.innertube.models.WatchEndpoint
import com.metrolist.innertube.pages.ArtistSection
import com.metrolist.music.LocalDatabase
import com.metrolist.music.LocalListenTogetherManager
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.LocalPlayerConnection
import com.metrolist.music.R
import com.metrolist.music.constants.AppBarHeight
import com.metrolist.music.constants.HideExplicitKey
import com.metrolist.music.constants.ShowArtistDescriptionKey
import com.metrolist.music.constants.ShowArtistSubscriberCountKey
import com.metrolist.music.constants.ShowMonthlyListenersKey
import com.metrolist.music.extensions.toMediaItem
import com.metrolist.music.models.toMediaMetadata
import com.metrolist.music.playback.queues.ListQueue
import com.metrolist.music.playback.queues.YouTubeQueue
import com.metrolist.music.ui.component.AlbumGridItem
import com.metrolist.music.ui.component.ChipsRow
import com.metrolist.music.ui.component.ExpandableText
import com.metrolist.music.ui.component.HideOnScrollFAB
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.LinkSegment
import com.metrolist.music.ui.component.LocalMenuState
import com.metrolist.music.ui.component.NavigationTitle
import com.metrolist.music.ui.component.SongListItem
import com.metrolist.music.ui.component.YouTubeGridItem
import com.metrolist.music.ui.component.YouTubeListItem
import com.metrolist.music.ui.component.shimmer.ButtonPlaceholder
import com.metrolist.music.ui.component.shimmer.ListItemPlaceHolder
import com.metrolist.music.ui.component.shimmer.ShimmerHost
import com.metrolist.music.ui.component.shimmer.TextPlaceholder
import com.metrolist.music.ui.menu.AlbumMenu
import com.metrolist.music.ui.menu.SelectionSongMenu
import com.metrolist.music.ui.menu.SongMenu
import com.metrolist.music.ui.menu.YouTubeAlbumMenu
import com.metrolist.music.ui.menu.YouTubeArtistMenu
import com.metrolist.music.ui.menu.YouTubePlaylistMenu
import com.metrolist.music.ui.menu.YouTubeSelectionSongMenu
import com.metrolist.music.ui.menu.YouTubeSongMenu
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.ui.utils.fadingEdge
import com.metrolist.music.ui.utils.isScrollingUp
import com.metrolist.music.ui.utils.resize
import com.metrolist.music.utils.rememberPreference
import com.metrolist.music.viewmodels.ArtistViewModel
import com.valentinilk.shimmer.shimmer
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class ArtistContentFilter {
    ALL,
    SONGS,
    ALBUMS,
    SINGLES,
    VIDEOS_LIVE,
    FEATURED,
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ArtistScreen(
    navController: NavController,
    viewModel: ArtistViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val database = LocalDatabase.current
    val menuState = LocalMenuState.current
    val haptic = LocalHapticFeedback.current
    val coroutineScope = rememberCoroutineScope()
    val playerConnection = LocalPlayerConnection.current ?: return
    val listenTogetherManager = LocalListenTogetherManager.current
    val isGuest = listenTogetherManager?.isInRoom == true && !listenTogetherManager.isHost
    val isPlaying by playerConnection.isEffectivelyPlaying.collectAsStateWithLifecycle()
    val mediaMetadata by playerConnection.mediaMetadata.collectAsStateWithLifecycle()
    val artistPage = viewModel.artistPage
    val libraryArtist by viewModel.libraryArtist.collectAsStateWithLifecycle()
    val librarySongs by viewModel.librarySongs.collectAsStateWithLifecycle()
    val libraryAlbums by viewModel.libraryAlbums.collectAsStateWithLifecycle()
    val isChannelSubscribed by viewModel.isChannelSubscribed.collectAsStateWithLifecycle()
    val hideExplicit by rememberPreference(key = HideExplicitKey, defaultValue = false)
    val showArtistDescription by rememberPreference(key = ShowArtistDescriptionKey, defaultValue = true)
    val showArtistSubscriberCount by rememberPreference(key = ShowArtistSubscriberCountKey, defaultValue = true)
    val showMonthlyListeners by rememberPreference(key = ShowMonthlyListenersKey, defaultValue = true)

    val lazyListState = rememberLazyListState()
    val snackbarHostState = remember { SnackbarHostState() }
    var showLocal by rememberSaveable { mutableStateOf(false) }
    var currentFilter by rememberSaveable { mutableStateOf(ArtistContentFilter.ALL) }

    val selectedLocalSongs =
        rememberSaveable(
            saver =
                listSaver(
                    save = { it.toList() },
                    restore = { it.toMutableStateList() },
                ),
        ) {
            mutableStateListOf<String>()
        }

    val selectedYouTubeSongs =
        rememberSaveable(
            saver =
                listSaver(
                    save = { it.toList() },
                    restore = { it.toMutableStateList() },
                ),
        ) {
            mutableStateListOf<String>()
        }

    val inSelectMode = if (showLocal) selectedLocalSongs.isNotEmpty() else selectedYouTubeSongs.isNotEmpty()

    BackHandler(inSelectMode) {
        selectedLocalSongs.clear()
        selectedYouTubeSongs.clear()
    }

    val density = LocalDensity.current

    // Calculate the offset value outside of the offset lambda
    val systemBarsTopPadding = WindowInsets.systemBars.asPaddingValues().calculateTopPadding()
    val headerOffset =
        with(density) {
            -(systemBarsTopPadding + AppBarHeight).roundToPx()
        }

    val transparentAppBar by remember {
        derivedStateOf {
            lazyListState.firstVisibleItemIndex == 0 && lazyListState.firstVisibleItemScrollOffset < 100
        }
    }

    val distinctItemsBySection = remember(artistPage?.sections) {
        artistPage?.sections?.map { section ->
            section.items.distinctBy { it.id }
        } ?: emptyList()
    }

    fun shouldShowArtistSection(section: ArtistSection, filter: ArtistContentFilter): Boolean {
        val titleLower = section.title.lowercase()
        val isSongSection = (section.items.firstOrNull() as? SongItem)?.album != null ||
            titleLower.contains("song") || titleLower.contains("track") || titleLower.contains("bài hát") || titleLower.contains("popular") || titleLower.contains("top")
        val isSingleSection = titleLower.contains("single") || titleLower.contains("ep") || titleLower.contains("đĩa đơn") || titleLower.contains("release")
        val isAlbumSection = (titleLower.contains("album") || titleLower.contains("discography")) && !isSingleSection
        val isVideoSection = titleLower.contains("video") || titleLower.contains("live") || titleLower.contains("performance") || titleLower.contains("trực tiếp") || titleLower.contains("clip")
        val isFeaturedSection = titleLower.contains("featured") || titleLower.contains("appear") || titleLower.contains("from the artist") || titleLower.contains("hợp tác") || titleLower.contains("xuất hiện") || titleLower.contains("fans might") || titleLower.contains("similar")

        return when (filter) {
            ArtistContentFilter.ALL -> true
            ArtistContentFilter.SONGS -> isSongSection
            ArtistContentFilter.ALBUMS -> isAlbumSection
            ArtistContentFilter.SINGLES -> isSingleSection
            ArtistContentFilter.VIDEOS_LIVE -> isVideoSection
            ArtistContentFilter.FEATURED -> isFeaturedSection
        }
    }

    val visibleYouTubeSongs = remember(artistPage?.sections, distinctItemsBySection, currentFilter) {
        artistPage?.sections?.mapIndexedNotNull { index, section ->
            if (shouldShowArtistSection(section, currentFilter)) {
                val items = distinctItemsBySection.getOrNull(index) ?: section.items
                items.filterIsInstance<SongItem>()
            } else {
                null
            }
        }?.flatten() ?: emptyList()
    }

    val visibleLocalSongs = remember(librarySongs, hideExplicit, currentFilter) {
        if (currentFilter == ArtistContentFilter.ALL || currentFilter == ArtistContentFilter.SONGS) {
            if (hideExplicit) librarySongs.filter { !it.song.explicit } else librarySongs
        } else {
            emptyList()
        }
    }

    val artistName = artistPage?.artist?.title ?: libraryArtist?.artist?.name

    LaunchedEffect(libraryArtist) {
        // always show local page for local artists. Show local page remote artist when offline
        showLocal = libraryArtist?.artist?.isLocal == true
    }

    Box(
        modifier = Modifier.fillMaxSize(),
    ) {
        LazyColumn(
            state = lazyListState,
            contentPadding = LocalPlayerAwareWindowInsets.current.asPaddingValues(),
        ) {
            if (artistPage == null && !showLocal) {
                item(key = "shimmer") {
                    ShimmerHost(
                        modifier =
                            Modifier
                                .offset {
                                    IntOffset(x = 0, y = headerOffset)
                                },
                    ) {
                        // Artist Image Placeholder
                        Box(
                            modifier =
                                Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(1.1f),
                        ) {
                            Spacer(
                                modifier =
                                    Modifier
                                        .fillMaxSize()
                                        .shimmer()
                                        .background(MaterialTheme.colorScheme.onSurface)
                                        .fadingEdge(
                                            top = systemBarsTopPadding + AppBarHeight,
                                            bottom = 200.dp,
                                        ),
                            )
                        }
                        // Artist Name and Controls Section
                        Column(
                            modifier =
                                Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                        ) {
                            // Artist Name Placeholder
                            TextPlaceholder(
                                height = 36.dp,
                                modifier =
                                    Modifier
                                        .fillMaxWidth(0.7f)
                                        .padding(bottom = 16.dp),
                            )

                            // Buttons Row Placeholder
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                // Subscribe Button Placeholder
                                ButtonPlaceholder(
                                    modifier =
                                        Modifier
                                            .width(120.dp)
                                            .height(40.dp),
                                )

                                Spacer(modifier = Modifier.weight(1f))

                                // Right side buttons
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    // Radio Button Placeholder
                                    ButtonPlaceholder(
                                        modifier =
                                            Modifier
                                                .width(100.dp)
                                                .height(40.dp),
                                    )

                                    // Shuffle Button Placeholder
                                    Box(
                                        modifier =
                                            Modifier
                                                .size(48.dp)
                                                .shimmer()
                                                .background(
                                                    MaterialTheme.colorScheme.onSurface,
                                                    RoundedCornerShape(24.dp),
                                                ),
                                    )
                                }
                            }
                        }
                        // Songs List Placeholder
                        repeat(6) {
                            ListItemPlaceHolder()
                        }
                    }
                }
            } else {
                item(key = "header") {
                    val thumbnail = artistPage?.artist?.thumbnail ?: libraryArtist?.artist?.thumbnailUrl

                    Box {
                        // Artist Image with offset
                        if (thumbnail != null) {
                            Box(
                                modifier =
                                    Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(1f)
                                        .offset {
                                            IntOffset(x = 0, y = headerOffset)
                                        },
                            ) {
                                AsyncImage(
                                    model = thumbnail.resize(1200, 1200),
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier =
                                        Modifier
                                            .fillMaxWidth()
                                            .align(Alignment.TopCenter)
                                            .fadingEdge(
                                                bottom = 200.dp,
                                            ),
                                )
                            }
                        }

                        // Artist Name and Controls Section - positioned at bottom of image
                        Column(
                            modifier =
                                Modifier
                                    .fillMaxWidth()
                                    .padding(
                                        top =
                                            if (thumbnail != null) {
                                                // Position content at the bottom part of the image
                                                // Using screen width to calculate aspect ratio height minus overlap
                                                LocalResources.current.displayMetrics.widthPixels.let { screenWidth ->
                                                    with(density) {
                                                        ((screenWidth / 1.2f) - 144).toDp()
                                                    }
                                                }
                                            } else {
                                                16.dp
                                            },
                                    ),
                        ) {
                            Column(
                                modifier =
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp),
                            ) {
                                // Official Channel Badge
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f),
                                    modifier = Modifier.padding(bottom = 8.dp),
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    ) {
                                        Icon(
                                            painter = painterResource(R.drawable.music_note),
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.size(14.dp),
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = stringResource(R.string.artist_official_channel),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        )
                                    }
                                }

                                // Artist Name
                                Text(
                                    text = artistName ?: "Unknown",
                                    style = MaterialTheme.typography.headlineLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    fontSize = 32.sp,
                                    modifier = Modifier.padding(bottom = 8.dp),
                                )

                                // Channel Stats Pills Row
                                val subCount = artistPage?.subscriberCountText
                                val monListeners = artistPage?.monthlyListenerCount
                                if (!subCount.isNullOrEmpty() || !monListeners.isNullOrEmpty()) {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(bottom = 12.dp),
                                    ) {
                                        if (!subCount.isNullOrEmpty()) {
                                            Surface(
                                                shape = RoundedCornerShape(16.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                                ) {
                                                    Icon(
                                                        painter = painterResource(R.drawable.subscribed),
                                                        contentDescription = null,
                                                        modifier = Modifier.size(12.dp),
                                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        text = subCount,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    )
                                                }
                                            }
                                        }

                                        if (!monListeners.isNullOrEmpty()) {
                                            Surface(
                                                shape = RoundedCornerShape(16.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                                ) {
                                                    Icon(
                                                        painter = painterResource(R.drawable.library_music),
                                                        contentDescription = null,
                                                        modifier = Modifier.size(12.dp),
                                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        text = monListeners,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                // Interactive Buttons Row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                ) {
                                    // Revamped Subscribe Button
                                    if (isChannelSubscribed) {
                                        FilledTonalButton(
                                            onClick = { viewModel.toggleChannelSubscription() },
                                            shape = RoundedCornerShape(24.dp),
                                            contentPadding = ButtonDefaults.ButtonWithIconContentPadding,
                                            modifier = Modifier.height(42.dp),
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.check),
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp),
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = stringResource(R.string.subscribed),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold,
                                            )
                                        }
                                    } else {
                                        Button(
                                            onClick = { viewModel.toggleChannelSubscription() },
                                            shape = RoundedCornerShape(24.dp),
                                            contentPadding = ButtonDefaults.ButtonWithIconContentPadding,
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = MaterialTheme.colorScheme.primary,
                                                contentColor = MaterialTheme.colorScheme.onPrimary,
                                            ),
                                            modifier = Modifier.height(42.dp),
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.subscribe),
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp),
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = stringResource(R.string.subscribe),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.weight(1f))

                                    // Radio Button
                                    if (!showLocal && !isGuest) {
                                        artistPage?.artist?.radioEndpoint?.let { radioEndpoint ->
                                            FilledTonalButton(
                                                onClick = {
                                                    playerConnection.playQueue(YouTubeQueue(radioEndpoint))
                                                },
                                                shape = RoundedCornerShape(24.dp),
                                                modifier = Modifier.height(42.dp),
                                            ) {
                                                Icon(
                                                    painter = painterResource(R.drawable.radio),
                                                    contentDescription = null,
                                                    modifier = Modifier.size(18.dp),
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = stringResource(R.string.radio),
                                                    fontSize = 13.sp,
                                                )
                                            }
                                        }
                                    }

                                    // Shuffle Button
                                    if (!showLocal && !isGuest) {
                                        artistPage?.artist?.shuffleEndpoint?.let { shuffleEndpoint ->
                                            IconButton(
                                                onClick = {
                                                    playerConnection.playQueue(YouTubeQueue(shuffleEndpoint))
                                                },
                                                modifier =
                                                    Modifier
                                                        .size(42.dp)
                                                        .background(
                                                            MaterialTheme.colorScheme.primary,
                                                            CircleShape,
                                                        ),
                                            ) {
                                                Icon(
                                                    painter = painterResource(R.drawable.shuffle),
                                                    contentDescription = "Shuffle",
                                                    tint = MaterialTheme.colorScheme.onPrimary,
                                                    modifier = Modifier.size(20.dp),
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }
                }

                // About Artist Section
                if (!showLocal && (showArtistDescription || showArtistSubscriberCount || showMonthlyListeners)) {
                    val description = artistPage?.description
                    val descriptionRuns = artistPage?.descriptionRuns
                    val subscriberCount = artistPage?.subscriberCountText
                    val monthlyListeners = artistPage?.monthlyListenerCount

                    if ((showArtistDescription && !description.isNullOrEmpty()) ||
                        (showArtistSubscriberCount && !subscriberCount.isNullOrEmpty()) ||
                        (showMonthlyListeners && !monthlyListeners.isNullOrEmpty())
                    ) {
                        item(key = "about_artist") {
                            Column(
                                modifier =
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp)
                                        .padding(bottom = 16.dp)
                                        .animateItem(),
                            ) {
                                if (showArtistDescription && (!description.isNullOrEmpty() || !descriptionRuns.isNullOrEmpty())) {
                                    Text(
                                        text = stringResource(R.string.about_artist),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(bottom = 8.dp),
                                    )
                                }

                                if (showArtistSubscriberCount && !subscriberCount.isNullOrEmpty()) {
                                    Text(
                                        text = subscriberCount,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(bottom = 4.dp),
                                    )
                                }

                                if (showMonthlyListeners && !monthlyListeners.isNullOrEmpty()) {
                                    Text(
                                        text = monthlyListeners,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier =
                                            Modifier.padding(
                                                bottom =
                                                    if (showArtistDescription &&
                                                        !description.isNullOrEmpty()
                                                    ) {
                                                        8.dp
                                                    } else {
                                                        0.dp
                                                    },
                                            ),
                                    )
                                }

                                if (showArtistDescription && (!description.isNullOrEmpty() || !descriptionRuns.isNullOrEmpty())) {
                                    ExpandableText(
                                        text = description.orEmpty(),
                                        runs =
                                            descriptionRuns?.map {
                                                LinkSegment(
                                                    text = it.text,
                                                    url = it.navigationEndpoint?.urlEndpoint?.url,
                                                )
                                            },
                                        collapsedMaxLines = 3,
                                    )
                                }
                            }
                        }
                    }
                }

                // Now Playing Artist Music Hub
                val isArtistTrackPlaying = mediaMetadata?.artists?.any { 
                    it.name.equals(artistName, ignoreCase = true) 
                } == true || (mediaMetadata != null && (librarySongs.any { it.id == mediaMetadata?.id } || artistPage?.sections?.any { sec -> sec.items.any { item -> item.id == mediaMetadata?.id } } == true))

                if (isArtistTrackPlaying && mediaMetadata != null) {
                    item(key = "artist_live_player") {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                                .animateItem(),
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                            ) {
                                // Track Art
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.size(52.dp),
                                ) {
                                    AsyncImage(
                                        model = mediaMetadata?.thumbnailUrl?.resize(200, 200),
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize(),
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                // Track Details
                                Column(
                                    modifier = Modifier.weight(1f),
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Icon(
                                            painter = painterResource(R.drawable.music_note),
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(12.dp),
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = stringResource(R.string.artist_now_playing),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary,
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = mediaMetadata?.title.orEmpty(),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        text = mediaMetadata?.album?.title ?: artistName ?: "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                // Play / Pause Button
                                IconButton(
                                    onClick = { playerConnection.togglePlayPause() },
                                    modifier = Modifier
                                        .size(44.dp)
                                        .background(
                                            MaterialTheme.colorScheme.primary,
                                            CircleShape,
                                        ),
                                ) {
                                    Icon(
                                        painter = painterResource(
                                            if (isPlaying) R.drawable.pause else R.drawable.play
                                        ),
                                        contentDescription = if (isPlaying) "Pause" else "Play",
                                        tint = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.size(20.dp),
                                    )
                                }
                            }
                        }
                    }
                }

                // Filter Chips Row
                item(key = "artist_filter_chips") {
                    ChipsRow(
                        chips = listOf(
                            ArtistContentFilter.ALL to stringResource(R.string.filter_all),
                            ArtistContentFilter.SONGS to stringResource(R.string.songs),
                            ArtistContentFilter.ALBUMS to stringResource(R.string.albums),
                            ArtistContentFilter.SINGLES to stringResource(R.string.filter_singles_eps),
                            ArtistContentFilter.VIDEOS_LIVE to stringResource(R.string.filter_live_performances),
                            ArtistContentFilter.FEATURED to stringResource(R.string.filter_featured_on),
                        ),
                        currentValue = currentFilter,
                        onValueUpdate = { currentFilter = it },
                        modifier = Modifier.padding(vertical = 8.dp).animateItem(),
                    )
                }

                // Show loading shimmer for sections when API hasn't returned yet
                if (artistPage == null && !showLocal) {
                    item(key = "section_shimmer") {
                        ShimmerHost {
                            repeat(4) { ListItemPlaceHolder() }
                        }
                    }
                }

                if (showLocal) {
                    val showLocalSongs = (currentFilter == ArtistContentFilter.ALL || currentFilter == ArtistContentFilter.SONGS) && librarySongs.isNotEmpty()
                    if (showLocalSongs) {
                        item(key = "local_songs_title") {
                            NavigationTitle(
                                title = stringResource(R.string.songs),
                                modifier = Modifier.animateItem(),
                                onClick = {
                                    navController.navigate("artist/${viewModel.artistId}/songs")
                                },
                            )
                        }

                        val filteredLibrarySongs =
                            if (hideExplicit) {
                                librarySongs.filter { !it.song.explicit }
                            } else {
                                librarySongs
                            }
                        itemsIndexed(
                            items = filteredLibrarySongs,
                            key = { index, item -> "local_song_${item.id}_$index" },
                        ) { index, song ->
                            SongListItem(
                                song = song,
                                showInLibraryIcon = true,
                                isActive = song.id == mediaMetadata?.id,
                                isPlaying = isPlaying,
                                trailingContent = {
                                    if (inSelectMode) {
                                        Checkbox(
                                            checked = song.id in selectedLocalSongs,
                                            onCheckedChange = { checked ->
                                                if (checked) {
                                                    selectedLocalSongs.add(song.id)
                                                } else {
                                                    selectedLocalSongs.remove(song.id)
                                                }
                                            },
                                        )
                                    } else {
                                        IconButton(
                                            onClick = {
                                                menuState.show {
                                                    SongMenu(
                                                        originalSong = song,
                                                        onDismiss = menuState::dismiss,
                                                    )
                                                }
                                            },
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.more_vert),
                                                contentDescription = null,
                                            )
                                        }
                                    }
                                },
                                modifier =
                                    Modifier
                                        .fillMaxWidth()
                                        .combinedClickable(
                                            onClick = {
                                                if (inSelectMode) {
                                                    if (song.id in selectedLocalSongs) {
                                                        selectedLocalSongs.remove(song.id)
                                                    } else {
                                                        selectedLocalSongs.add(song.id)
                                                    }
                                                } else if (!isGuest) {
                                                    if (song.id == mediaMetadata?.id) {
                                                        playerConnection.togglePlayPause()
                                                    } else {
                                                        playerConnection.playQueue(
                                                            ListQueue(
                                                                title = libraryArtist?.artist?.name ?: "Unknown Artist",
                                                                items = librarySongs.map { it.toMediaItem() },
                                                                startIndex = index,
                                                            ),
                                                        )
                                                    }
                                                }
                                            },
                                            onLongClick = {
                                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                if (song.id in selectedLocalSongs) {
                                                    selectedLocalSongs.remove(song.id)
                                                } else {
                                                    selectedLocalSongs.add(song.id)
                                                }
                                            },
                                        ).animateItem(),
                            )
                        }
                    }

                    val showLocalAlbums = (currentFilter == ArtistContentFilter.ALL || currentFilter == ArtistContentFilter.ALBUMS || currentFilter == ArtistContentFilter.SINGLES) && libraryAlbums.isNotEmpty()
                    if (showLocalAlbums) {
                        item(key = "local_albums_title") {
                            NavigationTitle(
                                title = stringResource(R.string.albums),
                                modifier = Modifier.animateItem(),
                                onClick = {
                                    navController.navigate("artist/${viewModel.artistId}/albums")
                                },
                            )
                        }

                        item(key = "local_albums_list") {
                            val filteredLibraryAlbums =
                                if (hideExplicit) {
                                    libraryAlbums.filter { !it.album.explicit }
                                } else {
                                    libraryAlbums
                                }
                            LazyRow(
                                contentPadding = WindowInsets.systemBars.only(WindowInsetsSides.Horizontal).asPaddingValues(),
                            ) {
                                items(
                                    items = filteredLibraryAlbums,
                                    key = { "local_album_${it.id}_${filteredLibraryAlbums.indexOf(it)}" },
                                ) { album ->
                                    AlbumGridItem(
                                        album = album,
                                        isActive = mediaMetadata?.album?.id == album.id,
                                        isPlaying = isPlaying,
                                        coroutineScope = coroutineScope,
                                        modifier =
                                            Modifier
                                                .combinedClickable(
                                                    onClick = {
                                                        navController.navigate("album/${album.id}")
                                                    },
                                                    onLongClick = {
                                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                        menuState.show {
                                                            AlbumMenu(
                                                                originalAlbum = album,
                                                                onDismiss = menuState::dismiss,
                                                            )
                                                        }
                                                    },
                                                ).animateItem(),
                                    )
                                }
                            }
                        }
                    }
                } else {
                    artistPage?.sections?.forEachIndexed { index, section ->
                        if (shouldShowArtistSection(section, currentFilter)) {
                            if (section.items.isNotEmpty()) {
                                item(key = "section_${section.title}") {
                                    NavigationTitle(
                                        title = section.title,
                                        modifier = Modifier.animateItem(),
                                        onClick =
                                            section.moreEndpoint?.let {
                                                {
                                                    navController.navigate(
                                                        "artist/${viewModel.artistId}/items?browseId=${it.browseId}?params=${it.params}",
                                                    )
                                                }
                                            },
                                    )
                                }
                            }

                            if ((section.items.firstOrNull() as? SongItem)?.album != null) {
                                items(
                                    items = distinctItemsBySection.getOrNull(index) ?: section.items,
                                    key = { "youtube_song_${it.id}" },
                                ) { song ->
                                    val songItem = song as SongItem
                                    YouTubeListItem(
                                        item = songItem,
                                        isActive = mediaMetadata?.id == songItem.id,
                                        isPlaying = isPlaying,
                                        trailingContent = {
                                            if (inSelectMode) {
                                                Checkbox(
                                                    checked = songItem.id in selectedYouTubeSongs,
                                                    onCheckedChange = { checked ->
                                                        if (checked) {
                                                            selectedYouTubeSongs.add(songItem.id)
                                                        } else {
                                                            selectedYouTubeSongs.remove(songItem.id)
                                                        }
                                                    },
                                                )
                                            } else {
                                                IconButton(
                                                    onClick = {
                                                        menuState.show {
                                                            YouTubeSongMenu(
                                                                song = songItem,
                                                                onDismiss = menuState::dismiss,
                                                            )
                                                        }
                                                    },
                                                ) {
                                                    Icon(
                                                        painter = painterResource(R.drawable.more_vert),
                                                        contentDescription = null,
                                                    )
                                                }
                                            }
                                        },
                                        modifier =
                                            Modifier
                                                .combinedClickable(
                                                    onClick = {
                                                        if (inSelectMode) {
                                                            if (songItem.id in selectedYouTubeSongs) {
                                                                selectedYouTubeSongs.remove(songItem.id)
                                                            } else {
                                                                selectedYouTubeSongs.add(songItem.id)
                                                            }
                                                        } else if (!isGuest) {
                                                            if (songItem.id == mediaMetadata?.id) {
                                                                playerConnection.togglePlayPause()
                                                            } else {
                                                                playerConnection.playQueue(
                                                                    YouTubeQueue(
                                                                        WatchEndpoint(videoId = songItem.id),
                                                                        songItem.toMediaMetadata(),
                                                                    ),
                                                                )
                                                            }
                                                        }
                                                    },
                                                    onLongClick = {
                                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                        if (songItem.id in selectedYouTubeSongs) {
                                                            selectedYouTubeSongs.remove(songItem.id)
                                                        } else {
                                                            selectedYouTubeSongs.add(songItem.id)
                                                        }
                                                    },
                                                ).animateItem(),
                                    )
                                }
                            } else {
                                item(key = "section_list_${section.title}") {
                                    LazyRow(
                                        contentPadding = WindowInsets.systemBars.only(WindowInsetsSides.Horizontal).asPaddingValues(),
                                    ) {
                                        items(
                                            items = distinctItemsBySection.getOrNull(index) ?: section.items,
                                            key = { "youtube_album_${it.id}" },
                                        ) { item ->
                                            YouTubeGridItem(
                                                item = item,
                                                isActive =
                                                    when (item) {
                                                        is SongItem -> mediaMetadata?.id == item.id
                                                        is AlbumItem -> mediaMetadata?.album?.id == item.id
                                                        else -> false
                                                    },
                                                isPlaying = isPlaying,
                                                coroutineScope = coroutineScope,
                                                thumbnailRatio = 1f, // Use square thumbnails for all items in horizontal scroll
                                                modifier =
                                                    Modifier
                                                        .combinedClickable(
                                                            onClick = {
                                                                when (item) {
                                                                    is SongItem -> {
                                                                        if (!isGuest) {
                                                                            playerConnection.playQueue(
                                                                                YouTubeQueue(
                                                                                    WatchEndpoint(videoId = item.id),
                                                                                    item.toMediaMetadata(),
                                                                                ),
                                                                            )
                                                                        }
                                                                    }

                                                                    is AlbumItem -> {
                                                                        navController.navigate("album/${item.id}")
                                                                    }

                                                                    is ArtistItem -> {
                                                                        navController.navigate("artist/${item.id}")
                                                                    }

                                                                    is PlaylistItem -> {
                                                                        navController.navigate("online_playlist/${item.id}")
                                                                    }

                                                                    is PodcastItem -> {
                                                                        navController.navigate("online_podcast/${android.net.Uri.encode(item.id)}")
                                                                    }

                                                                    is EpisodeItem -> {
                                                                        if (!isGuest) {
                                                                            playerConnection.playQueue(
                                                                                YouTubeQueue(
                                                                                    WatchEndpoint(videoId = item.id),
                                                                                    item.toMediaMetadata(),
                                                                                ),
                                                                            )
                                                                        }
                                                                    }
                                                                }
                                                            },
                                                            onLongClick = {
                                                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                                menuState.show {
                                                                    when (item) {
                                                                        is SongItem -> {
                                                                            YouTubeSongMenu(
                                                                                song = item,
                                                                                onDismiss = menuState::dismiss,
                                                                            )
                                                                        }

                                                                        is AlbumItem -> {
                                                                            YouTubeAlbumMenu(
                                                                                albumItem = item,
                                                                                onDismiss = menuState::dismiss,
                                                                            )
                                                                        }

                                                                        is ArtistItem -> {
                                                                            YouTubeArtistMenu(
                                                                                artist = item,
                                                                                onDismiss = menuState::dismiss,
                                                                            )
                                                                        }

                                                                        is PlaylistItem -> {
                                                                            YouTubePlaylistMenu(
                                                                                playlist = item,
                                                                                coroutineScope = coroutineScope,
                                                                                onDismiss = menuState::dismiss,
                                                                            )
                                                                        }

                                                                        is PodcastItem -> {
                                                                            YouTubePlaylistMenu(
                                                                                playlist = item.asPlaylistItem(),
                                                                                coroutineScope = coroutineScope,
                                                                                onDismiss = menuState::dismiss,
                                                                            )
                                                                        }

                                                                        is EpisodeItem -> {
                                                                            YouTubeSongMenu(
                                                                                song = item.asSongItem(),
                                                                                onDismiss = menuState::dismiss,
                                                                            )
                                                                        }
                                                                    }
                                                                }
                                                            },
                                                        ).animateItem(),
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (!inSelectMode) {
            val isScrollingUp = lazyListState.isScrollingUp()
            val showLocalFab = librarySongs.isNotEmpty() && libraryArtist?.artist?.isLocal != true

            // Library/Local Toggle FAB
            HideOnScrollFAB(
                visible = showLocalFab,
                lazyListState = lazyListState,
                icon = if (showLocal) R.drawable.language else R.drawable.library_music,
                onClick = {
                    showLocal = showLocal.not()
                    if (!showLocal && artistPage == null) viewModel.fetchArtistsFromYTM()
                },
            )

            // Play All FAB (Stacked above Library/Local FAB if visible)
            val canPlayAll =
                !isGuest && (
                    (showLocal && librarySongs.isNotEmpty()) ||
                        (
                            !showLocal && artistPage?.sections?.any {
                                (it.items.firstOrNull() as? SongItem)?.album != null
                            } == true
                        )
                )

            if (canPlayAll) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = isScrollingUp,
                    enter = androidx.compose.animation.slideInVertically { it * 2 },
                    exit = androidx.compose.animation.slideOutVertically { it * 2 },
                    modifier =
                        Modifier
                            .align(Alignment.BottomEnd)
                            .windowInsetsPadding(
                                LocalPlayerAwareWindowInsets.current
                                    .only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal),
                            )
                            // Add padding to position it above the other FAB (56dp height + 16dp padding + 8dp spacing)
                            // If the other FAB is visible.
                            .padding(bottom = if (showLocalFab) 64.dp else 0.dp),
                ) {
                    val onPlayAllClick: () -> Unit = {
                        if (!isGuest) {
                            if (showLocal) {
                                if (librarySongs.isNotEmpty()) {
                                    playerConnection.playQueue(
                                        ListQueue(
                                            title = libraryArtist?.artist?.name ?: "Unknown Artist",
                                            items = librarySongs.map { it.toMediaItem() },
                                        ),
                                    )
                                }
                            } else if (artistPage != null) {
                                val songSection =
                                    artistPage.sections.find { section ->
                                        (section.items.firstOrNull() as? SongItem)?.album != null
                                    }

                                val moreEndpoint = songSection?.moreEndpoint
                                if (moreEndpoint != null) {
                                    coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                        val result = YouTube.artistItems(moreEndpoint).getOrNull()
                                        withContext(kotlinx.coroutines.Dispatchers.Main) {
                                            if (result != null && result.items.isNotEmpty()) {
                                                val songs = result.items.filterIsInstance<SongItem>().map { it.toMediaItem() }
                                                playerConnection.playQueue(
                                                    ListQueue(
                                                        title = artistPage.artist.title,
                                                        items = songs,
                                                    ),
                                                )
                                            } else {
                                                // Fallback to loaded items
                                                val songs = songSection.items.filterIsInstance<SongItem>().map { it.toMediaItem() }
                                                if (songs.isNotEmpty()) {
                                                    playerConnection.playQueue(
                                                        ListQueue(
                                                            title = artistPage.artist.title,
                                                            items = songs,
                                                        ),
                                                    )
                                                }
                                            }
                                        }
                                    }
                                } else if (songSection != null) {
                                    // Use loaded items if no more endpoint
                                    val songs = songSection.items.filterIsInstance<SongItem>().map { it.toMediaItem() }
                                    playerConnection.playQueue(
                                        ListQueue(
                                            title = artistPage.artist.title,
                                            items = songs,
                                        ),
                                    )
                                } else {
                                    // Fallback to shuffle endpoint (stripped) if no song section found
                                    val shuffleEndpoint = artistPage.artist.shuffleEndpoint
                                    if (shuffleEndpoint != null) {
                                        val endpoint =
                                            if (shuffleEndpoint.playlistId != null) {
                                                WatchEndpoint(
                                                    playlistId = shuffleEndpoint.playlistId,
                                                    params = null, // Remove shuffle params to play in order
                                                    videoId = null, // Ensure videoId is null to start from beginning of playlist
                                                )
                                            } else {
                                                shuffleEndpoint
                                            }
                                        playerConnection.playQueue(YouTubeQueue(endpoint))
                                    }
                                }
                            }
                        }
                    }

                    if (showLocalFab) {
                        androidx.compose.material3.SmallFloatingActionButton(
                            modifier = Modifier.padding(16.dp).offset(x = (-4).dp), // Align center with standard FAB (56dp vs 48dp)
                            onClick = onPlayAllClick,
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.play),
                                contentDescription = "Play All",
                            )
                        }
                    } else {
                        androidx.compose.material3.FloatingActionButton(
                            modifier = Modifier.padding(16.dp),
                            onClick = onPlayAllClick,
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.play),
                                contentDescription = "Play All",
                                modifier = Modifier.size(32.dp),
                            )
                        }
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier =
                Modifier
                    .windowInsetsPadding(LocalPlayerAwareWindowInsets.current)
                    .align(Alignment.BottomCenter),
        )
    }

    TopAppBar(
        title = {
            if (inSelectMode) {
                val count = if (showLocal) selectedLocalSongs.size else selectedYouTubeSongs.size
                Text(pluralStringResource(R.plurals.n_selected, count, count))
            } else if (!transparentAppBar) {
                Text(artistPage?.artist?.title.orEmpty())
            }
        },
        navigationIcon = {
            if (inSelectMode) {
                IconButton(
                    onClick = {
                        selectedLocalSongs.clear()
                        selectedYouTubeSongs.clear()
                    },
                ) {
                    Icon(
                        painter = painterResource(R.drawable.close),
                        contentDescription = null,
                    )
                }
            } else {
                IconButton(
                    onClick = navController::navigateUp,
                    onLongClick = navController::backToMain,
                ) {
                    Icon(
                        painterResource(R.drawable.arrow_back),
                        contentDescription = null,
                    )
                }
            }
        },
        actions = {
            if (inSelectMode) {
                if (showLocal) {
                    val allSelected = visibleLocalSongs.isNotEmpty() && selectedLocalSongs.size == visibleLocalSongs.size
                    Checkbox(
                        checked = allSelected,
                        onCheckedChange = {
                            if (allSelected) {
                                selectedLocalSongs.clear()
                            } else {
                                selectedLocalSongs.clear()
                                selectedLocalSongs.addAll(visibleLocalSongs.map { it.id })
                            }
                        },
                    )
                    IconButton(
                        enabled = selectedLocalSongs.isNotEmpty(),
                        onClick = {
                            val songsToQueue = visibleLocalSongs.filter { it.id in selectedLocalSongs }
                            playerConnection.addToQueue(songsToQueue.map { it.toMediaItem() })
                            Toast.makeText(context, R.string.added_to_queue, Toast.LENGTH_SHORT).show()
                            selectedLocalSongs.clear()
                        },
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.queue_music),
                            contentDescription = stringResource(R.string.add_to_queue),
                        )
                    }
                    IconButton(
                        enabled = selectedLocalSongs.isNotEmpty(),
                        onClick = {
                            val songsToPlayNext = visibleLocalSongs.filter { it.id in selectedLocalSongs }
                            playerConnection.playNext(songsToPlayNext.map { it.toMediaItem() })
                            Toast.makeText(context, R.string.play_next, Toast.LENGTH_SHORT).show()
                            selectedLocalSongs.clear()
                        },
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.play_arrow),
                            contentDescription = stringResource(R.string.play_next),
                        )
                    }
                    IconButton(
                        enabled = selectedLocalSongs.isNotEmpty(),
                        onClick = {
                            val songsForMenu = visibleLocalSongs.filter { it.id in selectedLocalSongs }
                            menuState.show {
                                SelectionSongMenu(
                                    songSelection = songsForMenu,
                                    onDismiss = menuState::dismiss,
                                    clearAction = { selectedLocalSongs.clear() },
                                )
                            }
                        },
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.more_vert),
                            contentDescription = null,
                        )
                    }
                } else {
                    val allSelected = visibleYouTubeSongs.isNotEmpty() && selectedYouTubeSongs.size == visibleYouTubeSongs.size
                    Checkbox(
                        checked = allSelected,
                        onCheckedChange = {
                            if (allSelected) {
                                selectedYouTubeSongs.clear()
                            } else {
                                selectedYouTubeSongs.clear()
                                selectedYouTubeSongs.addAll(visibleYouTubeSongs.map { it.id })
                            }
                        },
                    )
                    IconButton(
                        enabled = selectedYouTubeSongs.isNotEmpty(),
                        onClick = {
                            val songsToQueue = visibleYouTubeSongs.filter { it.id in selectedYouTubeSongs }
                            playerConnection.addToQueue(songsToQueue.map { it.toMediaItem() })
                            Toast.makeText(context, R.string.added_to_queue, Toast.LENGTH_SHORT).show()
                            selectedYouTubeSongs.clear()
                        },
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.queue_music),
                            contentDescription = stringResource(R.string.add_to_queue),
                        )
                    }
                    IconButton(
                        enabled = selectedYouTubeSongs.isNotEmpty(),
                        onClick = {
                            val songsToPlayNext = visibleYouTubeSongs.filter { it.id in selectedYouTubeSongs }
                            playerConnection.playNext(songsToPlayNext.map { it.toMediaItem() })
                            Toast.makeText(context, R.string.play_next, Toast.LENGTH_SHORT).show()
                            selectedYouTubeSongs.clear()
                        },
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.play_arrow),
                            contentDescription = stringResource(R.string.play_next),
                        )
                    }
                    IconButton(
                        enabled = selectedYouTubeSongs.isNotEmpty(),
                        onClick = {
                            val songsForMenu = visibleYouTubeSongs.filter { it.id in selectedYouTubeSongs }
                            menuState.show {
                                YouTubeSelectionSongMenu(
                                    songSelection = songsForMenu,
                                    onDismiss = menuState::dismiss,
                                    clearAction = { selectedYouTubeSongs.clear() },
                                )
                            }
                        },
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.more_vert),
                            contentDescription = null,
                        )
                    }
                }
            } else {
                IconButton(
                    onClick = {
                        viewModel.artistPage?.artist?.shareLink?.let { link ->
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Artist Link", link)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, R.string.link_copied, Toast.LENGTH_SHORT).show()
                        }
                    },
                ) {
                    Icon(
                        painterResource(R.drawable.link),
                        contentDescription = null,
                    )
                }
            }
        },
        colors =
            if (inSelectMode || !transparentAppBar) {
                TopAppBarDefaults.topAppBarColors()
            } else {
                TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            },
    )
}
