package com.metrolist.music.eq.data

/**
 * Predefined audio profiles and standard frequency bands
 */
object PresetEQProfiles {
    val defaultPresets = listOf(
        SavedEQProfile(
            id = "preset_bass_boost",
            name = "Bass Boost",
            deviceModel = "Preset • Low-End Enhancement",
            bands = listOf(
                ParametricEQBand(32.0, 6.0),
                ParametricEQBand(64.0, 5.5),
                ParametricEQBand(125.0, 4.0),
                ParametricEQBand(250.0, 2.0),
                ParametricEQBand(500.0, 0.0),
                ParametricEQBand(1000.0, 0.0),
                ParametricEQBand(2000.0, 0.0),
                ParametricEQBand(4000.0, 0.0),
                ParametricEQBand(8000.0, 0.0),
                ParametricEQBand(16000.0, 0.0)
            ),
            preamp = -3.0,
            source = "preset",
            isCustom = false
        ),
        SavedEQProfile(
            id = "preset_rock",
            name = "Rock",
            deviceModel = "Preset • Punchy & Crisp",
            bands = listOf(
                ParametricEQBand(32.0, 4.5),
                ParametricEQBand(64.0, 3.5),
                ParametricEQBand(125.0, 1.5),
                ParametricEQBand(250.0, -1.0),
                ParametricEQBand(500.0, -2.0),
                ParametricEQBand(1000.0, 0.5),
                ParametricEQBand(2000.0, 2.5),
                ParametricEQBand(4000.0, 3.5),
                ParametricEQBand(8000.0, 4.0),
                ParametricEQBand(16000.0, 4.5)
            ),
            preamp = -2.5,
            source = "preset",
            isCustom = false
        ),
        SavedEQProfile(
            id = "preset_jazz",
            name = "Jazz",
            deviceModel = "Preset • Warm & Smooth",
            bands = listOf(
                ParametricEQBand(32.0, 3.0),
                ParametricEQBand(64.0, 2.0),
                ParametricEQBand(125.0, 1.0),
                ParametricEQBand(250.0, 1.5),
                ParametricEQBand(500.0, -1.5),
                ParametricEQBand(1000.0, -1.5),
                ParametricEQBand(2000.0, 0.0),
                ParametricEQBand(4000.0, 1.5),
                ParametricEQBand(8000.0, 2.5),
                ParametricEQBand(16000.0, 3.0)
            ),
            preamp = -1.5,
            source = "preset",
            isCustom = false
        ),
        SavedEQProfile(
            id = "preset_pop",
            name = "Pop",
            deviceModel = "Preset • Mid-Range Focus",
            bands = listOf(
                ParametricEQBand(32.0, -1.0),
                ParametricEQBand(64.0, 2.0),
                ParametricEQBand(125.0, 4.0),
                ParametricEQBand(250.0, 5.0),
                ParametricEQBand(500.0, 3.0),
                ParametricEQBand(1000.0, -1.0),
                ParametricEQBand(2000.0, -2.0),
                ParametricEQBand(4000.0, -1.5),
                ParametricEQBand(8000.0, 1.0),
                ParametricEQBand(16000.0, 2.0)
            ),
            preamp = -2.0,
            source = "preset",
            isCustom = false
        ),
        SavedEQProfile(
            id = "preset_vocal",
            name = "Vocal Boost",
            deviceModel = "Preset • Clear Vocals",
            bands = listOf(
                ParametricEQBand(32.0, -2.0),
                ParametricEQBand(64.0, -1.5),
                ParametricEQBand(125.0, -1.0),
                ParametricEQBand(250.0, 1.0),
                ParametricEQBand(500.0, 3.5),
                ParametricEQBand(1000.0, 4.5),
                ParametricEQBand(2000.0, 4.0),
                ParametricEQBand(4000.0, 2.0),
                ParametricEQBand(8000.0, 0.0),
                ParametricEQBand(16000.0, -1.0)
            ),
            preamp = -2.0,
            source = "preset",
            isCustom = false
        ),
        SavedEQProfile(
            id = "preset_acoustic",
            name = "Acoustic",
            deviceModel = "Preset • Natural Instrument Balance",
            bands = listOf(
                ParametricEQBand(32.0, 3.0),
                ParametricEQBand(64.0, 3.0),
                ParametricEQBand(125.0, 2.0),
                ParametricEQBand(250.0, 1.0),
                ParametricEQBand(500.0, 1.5),
                ParametricEQBand(1000.0, 1.5),
                ParametricEQBand(2000.0, 2.0),
                ParametricEQBand(4000.0, 3.0),
                ParametricEQBand(8000.0, 2.5),
                ParametricEQBand(16000.0, 2.0)
            ),
            preamp = -1.5,
            source = "preset",
            isCustom = false
        ),
        SavedEQProfile(
            id = "preset_edm",
            name = "Electronic / EDM",
            deviceModel = "Preset • Sub-Bass & High Clarity",
            bands = listOf(
                ParametricEQBand(32.0, 5.5),
                ParametricEQBand(64.0, 5.0),
                ParametricEQBand(125.0, 2.0),
                ParametricEQBand(250.0, 0.0),
                ParametricEQBand(500.0, -2.0),
                ParametricEQBand(1000.0, 2.0),
                ParametricEQBand(2000.0, 1.0),
                ParametricEQBand(4000.0, 3.0),
                ParametricEQBand(8000.0, 4.5),
                ParametricEQBand(16000.0, 5.0)
            ),
            preamp = -3.0,
            source = "preset",
            isCustom = false
        ),
        SavedEQProfile(
            id = "preset_classical",
            name = "Classical",
            deviceModel = "Preset • Orchestral Dynamics",
            bands = listOf(
                ParametricEQBand(32.0, 4.0),
                ParametricEQBand(64.0, 3.0),
                ParametricEQBand(125.0, 2.0),
                ParametricEQBand(250.0, 2.0),
                ParametricEQBand(500.0, -1.0),
                ParametricEQBand(1000.0, -1.0),
                ParametricEQBand(2000.0, 0.0),
                ParametricEQBand(4000.0, 2.0),
                ParametricEQBand(8000.0, 3.0),
                ParametricEQBand(16000.0, 4.0)
            ),
            preamp = -2.0,
            source = "preset",
            isCustom = false
        ),
        SavedEQProfile(
            id = "preset_treble",
            name = "Treble Boost",
            deviceModel = "Preset • High-Frequency Brightness",
            bands = listOf(
                ParametricEQBand(32.0, 0.0),
                ParametricEQBand(64.0, 0.0),
                ParametricEQBand(125.0, 0.0),
                ParametricEQBand(250.0, 0.0),
                ParametricEQBand(500.0, 0.0),
                ParametricEQBand(1000.0, 1.0),
                ParametricEQBand(2000.0, 2.5),
                ParametricEQBand(4000.0, 4.5),
                ParametricEQBand(8000.0, 6.0),
                ParametricEQBand(16000.0, 6.5)
            ),
            preamp = -3.0,
            source = "preset",
            isCustom = false
        ),
        SavedEQProfile(
            id = "preset_flat",
            name = "Flat / Neutral",
            deviceModel = "Preset • Neutral Zero Response",
            bands = listOf(
                ParametricEQBand(32.0, 0.0),
                ParametricEQBand(64.0, 0.0),
                ParametricEQBand(125.0, 0.0),
                ParametricEQBand(250.0, 0.0),
                ParametricEQBand(500.0, 0.0),
                ParametricEQBand(1000.0, 0.0),
                ParametricEQBand(2000.0, 0.0),
                ParametricEQBand(4000.0, 0.0),
                ParametricEQBand(8000.0, 0.0),
                ParametricEQBand(16000.0, 0.0)
            ),
            preamp = 0.0,
            source = "preset",
            isCustom = false
        )
    )

    val standardFrequencies = listOf(32.0, 64.0, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0)

    fun createDefault10Bands(): List<ParametricEQBand> {
        return standardFrequencies.map { ParametricEQBand(frequency = it, gain = 0.0) }
    }
}
