package com.metrolist.music.ui.screens.equalizer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.metrolist.music.eq.EqualizerService
import com.metrolist.music.eq.data.EQProfileRepository
import com.metrolist.music.eq.data.ParametricEQ
import com.metrolist.music.eq.data.ParametricEQBand
import com.metrolist.music.eq.data.ParametricEQParser
import com.metrolist.music.eq.data.PresetEQProfiles
import com.metrolist.music.eq.data.SavedEQProfile
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.InputStream
import javax.inject.Inject

/**
 * ViewModel for EQ Screen
 * Manages EQ profiles, multi-band sliders, and applies them to EqualizerService
 */
@HiltViewModel
class EQViewModel @Inject constructor(
    private val eqProfileRepository: EQProfileRepository,
    private val equalizerService: EqualizerService
) : ViewModel() {

    private val _state = MutableStateFlow(EQState())
    val state: StateFlow<EQState> = _state.asStateFlow()

    init {
        loadProfiles()
    }

    /**
     * Load all saved EQ profiles and active profile
     */
    private fun loadProfiles() {
        viewModelScope.launch {
            eqProfileRepository.profiles.collect { _ ->
                val sortedProfiles = eqProfileRepository.getSortedProfiles()
                _state.update {
                    it.copy(profiles = sortedProfiles)
                }
            }
        }

        viewModelScope.launch {
            eqProfileRepository.activeProfile.collect { activeProfile ->
                val isEnabled = activeProfile != null
                val bands = activeProfile?.bands ?: PresetEQProfiles.createDefault10Bands()
                val preamp = activeProfile?.preamp ?: 0.0

                _state.update {
                    it.copy(
                        activeProfileId = activeProfile?.id,
                        isEqualizerEnabled = isEnabled,
                        currentBands = if (bands.isNotEmpty()) bands else PresetEQProfiles.createDefault10Bands(),
                        currentPreamp = preamp
                    )
                }
            }
        }
    }

    /**
     * Master toggle for Equalizer
     */
    fun setEqualizerEnabled(enabled: Boolean) {
        viewModelScope.launch {
            if (!enabled) {
                equalizerService.disable()
                eqProfileRepository.setActiveProfile(null)
                _state.update { it.copy(isEqualizerEnabled = false, activeProfileId = null) }
            } else {
                // Re-enable with currently selected profile or Flat preset by default
                val targetId = _state.value.activeProfileId ?: "preset_flat"
                selectProfile(targetId)
            }
        }
    }

    /**
     * Select and apply an EQ profile (Preset or Custom)
     */
    fun selectProfile(profileId: String?) {
        viewModelScope.launch {
            if (profileId == null) {
                equalizerService.disable()
                eqProfileRepository.setActiveProfile(null)
                _state.update {
                    it.copy(
                        activeProfileId = null,
                        isEqualizerEnabled = false
                    )
                }
            } else {
                val allProfiles = eqProfileRepository.getAllProfiles()
                val profile = allProfiles.find { it.id == profileId }
                if (profile != null) {
                    val result = equalizerService.applyProfile(profile)
                    result.onSuccess {
                        eqProfileRepository.setActiveProfile(profileId)
                        _state.update {
                            it.copy(
                                activeProfileId = profileId,
                                isEqualizerEnabled = true,
                                currentBands = profile.bands,
                                currentPreamp = profile.preamp
                            )
                        }
                    }.onFailure { e ->
                        _state.update { it.copy(error = e.message ?: "Unknown error") }
                    }
                }
            }
        }
    }

    /**
     * Update an individual band gain in real-time
     */
    fun updateBandGain(frequency: Double, gain: Double) {
        viewModelScope.launch {
            val existingBands = _state.value.currentBands.toMutableList()
            val index = existingBands.indexOfFirst { it.frequency == frequency }

            if (index >= 0) {
                existingBands[index] = existingBands[index].copy(gain = gain)
            } else {
                existingBands.add(ParametricEQBand(frequency = frequency, gain = gain))
            }

            // Ensure sorted by frequency
            existingBands.sortBy { it.frequency }

            val preamp = _state.value.currentPreamp
            val customLiveProfile = SavedEQProfile(
                id = "custom_live",
                name = "Custom Tuning",
                deviceModel = "Custom Tuning",
                bands = existingBands,
                preamp = preamp,
                isCustom = true
            )

            val result = equalizerService.applyProfile(customLiveProfile)
            result.onSuccess {
                _state.update {
                    it.copy(
                        currentBands = existingBands,
                        isEqualizerEnabled = true,
                        activeProfileId = null // Indicates custom live tuning
                    )
                }
            }.onFailure { e ->
                _state.update { it.copy(error = e.message ?: "Failed to apply custom band") }
            }
        }
    }

    /**
     * Update preamp gain
     */
    fun updatePreamp(preamp: Double) {
        viewModelScope.launch {
            val bands = _state.value.currentBands
            val customLiveProfile = SavedEQProfile(
                id = "custom_live",
                name = "Custom Tuning",
                deviceModel = "Custom Tuning",
                bands = bands,
                preamp = preamp,
                isCustom = true
            )

            equalizerService.applyProfile(customLiveProfile)
            _state.update {
                it.copy(currentPreamp = preamp)
            }
        }
    }

    /**
     * Save the current active band gains as a new custom preset profile
     */
    fun saveCurrentAsCustomProfile(profileName: String) {
        if (profileName.isBlank()) return
        viewModelScope.launch {
            val bands = _state.value.currentBands
            val preamp = _state.value.currentPreamp
            val parametricEQ = ParametricEQ(preamp = preamp, bands = bands)
            eqProfileRepository.importCustomProfile(profileName.trim(), parametricEQ)
            _state.update { it.copy(importStatus = "Saved custom profile: $profileName") }
        }
    }

    /**
     * Reset all bands to Flat (0 dB)
     */
    fun resetToFlat() {
        selectProfile("preset_flat")
    }

    /**
     * Clear error message
     */
    fun clearError() {
        _state.update { it.copy(error = null) }
    }

    /**
     * Delete an EQ profile
     */
    fun deleteProfile(profileId: String) {
        viewModelScope.launch {
            eqProfileRepository.deleteProfile(profileId)
        }
    }

    /**
     * Import a custom EQ profile from a file
     */
    fun importCustomProfile(
        fileName: String,
        inputStream: InputStream,
        onSuccess: () -> Unit,
        onError: (Exception) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val content = inputStream.bufferedReader().use { it.readText() }
                inputStream.close()

                val parametricEQ = ParametricEQParser.parseText(content)
                val validationErrors = ParametricEQParser.validate(parametricEQ)
                if (validationErrors.isNotEmpty()) {
                    onError(Exception("Invalid EQ file: ${validationErrors.first()}"))
                    return@launch
                }

                val profileName = fileName.removeSuffix(".txt")
                eqProfileRepository.importCustomProfile(profileName, parametricEQ)

                _state.update { it.copy(importStatus = "Successfully imported $profileName") }
                onSuccess()
            } catch (e: Exception) {
                onError(Exception("Failed to import EQ profile: ${e.message}"))
            }
        }
    }
}
