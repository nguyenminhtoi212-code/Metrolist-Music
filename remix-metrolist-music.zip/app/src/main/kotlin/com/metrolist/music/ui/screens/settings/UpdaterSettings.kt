/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import android.os.Environment
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberTopAppBarState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.metrolist.music.BuildConfig
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.constants.CheckForUpdatesKey
import com.metrolist.music.constants.InstallationMethodKey
import com.metrolist.music.constants.NightlyBuildsKey
import com.metrolist.music.constants.UpdateInstalledNotificationEnabledKey
import com.metrolist.music.constants.UpdateNotificationSoundEnabledKey
import com.metrolist.music.constants.UpdateNotificationSoundTypeKey
import com.metrolist.music.constants.UpdateNotificationsEnabledKey
import com.metrolist.music.ui.component.AppUpdateStatusDot
import com.metrolist.music.ui.component.EnumDialog
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.AppUpdateStatus
import com.metrolist.music.utils.AppUpdateStatusHelper
import com.metrolist.music.utils.UpdateNotificationHelper
import com.metrolist.music.utils.UpdateSoundType
import com.metrolist.music.utils.Updater
import com.metrolist.music.utils.UpdaterAnalytics
import com.metrolist.music.utils.rememberPreference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class UpdateStatus {
    IDLE,
    CHECKING,
    UP_TO_DATE,
    UPDATE_AVAILABLE,
    ERROR
}

private enum class InstallMethod(val key: String, val titleRes: Int, val descRes: Int) {
    STANDARD("Standard", R.string.updater_install_method_standard, R.string.updater_install_method_standard_desc),
    ROOT("Root", R.string.updater_install_method_root, R.string.updater_install_method_root_desc),
    SESSION("Session", R.string.updater_install_method_session, R.string.updater_install_method_session_desc)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UpdaterScreen(
    navController: NavController
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val scrollBehavior = TopAppBarDefaults.pinnedScrollBehavior(rememberTopAppBarState())

    var (checkForUpdates, onCheckForUpdatesChange) = rememberPreference(
        key = CheckForUpdatesKey,
        defaultValue = true
    )
    var (updateNotifications, onUpdateNotificationsChange) = rememberPreference(
        key = UpdateNotificationsEnabledKey,
        defaultValue = true
    )
    var (updateNotificationSound, onUpdateNotificationSoundChange) = rememberPreference(
        key = UpdateNotificationSoundEnabledKey,
        defaultValue = true
    )
    var (updateNotificationSoundTypeKey, onUpdateNotificationSoundTypeKeyChange) = rememberPreference(
        key = UpdateNotificationSoundTypeKey,
        defaultValue = UpdateSoundType.DEFAULT.key
    )
    var (updateInstalledNotification, onUpdateInstalledNotificationChange) = rememberPreference(
        key = UpdateInstalledNotificationEnabledKey,
        defaultValue = true
    )
    var (nightlyBuilds, onNightlyBuildsChange) = rememberPreference(
        key = NightlyBuildsKey,
        defaultValue = false
    )
    var (installationMethodKey, onInstallationMethodKeyChange) = rememberPreference(
        key = InstallationMethodKey,
        defaultValue = "Standard"
    )

    var status by remember { mutableStateOf(UpdateStatus.IDLE) }
    var latestVersionTag by remember { mutableStateOf("v${BuildConfig.VERSION_NAME}") }
    var showInstallMethodDialog by remember { mutableStateOf(false) }
    var showSoundDialog by remember { mutableStateOf(false) }
    var showChangelogDialog by remember { mutableStateOf(false) }

    val persistentUpdateStatus by remember(context) {
        AppUpdateStatusHelper.observeUpdateStatus(context)
    }.collectAsStateWithLifecycle(
        initialValue = AppUpdateStatus(
            isUpToDate = true,
            hasDetectedUpdate = false,
            latestVersion = BuildConfig.VERSION_NAME,
            lastCheckedTimeMs = 0L,
            source = "",
            downloadUrl = null,
            releaseNotes = null
        )
    )
    val relativeTime = remember(persistentUpdateStatus.lastCheckedTimeMs) {
        AppUpdateStatusHelper.formatLastCheckedRelative(context, persistentUpdateStatus.lastCheckedTimeMs)
    }
    val sourceLabel = remember(persistentUpdateStatus.source) {
        AppUpdateStatusHelper.getSourceLabel(context, persistentUpdateStatus.source)
    }

    val errorRed = Color(0xFFB3261E)
    val buttonTeal = Color(0xFF1E5E53)

    val currentInstallMethod = InstallMethod.values().firstOrNull {
        it.key.equals(installationMethodKey, ignoreCase = true) || it.name.equals(installationMethodKey, ignoreCase = true)
    } ?: InstallMethod.STANDARD

    val currentSoundType = UpdateSoundType.values().firstOrNull {
        it.key.equals(updateNotificationSoundTypeKey, ignoreCase = true) || it.name.equals(updateNotificationSoundTypeKey, ignoreCase = true)
    } ?: UpdateSoundType.DEFAULT

    val chevronTrailing: @Composable () -> Unit = {
        Icon(
            painter = painterResource(R.drawable.navigate_next),
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.size(20.dp)
        )
    }

    var lastCheckClickTime by remember { mutableStateOf(0L) }
    var isTransitionSettled by remember { mutableStateOf(false) }

    fun performCheck() {
        val currentTime = android.os.SystemClock.elapsedRealtime()
        if (!isTransitionSettled || status == UpdateStatus.CHECKING) return
        if (currentTime - lastCheckClickTime < 1200L) return
        lastCheckClickTime = currentTime
        status = UpdateStatus.CHECKING

        coroutineScope.launch {
            delay(350)
            withContext(Dispatchers.IO) {
                try {
                    val (isUpToDate, latestTag) = Updater.checkUpToDateWithChangelog(context)
                    latestVersionTag = latestTag
                    val latestVersion = latestTag.removePrefix("v")

                    UpdaterAnalytics.logUpdateCheck(
                        context = context,
                        source = "manual_settings",
                        success = true,
                        hasUpdate = !isUpToDate,
                        latestVersion = latestVersion
                    )
                    if (!isUpToDate) {
                        UpdaterAnalytics.logNewVersionDetected(
                            context = context,
                            latestVersion = latestVersion,
                            source = "manual_settings",
                            versionTag = latestTag
                        )
                    }

                    withContext(Dispatchers.Main) {
                        if (isUpToDate) {
                            status = UpdateStatus.UP_TO_DATE
                            Toast.makeText(
                                context,
                                context.getString(R.string.app_is_up_to_date, latestTag),
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            status = UpdateStatus.UPDATE_AVAILABLE
                            Toast.makeText(
                                context,
                                context.getString(R.string.app_update_available_toast, latestTag),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                } catch (e: Exception) {
                    UpdaterAnalytics.logUpdateCheck(
                        context = context,
                        source = "manual_settings",
                        success = false,
                        hasUpdate = false,
                        errorMessage = e.message
                    )
                    withContext(Dispatchers.Main) {
                        status = UpdateStatus.ERROR
                        Toast.makeText(
                            context,
                            context.getString(R.string.cant_check_for_updates),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }
    }

    // Đợi chuyển trang ổn định trước khi cho phép kiểm tra cập nhật tự động hoặc thủ công
    LaunchedEffect(Unit) {
        delay(500)
        isTransitionSettled = true
        if (checkForUpdates) {
            performCheck()
        }
    }

    fun cleanDownloadedApks() {
        coroutineScope.launch(Dispatchers.IO) {
            var deletedCount = 0
            try {
                val cacheDir = context.cacheDir
                val externalCacheDir = context.externalCacheDir
                val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)

                val dirsToCheck = listOfNotNull(cacheDir, externalCacheDir, downloadDir)
                for (dir in dirsToCheck) {
                    if (dir.exists() && dir.isDirectory) {
                        val apks = dir.listFiles { file -> file.isFile && file.name.endsWith(".apk", ignoreCase = true) }
                        apks?.forEach { file ->
                            if (file.name.contains("Metrolist", ignoreCase = true) || file.name.contains("music", ignoreCase = true)) {
                                if (file.delete()) deletedCount++
                            }
                        }
                    }
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        context.getString(R.string.updater_clean_apk_toast, deletedCount),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        context.getString(R.string.updater_clean_apk_error_toast, e.localizedMessage ?: "Unknown"),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    if (showChangelogDialog) {
        ChangelogScreen(
            onDismiss = { showChangelogDialog = false }
        )
    }

    if (showInstallMethodDialog) {
        EnumDialog(
            onDismiss = { showInstallMethodDialog = false },
            onSelect = { method ->
                onInstallationMethodKeyChange(method.key)
                showInstallMethodDialog = false
            },
            title = stringResource(R.string.updater_install_method_dialog_title),
            current = currentInstallMethod,
            values = InstallMethod.values().toList(),
            valueText = { stringResource(it.titleRes) },
            valueDescription = { stringResource(it.descRes) }
        )
    }

    if (showSoundDialog) {
        EnumDialog(
            onDismiss = { showSoundDialog = false },
            onSelect = { sound ->
                onUpdateNotificationSoundTypeKeyChange(sound.key)
                UpdateNotificationHelper.playSoundPreview(context, sound)
                showSoundDialog = false
            },
            title = stringResource(R.string.updater_sound_type_dialog_title),
            current = currentSoundType,
            values = UpdateSoundType.values().toList(),
            valueText = { stringResource(it.titleRes) },
            valueDescription = { stringResource(it.descRes) }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.updater),
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = navController::navigateUp,
                        onLongClick = navController::backToMain
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.arrow_back),
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                scrollBehavior = scrollBehavior
            )
        },
        contentWindowInsets = LocalPlayerAwareWindowInsets.current
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 24.dp)
        ) {
            // 1. Thẻ trạng thái nổi bật (Hero Status Card)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Biểu tượng trạng thái hình tròn
                    Surface(
                        shape = CircleShape,
                        color = when (status) {
                            UpdateStatus.CHECKING -> MaterialTheme.colorScheme.primaryContainer
                            UpdateStatus.UP_TO_DATE -> buttonTeal
                            UpdateStatus.UPDATE_AVAILABLE -> buttonTeal
                            UpdateStatus.ERROR -> errorRed
                            UpdateStatus.IDLE -> buttonTeal
                        },
                        modifier = Modifier.size(80.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            when (status) {
                                UpdateStatus.CHECKING -> {
                                    CircularProgressIndicator(
                                        color = buttonTeal,
                                        strokeWidth = 3.dp,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                                UpdateStatus.UP_TO_DATE, UpdateStatus.IDLE -> {
                                    Icon(
                                        painter = painterResource(R.drawable.check),
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(38.dp)
                                    )
                                }
                                UpdateStatus.UPDATE_AVAILABLE -> {
                                    Icon(
                                        painter = painterResource(R.drawable.download),
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                                UpdateStatus.ERROR -> {
                                    Text(
                                        text = "!",
                                        fontSize = 42.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Dòng trạng thái chính
                    Text(
                        text = when (status) {
                            UpdateStatus.CHECKING -> stringResource(R.string.checking_for_updates)
                            UpdateStatus.UP_TO_DATE -> stringResource(R.string.updater_up_to_date)
                            UpdateStatus.UPDATE_AVAILABLE -> stringResource(R.string.new_update_available_title)
                            UpdateStatus.ERROR -> stringResource(R.string.cant_check_for_updates)
                            UpdateStatus.IDLE -> stringResource(R.string.updater_up_to_date)
                        },
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        color = when (status) {
                            UpdateStatus.ERROR -> errorRed
                            UpdateStatus.UPDATE_AVAILABLE -> buttonTeal
                            UpdateStatus.UP_TO_DATE -> buttonTeal
                            UpdateStatus.IDLE -> buttonTeal
                            else -> MaterialTheme.colorScheme.onSurface
                        },
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Phiên bản hiện tại & release - GMS
                    Text(
                        text = stringResource(R.string.updater_version_label, BuildConfig.VERSION_NAME) + " • " + stringResource(R.string.updater_build_variant),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Persistent background check status indicator
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AppUpdateStatusDot(
                            status = persistentUpdateStatus,
                            dotSize = 8.dp,
                            showPulseWhenUpdateAvailable = true
                        )
                        Text(
                            text = if (persistentUpdateStatus.lastCheckedTimeMs > 0L) {
                                "$relativeTime ($sourceLabel)"
                            } else {
                                stringResource(R.string.updater_status_never_checked)
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Nút bấm kiểm tra bản cập nhật
                    Button(
                        onClick = { performCheck() },
                        enabled = isTransitionSettled && status != UpdateStatus.CHECKING,
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = buttonTeal,
                            disabledContainerColor = buttonTeal.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        if (status == UpdateStatus.CHECKING) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.checking_for_updates),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                            )
                        } else {
                            Icon(
                                painter = painterResource(R.drawable.refresh),
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.check_for_update_btn),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 2. Nhóm Cập nhật ứng dụng (App Updates)
            Material3SettingsGroup(
                title = stringResource(R.string.updater_group_title),
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.update),
                        title = { Text(stringResource(R.string.updater_system_update_title)) },
                        description = {
                            Text(
                                when (status) {
                                    UpdateStatus.UP_TO_DATE -> stringResource(R.string.updater_up_to_date)
                                    UpdateStatus.UPDATE_AVAILABLE -> stringResource(R.string.new_update_available_title)
                                    UpdateStatus.CHECKING -> stringResource(R.string.checking_for_updates)
                                    UpdateStatus.ERROR -> stringResource(R.string.cant_check_for_updates)
                                    UpdateStatus.IDLE -> stringResource(R.string.updater_up_to_date)
                                }
                            )
                        },
                        trailingContent = chevronTrailing,
                        onClick = {
                            if (isTransitionSettled && status != UpdateStatus.CHECKING) {
                                performCheck()
                            }
                        }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.info),
                        title = { Text(stringResource(R.string.updater_version_label, BuildConfig.VERSION_NAME)) },
                        description = { Text(stringResource(R.string.updater_build_variant)) },
                        onClick = {
                            Toast.makeText(
                                context,
                                context.getString(R.string.updater_version_label, BuildConfig.VERSION_NAME) + " (" + context.getString(R.string.updater_build_variant) + ")",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.bug_report),
                        title = { Text(stringResource(R.string.updater_nightly_builds_title)) },
                        description = { Text(stringResource(R.string.updater_nightly_builds_desc)) },
                        trailingContent = {
                            Switch(
                                checked = nightlyBuilds,
                                onCheckedChange = onNightlyBuildsChange
                            )
                        },
                        onClick = { onNightlyBuildsChange(!nightlyBuilds) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.download),
                        title = { Text(stringResource(R.string.updater_install_method_title)) },
                        description = { Text(stringResource(currentInstallMethod.titleRes)) },
                        trailingContent = chevronTrailing,
                        onClick = { showInstallMethodDialog = true }
                    )
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Nhóm Tùy chọn khác (More Options)
            Material3SettingsGroup(
                title = stringResource(R.string.more_options),
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.sync),
                        title = { Text(stringResource(R.string.updater_auto_check_title)) },
                        description = { Text(stringResource(R.string.updater_auto_check_desc)) },
                        trailingContent = {
                            Switch(
                                checked = checkForUpdates,
                                onCheckedChange = onCheckForUpdatesChange
                            )
                        },
                        onClick = { onCheckForUpdatesChange(!checkForUpdates) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.notification),
                        title = { Text(stringResource(R.string.updater_notif_title)) },
                        description = { Text(stringResource(R.string.updater_notif_desc)) },
                        trailingContent = {
                            Switch(
                                checked = updateNotifications,
                                onCheckedChange = onUpdateNotificationsChange
                            )
                        },
                        onClick = { onUpdateNotificationsChange(!updateNotifications) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.volume_up),
                        title = { Text(stringResource(R.string.updater_sound_title)) },
                        description = { Text(stringResource(R.string.updater_sound_desc)) },
                        enabled = updateNotifications,
                        trailingContent = {
                            Switch(
                                checked = updateNotificationSound,
                                onCheckedChange = onUpdateNotificationSoundChange,
                                enabled = updateNotifications
                            )
                        },
                        onClick = {
                            if (updateNotifications) {
                                onUpdateNotificationSoundChange(!updateNotificationSound)
                            }
                        }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.tune),
                        title = { Text(stringResource(R.string.updater_sound_type_title)) },
                        description = { Text(stringResource(currentSoundType.titleRes)) },
                        enabled = updateNotifications && updateNotificationSound,
                        trailingContent = chevronTrailing,
                        onClick = {
                            if (updateNotifications && updateNotificationSound) {
                                showSoundDialog = true
                            }
                        }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.check),
                        title = { Text(stringResource(R.string.updater_notify_installed_title)) },
                        description = { Text(stringResource(R.string.updater_notify_installed_desc)) },
                        trailingContent = {
                            Switch(
                                checked = updateInstalledNotification,
                                onCheckedChange = onUpdateInstalledNotificationChange
                            )
                        },
                        onClick = { onUpdateInstalledNotificationChange(!updateInstalledNotification) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.settings),
                        title = { Text(stringResource(R.string.updater_channel_settings_title)) },
                        description = { Text(stringResource(R.string.updater_channel_settings_desc)) },
                        trailingContent = chevronTrailing,
                        onClick = {
                            UpdateNotificationHelper.openNotificationChannelSettings(context)
                        }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.music_note),
                        title = { Text(stringResource(R.string.updater_test_alert_title)) },
                        description = { Text(stringResource(R.string.updater_test_alert_desc)) },
                        onClick = {
                            UpdateNotificationHelper.sendTestNotification(
                                context = context,
                                isInstalledTest = false,
                                soundEnabled = updateNotificationSound,
                                soundType = currentSoundType
                            )
                            Toast.makeText(
                                context,
                                context.getString(R.string.updater_test_alert_toast),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.trending_up),
                        title = { Text(stringResource(R.string.release_diff_title)) },
                        description = { Text(stringResource(R.string.release_diff_desc)) },
                        trailingContent = chevronTrailing,
                        onClick = { navController.navigate("settings/updater/release_diff") }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.history),
                        title = { Text(stringResource(R.string.version_history_title)) },
                        description = { Text(stringResource(R.string.version_history_desc)) },
                        trailingContent = chevronTrailing,
                        onClick = { showChangelogDialog = true }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.delete),
                        title = { Text(stringResource(R.string.updater_clean_apk_title)) },
                        description = { Text(stringResource(R.string.updater_clean_apk_desc)) },
                        onClick = { cleanDownloadedApks() }
                    )
                )
            )
        }
    }
}
