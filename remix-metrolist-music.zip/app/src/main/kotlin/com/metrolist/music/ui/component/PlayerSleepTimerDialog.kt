/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */
package com.metrolist.music.ui.component

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.graphics.Color
import com.metrolist.music.R
import com.metrolist.music.constants.EnableLiquidGlassKey
import com.metrolist.music.constants.GlassSaturationKey
import com.metrolist.music.constants.GlassBlurRadiusKey
import com.metrolist.music.constants.LensRefractionHeightKey
import com.metrolist.music.constants.LensRefractionAmountKey
import com.metrolist.music.constants.ChromaticAberrationKey
import com.metrolist.music.constants.DepthEffectKey
import com.metrolist.music.constants.SurfaceOpacityKey
import com.metrolist.music.constants.PureBlackKey
import com.metrolist.music.constants.SleepTimerDefaultKey
import com.metrolist.music.constants.SleepTimerFadeOutKey
import com.metrolist.music.constants.SleepTimerStopAfterCurrentSongKey
import com.metrolist.music.playback.PlayerConnection
import com.metrolist.music.ui.components.liquidGlass
import com.metrolist.music.utils.makeTimeString
import com.metrolist.music.utils.rememberPreference
import com.metrolist.music.utils.safeDataStoreEdit
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PlayerSleepTimerDialog(
    isVisible: Boolean,
    onDismiss: () -> Unit,
    playerConnection: PlayerConnection,
) {
    if (!isVisible) return

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val sleepTimer = playerConnection.service.sleepTimer

    val isTimerActive = remember(sleepTimer?.triggerTime, sleepTimer?.pauseWhenSongEnd) {
        sleepTimer?.isActive == true
    }

    var remainingTimeMs by remember { mutableLongStateOf(0L) }

    LaunchedEffect(isTimerActive, sleepTimer?.triggerTime, sleepTimer?.pauseWhenSongEnd) {
        if (isTimerActive && sleepTimer != null) {
            while (true) {
                remainingTimeMs = if (sleepTimer.pauseWhenSongEnd) {
                    (playerConnection.player.duration - playerConnection.player.currentPosition).coerceAtLeast(0L)
                } else {
                    (sleepTimer.triggerTime - System.currentTimeMillis()).coerceAtLeast(0L)
                }
                delay(1000L)
            }
        }
    }

    val sleepTimerDefault by rememberPreference(SleepTimerDefaultKey, 30f)
    var sleepTimerValue by remember { mutableFloatStateOf(sleepTimerDefault) }
    var stopAfterCurrentSong by rememberPreference(SleepTimerStopAfterCurrentSongKey, false)
    var fadeOut by rememberPreference(SleepTimerFadeOutKey, false)

    val enableLiquidGlass by rememberPreference(EnableLiquidGlassKey, defaultValue = true)
    val glassSaturation by rememberPreference(GlassSaturationKey, defaultValue = 1.3f)
    val glassBlurRadius by rememberPreference(GlassBlurRadiusKey, defaultValue = 24f)
    val lensRefractionHeight by rememberPreference(LensRefractionHeightKey, defaultValue = 14f)
    val lensRefractionAmount by rememberPreference(LensRefractionAmountKey, defaultValue = 0.85f)
    val chromaticAberration by rememberPreference(ChromaticAberrationKey, defaultValue = 0.45f)
    val depthEffect by rememberPreference(DepthEffectKey, defaultValue = 0.75f)
    val surfaceOpacity by rememberPreference(SurfaceOpacityKey, defaultValue = 1.0f)
    val pureBlack by rememberPreference(PureBlackKey, defaultValue = false)

    val dialogBgColor = if (pureBlack) Color.Black else MaterialTheme.colorScheme.surfaceContainerHigh

    val isAtDefault by remember {
        derivedStateOf { sleepTimerValue.roundToInt() == sleepTimerDefault.roundToInt() }
    }

    AlertDialog(
        modifier = Modifier
            .padding(horizontal = 16.dp)
            .then(
                if (enableLiquidGlass) {
                    Modifier.liquidGlass(
                        enabled = true,
                        blurRadiusDp = glassBlurRadius,
                        saturation = glassSaturation,
                        refractionHeight = lensRefractionHeight,
                        refractionAmount = lensRefractionAmount,
                        chromaticAberration = chromaticAberration,
                        depthEffect = depthEffect,
                        surfaceOpacity = surfaceOpacity,
                        surfaceTintColor = dialogBgColor,
                        shape = RoundedCornerShape(28.dp)
                    )
                } else {
                    Modifier.background(dialogBgColor, shape = RoundedCornerShape(28.dp))
                }
            ),
        containerColor = Color.Transparent,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                painter = painterResource(R.drawable.bedtime),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
            )
        },
        title = {
            Text(
                text = stringResource(R.string.sleep_timer),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        },
        confirmButton = {
            if (isTimerActive) {
                OutlinedButton(
                    onClick = {
                        sleepTimer?.clear()
                        Toast.makeText(context, "Sleep timer turned off", Toast.LENGTH_SHORT).show()
                        onDismiss()
                    },
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("Turn Off")
                }
            } else {
                Button(
                    onClick = {
                        sleepTimer?.start(
                            minute = sleepTimerValue.roundToInt(),
                            stopAfterCurrentSong = stopAfterCurrentSong,
                            fadeOut = fadeOut,
                        )
                        Toast.makeText(
                            context,
                            "Sleep timer set for ${sleepTimerValue.roundToInt()} minutes",
                            Toast.LENGTH_SHORT
                        ).show()
                        onDismiss()
                    }
                ) {
                    Text(stringResource(android.R.string.ok))
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(android.R.string.cancel))
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Active Sleep Timer Banner
                AnimatedVisibility(
                    visible = isTimerActive,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Active Sleep Timer",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (sleepTimer?.pauseWhenSongEnd == true) "End of current song" else makeTimeString(remainingTimeMs),
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Quick Extension",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = {
                                        sleepTimer?.addMinutes(5)
                                        Toast.makeText(context, "+5 minutes added", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.surface,
                                        contentColor = MaterialTheme.colorScheme.onSurface
                                    )
                                ) {
                                    Text("+5m")
                                }
                                Button(
                                    onClick = {
                                        sleepTimer?.addMinutes(15)
                                        Toast.makeText(context, "+15 minutes added", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.surface,
                                        contentColor = MaterialTheme.colorScheme.onSurface
                                    )
                                ) {
                                    Text("+15m")
                                }
                                Button(
                                    onClick = {
                                        sleepTimer?.addMinutes(30)
                                        Toast.makeText(context, "+30 minutes added", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.surface,
                                        contentColor = MaterialTheme.colorScheme.onSurface
                                    )
                                ) {
                                    Text("+30m")
                                }
                            }
                        }
                    }
                }

                // Preset Chips Row
                Text(
                    text = "Quick Presets",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.Start)
                )
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val presets = listOf(15, 30, 45, 60, 90)
                    presets.forEach { minutes ->
                        FilterChip(
                            selected = (sleepTimerValue.roundToInt() == minutes),
                            onClick = {
                                sleepTimerValue = minutes.toFloat()
                                if (isTimerActive) {
                                    sleepTimer?.start(
                                        minute = minutes,
                                        stopAfterCurrentSong = stopAfterCurrentSong,
                                        fadeOut = fadeOut
                                    )
                                    Toast.makeText(context, "Timer set to $minutes minutes", Toast.LENGTH_SHORT).show()
                                }
                            },
                            label = { Text("$minutes min") }
                        )
                    }
                    FilterChip(
                        selected = false,
                        onClick = {
                            sleepTimer?.start(minute = -1)
                            Toast.makeText(context, "Stopping at end of current song", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        },
                        label = { Text(stringResource(R.string.end_of_song)) }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Slider duration selection
                Text(
                    text = pluralStringResource(
                        R.plurals.minute,
                        sleepTimerValue.roundToInt(),
                        sleepTimerValue.roundToInt(),
                    ),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Slider(
                    value = sleepTimerValue,
                    onValueChange = { sleepTimerValue = it },
                    valueRange = 5f..120f,
                    steps = (120 - 5) / 5 - 1,
                    modifier = Modifier.fillMaxWidth()
                )

                val defaultSetTemplate = stringResource(R.string.sleep_timer_default_set)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = {
                            coroutineScope.launch {
                                context.safeDataStoreEdit { settings ->
                                    settings[SleepTimerDefaultKey] = sleepTimerValue
                                }
                            }
                            val msg = String.format(
                                defaultSetTemplate,
                                sleepTimerValue.roundToInt()
                            )
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Text(
                            text = if (isAtDefault) "Default (${sleepTimerValue.roundToInt()}m)" else stringResource(R.string.set_as_default),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Options / Toggles
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Stop after current song toggle
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val newValue = !stopAfterCurrentSong
                                    stopAfterCurrentSong = newValue
                                    coroutineScope.launch {
                                        context.safeDataStoreEdit { settings ->
                                            settings[SleepTimerStopAfterCurrentSongKey] = newValue
                                        }
                                    }
                                    sleepTimer?.toggleStopAfterCurrentSong(newValue)
                                },
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.sleep_timer_stop_after_current_song_title),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = stringResource(R.string.sleep_timer_stop_after_current_song_description),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = stopAfterCurrentSong,
                                onCheckedChange = { newValue ->
                                    stopAfterCurrentSong = newValue
                                    coroutineScope.launch {
                                        context.safeDataStoreEdit { settings ->
                                            settings[SleepTimerStopAfterCurrentSongKey] = newValue
                                        }
                                    }
                                    sleepTimer?.toggleStopAfterCurrentSong(newValue)
                                }
                            )
                        }

                        // Fade out toggle
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val newValue = !fadeOut
                                    fadeOut = newValue
                                    coroutineScope.launch {
                                        context.safeDataStoreEdit { settings ->
                                            settings[SleepTimerFadeOutKey] = newValue
                                        }
                                    }
                                    sleepTimer?.toggleFadeOut(newValue)
                                },
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.sleep_timer_fade_out_title),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = stringResource(R.string.sleep_timer_fade_out_description),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = fadeOut,
                                onCheckedChange = { newValue ->
                                    fadeOut = newValue
                                    coroutineScope.launch {
                                        context.safeDataStoreEdit { settings ->
                                            settings[SleepTimerFadeOutKey] = newValue
                                        }
                                    }
                                    sleepTimer?.toggleFadeOut(newValue)
                                }
                            )
                        }
                    }
                }
            }
        }
    )
}
