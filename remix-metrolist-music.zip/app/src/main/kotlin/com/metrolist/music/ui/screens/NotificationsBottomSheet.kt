/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.metrolist.music.R
import com.metrolist.music.constants.NotificationsReadIdsKey
import com.metrolist.music.utils.rememberPreference
import com.metrolist.music.LocalPlayerConnection
import com.metrolist.music.LocalListenTogetherManager

@Immutable
data class NotificationItem(
    val id: String,
    val title: String,
    val description: String,
    val time: String,
    val iconRes: Int,
    val iconColor: Color,
    val route: String? = null
)

private fun formatEventTime(context: android.content.Context, timestamp: java.time.LocalDateTime): String {
    return try {
        val now = java.time.LocalDateTime.now()
        val duration = java.time.Duration.between(timestamp, now)
        val seconds = duration.seconds
        when {
            seconds < 0 -> context.getString(R.string.notif_just_now)
            seconds < 60 -> context.getString(R.string.notif_just_now)
            seconds < 3600 -> context.getString(R.string.notif_minutes_ago, seconds / 60)
            seconds < 86400 -> context.getString(R.string.notif_hours_ago, seconds / 3600)
            else -> context.getString(R.string.notif_days_ago, seconds / 86400)
        }
    } catch (e: Exception) {
        context.getString(R.string.notif_just_now)
    }
}

private fun formatDuration(context: android.content.Context, ms: Long): String {
    val sec = ms / 1000
    val min = sec / 60
    val remainingSec = sec % 60
    return if (min > 0) {
        context.getString(R.string.notif_duration_minutes_seconds, min, remainingSec)
    } else {
        context.getString(R.string.notif_duration_seconds, sec)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsBottomSheet(
    onDismiss: () -> Unit,
    navController: NavController
) {
    val context = LocalContext.current
    val playerConnection = LocalPlayerConnection.current
    val database = playerConnection?.database
    val listenTogetherManager = LocalListenTogetherManager.current

    // Real-time observations from player
    val currentSongState by (playerConnection?.currentSong?.collectAsState() ?: remember { mutableStateOf(null) })
    val isPlayingState by (playerConnection?.isPlaying?.collectAsState() ?: remember { mutableStateOf(false) })
    
    // Real-time observations from Listen Together
    val isInRoomState = listenTogetherManager?.isInRoom == true
    val isHostState = listenTogetherManager?.isHost == true

    // Real-time history & stats from database
    val recentEvents by (database?.events()?.collectAsState(initial = emptyList()) ?: remember { mutableStateOf(emptyList()) })
    val downloadedSongs by (database?.downloadedSongsByCreateDateAsc()?.collectAsState(initial = emptyList()) ?: remember { mutableStateOf(emptyList()) })
    val likedSongsCount by (database?.likedSongsCount()?.collectAsState(initial = 0) ?: remember { mutableStateOf(0) })

    // Save read notification IDs in DataStore
    var readIdsString by rememberPreference(NotificationsReadIdsKey, "")
    
    val readIds = remember(readIdsString) {
        readIdsString.split(",").filter { it.isNotEmpty() }.toSet()
    }

    val notifications = remember(context, currentSongState, isPlayingState, isInRoomState, isHostState, recentEvents, downloadedSongs, likedSongsCount) {
        val list = mutableListOf<NotificationItem>()

        // 1. Current playing song
        currentSongState?.let { song ->
            list.add(
                NotificationItem(
                    id = "current_song_${song.id}",
                    title = if (isPlayingState) {
                        context.getString(R.string.notif_title_playing, song.title)
                    } else {
                        context.getString(R.string.notif_title_paused, song.title)
                    },
                    description = context.getString(R.string.notif_desc_current_song, song.artists.joinToString { it.name }),
                    time = context.getString(R.string.notif_time_now),
                    iconRes = if (isPlayingState) R.drawable.play else R.drawable.pause,
                    iconColor = Color(0xFF4CAF50),
                    route = null // Clicking doesn't route away, just stay or dismiss
                )
            )
        }

        // 2. Listen Together Active Session
        if (isInRoomState) {
            list.add(
                NotificationItem(
                    id = "listen_together_active",
                    title = context.getString(R.string.notif_listen_together_room_open),
                    description = if (isHostState) {
                        context.getString(R.string.notif_listen_together_room_desc_host)
                    } else {
                        context.getString(R.string.notif_listen_together_room_desc_member)
                    },
                    time = context.getString(R.string.notif_time_realtime),
                    iconRes = R.drawable.group,
                    iconColor = Color(0xFF2196F3),
                    route = "listen_together"
                )
            )
        }

        // 3. Offline downloads info
        if (downloadedSongs.isNotEmpty()) {
            list.add(
                NotificationItem(
                    id = "downloaded_songs_status",
                    title = context.getString(R.string.notif_downloads_completed),
                    description = context.getString(R.string.notif_downloads_desc, downloadedSongs.size),
                    time = context.getString(R.string.notif_time_offline),
                    iconRes = R.drawable.download,
                    iconColor = Color(0xFFFF9800),
                    route = "local_playlist/LP_DOWNLOADED"
                )
            )
        }

        // 4. Liked Songs info
        if (likedSongsCount > 0) {
            list.add(
                NotificationItem(
                    id = "liked_songs_status",
                    title = context.getString(R.string.notif_your_favorites),
                    description = context.getString(R.string.notif_favorites_desc, likedSongsCount),
                    time = context.getString(R.string.notif_time_sync),
                    iconRes = R.drawable.favorite,
                    iconColor = Color(0xFFE91E63),
                    route = "online_playlist/LM"
                )
            )
        }

        // 5. Recent History (List up to 3 most recent events)
        recentEvents.take(3).forEach { eventWithSong ->
            val song = eventWithSong.song
            val formattedTime = formatEventTime(context, eventWithSong.event.timestamp)
            list.add(
                NotificationItem(
                    id = "history_event_${eventWithSong.event.id}",
                    title = context.getString(R.string.notif_listened_title, song.song.title),
                    description = context.getString(
                        R.string.notif_listened_desc,
                        song.artists.joinToString { it.name },
                        formatDuration(context, eventWithSong.event.playTime)
                    ),
                    time = formattedTime,
                    iconRes = R.drawable.history,
                    iconColor = Color(0xFF9C27B0),
                    route = "history"
                )
            )
        }

        // 6. Default general info notifications if there is no dynamic ones
        if (list.size < 3) {
            list.add(
                NotificationItem(
                    id = "default_stats",
                    title = context.getString(R.string.notif_view_stats),
                    description = context.getString(R.string.notif_view_stats_desc),
                    time = context.getString(R.string.notif_time_realtime),
                    iconRes = R.drawable.stats,
                    iconColor = Color(0xFF00BCD4),
                    route = "stats"
                )
            )
            list.add(
                NotificationItem(
                    id = "default_settings",
                    title = context.getString(R.string.notif_settings_title),
                    description = context.getString(R.string.notif_settings_desc),
                    time = context.getString(R.string.notif_time_system),
                    iconRes = R.drawable.settings,
                    iconColor = Color(0xFF607D8B),
                    route = "settings"
                )
            )
        }

        list
    }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = { BottomSheetDefaults.DragHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = WindowInsets.systemBars.asPaddingValues().calculateBottomPadding())
        ) {
            // Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.notification),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Text(
                        text = stringResource(R.string.notif_header_title),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Mark as read button
                val unreadCount = notifications.count { it.id !in readIds }
                if (unreadCount > 0) {
                    TextButton(
                        onClick = {
                            val allIds = notifications.map { it.id }.joinToString(",")
                            readIdsString = allIds
                        }
                    ) {
                        Text(
                            text = stringResource(R.string.notif_mark_all_read),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (notifications.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = stringResource(R.string.notif_empty_message),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(notifications, key = { it.id }) { item ->
                        val isUnread = item.id !in readIds
                        
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .clickable {
                                    // Mark as read
                                    if (isUnread) {
                                        val newIds = (readIds + item.id).joinToString(",")
                                        readIdsString = newIds
                                    }
                                    onDismiss()
                                    item.route?.let {
                                        navController.navigate(it)
                                    }
                                },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUnread) {
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.12f)
                                } else {
                                    MaterialTheme.colorScheme.surfaceContainer
                                }
                            ),
                            border = if (isUnread) {
                                CardDefaults.outlinedCardBorder().copy(
                                    brush = androidx.compose.ui.graphics.SolidColor(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
                                    )
                                )
                            } else null
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                // Notification Icon container
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(
                                            color = item.iconColor.copy(alpha = 0.15f),
                                            shape = CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        painter = painterResource(item.iconRes),
                                        contentDescription = null,
                                        tint = item.iconColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                // Text Content block
                                Column(
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = item.title,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = if (isUnread) FontWeight.Bold else FontWeight.SemiBold,
                                            color = if (isUnread) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )

                                        if (isUnread) {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .background(
                                                        color = MaterialTheme.colorScheme.primary,
                                                        shape = CircleShape
                                                    )
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        text = item.description,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = if (isUnread) FontWeight.Medium else FontWeight.Normal
                                    )

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = item.time,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
