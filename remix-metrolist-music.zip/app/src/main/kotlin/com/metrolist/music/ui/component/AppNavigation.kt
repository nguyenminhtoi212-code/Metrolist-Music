/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.component

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.metrolist.music.R
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.metrolist.music.constants.ChromaticAberrationKey
import com.metrolist.music.constants.DepthEffectKey
import com.metrolist.music.constants.EnableLiquidGlassKey
import com.metrolist.music.constants.FloatingNavBarKey
import com.metrolist.music.constants.GlassBlurRadiusKey
import com.metrolist.music.constants.GlassNavBarKey
import com.metrolist.music.constants.GlassSaturationKey
import com.metrolist.music.constants.LensRefractionAmountKey
import com.metrolist.music.constants.LensRefractionHeightKey
import com.metrolist.music.constants.SurfaceOpacityKey
import com.metrolist.music.ui.components.liquidGlass
import com.metrolist.music.ui.screens.Screens
import com.metrolist.music.utils.rememberPreference
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest

@Immutable
private data class NavItemState(
    val isSelected: Boolean,
    val iconRes: Int
)

@Stable
private fun isRouteSelected(currentRoute: String?, screenRoute: String, navigationItems: List<Screens>): Boolean {
    if (currentRoute == null) return false
    if (currentRoute == screenRoute) return true
    if (navigationItems.any { it.route == screenRoute } &&
        currentRoute.startsWith("$screenRoute/")) return true

    // Fix: match the route template, not the resolved route
    if (screenRoute == "search_input" &&
        (currentRoute.startsWith("search/") || currentRoute == "search/{query}")) return true

    return false
}

@Composable
fun AppNavigationRail(
    navigationItems: List<Screens>,
    currentRoute: String?,
    onItemClick: (Screens, Boolean) -> Unit,
    modifier: Modifier = Modifier,
    pureBlack: Boolean = false,
    onSearchLongClick: (() -> Unit)? = null
) {
    val enableLiquidGlass by rememberPreference(EnableLiquidGlassKey, defaultValue = true)
    val glassNavBar by rememberPreference(GlassNavBarKey, defaultValue = true)
    val glassSaturation by rememberPreference(GlassSaturationKey, defaultValue = 1.3f)
    val glassBlurRadius by rememberPreference(GlassBlurRadiusKey, defaultValue = 24f)
    val lensRefractionHeight by rememberPreference(LensRefractionHeightKey, defaultValue = 14f)
    val lensRefractionAmount by rememberPreference(LensRefractionAmountKey, defaultValue = 0.85f)
    val chromaticAberration by rememberPreference(ChromaticAberrationKey, defaultValue = 0.45f)
    val depthEffect by rememberPreference(DepthEffectKey, defaultValue = 0.75f)
    val surfaceOpacity by rememberPreference(SurfaceOpacityKey, defaultValue = 0.35f)

    val isGlassActive = enableLiquidGlass && glassNavBar
    val containerColor = when {
        isGlassActive -> Color.Transparent
        pureBlack -> Color.Black
        else -> MaterialTheme.colorScheme.surfaceContainer
    }
    val haptics = LocalHapticFeedback.current
    val viewConfiguration = LocalViewConfiguration.current

    val navRailModifier = if (isGlassActive) {
        modifier.liquidGlass(
            enabled = true,
            blurRadiusDp = glassBlurRadius,
            saturation = glassSaturation,
            refractionHeight = lensRefractionHeight,
            refractionAmount = lensRefractionAmount,
            chromaticAberration = chromaticAberration,
            depthEffect = depthEffect,
            surfaceOpacity = surfaceOpacity,
            surfaceTintColor = MaterialTheme.colorScheme.surfaceContainerHigh,
            shape = RoundedCornerShape(24.dp)
        )
    } else modifier

    val railItemColors = if (isGlassActive) {
        NavigationRailItemDefaults.colors(
            selectedIconColor = Color.White,
            selectedTextColor = Color.White,
            indicatorColor = Color(0xFF53286D),
            unselectedIconColor = Color.White.copy(alpha = 0.85f),
            unselectedTextColor = Color.White.copy(alpha = 0.85f)
        )
    } else {
        NavigationRailItemDefaults.colors()
    }

    NavigationRail(
        modifier = navRailModifier,
        containerColor = containerColor
    ) {
        Spacer(modifier = Modifier.weight(1f))

        navigationItems.forEach { screen ->
            val isSelected = remember(currentRoute, screen.route) {
                isRouteSelected(currentRoute, screen.route, navigationItems)
            }
            val currentIsSelected by rememberUpdatedState(isSelected)
            val iconRes = remember(isSelected, screen) {
                if (isSelected) screen.iconIdActive else screen.iconIdInactive
            }

            val isSearchItem = screen == Screens.Search && onSearchLongClick != null
            val interactionSource = remember { MutableInteractionSource() }

            // Long press detection using InteractionSource
            if (isSearchItem) {
                LaunchedEffect(interactionSource) {
                    var isLongClick = false
                    interactionSource.interactions.collectLatest { interaction ->
                        when (interaction) {
                            is PressInteraction.Press -> {
                                isLongClick = false
                                delay(viewConfiguration.longPressTimeoutMillis)
                                isLongClick = true
                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                onSearchLongClick?.invoke()
                            }
                            is PressInteraction.Release -> {
                                if (!isLongClick) {
                                    onItemClick(screen, currentIsSelected)
                                }
                            }
                            is PressInteraction.Cancel -> {
                                isLongClick = false
                            }
                        }
                    }
                }
            }

            NavigationRailItem(
                selected = isSelected,
                onClick = {
                    if (!isSearchItem) {
                        onItemClick(screen, currentIsSelected)
                    }
                },
                interactionSource = interactionSource,
                colors = railItemColors,
                icon = {
                    Icon(
                        painter = painterResource(id = iconRes),
                        contentDescription = stringResource(screen.titleId)
                    )
                }
            )
        }

        Spacer(modifier = Modifier.weight(1f))
    }
}

@Composable
fun AppNavigationBar(
    navigationItems: List<Screens>,
    currentRoute: String?,
    onItemClick: (Screens, Boolean) -> Unit,
    modifier: Modifier = Modifier,
    pureBlack: Boolean = false,
    slimNav: Boolean = false,
    onSearchLongClick: (() -> Unit)? = null
) {
    val enableLiquidGlass by rememberPreference(EnableLiquidGlassKey, defaultValue = true)
    val glassNavBar by rememberPreference(GlassNavBarKey, defaultValue = true)
    val glassSaturation by rememberPreference(GlassSaturationKey, defaultValue = 1.3f)
    val glassBlurRadius by rememberPreference(GlassBlurRadiusKey, defaultValue = 24f)
    val lensRefractionHeight by rememberPreference(LensRefractionHeightKey, defaultValue = 14f)
    val lensRefractionAmount by rememberPreference(LensRefractionAmountKey, defaultValue = 0.85f)
    val chromaticAberration by rememberPreference(ChromaticAberrationKey, defaultValue = 0.45f)
    val depthEffect by rememberPreference(DepthEffectKey, defaultValue = 0.75f)
    val surfaceOpacity by rememberPreference(SurfaceOpacityKey, defaultValue = 0.35f)
    val floatingNavBar by rememberPreference(FloatingNavBarKey, defaultValue = true)

    val isGlassActive = enableLiquidGlass && glassNavBar
    val glassShape = if (floatingNavBar) RoundedCornerShape(34.dp) else RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)

    val floatingPadding by animateDpAsState(
        targetValue = if (floatingNavBar) 16.dp else 0.dp,
        animationSpec = tween(250),
        label = "floatingPadding"
    )

    val containerColor = when {
        isGlassActive -> Color.Transparent
        pureBlack -> Color.Black
        floatingNavBar -> MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.92f)
        else -> MaterialTheme.colorScheme.surfaceContainer
    }
    val contentColor = if (pureBlack) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
    val haptics = LocalHapticFeedback.current
    val viewConfiguration = LocalViewConfiguration.current

    val baseModifier = if (floatingNavBar) {
        modifier
            .padding(horizontal = floatingPadding)
            .shadow(
                elevation = if (isGlassActive) 0.dp else 8.dp,
                shape = glassShape,
                clip = false
            )
            .clip(glassShape)
            .border(
                width = 1.dp,
                color = Color.White.copy(alpha = 0.35f),
                shape = glassShape
            )
    } else modifier

    val navBarModifier = if (isGlassActive) {
        baseModifier.liquidGlass(
            enabled = true,
            blurRadiusDp = glassBlurRadius,
            saturation = glassSaturation,
            refractionHeight = lensRefractionHeight,
            refractionAmount = lensRefractionAmount,
            chromaticAberration = chromaticAberration,
            depthEffect = depthEffect,
            surfaceOpacity = surfaceOpacity,
            surfaceTintColor = Color(0xFF1F1F26),
            shape = glassShape
        )
    } else baseModifier

    val itemColors = if (isGlassActive || floatingNavBar) {
        NavigationBarItemDefaults.colors(
            selectedIconColor = Color.White,
            selectedTextColor = Color.White,
            indicatorColor = Color(0x35FFFFFF),
            unselectedIconColor = Color.White.copy(alpha = 0.72f),
            unselectedTextColor = Color.White.copy(alpha = 0.72f)
        )
    } else {
        NavigationBarItemDefaults.colors()
    }

    Box(modifier = navBarModifier) {
        NavigationBar(
            modifier = Modifier.height(if (slimNav) 56.dp else 68.dp),
            containerColor = containerColor,
            contentColor = contentColor,
            windowInsets = WindowInsets(0, 0, 0, 0)
        ) {
            navigationItems.forEach { screen ->
                val isSelected = remember(currentRoute, screen.route) {
                    isRouteSelected(currentRoute, screen.route, navigationItems)
                }
                val currentIsSelected by rememberUpdatedState(isSelected)
                val iconRes = remember(isSelected, screen) {
                    if (isSelected) screen.iconIdActive else screen.iconIdInactive
                }

                val isSearchItem = screen == Screens.Search && onSearchLongClick != null
                val interactionSource = remember { MutableInteractionSource() }

                // Long press detection using InteractionSource
                if (isSearchItem) {
                    LaunchedEffect(interactionSource) {
                        var isLongClick = false
                        interactionSource.interactions.collectLatest { interaction ->
                            when (interaction) {
                                is PressInteraction.Press -> {
                                    isLongClick = false
                                    delay(viewConfiguration.longPressTimeoutMillis)
                                    isLongClick = true
                                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                    onSearchLongClick?.invoke()
                                }
                                is PressInteraction.Release -> {
                                    if (!isLongClick) {
                                        onItemClick(screen, currentIsSelected)
                                    }
                                }
                                is PressInteraction.Cancel -> {
                                    isLongClick = false
                                }
                            }
                        }
                    }
                }

                NavigationBarItem(
                    selected = isSelected,
                    onClick = {
                        if (!isSearchItem) {
                            onItemClick(screen, currentIsSelected)
                        }
                        // For search item, click is handled via InteractionSource
                    },
                    interactionSource = interactionSource,
                    colors = itemColors,
                    icon = {
                        Icon(
                            painter = painterResource(id = iconRes),
                            contentDescription = stringResource(screen.titleId)
                        )
                    },
                    label = if (!slimNav) {
                        {
                            Text(
                                text = stringResource(screen.titleId),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            )
                        }
                    } else null
                )
            }
        }
    }
}
