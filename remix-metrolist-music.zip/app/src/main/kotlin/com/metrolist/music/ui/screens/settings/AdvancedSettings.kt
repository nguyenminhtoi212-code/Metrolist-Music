/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import coil3.imageLoader
import com.metrolist.music.constants.EnableHighRefreshRateKey
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.rememberPreference
import androidx.datastore.preferences.core.booleanPreferencesKey

val DevModeKey = booleanPreferencesKey("devMode")
val AdvancedSecurityProtocolKey = booleanPreferencesKey("advancedSecurityProtocol")
val AutoSendErrorReportKey = booleanPreferencesKey("autoSendErrorReport")
val AutoOptimizePerformanceKey = booleanPreferencesKey("autoOptimizePerformance")
val UnlimitedBackgroundRunKey = booleanPreferencesKey("unlimitedBackgroundRun")

val ShowMostPlayedSongsKey = booleanPreferencesKey("showMostPlayedSongs")
val ShowMostPlayedArtistsKey = booleanPreferencesKey("showMostPlayedArtists")
val ShowMostPlayedMusicVideosKey = booleanPreferencesKey("showMostPlayedMusicVideos")
val ShowMostPlayedPlaylistsKey = booleanPreferencesKey("showMostPlayedPlaylists")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdvancedSettings(
    navController: NavController
) {
    val (devMode, onDevModeChange) = rememberPreference(key = DevModeKey, defaultValue = false)
    val (advSecurity, onAdvSecurityChange) = rememberPreference(key = AdvancedSecurityProtocolKey, defaultValue = true)
    val (sendErrors, onSendErrorsChange) = rememberPreference(key = AutoSendErrorReportKey, defaultValue = true)
    val (optimizePerf, onOptimizePerfChange) = rememberPreference(key = AutoOptimizePerformanceKey, defaultValue = true)
    val (unlimitBg, onUnlimitBgChange) = rememberPreference(key = UnlimitedBackgroundRunKey, defaultValue = false)
    val context = LocalContext.current
    val (enableHighRefreshRate, onEnableHighRefreshRateChange) = rememberPreference(key = EnableHighRefreshRateKey, defaultValue = true)

    val (showMostPlayedSongs, onShowMostPlayedSongsChange) = rememberPreference(key = ShowMostPlayedSongsKey, defaultValue = false)
    val (showMostPlayedArtists, onShowMostPlayedArtistsChange) = rememberPreference(key = ShowMostPlayedArtistsKey, defaultValue = false)
    val (showMostPlayedMusicVideos, onShowMostPlayedMusicVideosChange) = rememberPreference(key = ShowMostPlayedMusicVideosKey, defaultValue = false)
    val (showMostPlayedPlaylists, onShowMostPlayedPlaylistsChange) = rememberPreference(key = ShowMostPlayedPlaylistsKey, defaultValue = false)

    Column(
        Modifier
            .windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top
                )
            )
        )

        Material3SettingsGroup(
            title = stringResource(R.string.advanced_options_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.settings),
                    title = { Text(stringResource(R.string.dev_mode_title)) },
                    trailingContent = {
                        Switch(
                            checked = devMode,
                            onCheckedChange = onDevModeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (devMode) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onDevModeChange(!devMode) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.security),
                    title = { Text(stringResource(R.string.adv_security_title)) },
                    trailingContent = {
                        Switch(
                            checked = advSecurity,
                            onCheckedChange = onAdvSecurityChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (advSecurity) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAdvSecurityChange(!advSecurity) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.info),
                    title = { Text(stringResource(R.string.auto_send_error_report_title)) },
                    trailingContent = {
                        Switch(
                            checked = sendErrors,
                            onCheckedChange = onSendErrorsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (sendErrors) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onSendErrorsChange(!sendErrors) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.sliders),
                    title = { Text(stringResource(R.string.auto_optimize_performance_title)) },
                    trailingContent = {
                        Switch(
                            checked = optimizePerf,
                            onCheckedChange = onOptimizePerfChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (optimizePerf) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onOptimizePerfChange(!optimizePerf) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.restore),
                    title = { Text(stringResource(R.string.unlimited_background_run_title)) },
                    trailingContent = {
                        Switch(
                            checked = unlimitBg,
                            onCheckedChange = onUnlimitBgChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (unlimitBg) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onUnlimitBgChange(!unlimitBg) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.cached),
                    title = { Text(stringResource(R.string.instant_optimize_title)) },
                    description = { Text(stringResource(R.string.instant_optimize_desc)) },
                    onClick = {
                        try {
                            // 1. Clear Coil memory & disk cache
                            context.imageLoader.memoryCache?.clear()
                            context.imageLoader.diskCache?.clear()
                            // 2. Turn on high refresh rate
                            onEnableHighRefreshRateChange(true)
                            // 3. Turn on auto optimize performance
                            onOptimizePerfChange(true)
                            // 4. Force JVM GC
                            System.gc()
                            Toast.makeText(context, context.getString(R.string.instant_optimize_success), Toast.LENGTH_LONG).show()
                        } catch (e: Exception) {
                            Toast.makeText(context, context.getString(R.string.instant_optimize_error, e.message ?: ""), Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.show_most_played_group_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.music_note),
                    title = { Text(stringResource(R.string.show_most_played_songs_title)) },
                    trailingContent = {
                        Switch(
                            checked = showMostPlayedSongs,
                            onCheckedChange = onShowMostPlayedSongsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (showMostPlayedSongs) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onShowMostPlayedSongsChange(!showMostPlayedSongs) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.person),
                    title = { Text(stringResource(R.string.show_most_played_artists_title)) },
                    trailingContent = {
                        Switch(
                            checked = showMostPlayedArtists,
                            onCheckedChange = onShowMostPlayedArtistsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (showMostPlayedArtists) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onShowMostPlayedArtistsChange(!showMostPlayedArtists) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.play),
                    title = { Text(stringResource(R.string.show_most_played_music_videos_title)) },
                    description = { Text(stringResource(R.string.show_most_played_music_videos_desc)) },
                    trailingContent = {
                        Switch(
                            checked = showMostPlayedMusicVideos,
                            onCheckedChange = onShowMostPlayedMusicVideosChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (showMostPlayedMusicVideos) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onShowMostPlayedMusicVideosChange(!showMostPlayedMusicVideos) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.queue_music),
                    title = { Text(stringResource(R.string.show_most_played_playlists_title)) },
                    description = { Text(stringResource(R.string.show_most_played_playlists_desc)) },
                    trailingContent = {
                        Switch(
                            checked = showMostPlayedPlaylists,
                            onCheckedChange = onShowMostPlayedPlaylistsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (showMostPlayedPlaylists) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onShowMostPlayedPlaylistsChange(!showMostPlayedPlaylists) }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))
    }

    TopAppBar(
        title = { Text(stringResource(R.string.advanced_settings_title)) },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain,
            ) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                )
            }
        }
    )
}
