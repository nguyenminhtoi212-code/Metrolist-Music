/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings.integrations

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.LocalPlayerConnection
import com.metrolist.music.R
import com.metrolist.music.constants.DiscordActivityNameKey
import com.metrolist.music.constants.DiscordActivityTypeKey
import com.metrolist.music.constants.DiscordAdvancedModeKey
import com.metrolist.music.constants.DiscordButton1EnabledKey
import com.metrolist.music.constants.DiscordButton1LabelKey
import com.metrolist.music.constants.DiscordButton1UrlKey
import com.metrolist.music.constants.DiscordButton2EnabledKey
import com.metrolist.music.constants.DiscordButton2LabelKey
import com.metrolist.music.constants.DiscordButton2UrlKey
import com.metrolist.music.constants.DiscordDetailStateToggleKey
import com.metrolist.music.constants.DiscordDetailsTemplateKey
import com.metrolist.music.constants.DiscordShowWhenPausedKey
import com.metrolist.music.constants.DiscordStateTemplateKey
import com.metrolist.music.constants.DiscordUserStatusKey
import com.metrolist.music.constants.EnableDiscordRPCKey
import com.metrolist.music.discord.DiscordDefaults
import com.metrolist.music.discord.DiscordRpcManager
import com.metrolist.music.discord.DiscordTokenStore
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.rememberPreference
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiscordSettings(
    navController: NavController
) {
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    // Player Context (for previewing song info)
    val playerConnection = LocalPlayerConnection.current
    val currentSong by playerConnection?.currentSong?.collectAsState() ?: remember { mutableStateOf(null) }

    // Discord Prefs
    val (discordRpcEnabled, onDiscordRpcEnabledChange) = rememberPreference(
        key = EnableDiscordRPCKey,
        defaultValue = false
    )
    val (advancedMode, onAdvancedModeChange) = rememberPreference(
        key = DiscordAdvancedModeKey,
        defaultValue = false
    )
    val (showWhenPaused, onShowWhenPausedChange) = rememberPreference(
        key = DiscordShowWhenPausedKey,
        defaultValue = true
    )
    val (userStatus, onUserStatusChange) = rememberPreference(
        key = DiscordUserStatusKey,
        defaultValue = DiscordDefaults.USER_STATUS
    )
    val (activityType, onActivityTypeChange) = rememberPreference(
        key = DiscordActivityTypeKey,
        defaultValue = DiscordDefaults.ACTIVITY_TYPE
    )
    val (activityName, onActivityNameChange) = rememberPreference(
        key = DiscordActivityNameKey,
        defaultValue = DiscordDefaults.ACTIVITY_NAME
    )
    val (detailsTemplate, onDetailsTemplateChange) = rememberPreference(
        key = DiscordDetailsTemplateKey,
        defaultValue = DiscordDefaults.DETAILS_TEMPLATE
    )
    val (stateTemplate, onStateTemplateChange) = rememberPreference(
        key = DiscordStateTemplateKey,
        defaultValue = DiscordDefaults.STATE_TEMPLATE
    )
    val (detailStateToggle, onDetailStateToggleChange) = rememberPreference(
        key = DiscordDetailStateToggleKey,
        defaultValue = false
    )
    val (btn1Enabled, onBtn1EnabledChange) = rememberPreference(
        key = DiscordButton1EnabledKey,
        defaultValue = true
    )
    val (btn1Label, onBtn1LabelChange) = rememberPreference(
        key = DiscordButton1LabelKey,
        defaultValue = DiscordDefaults.BUTTON1_LABEL
    )
    val (btn1Url, onBtn1UrlChange) = rememberPreference(
        key = DiscordButton1UrlKey,
        defaultValue = DiscordDefaults.BUTTON1_URL_TEMPLATE
    )
    val (btn2Enabled, onBtn2EnabledChange) = rememberPreference(
        key = DiscordButton2EnabledKey,
        defaultValue = false
    )
    val (btn2Label, onBtn2LabelChange) = rememberPreference(
        key = DiscordButton2LabelKey,
        defaultValue = DiscordDefaults.BUTTON2_LABEL
    )
    val (btn2Url, onBtn2UrlChange) = rememberPreference(
        key = DiscordButton2UrlKey,
        defaultValue = DiscordDefaults.BUTTON2_URL
    )

    // Token State
    var showTokenDialog by rememberSaveable { mutableStateOf(false) }
    var currentToken by remember { mutableStateOf(DiscordTokenStore.retrieve() ?: "") }

    // Dialog trigger states
    var showStatusDialog by rememberSaveable { mutableStateOf(false) }
    var showActivityTypeDialog by rememberSaveable { mutableStateOf(false) }

    val onEnabledChange: (Boolean) -> Unit = { enabled ->
        onDiscordRpcEnabledChange(enabled)
        coroutineScope.launch {
            if (enabled) {
                if (!DiscordRpcManager.isInitialized()) {
                    DiscordRpcManager.init(context)
                }
                val token = DiscordTokenStore.retrieve()
                if (!token.isNullOrEmpty()) {
                    DiscordRpcManager.reconnectWithToken(token)
                }
            } else {
                DiscordRpcManager.disconnect()
            }
        }
    }

    // Token Editor Dialog
    if (showTokenDialog) {
        var tempToken by rememberSaveable { mutableStateOf(currentToken) }
        var isTokenVisible by rememberSaveable { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showTokenDialog = false },
            title = { Text(stringResource(R.string.discord_integration)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = stringResource(R.string.discord_token_dialog_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = tempToken,
                        onValueChange = { tempToken = it },
                        label = { Text(stringResource(R.string.discord_token_label)) },
                        singleLine = true,
                        visualTransformation = if (isTokenVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(
                                onClick = { isTokenVisible = !isTokenVisible },
                                onLongClick = {}
                            ) {
                                Icon(
                                    painter = painterResource(
                                        id = if (isTokenVisible) R.drawable.lock_open else R.drawable.lock
                                    ),
                                    contentDescription = null
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        currentToken = tempToken
                        DiscordTokenStore.store(tempToken)
                        showTokenDialog = false
                        if (discordRpcEnabled && tempToken.isNotEmpty()) {
                            coroutineScope.launch {
                                if (!DiscordRpcManager.isInitialized()) {
                                    DiscordRpcManager.init(context)
                                }
                                DiscordRpcManager.reconnectWithToken(tempToken)
                            }
                        }
                    }
                ) {
                    Text(stringResource(android.R.string.ok))
                }
            },
            dismissButton = {
                TextButton(onClick = { showTokenDialog = false }) {
                    Text(stringResource(android.R.string.cancel))
                }
            }
        )
    }

    // User Status Selector Dialog
    if (showStatusDialog) {
        AlertDialog(
            onDismissRequest = { showStatusDialog = false },
            title = { Text(stringResource(R.string.discord_status)) },
            text = {
                Column {
                    val statuses = listOf(
                        DiscordDefaults.USER_STATUS to stringResource(R.string.discord_status_online),
                        DiscordDefaults.STATUS_IDLE to stringResource(R.string.discord_status_idle),
                        DiscordDefaults.STATUS_DND to stringResource(R.string.discord_status_dnd)
                    )
                    statuses.forEach { (statusVal, statusLabel) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onUserStatusChange(statusVal)
                                    showStatusDialog = false
                                    DiscordRpcManager.notifySettingsChanged()
                                }
                                .padding(vertical = 12.dp)
                        ) {
                            RadioButton(
                                selected = userStatus == statusVal,
                                onClick = {
                                    onUserStatusChange(statusVal)
                                    showStatusDialog = false
                                    DiscordRpcManager.notifySettingsChanged()
                                }
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(statusLabel)
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }

    // Activity Type Selector Dialog
    if (showActivityTypeDialog) {
        AlertDialog(
            onDismissRequest = { showActivityTypeDialog = false },
            title = { Text(stringResource(R.string.discord_activity_type)) },
            text = {
                Column {
                    val types = listOf(
                        DiscordDefaults.ACTIVITY_TYPE_PLAYING to stringResource(R.string.discord_activity_playing),
                        DiscordDefaults.ACTIVITY_TYPE_LISTENING to stringResource(R.string.discord_activity_listening),
                        DiscordDefaults.ACTIVITY_TYPE_WATCHING to stringResource(R.string.discord_activity_watching),
                        DiscordDefaults.ACTIVITY_TYPE_COMPETING to stringResource(R.string.discord_activity_competing)
                    )
                    types.forEach { (typeVal, typeLabel) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onActivityTypeChange(typeVal)
                                    showActivityTypeDialog = false
                                    DiscordRpcManager.notifySettingsChanged()
                                }
                                .padding(vertical = 12.dp)
                        ) {
                            RadioButton(
                                selected = activityType == typeVal,
                                onClick = {
                                    onActivityTypeChange(typeVal)
                                    showActivityTypeDialog = false
                                    DiscordRpcManager.notifySettingsChanged()
                                }
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(typeLabel)
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.discord_integration)) },
                navigationIcon = {
                    IconButton(
                        onClick = navController::navigateUp,
                        onLongClick = navController::backToMain,
                    ) {
                        Icon(
                            painterResource(R.drawable.arrow_back),
                            contentDescription = null,
                        )
                    }
                }
            )
        },
        contentWindowInsets = LocalPlayerAwareWindowInsets.current
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        painter = painterResource(R.drawable.info),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(
                            text = stringResource(R.string.discord_rpc_proposal_title),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = stringResource(R.string.discord_rpc_proposal_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // Options (Tùy chọn) Card Group
        Material3SettingsGroup(
            title = stringResource(R.string.options),
            items = listOf(
                Material3SettingsItem(
                    title = { Text(stringResource(R.string.enable_discord_rpc)) },
                    trailingContent = {
                        Switch(
                            checked = discordRpcEnabled,
                            onCheckedChange = onEnabledChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (discordRpcEnabled) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize),
                                )
                            }
                        )
                    },
                    icon = painterResource(R.drawable.discord)
                ),
                Material3SettingsItem(
                    title = { Text(stringResource(R.string.discord_show_when_paused)) },
                    description = { Text(stringResource(R.string.discord_show_when_paused_desc)) },
                    trailingContent = {
                        Switch(
                            checked = showWhenPaused,
                            onCheckedChange = {
                                onShowWhenPausedChange(it)
                                DiscordRpcManager.notifySettingsChanged()
                            },
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (showWhenPaused) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize),
                                )
                            }
                        )
                    },
                    icon = painterResource(R.drawable.pause)
                ),
                Material3SettingsItem(
                    title = { Text(stringResource(R.string.discord_advanced_mode)) },
                    description = { Text(stringResource(R.string.discord_advanced_mode_description)) },
                    trailingContent = {
                        Switch(
                            checked = advancedMode,
                            onCheckedChange = onAdvancedModeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (advancedMode) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize),
                                )
                            }
                        )
                    },
                    icon = painterResource(R.drawable.settings)
                ),
                Material3SettingsItem(
                    title = { Text(stringResource(R.string.discord_token_label)) },
                    description = { 
                        Text(
                            if (currentToken.isEmpty()) stringResource(R.string.discord_token_status_empty) 
                            else stringResource(R.string.discord_token_status_filled)
                        ) 
                    },
                    onClick = { showTokenDialog = true },
                    icon = painterResource(R.drawable.key)
                )
            )
        )

        // Expandable Advanced Customization Section
        AnimatedVisibility(visible = advancedMode) {
            Column {
                Material3SettingsGroup(
                    title = stringResource(R.string.discord_presence),
                    items = listOf(
                        Material3SettingsItem(
                            title = { Text(stringResource(R.string.discord_status)) },
                            description = {
                                val labelId = when (userStatus) {
                                    DiscordDefaults.STATUS_IDLE -> R.string.discord_status_idle
                                    DiscordDefaults.STATUS_DND -> R.string.discord_status_dnd
                                    else -> R.string.discord_status_online
                                }
                                Text(stringResource(labelId))
                            },
                            onClick = { showStatusDialog = true },
                            icon = painterResource(R.drawable.person)
                        ),
                        Material3SettingsItem(
                            title = { Text(stringResource(R.string.discord_activity_type)) },
                            description = {
                                val labelId = when (activityType) {
                                    DiscordDefaults.ACTIVITY_TYPE_PLAYING -> R.string.discord_activity_playing
                                    DiscordDefaults.ACTIVITY_TYPE_WATCHING -> R.string.discord_activity_watching
                                    DiscordDefaults.ACTIVITY_TYPE_COMPETING -> R.string.discord_activity_competing
                                    else -> R.string.discord_activity_listening
                                }
                                Text(stringResource(labelId))
                            },
                            onClick = { showActivityTypeDialog = true },
                            icon = painterResource(R.drawable.play)
                        )
                    )
                )

                // Advanced templates
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.discord_customize_display_info),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        OutlinedTextField(
                            value = activityName,
                            onValueChange = {
                                onActivityNameChange(it)
                                DiscordRpcManager.notifySettingsChanged()
                            },
                            label = { Text(stringResource(R.string.discord_activity_name)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = detailsTemplate,
                            onValueChange = {
                                onDetailsTemplateChange(it)
                                DiscordRpcManager.notifySettingsChanged()
                            },
                            label = { Text(stringResource(R.string.discord_details)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = stateTemplate,
                            onValueChange = {
                                onStateTemplateChange(it)
                                DiscordRpcManager.notifySettingsChanged()
                            },
                            label = { Text(stringResource(R.string.discord_state)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Invert toggle
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onDetailStateToggleChange(!detailStateToggle)
                                    DiscordRpcManager.notifySettingsChanged()
                                }
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.discord_invert_detail_state),
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            Switch(
                                checked = detailStateToggle,
                                onCheckedChange = {
                                    onDetailStateToggleChange(it)
                                    DiscordRpcManager.notifySettingsChanged()
                                }
                            )
                        }

                        // Placeholders helper
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    MaterialTheme.colorScheme.surfaceContainerHighest,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .padding(12.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.discord_placeholders),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "• {song.name} - " + stringResource(R.string.discord_placeholder_song) + "\n" +
                                       "• {artist.name} - " + stringResource(R.string.discord_placeholder_artist) + "\n" +
                                       "• {album.name} - " + stringResource(R.string.discord_placeholder_album),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }

                // Buttons configuration
                Material3SettingsGroup(
                    title = stringResource(R.string.discord_buttons),
                    items = listOf(
                        Material3SettingsItem(
                            title = { Text(stringResource(R.string.discord_enable_button_1)) },
                            trailingContent = {
                                Switch(
                                    checked = btn1Enabled,
                                    onCheckedChange = {
                                        onBtn1EnabledChange(it)
                                        DiscordRpcManager.notifySettingsChanged()
                                    }
                                )
                            },
                            icon = painterResource(R.drawable.link)
                        ),
                        Material3SettingsItem(
                            title = { Text(stringResource(R.string.discord_enable_button_2)) },
                            trailingContent = {
                                Switch(
                                    checked = btn2Enabled,
                                    onCheckedChange = {
                                        onBtn2EnabledChange(it)
                                        DiscordRpcManager.notifySettingsChanged()
                                    }
                                )
                            },
                            icon = painterResource(R.drawable.link)
                        )
                    )
                )

                // Button fields
                AnimatedVisibility(visible = btn1Enabled || btn2Enabled) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            if (btn1Enabled) {
                                Text(
                                    text = stringResource(R.string.discord_button_1_config),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                OutlinedTextField(
                                    value = btn1Label,
                                    onValueChange = {
                                        onBtn1LabelChange(it)
                                        DiscordRpcManager.notifySettingsChanged()
                                    },
                                    label = { Text(stringResource(R.string.discord_button_label)) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = btn1Url,
                                    onValueChange = {
                                        onBtn1UrlChange(it)
                                        DiscordRpcManager.notifySettingsChanged()
                                    },
                                    label = { Text(stringResource(R.string.discord_button_url)) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            if (btn2Enabled) {
                                if (btn1Enabled) Spacer(Modifier.height(8.dp))
                                Text(
                                    text = stringResource(R.string.discord_button_2_config),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                OutlinedTextField(
                                    value = btn2Label,
                                    onValueChange = {
                                        onBtn2LabelChange(it)
                                        DiscordRpcManager.notifySettingsChanged()
                                    },
                                    label = { Text(stringResource(R.string.discord_button_label)) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = btn2Url,
                                    onValueChange = {
                                        onBtn2UrlChange(it)
                                        DiscordRpcManager.notifySettingsChanged()
                                    },
                                    label = { Text(stringResource(R.string.discord_button_url)) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // Rich Presence Preview Card
        Text(
            text = stringResource(R.string.discord_rpc_preview),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 8.dp)
        )

        val defaultSongPlaceholder = stringResource(R.string.discord_preview_default_song)
        val defaultArtistPlaceholder = stringResource(R.string.discord_preview_default_artist)
        val displaySongTitle = currentSong?.song?.title ?: defaultSongPlaceholder
        val displayArtistName = currentSong?.artists?.joinToString { it.name }
        val displayArtistText = if (displayArtistName != null) {
            stringResource(R.string.discord_preview_artist_label, displayArtistName)
        } else {
            defaultArtistPlaceholder
        }
        val displayActivityHeader = if (advancedMode && activityName.isNotEmpty()) {
            when (activityType) {
                DiscordDefaults.ACTIVITY_TYPE_PLAYING -> stringResource(R.string.discord_preview_playing_prefix, activityName)
                DiscordDefaults.ACTIVITY_TYPE_WATCHING -> stringResource(R.string.discord_preview_watching_prefix, activityName)
                DiscordDefaults.ACTIVITY_TYPE_COMPETING -> stringResource(R.string.discord_preview_competing_prefix, activityName)
                else -> stringResource(R.string.discord_preview_listening_prefix, activityName)
            }
        } else {
            stringResource(R.string.discord_preview_listening_artist)
        }

        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF1E1F22) // Discord's exact dark background color for previews
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = displayActivityHeader,
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Gray image placeholder representing album cover/music icon
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF313338)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.music_note),
                            contentDescription = null,
                            tint = Color.LightGray,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(Modifier.width(16.dp))

                    Column {
                        Text(
                            text = displaySongTitle,
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = 15.sp),
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = displayArtistText,
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                            color = Color(0xFFB5BAC1)
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = stringResource(R.string.discord_preview_elapsed_time),
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                            color = Color(0xFF949BA4)
                        )
                    }
                }

                // If buttons are configured, draw them elegantly
                if (btn1Enabled) {
                    val defaultBtnLabel = stringResource(R.string.discord_preview_default_button_label)
                    val label1 = if (advancedMode) btn1Label else defaultBtnLabel
                    OutlinedButton(
                        onClick = {},
                        shape = RoundedCornerShape(4.dp),
                        colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                            contentColor = Color.White
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF4E5058)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = label1,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(48.dp))
        }
    }
}
