package com.metrolist.music.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp

/**
 * Applies Liquid Glass (Glassmorphism) visual effects including background blur,
 * surface tinting, lens refraction highlights, chromatic aberration border, and depth shadow.
 */
fun Modifier.liquidGlass(
    enabled: Boolean = true,
    blurRadiusDp: Float = 24f,
    saturation: Float = 1.3f,
    refractionHeight: Float = 14f,
    refractionAmount: Float = 0.85f,
    chromaticAberration: Float = 0.45f,
    depthEffect: Float = 0.75f,
    surfaceTintColor: Color = Color.Unspecified,
    surfaceOpacity: Float = 1.0f,
    dominantColor: Color = Color.Unspecified,
    shape: Shape = RoundedCornerShape(24.dp)
): Modifier {
    if (!enabled) return this

    val effectiveBlur = blurRadiusDp.coerceIn(4f, 60f).dp
    val effectiveOpacity = 1.0f
    val tint = if (surfaceTintColor == Color.Unspecified) Color(0xFF1E293B) else surfaceTintColor

    val satFactor = saturation.coerceIn(0.5f, 2.0f)
    val blendedTint = if (dominantColor != Color.Unspecified) {
        Color(
            red = (tint.red * 0.4f + dominantColor.red * 0.6f * satFactor).coerceIn(0f, 1f),
            green = (tint.green * 0.4f + dominantColor.green * 0.6f * satFactor).coerceIn(0f, 1f),
            blue = (tint.blue * 0.4f + dominantColor.blue * 0.6f * satFactor).coerceIn(0f, 1f),
            alpha = tint.alpha
        )
    } else tint

    val overlayColor = blendedTint.copy(alpha = effectiveOpacity)

    val backdropGlowBrush = if (dominantColor != Color.Unspecified) {
        Brush.radialGradient(
            colors = listOf(
                dominantColor.copy(alpha = (0.45f * depthEffect).coerceIn(0.15f, 0.65f)),
                dominantColor.copy(alpha = (0.20f * depthEffect).coerceIn(0.05f, 0.35f)),
                Color.Transparent
            )
        )
    } else null

    val highlightBrush = Brush.linearGradient(
        colors = listOf(
            Color.White.copy(alpha = (0.35f * refractionAmount + 0.15f * depthEffect).coerceIn(0.10f, 0.85f)),
            Color.White.copy(alpha = 0.12f),
            Color.Transparent,
            Color.Black.copy(alpha = (0.15f * depthEffect).coerceIn(0f, 0.40f))
        ),
        start = androidx.compose.ui.geometry.Offset(0f, 0f),
        end = androidx.compose.ui.geometry.Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
    )

    val borderBrush = Brush.linearGradient(
        colors = listOf(
            Color.White.copy(alpha = (0.40f + chromaticAberration * 0.25f).coerceAtMost(0.9f)),
            Color.Cyan.copy(alpha = (0.25f * chromaticAberration).coerceAtMost(0.5f)),
            Color.Magenta.copy(alpha = (0.25f * chromaticAberration).coerceAtMost(0.5f)),
            Color.White.copy(alpha = 0.25f)
        )
    )

    var base = this
        .graphicsLayer {
            shadowElevation = (8f * depthEffect).coerceAtLeast(0f)
            this.shape = shape
            clip = false
        }
        .clip(shape)

    if (backdropGlowBrush != null) {
        base = base.background(backdropGlowBrush, shape)
    }

    val borderWidth = (1.2f * refractionAmount.coerceAtLeast(0.5f) + (refractionHeight / 50f)).dp
    return base
        .background(overlayColor, shape)
        .background(highlightBrush, shape)
        .border(
            width = borderWidth,
            brush = borderBrush,
            shape = shape
        )
}

@Composable
fun LiquidGlassContainer(
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    blurRadiusDp: Float = 24f,
    saturation: Float = 1.3f,
    refractionHeight: Float = 14f,
    refractionAmount: Float = 0.85f,
    chromaticAberration: Float = 0.45f,
    depthEffect: Float = 0.75f,
    surfaceTintColor: Color = Color(0xFF1E293B),
    surfaceOpacity: Float = 1.0f,
    dominantColor: Color = Color.Unspecified,
    shape: Shape = RoundedCornerShape(24.dp),
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier.liquidGlass(
            enabled = enabled,
            blurRadiusDp = blurRadiusDp,
            saturation = saturation,
            refractionHeight = refractionHeight,
            refractionAmount = refractionAmount,
            chromaticAberration = chromaticAberration,
            depthEffect = depthEffect,
            surfaceTintColor = surfaceTintColor,
            surfaceOpacity = surfaceOpacity,
            dominantColor = dominantColor,
            shape = shape
        ),
        contentAlignment = Alignment.Center,
        content = content
    )
}
