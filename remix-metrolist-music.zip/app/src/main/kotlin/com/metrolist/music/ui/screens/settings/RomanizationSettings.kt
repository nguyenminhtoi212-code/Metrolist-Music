/**
 * Metrolist Music (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.constants.ContentLanguageKey
import com.metrolist.music.constants.LanguageCodeToName
import com.metrolist.music.constants.LyricsRomanizeAsMainKey
import com.metrolist.music.constants.LyricsRomanizeCyrillicByLineKey
import com.metrolist.music.constants.LyricsRomanizeList
import com.metrolist.music.constants.SYSTEM_DEFAULT
import com.metrolist.music.ui.component.EnumDialog
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.rememberPreference

val defaultList = mutableListOf(
    "Japanese" to true,
    "Korean" to true,
    "Chinese" to true,
    "Hindi" to true,
    "Punjabi" to true,
    "Russian" to true,
    "Ukrainian" to true,
    "Serbian" to true,
    "Bulgarian" to true,
    "Belarusian" to true,
    "Kyrgyz" to true,
    "Macedonian" to true,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RomanizationSettings(
    navController: NavController
) {
    val (pref, prefValue) = rememberPreference(LyricsRomanizeList, "")

    val initialList = remember(pref) {
        if (pref.isEmpty()) defaultList
        else {
            val savedMap = pref.split(",").associate { entry ->
                val (lang, checked) = entry.split(":")
                lang to checked.toBoolean()
            }

            defaultList.map { (lang, defaultChecked) ->
                Pair(lang, savedMap[lang] ?: defaultChecked)
            }
        }
    }

    val states = remember(initialList) { mutableStateListOf(*initialList.toTypedArray()) }

    val (lyricsRomanizeAsMain, onLyricsRomanizeAsMainChange) = rememberPreference(
        LyricsRomanizeAsMainKey,
        defaultValue = false
    )

    val (lyricsRomanizeCyrillicByLine, onLyricsRomanizeCyrillicByLineChange) = rememberPreference(
        LyricsRomanizeCyrillicByLineKey,
        defaultValue = false
    )

    val (contentLanguage, onContentLanguageChange) = rememberPreference(
        key = ContentLanguageKey,
        defaultValue = SYSTEM_DEFAULT
    )

    var showContentLanguageDialog by rememberSaveable { mutableStateOf(false) }

    if (showContentLanguageDialog) {
        EnumDialog(
            onDismiss = { showContentLanguageDialog = false },
            onSelect = {
                onContentLanguageChange(it)
                showContentLanguageDialog = false
            },
            title = stringResource(R.string.content_language),
            current = contentLanguage,
            values = (listOf(SYSTEM_DEFAULT) + LanguageCodeToName.keys.toList()),
            valueText = {
                LanguageCodeToName.getOrElse(it) { stringResource(R.string.system_default) }
            }
        )
    }

    val getLanguageChecked = { lang: String ->
        states.find { it.first == lang }?.second ?: true
    }

    val setLanguageChecked = { lang: String, checked: Boolean ->
        val index = states.indexOfFirst { it.first == lang }
        if (index != -1) {
            states[index] = Pair(lang, checked)
            prefValue(states.joinToString(",") { (l, c) -> "$l:$c" })
        }
    }

    Column(
        Modifier
            .windowInsetsPadding(LocalPlayerAwareWindowInsets.current)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        // Group 1: General Settings for Romanization & Content
        Material3SettingsGroup(
            title = stringResource(R.string.lyrics_romanization),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.queue_music),
                    title = { Text(stringResource(R.string.lyrics_romanize_as_main)) },
                    description = {
                        Text(
                            if (lyricsRomanizeAsMain) "Hiển thị lời phiên âm Latinh là chính, lời gốc là phụ"
                            else "Hiển thị lời gốc là chính, lời phiên âm Latinh là phụ"
                        )
                    },
                    trailingContent = {
                        Switch(
                            checked = lyricsRomanizeAsMain,
                            onCheckedChange = onLyricsRomanizeAsMainChange,
                        )
                    },
                    onClick = { onLyricsRomanizeAsMainChange(!lyricsRomanizeAsMain) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.info),
                    title = { Text(stringResource(R.string.line_by_line_option_title)) },
                    description = { Text(stringResource(R.string.line_by_line_option_desc)) },
                    trailingContent = {
                        Switch(
                            checked = lyricsRomanizeCyrillicByLine,
                            onCheckedChange = onLyricsRomanizeCyrillicByLineChange,
                        )
                    },
                    onClick = { onLyricsRomanizeCyrillicByLineChange(!lyricsRomanizeCyrillicByLine) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.language),
                    title = { Text(stringResource(R.string.content_language)) },
                    description = {
                        Text(
                            LanguageCodeToName.getOrElse(contentLanguage) { stringResource(R.string.system_default) }
                        )
                    },
                    onClick = { showContentLanguageDialog = true }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Group 2: Asian & Indian Languages
        Material3SettingsGroup(
            title = "Ngôn ngữ Châu Á & Ấn Độ",
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.language),
                    title = { Text(stringResource(R.string.lyrics_romanize_japanese)) },
                    trailingContent = {
                        Switch(
                            checked = getLanguageChecked("Japanese"),
                            onCheckedChange = { setLanguageChecked("Japanese", it) },
                        )
                    },
                    onClick = { setLanguageChecked("Japanese", !getLanguageChecked("Japanese")) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.language),
                    title = { Text(stringResource(R.string.lyrics_romanize_korean)) },
                    trailingContent = {
                        Switch(
                            checked = getLanguageChecked("Korean"),
                            onCheckedChange = { setLanguageChecked("Korean", it) },
                        )
                    },
                    onClick = { setLanguageChecked("Korean", !getLanguageChecked("Korean")) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.language),
                    title = { Text(stringResource(R.string.lyrics_romanize_chinese)) },
                    trailingContent = {
                        Switch(
                            checked = getLanguageChecked("Chinese"),
                            onCheckedChange = { setLanguageChecked("Chinese", it) },
                        )
                    },
                    onClick = { setLanguageChecked("Chinese", !getLanguageChecked("Chinese")) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.language),
                    title = { Text(stringResource(R.string.lyrics_romanize_hindi)) },
                    trailingContent = {
                        Switch(
                            checked = getLanguageChecked("Hindi"),
                            onCheckedChange = { setLanguageChecked("Hindi", it) },
                        )
                    },
                    onClick = { setLanguageChecked("Hindi", !getLanguageChecked("Hindi")) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.language),
                    title = { Text(stringResource(R.string.lyrics_romanize_punjabi)) },
                    trailingContent = {
                        Switch(
                            checked = getLanguageChecked("Punjabi"),
                            onCheckedChange = { setLanguageChecked("Punjabi", it) },
                        )
                    },
                    onClick = { setLanguageChecked("Punjabi", !getLanguageChecked("Punjabi")) }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Group 3: Cyrillic Languages
        Material3SettingsGroup(
            title = "Ngôn ngữ Cyrillic (Kirin)",
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.language),
                    title = { Text(stringResource(R.string.lyrics_romanize_russian)) },
                    trailingContent = {
                        Switch(
                            checked = getLanguageChecked("Russian"),
                            onCheckedChange = { setLanguageChecked("Russian", it) },
                        )
                    },
                    onClick = { setLanguageChecked("Russian", !getLanguageChecked("Russian")) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.language),
                    title = { Text(stringResource(R.string.lyrics_romanize_ukrainian)) },
                    trailingContent = {
                        Switch(
                            checked = getLanguageChecked("Ukrainian"),
                            onCheckedChange = { setLanguageChecked("Ukrainian", it) },
                        )
                    },
                    onClick = { setLanguageChecked("Ukrainian", !getLanguageChecked("Ukrainian")) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.language),
                    title = { Text(stringResource(R.string.lyrics_romanize_serbian)) },
                    trailingContent = {
                        Switch(
                            checked = getLanguageChecked("Serbian"),
                            onCheckedChange = { setLanguageChecked("Serbian", it) },
                        )
                    },
                    onClick = { setLanguageChecked("Serbian", !getLanguageChecked("Serbian")) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.language),
                    title = { Text(stringResource(R.string.lyrics_romanize_bulgarian)) },
                    trailingContent = {
                        Switch(
                            checked = getLanguageChecked("Bulgarian"),
                            onCheckedChange = { setLanguageChecked("Bulgarian", it) },
                        )
                    },
                    onClick = { setLanguageChecked("Bulgarian", !getLanguageChecked("Bulgarian")) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.language),
                    title = { Text(stringResource(R.string.lyrics_romanize_belarusian)) },
                    trailingContent = {
                        Switch(
                            checked = getLanguageChecked("Belarusian"),
                            onCheckedChange = { setLanguageChecked("Belarusian", it) },
                        )
                    },
                    onClick = { setLanguageChecked("Belarusian", !getLanguageChecked("Belarusian")) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.language),
                    title = { Text(stringResource(R.string.lyrics_romanize_kyrgyz)) },
                    trailingContent = {
                        Switch(
                            checked = getLanguageChecked("Kyrgyz"),
                            onCheckedChange = { setLanguageChecked("Kyrgyz", it) },
                        )
                    },
                    onClick = { setLanguageChecked("Kyrgyz", !getLanguageChecked("Kyrgyz")) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.language),
                    title = { Text(stringResource(R.string.lyrics_romanize_macedonian)) },
                    trailingContent = {
                        Switch(
                            checked = getLanguageChecked("Macedonian"),
                            onCheckedChange = { setLanguageChecked("Macedonian", it) },
                        )
                    },
                    onClick = { setLanguageChecked("Macedonian", !getLanguageChecked("Macedonian")) }
                )
            )
        )
    }

    TopAppBar(
        title = { Text(stringResource(R.string.lyrics_romanization)) },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain,
            ) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                )
            }
        }
    )
}
