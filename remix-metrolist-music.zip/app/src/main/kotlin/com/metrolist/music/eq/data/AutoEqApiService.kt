package com.metrolist.music.eq.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import java.io.File
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Service to fetch AutoEQ sound profiles and presets via open public APIs.
 * Requires internet connection to fetch index and presets, but does not require
 * any user account, registration, or API key.
 * All downloaded audio profiles are cached locally on the device for fast offline reuse.
 */
class AutoEqApiService(private val context: Context) {

    private val entries = mutableListOf<Entry>()
    private var isIndexed = false

    private val cacheDir = File(context.filesDir, "autoeq_cache")
    private val indexFile = File(cacheDir, "index.md")
    private val indexTimestampFile = File(cacheDir, "index_timestamp")

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    companion object {
        private const val TAG = "AutoEqApiService"

        // Public Open API / CDN Mirrors for AutoEQ Index (no account / no token required)
        private val INDEX_MIRRORS = listOf(
            "https://cdn.jsdelivr.net/gh/jaakkopasanen/AutoEq@master/results/INDEX.md",
            "https://fastly.jsdelivr.net/gh/jaakkopasanen/AutoEq@master/results/INDEX.md",
            "https://raw.githubusercontent.com/jaakkopasanen/AutoEq/master/results/INDEX.md",
            "https://raw.githack.com/jaakkopasanen/AutoEq/master/results/INDEX.md",
            "https://cdn.statically.io/gh/jaakkopasanen/AutoEq/master/results/INDEX.md"
        )

        // Public Open API / CDN Base Mirrors for ParametricEQ files
        private val RAW_BASE_MIRRORS = listOf(
            "https://cdn.jsdelivr.net/gh/jaakkopasanen/AutoEq@master/results",
            "https://fastly.jsdelivr.net/gh/jaakkopasanen/AutoEq@master/results",
            "https://raw.githubusercontent.com/jaakkopasanen/AutoEq/master/results",
            "https://raw.githack.com/jaakkopasanen/AutoEq/master/results"
        )

        private const val CACHE_TTL_MS = 7 * 24 * 60 * 60 * 1000L // 7 days cache
        private val INDEX_LINE_REGEX = Regex("""^-\s*\[(.*?)\]\((.*?)\)(?:\s+by\s+(.*?))?(?:\s+on\s+(.*?))?$""")
    }

    /**
     * Check whether a cached database index exists locally.
     */
    fun isDatabaseCached(): Boolean = indexFile.exists() && indexFile.length() > 0

    /**
     * Build the search index by downloading or loading the AutoEQ database.
     * Requires network access to download fresh index if not cached.
     */
    suspend fun buildIndex(): Boolean = withContext(Dispatchers.IO) {
        try {
            cacheDir.mkdirs()

            val indexContent = getCachedOrFetchIndex()
            if (!indexContent.isNullOrBlank()) {
                val parsedEntries = parseIndexMarkdown(indexContent)
                if (parsedEntries.isNotEmpty()) {
                    entries.clear()
                    entries.addAll(parsedEntries)
                    isIndexed = true
                    Timber.tag(TAG).d("Successfully indexed ${entries.size} AutoEQ sound profiles")
                    return@withContext true
                }
            }

            false
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to build AutoEQ index")
            false
        }
    }

    /**
     * Fetch INDEX.md from public mirrors or read from local disk cache.
     */
    private fun getCachedOrFetchIndex(): String? {
        // Use local cache if fresh
        if (indexFile.exists() && indexTimestampFile.exists()) {
            val timestamp = indexTimestampFile.readText().trim().toLongOrNull() ?: 0L
            if (System.currentTimeMillis() - timestamp < CACHE_TTL_MS) {
                val cached = indexFile.readText()
                if (cached.isNotBlank()) return cached
            }
        }

        // Fetch from open public CDN mirrors (no account needed)
        for (mirrorUrl in INDEX_MIRRORS) {
            try {
                val request = Request.Builder()
                    .url(mirrorUrl)
                    .header("User-Agent", "Mozilla/5.0 (Android; Mobile)")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string()
                        if (!body.isNullOrBlank() && body.contains("- [")) {
                            indexFile.writeText(body)
                            indexTimestampFile.writeText(System.currentTimeMillis().toString())
                            return body
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.tag(TAG).w("Mirror fetch failed (%s): %s", mirrorUrl, e.message)
            }
        }

        // Fallback to existing cache if offline
        if (indexFile.exists()) {
            return indexFile.readText()
        }

        return null
    }

    /**
     * Parse INDEX.md into structured Entry items.
     */
    private fun parseIndexMarkdown(markdown: String): List<Entry> {
        val result = ArrayList<Entry>(9000)

        for (line in markdown.lineSequence()) {
            val trimmed = line.trim()
            if (!trimmed.startsWith("- [")) continue

            val match = INDEX_LINE_REGEX.matchEntire(trimmed) ?: continue
            val labelFromLine = match.groupValues[1].trim()
            val rawPath = match.groupValues[2].trim()
            val sourceFromLine = match.groupValues[3].trim()
            val rigFromLine = match.groupValues[4].trim()

            val decodedPath = try {
                URLDecoder.decode(rawPath, "UTF-8")
            } catch (e: Exception) {
                rawPath
            }.removePrefix("./").trim()

            val parts = decodedPath.split("/")
            if (parts.size >= 3) {
                val source = if (sourceFromLine.isNotEmpty()) sourceFromLine else parts[0]
                val formRigDir = parts[1]
                val modelFolder = parts[2]
                val label = labelFromLine.ifEmpty { modelFolder }

                val (rigFromDir, parsedForm) = parseFormAndRig(formRigDir)
                val finalRig = when {
                    rigFromLine.isNotEmpty() -> rigFromLine
                    rigFromDir != "unknown" -> rigFromDir
                    else -> "unknown"
                }

                result.add(
                    Entry(
                        label = label,
                        form = parsedForm,
                        rig = finalRig,
                        source = source,
                        formDirectory = formRigDir
                    )
                )
            }
        }

        return result
    }

    /**
     * Search models by keyword or get recommended presets when query is empty.
     */
    fun searchModels(query: String, maxResults: Int = 100): Map<String, List<Entry>> {
        if (!isIndexed) {
            Timber.tag(TAG).w("Index not built. Call buildIndex() first.")
            return emptyMap()
        }

        val lowerQuery = query.lowercase().trim()

        val filtered = if (lowerQuery.isBlank()) {
            entries
        } else {
            entries.filter { normalizeModelName(it.label).lowercase().contains(lowerQuery) }
        }

        val grouped = filtered.groupBy { normalizeModelName(it.label) }

        val sortedNames = grouped.keys.sortedWith(
            compareByDescending<String> { name ->
                val lower = name.lowercase()
                when {
                    lowerQuery.isEmpty() -> 0
                    lower == lowerQuery -> 2000
                    lower.startsWith(lowerQuery) -> 1000
                    else -> 100
                }
            }.thenBy { it }
        ).take(maxResults)

        return sortedNames.associateWith { grouped.getValue(it) }
    }

    /**
     * Get all variants and sound recording profiles for a specific headphone model.
     */
    fun getVariantsForModel(modelName: String): List<Entry> {
        val normalizedSearch = normalizeModelName(modelName)
        return entries.filter {
            normalizeModelName(it.label).equals(normalizedSearch, ignoreCase = true)
        }
    }

    /**
     * Load the Parametric EQ audio profile for a selected entry.
     * Uses local disk cache if available, or downloads via public API.
     */
    suspend fun loadEQ(entry: Entry): ParametricEQ? = withContext(Dispatchers.IO) {
        try {
            val relativePath = "${entry.source}/${entry.formDirectory}/${entry.label}/${entry.label} ParametricEQ.txt"
            val content = fetchParametricEQFile(relativePath, entry) ?: return@withContext null
            ParametricEQParser.parseText(content)
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to load EQ for %s", entry.label)
            null
        }
    }

    /**
     * Fetch ParametricEQ preset with local disk caching and multi-mirror failover.
     */
    private fun fetchParametricEQFile(relativePath: String, entry: Entry): String? {
        val safeLocalFileName = "${entry.source}_${entry.formDirectory}_${entry.label}_ParametricEQ.txt"
            .replace("[^a-zA-Z0-9._-]".toRegex(), "_")
        val cacheFile = File(cacheDir, safeLocalFileName)

        // Return cached file if present
        if (cacheFile.exists() && cacheFile.length() > 0) {
            return cacheFile.readText()
        }

        val encodedPath = relativePath.split("/").joinToString("/") { segment ->
            try {
                URLEncoder.encode(segment, "UTF-8").replace("+", "%20")
            } catch (e: Exception) {
                segment
            }
        }

        // Fetch through public CDN API mirrors without requiring an account
        for (baseUrl in RAW_BASE_MIRRORS) {
            val url = "$baseUrl/$encodedPath"
            try {
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "Mozilla/5.0 (Android; Mobile)")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string()
                        if (!body.isNullOrBlank() && (body.contains("Preamp:") || body.contains("Filter "))) {
                            cacheFile.writeText(body)
                            return body
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.tag(TAG).w("Failed to fetch %s from %s: %s", relativePath, baseUrl, e.message)
            }
        }

        return null
    }

    /**
     * Get all indexed entries.
     */
    fun getAllEntries(): List<Entry> = entries.toList()

    private fun normalizeModelName(modelName: String): String {
        return modelName.replace(Regex("""\s*\([^)]*\)\s*"""), "").trim()
    }

    private fun parseFormAndRig(formRig: String): Pair<String, String> {
        val formKeywords = listOf("in-ear", "over-ear", "earbud")

        val foundForm = formKeywords.firstOrNull {
            formRig.contains(it, ignoreCase = true)
        } ?: "unknown"

        val rig = formRig.replace(foundForm, "", ignoreCase = true).trim()

        return Pair(rig.ifEmpty { "unknown" }, foundForm)
    }
}
