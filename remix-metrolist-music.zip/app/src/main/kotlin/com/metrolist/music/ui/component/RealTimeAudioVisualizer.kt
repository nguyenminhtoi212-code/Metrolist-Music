package com.metrolist.music.ui.component

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.sin

@Composable
fun RealTimeAudioVisualizer(
    isPlaying: Boolean,
    style: String,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary
) {
    when (style) {
        "wave" -> WaveVisualizer(isPlaying = isPlaying, modifier = modifier, color = color)
        "pulse" -> PulseVisualizer(isPlaying = isPlaying, modifier = modifier, color = color)
        else -> SpectrumVisualizer(isPlaying = isPlaying, modifier = modifier, color = color)
    }
}

@Composable
fun SpectrumVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary
) {
    val infiniteTransition = rememberInfiniteTransition(label = "spectrum")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * kotlin.math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        val barCount = 18
        val spacing = 4.dp.toPx()
        val totalSpacing = spacing * (barCount - 1)
        val barWidth = (width - totalSpacing) / barCount

        val primaryColor = color
        val secondaryColor = color.copy(alpha = 0.4f)
        val gradient = Brush.verticalGradient(
            colors = listOf(primaryColor, secondaryColor)
        )

        for (i in 0 until barCount) {
            val animatedHeight = if (isPlaying) {
                val s1 = sin(phase + i * 0.8f)
                val s2 = sin(phase * 1.5f - i * 0.4f)
                val s3 = sin(phase * 0.7f + i * 1.2f)
                0.15f + 0.8f * ((s1 + s2 + s3) / 3f + 1f) / 2f
            } else {
                0.08f + 0.04f * sin(i * 0.5f)
            }

            val currentBarHeight = height * animatedHeight
            val x = i * (barWidth + spacing)
            val y = height - currentBarHeight

            drawRoundRect(
                brush = gradient,
                topLeft = Offset(x, y),
                size = Size(barWidth, currentBarHeight),
                cornerRadius = CornerRadius(barWidth / 2, barWidth / 2)
            )
        }
    }
}

@Composable
fun WaveVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary
) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * kotlin.math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        val midY = height / 2f

        val path1 = Path()
        val path2 = Path()

        val points = 80
        val dx = width / points

        val amp = if (isPlaying) height * 0.4f else height * 0.05f

        for (i in 0..points) {
            val x = i * dx
            val angle1 = (i.toFloat() / points) * 2f * kotlin.math.PI.toFloat() * 2f + phase
            val y1 = midY + sin(angle1) * amp

            val angle2 = (i.toFloat() / points) * 2f * kotlin.math.PI.toFloat() * 1.5f - phase * 1.3f
            val y2 = midY + sin(angle2) * (amp * 0.6f)

            if (i == 0) {
                path1.moveTo(x, y1)
                path2.moveTo(x, y2)
            } else {
                path1.lineTo(x, y1)
                path2.lineTo(x, y2)
            }
        }

        drawPath(
            path = path1,
            color = color,
            style = Stroke(width = 3.dp.toPx())
        )

        drawPath(
            path = path2,
            color = color.copy(alpha = 0.4f),
            style = Stroke(width = 1.5.dp.toPx())
        )
    }
}

@Composable
fun PulseVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scale"
    )
    val alpha by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "alpha"
    )

    Canvas(modifier = modifier) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val maxRadius = kotlin.math.min(size.width, size.height) / 2f

        if (isPlaying) {
            // Circle 1
            drawCircle(
                color = color.copy(alpha = alpha * 0.5f),
                radius = maxRadius * scale,
                center = center,
                style = Stroke(width = 3.dp.toPx())
            )

            // Circle 2 (offset)
            val delayedScale = if (scale > 0.75f) scale - 0.25f else scale + 0.25f
            val delayedAlpha = 1.0f - delayedScale
            drawCircle(
                color = color.copy(alpha = delayedAlpha * 0.3f),
                radius = maxRadius * delayedScale,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )
        } else {
            drawCircle(
                color = color.copy(alpha = 0.2f),
                radius = maxRadius * 0.5f,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )
        }
    }
}
