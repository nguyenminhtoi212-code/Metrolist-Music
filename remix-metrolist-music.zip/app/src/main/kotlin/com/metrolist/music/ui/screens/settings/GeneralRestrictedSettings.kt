/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.rememberPreference
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey

val RestrictedModeKey = booleanPreferencesKey("restrictedModeEnabled")
val DetailedStatsKey = booleanPreferencesKey("enableDetailedStats")
val CaptionsEnabledKey = booleanPreferencesKey("captionsEnabled")
val CaptionsTextSizeKey = stringPreferencesKey("captionsTextSize")
val CaptionsLanguageKey = stringPreferencesKey("captionsLanguage")
val RestrictedThisDeviceKey = booleanPreferencesKey("restrictedModeThisDevice")
val SmartDevicesKey = stringPreferencesKey("smartDevicesConfig")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeneralRestrictedSettings(
    navController: NavController
) {
    val (restrictedMode, onRestrictedModeChange) = rememberPreference(key = RestrictedModeKey, defaultValue = false)
    val (detailedStats, onDetailedStatsChange) = rememberPreference(key = DetailedStatsKey, defaultValue = true)
    val (captionsEnabled, onCaptionsEnabledChange) = rememberPreference(key = CaptionsEnabledKey, defaultValue = true)
    val (captionsTextSize, onCaptionsTextSizeChange) = rememberPreference(key = CaptionsTextSizeKey, defaultValue = "Normal")
    val (captionsLanguage, onCaptionsLanguageChange) = rememberPreference(key = CaptionsLanguageKey, defaultValue = "vi")
    val (restrictedThisDevice, onRestrictedThisDeviceChange) = rememberPreference(key = RestrictedThisDeviceKey, defaultValue = true)
    val (smartDevicesConfig, onSmartDevicesConfigChange) = rememberPreference(
        key = SmartDevicesKey,
        defaultValue = "Android TV:true,Google Nest Hub:false,Living Room Speaker:true"
    )

    // New custom settings states
    val (appLanguage, onAppLanguageChange) = rememberPreference(key = com.metrolist.music.constants.AppLanguageKey, defaultValue = com.metrolist.music.constants.SYSTEM_DEFAULT)
    val (audioQuality, onAudioQualityChange) = rememberPreference(key = com.metrolist.music.constants.AudioQualityKey, defaultValue = "AUTO")
    val (eqToggleProfessional, onEqToggleProfessionalChange) = rememberPreference(key = com.metrolist.music.constants.EqToggleProfessionalKey, defaultValue = false)
    val (dynamicTheme, onDynamicThemeChange) = rememberPreference(key = com.metrolist.music.constants.DynamicThemeKey, defaultValue = false)
    val (predictiveBack, onPredictiveBackChange) = rememberPreference(key = com.metrolist.music.constants.PredictiveBackKey, defaultValue = false)
    val (proxyEnabled, onProxyEnabledChange) = rememberPreference(key = com.metrolist.music.constants.ProxyEnabledKey, defaultValue = true)
    val (offlineMode, onOfflineModeChange) = rememberPreference(key = com.metrolist.music.constants.OfflineModeKey, defaultValue = false)
    val (sponsorBlock, onSponsorBlockChange) = rememberPreference(key = com.metrolist.music.constants.SponsorBlockKey, defaultValue = false)
    val (automaticSongPicker, onAutomaticSongPickerChange) = rememberPreference(key = com.metrolist.music.constants.AutomaticSongPickerKey, defaultValue = false)
    val (externalRecommendations, onExternalRecommendationsChange) = rememberPreference(key = com.metrolist.music.constants.ExternalRecommendationsKey, defaultValue = false)

    var showCaptionsDialog by rememberSaveable { mutableStateOf(false) }
    var showSmartDevicesDialog by rememberSaveable { mutableStateOf(false) }
    var showAddDeviceDialog by rememberSaveable { mutableStateOf(false) }
    var newDeviceName by rememberSaveable { mutableStateOf("") }

    var showAppLanguageDialog by rememberSaveable { mutableStateOf(false) }
    var showAudioQualityDialog by rememberSaveable { mutableStateOf(false) }

    // Dialogs
    if (showAppLanguageDialog) {
        com.metrolist.music.ui.component.EnumDialog(
            onDismiss = { showAppLanguageDialog = false },
            onSelect = {
                onAppLanguageChange(it)
                showAppLanguageDialog = false
            },
            title = "Ngôn ngữ (Language)",
            current = appLanguage,
            values = (listOf(com.metrolist.music.constants.SYSTEM_DEFAULT) + com.metrolist.music.constants.LanguageCodeToName.keys.toList()),
            valueText = {
                com.metrolist.music.constants.LanguageCodeToName.getOrElse(it) { "Mặc định hệ thống" }
            },
        )
    }

    if (showAudioQualityDialog) {
        com.metrolist.music.ui.component.EnumDialog(
            onDismiss = { showAudioQualityDialog = false },
            onSelect = {
                onAudioQualityChange(it)
                showAudioQualityDialog = false
            },
            title = "Chất lượng âm thanh (Audio quality)",
            current = audioQuality,
            values = listOf("AUTO", "LOW", "HIGH"),
            valueText = {
                when (it) {
                    "AUTO" -> "Tự động (Auto)"
                    "LOW" -> "Thấp (Low)"
                    "HIGH" -> "Cao (High)"
                    else -> it
                }
            },
        )
    }

    // Parse smart devices config
    val smartDevices = remember(smartDevicesConfig) {
        if (smartDevicesConfig.isBlank()) emptyList()
        else smartDevicesConfig.split(",").mapNotNull {
            val parts = it.split(":")
            if (parts.size == 2) {
                parts[0] to parts[1].toBoolean()
            } else {
                null
            }
        }
    }

    // Captions Management Dialog
    if (showCaptionsDialog) {
        AlertDialog(
            onDismissRequest = { showCaptionsDialog = false },
            title = { Text(stringResource(R.string.captions_title)) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(stringResource(R.string.enable_captions_title))
                        Switch(
                            checked = captionsEnabled,
                            onCheckedChange = onCaptionsEnabledChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (captionsEnabled) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    }

                    AnimatedVisibility(visible = captionsEnabled) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = stringResource(R.string.captions_text_size_title),
                                style = MaterialTheme.typography.titleSmall
                            )
                            listOf(
                                "Normal" to stringResource(R.string.captions_size_normal),
                                "Large" to stringResource(R.string.captions_size_large),
                                "Extra Large" to stringResource(R.string.captions_size_extra_large)
                            ).forEach { (value, label) ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onCaptionsTextSizeChange(value) }
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = captionsTextSize == value,
                                        onClick = { onCaptionsTextSizeChange(value) }
                                    )
                                    Text(
                                        text = label,
                                        modifier = Modifier.padding(start = 8.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = stringResource(R.string.captions_language_title),
                                style = MaterialTheme.typography.titleSmall
                            )
                            listOf(
                                "vi" to stringResource(R.string.lang_vi),
                                "en" to stringResource(R.string.lang_en),
                                "auto" to stringResource(R.string.lang_auto)
                            ).forEach { (value, label) ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onCaptionsLanguageChange(value) }
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = captionsLanguage == value,
                                        onClick = { onCaptionsLanguageChange(value) }
                                    )
                                    Text(
                                        text = label,
                                        modifier = Modifier.padding(start = 8.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCaptionsDialog = false }) {
                    Text(stringResource(R.string.close))
                }
            }
        )
    }

    // Smart Devices Configuration Dialog
    if (showSmartDevicesDialog) {
        AlertDialog(
            onDismissRequest = { showSmartDevicesDialog = false },
            title = { Text(stringResource(R.string.smart_devices_title)) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = stringResource(R.string.smart_devices_dialog_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    smartDevices.forEach { (name, isEnabled) ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = name, style = MaterialTheme.typography.bodyLarge)
                            Switch(
                                checked = isEnabled,
                                onCheckedChange = { checked ->
                                    val updated = smartDevices.map {
                                        if (it.first == name) name to checked else it
                                    }
                                    onSmartDevicesConfigChange(updated.joinToString(",") { "${it.first}:${it.second}" })
                                },
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (isEnabled) R.drawable.check else R.drawable.close
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize)
                                    )
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    TextButton(
                        onClick = { showAddDeviceDialog = true },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(stringResource(R.string.add_smart_device_btn))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSmartDevicesDialog = false }) {
                    Text(stringResource(R.string.close))
                }
            }
        )
    }

    // Add Smart Device Sub-dialog
    if (showAddDeviceDialog) {
        AlertDialog(
            onDismissRequest = { showAddDeviceDialog = false },
            title = { Text(stringResource(R.string.add_smart_device_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(stringResource(R.string.add_smart_device_desc))
                    OutlinedTextField(
                        value = newDeviceName,
                        onValueChange = { newDeviceName = it },
                        label = { Text(stringResource(R.string.device_name_label)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newDeviceName.isNotBlank()) {
                            val updated = smartDevices + (newDeviceName to true)
                            onSmartDevicesConfigChange(updated.joinToString(",") { "${it.first}:${it.second}" })
                            newDeviceName = ""
                            showAddDeviceDialog = false
                        }
                    }
                ) {
                    Text(stringResource(R.string.add_btn))
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDeviceDialog = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    Column(
        Modifier
            .windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top
                )
            )
        )

        // Group 1: General & Audio
        Material3SettingsGroup(
            title = "Cài đặt chung & Âm thanh (General & Audio)",
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.language),
                    title = { Text("Ngôn ngữ (Language)") },
                    description = {
                        Text(
                            com.metrolist.music.constants.LanguageCodeToName.getOrElse(appLanguage) { "Mặc định hệ thống" }
                        )
                    },
                    onClick = { showAppLanguageDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.music_note),
                    title = { Text("Chất lượng âm thanh (Audio quality)") },
                    description = {
                        Text(
                            when (audioQuality) {
                                "AUTO" -> "Tự động (Auto)"
                                "LOW" -> "Thấp (Low)"
                                "HIGH" -> "Cao (High)"
                                else -> audioQuality
                            }
                        )
                    },
                    onClick = { showAudioQualityDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.equalizer),
                    title = { Text("Bộ cân bằng âm thanh (Equalizer)") },
                    description = { Text("Xử lý âm thanh chuyên nghiệp & hiệu ứng") },
                    trailingContent = {
                        Switch(
                            checked = eqToggleProfessional,
                            onCheckedChange = onEqToggleProfessionalChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (eqToggleProfessional) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onEqToggleProfessionalChange(!eqToggleProfessional) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.palette),
                    title = { Text("Dynamic accent color (Android 12+)") },
                    description = { Text("Áp dụng màu chủ đạo từ hình nền hệ thống") },
                    trailingContent = {
                        Switch(
                            checked = dynamicTheme,
                            onCheckedChange = onDynamicThemeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (dynamicTheme) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onDynamicThemeChange(!dynamicTheme) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.arrow_back),
                    title = { Text("Predictive back (Android 14+)") },
                    description = { Text("Cho phép xem trước màn hình trước khi quay lại") },
                    trailingContent = {
                        Switch(
                            checked = predictiveBack,
                            onCheckedChange = onPredictiveBackChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (predictiveBack) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPredictiveBackChange(!predictiveBack) }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Group 2: Connectivity & Advanced Features
        Material3SettingsGroup(
            title = "Kết nối & Tính năng nâng cao (Connectivity & Advanced)",
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.wifi_proxy),
                    title = { Text("Sử dụng Proxy (Use proxy)") },
                    description = { Text("Chỉ sử dụng proxy khi phát trực tuyến thất bại") },
                    trailingContent = {
                        Switch(
                            checked = proxyEnabled,
                            onCheckedChange = onProxyEnabledChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (proxyEnabled) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onProxyEnabledChange(!proxyEnabled) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.stats),
                    title = { Text("Thống kê nghe nhạc (Listening stats)") },
                    description = { Text("Theo dõi số liệu nghe nhạc để tổng hợp hàng tháng & hàng năm") },
                    trailingContent = {
                        Switch(
                            checked = detailedStats,
                            onCheckedChange = onDetailedStatsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (detailedStats) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onDetailedStatsChange(!detailedStats) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.offline),
                    title = { Text("Chế độ ngoại tuyến (Offline mode)") },
                    description = { Text("Tắt tính năng trực tuyến, chỉ sử dụng ngoại tuyến") },
                    trailingContent = {
                        Switch(
                            checked = offlineMode,
                            onCheckedChange = onOfflineModeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (offlineMode) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onOfflineModeChange(!offlineMode) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.security),
                    title = { Text("SponsorBlock") },
                    description = { Text("Tự động bỏ qua các phân đoạn quảng cáo trong bài hát") },
                    trailingContent = {
                        Switch(
                            checked = sponsorBlock,
                            onCheckedChange = onSponsorBlockChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (sponsorBlock) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onSponsorBlockChange(!sponsorBlock) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.music_note),
                    title = { Text("Tự động chọn bài (Automatic song picker)") },
                    description = { Text("Tự động phát ngẫu nhiên một bài hát khi danh sách phát kết thúc") },
                    trailingContent = {
                        Switch(
                            checked = automaticSongPicker,
                            onCheckedChange = onAutomaticSongPickerChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (automaticSongPicker) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAutomaticSongPickerChange(!automaticSongPicker) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.similar),
                    title = { Text("Gợi ý từ thuật toán ngoài (External recommendations)") },
                    description = { Text("Sử dụng thuật toán bên ngoài để đề xuất thay vì của Musify") },
                    trailingContent = {
                        Switch(
                            checked = externalRecommendations,
                            onCheckedChange = onExternalRecommendationsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (externalRecommendations) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onExternalRecommendationsChange(!externalRecommendations) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.settings),
                    title = { Text("Công cụ (Tools & Advanced)") },
                    description = { Text("Dọn dẹp bộ nhớ đệm, sửa lỗi giật lắc & các cài đặt gỡ lỗi") },
                    onClick = { navController.navigate("settings/advanced") }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Group 3: Device management & Captions
        Material3SettingsGroup(
            title = stringResource(R.string.settings_general_restricted_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.security),
                    title = { Text(stringResource(R.string.restricted_mode_title)) },
                    description = { Text(stringResource(R.string.restricted_mode_desc)) },
                    trailingContent = {
                        Switch(
                            checked = restrictedMode,
                            onCheckedChange = onRestrictedModeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (restrictedMode) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onRestrictedModeChange(!restrictedMode) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.translate),
                    title = { Text(stringResource(R.string.captions_title)) },
                    description = { Text(stringResource(R.string.captions_desc)) },
                    onClick = { showCaptionsDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.settings),
                    title = { Text(stringResource(R.string.this_device_title)) },
                    trailingContent = {
                        Switch(
                            checked = restrictedThisDevice,
                            onCheckedChange = onRestrictedThisDeviceChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (restrictedThisDevice) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onRestrictedThisDeviceChange(!restrictedThisDevice) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.wifi_proxy),
                    title = { Text(stringResource(R.string.smart_devices_title)) },
                    description = { Text(stringResource(R.string.smart_devices_desc)) },
                    onClick = { showSmartDevicesDialog = true }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))
    }

    TopAppBar(
        title = { Text(stringResource(R.string.settings_general_restricted_title)) },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain,
            ) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                )
            }
        }
    )
}
