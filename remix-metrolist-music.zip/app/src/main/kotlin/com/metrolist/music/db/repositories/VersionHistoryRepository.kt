/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.db.repositories

import android.content.Context
import com.metrolist.music.BuildConfig
import com.metrolist.music.db.daos.VersionHistoryDao
import com.metrolist.music.db.entities.VersionHistoryEntity
import com.metrolist.music.utils.Updater
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.format.DateTimeFormatter
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VersionHistoryRepository @Inject constructor(
    private val versionHistoryDao: VersionHistoryDao
) {
    val allVersions: Flow<List<VersionHistoryEntity>> = versionHistoryDao.getAllVersionHistory()

    suspend fun getVersion(version: String): VersionHistoryEntity? = withContext(Dispatchers.IO) {
        versionHistoryDao.getVersionHistory(version)
    }

    suspend fun saveVersion(versionHistory: VersionHistoryEntity) = withContext(Dispatchers.IO) {
        versionHistoryDao.upsertVersionHistory(versionHistory)
    }

    /**
     * Seeds or synchronizes version history from bundled assets and current app version into Room DB.
     */
    suspend fun syncVersionHistory(context: Context): Int = withContext(Dispatchers.IO) {
        val notes = Updater.loadChangelogFromAssets(context)
        val currentVersion = BuildConfig.VERSION_NAME
        val currentTag = "v$currentVersion"

        val entities = mutableListOf<VersionHistoryEntity>()

        // Add current app build version
        entities.add(
            VersionHistoryEntity(
                version = currentTag,
                versionName = currentVersion,
                releaseDate = DateTimeFormatter.ISO_INSTANT.format(Instant.now()),
                description = "",
                descriptionVi = "",
                descriptionEn = "",
                isCurrent = true,
                installedAt = System.currentTimeMillis()
            )
        )

        var timeOffset = 1000L * 60 * 60 * 24L // 1 day intervals in past for sorting
        for (note in notes) {
            val vName = note.version.removePrefix("v")
            if (note.version == currentTag || vName == currentVersion) continue

            entities.add(
                VersionHistoryEntity(
                    version = note.version,
                    versionName = vName,
                    releaseDate = "",
                    description = note.content,
                    descriptionVi = note.content,
                    descriptionEn = note.content,
                    isCurrent = false,
                    installedAt = System.currentTimeMillis() - timeOffset
                )
            )
            timeOffset += 1000L * 60 * 60 * 24L
        }

        versionHistoryDao.insertAll(entities)
        versionHistoryDao.markCurrentVersion(currentVersion)
        entities.size
    }

    /**
     * Inserts or updates release notes for a remote release info fetched from API.
     */
    suspend fun syncLatestRelease(releaseInfo: com.metrolist.music.utils.ReleaseInfo) = withContext(Dispatchers.IO) {
        val versionTag = if (releaseInfo.versionName.startsWith("v")) releaseInfo.versionName else "v${releaseInfo.versionName}"
        val versionName = releaseInfo.versionName.removePrefix("v")
        val isCurrent = versionName == BuildConfig.VERSION_NAME || versionTag == "v${BuildConfig.VERSION_NAME}"

        val entity = VersionHistoryEntity(
            version = versionTag,
            versionName = versionName,
            releaseDate = releaseInfo.releaseDate.ifBlank { DateTimeFormatter.ISO_INSTANT.format(Instant.now()) },
            description = releaseInfo.description,
            descriptionVi = releaseInfo.descriptionVi,
            descriptionEn = releaseInfo.descriptionEn,
            isCurrent = isCurrent,
            installedAt = if (isCurrent) System.currentTimeMillis() else 0L
        )
        versionHistoryDao.upsertVersionHistory(entity)
    }
}
