/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.constants.*
import com.metrolist.music.ui.component.DefaultDialog
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.rememberPreference
import com.metrolist.music.utils.rememberEnumPreference
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LyricSettings(
    navController: NavController
) {
    // 1. Sync & Scroll settings
    val (lyricsScroll, onLyricsScrollChange) = rememberPreference(LyricsScrollKey, defaultValue = true)
    val (lyricsClick, onLyricsClickChange) = rememberPreference(LyricsClickKey, defaultValue = true)
    
    // 2. Customizations settings
    val (experimentalLyrics, onExperimentalLyricsChange) = rememberPreference(ExperimentalLyricsKey, defaultValue = true)
    val (lineLanguageDetection, onLineLanguageDetectionChange) = rememberPreference(LineLanguageDetectionKey, defaultValue = false)
    val (lyricsGlowEffect, onLyricsGlowEffectChange) = rememberPreference(LyricsGlowEffectKey, defaultValue = false)
    val (lyricsTextSize, onLyricsTextSizeChange) = rememberPreference(LyricsTextSizeKey, defaultValue = 24f)
    val (lyricsLineSpacing, onLyricsLineSpacingChange) = rememberPreference(LyricsLineSpacingKey, defaultValue = 1.2f)
    
    // 3. Position & Animation
    val (lyricsPosition, onLyricsPositionChange) = rememberEnumPreference(LyricsTextPositionKey, defaultValue = LyricsPosition.CENTER)
    val (lyricsAnimationStyle, onLyricsAnimationStyleChange) = rememberEnumPreference(LyricsAnimationStyleKey, defaultValue = LyricsAnimationStyle.LYRICS_V2_FLUID)

    // Dialog state
    var showLyricsPositionDialog by rememberSaveable { mutableStateOf(false) }
    var showLyricsAnimationStyleDialog by rememberSaveable { mutableStateOf(false) }
    var showLyricsTextSizeDialog by remember { mutableStateOf(false) }
    var showLyricsLineSpacingDialog by remember { mutableStateOf(false) }

    // Dialog for text position
    if (showLyricsPositionDialog) {
        DefaultDialog(
            onDismiss = { showLyricsPositionDialog = false },
            buttons = {
                TextButton(onClick = { showLyricsPositionDialog = false }) {
                    Text(stringResource(android.R.string.cancel))
                }
            }
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.lyrics_text_position),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                LyricsPosition.values().forEach { position ->
                    val name = when (position) {
                        LyricsPosition.LEFT -> stringResource(R.string.left)
                        LyricsPosition.CENTER -> stringResource(R.string.center)
                        LyricsPosition.RIGHT -> stringResource(R.string.right)
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        RadioButton(
                            selected = lyricsPosition == position,
                            onClick = {
                                onLyricsPositionChange(position)
                                showLyricsPositionDialog = false
                            }
                        )
                        Text(
                            text = name,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(start = 16.dp)
                        )
                    }
                }
            }
        }
    }

    // Dialog for animation style
    if (showLyricsAnimationStyleDialog) {
        DefaultDialog(
            onDismiss = { showLyricsAnimationStyleDialog = false },
            buttons = {
                TextButton(onClick = { showLyricsAnimationStyleDialog = false }) {
                    Text(stringResource(android.R.string.cancel))
                }
            }
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.lyrics_animation_style_title),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                LyricsAnimationStyle.values().forEach { style ->
                    val name = when (style) {
                        LyricsAnimationStyle.NONE -> stringResource(R.string.none)
                        LyricsAnimationStyle.FADE -> stringResource(R.string.fade)
                        LyricsAnimationStyle.GLOW -> stringResource(R.string.glow)
                        LyricsAnimationStyle.SLIDE -> stringResource(R.string.slide)
                        LyricsAnimationStyle.KARAOKE -> stringResource(R.string.karaoke)
                        LyricsAnimationStyle.APPLE -> stringResource(R.string.apple_music_style)
                        LyricsAnimationStyle.APPLE_V2 -> stringResource(R.string.lyrics_animation_apple_v2)
                        LyricsAnimationStyle.VIVI_FLUID -> stringResource(R.string.lyrics_animation_vivi_fluid)
                        LyricsAnimationStyle.LYRICS_V2_FLUID -> stringResource(R.string.lyrics_animation_lyrics_v2_fluid)
                        LyricsAnimationStyle.METRO_LYRICS -> stringResource(R.string.lyrics_animation_metro_lyrics)
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        RadioButton(
                            selected = lyricsAnimationStyle == style,
                            onClick = {
                                onLyricsAnimationStyleChange(style)
                                showLyricsAnimationStyleDialog = false
                            }
                        )
                        Text(
                            text = name,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(start = 16.dp)
                        )
                    }
                }
            }
        }
    }

    // Dialog for text size
    if (showLyricsTextSizeDialog) {
        var tempTextSize by remember { mutableFloatStateOf(lyricsTextSize) }
        DefaultDialog(
            onDismiss = { showLyricsTextSizeDialog = false },
            buttons = {
                TextButton(
                    onClick = {
                        tempTextSize = lyricsTextSize
                        showLyricsTextSizeDialog = false
                    }
                ) {
                    Text(stringResource(android.R.string.cancel))
                }
                TextButton(
                    onClick = {
                        onLyricsTextSizeChange(tempTextSize)
                        showLyricsTextSizeDialog = false
                    }
                ) {
                    Text(stringResource(android.R.string.ok))
                }
            }
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    text = stringResource(R.string.lyrics_text_size),
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "${tempTextSize.roundToInt()} sp",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Slider(
                    value = tempTextSize,
                    onValueChange = { tempTextSize = it },
                    valueRange = 16f..36f,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    // Dialog for line spacing
    if (showLyricsLineSpacingDialog) {
        var tempLineSpacing by remember { mutableFloatStateOf(lyricsLineSpacing) }
        DefaultDialog(
            onDismiss = { showLyricsLineSpacingDialog = false },
            buttons = {
                TextButton(
                    onClick = {
                        tempLineSpacing = lyricsLineSpacing
                        showLyricsLineSpacingDialog = false
                    }
                ) {
                    Text(stringResource(android.R.string.cancel))
                }
                TextButton(
                    onClick = {
                        onLyricsLineSpacingChange(tempLineSpacing)
                        showLyricsLineSpacingDialog = false
                    }
                ) {
                    Text(stringResource(android.R.string.ok))
                }
            }
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    text = stringResource(R.string.lyrics_line_spacing),
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = String.format(Locale.US, "%.1f", tempLineSpacing),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Slider(
                    value = tempLineSpacing,
                    onValueChange = { tempLineSpacing = it },
                    valueRange = 1.0f..2.0f,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.lyric_settings_title)) },
                navigationIcon = {
                    IconButton(
                        onClick = { navController.backToMain() }
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.arrow_back),
                            contentDescription = stringResource(R.string.back_button_desc)
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            Modifier
                .padding(innerPadding)
                .windowInsetsPadding(
                    LocalPlayerAwareWindowInsets.current.only(
                        WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom,
                    ),
                )
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
        ) {
            // Section 1: Automatic Lyric Sync
            Material3SettingsGroup(
                title = stringResource(R.string.lyric_sync_section),
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.lyric_sync_auto)) },
                        description = { Text(stringResource(R.string.lyric_sync_auto_desc)) },
                        trailingContent = {
                            Switch(
                                checked = lyricsScroll,
                                onCheckedChange = onLyricsScrollChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (lyricsScroll) R.drawable.check else R.drawable.close,
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onLyricsScrollChange(!lyricsScroll) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.lyrics_click_change)) },
                        description = { Text(stringResource(R.string.lyrics_click_change_desc)) },
                        trailingContent = {
                            Switch(
                                checked = lyricsClick,
                                onCheckedChange = onLyricsClickChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (lyricsClick) R.drawable.check else R.drawable.close,
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onLyricsClickChange(!lyricsClick) }
                    )
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section 2: Visual & Customizations
            Material3SettingsGroup(
                title = stringResource(R.string.lyric_appearance_section),
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.experimental_lyrics)) },
                        description = { Text(stringResource(R.string.experimental_lyrics_desc)) },
                        trailingContent = {
                            Switch(
                                checked = experimentalLyrics,
                                onCheckedChange = onExperimentalLyricsChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (experimentalLyrics) R.drawable.check else R.drawable.close,
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onExperimentalLyricsChange(!experimentalLyrics) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text("THỬ NGHIỆM: Phát hiện ngôn ngữ theo từng dòng") },
                        description = { Text("Tự động nhận diện ngôn ngữ của từng dòng lời bài hát để tối ưu hiển thị") },
                        trailingContent = {
                            Switch(
                                checked = lineLanguageDetection,
                                onCheckedChange = onLineLanguageDetectionChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (lineLanguageDetection) R.drawable.check else R.drawable.close,
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onLineLanguageDetectionChange(!lineLanguageDetection) }
                    ),
                    if (experimentalLyrics) {
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.lyrics),
                            title = { Text(stringResource(R.string.lyrics_glow_effect)) },
                            description = { Text(stringResource(R.string.lyrics_glow_effect_subtext)) },
                            trailingContent = {
                                Switch(
                                    checked = lyricsGlowEffect,
                                    onCheckedChange = onLyricsGlowEffectChange,
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(
                                                id = if (lyricsGlowEffect) R.drawable.check else R.drawable.close,
                                            ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onLyricsGlowEffectChange(!lyricsGlowEffect) }
                        )
                    } else {
                        null
                    },
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.lyrics_animation_style_title)) },
                        description = {
                            val animName = when (lyricsAnimationStyle) {
                                LyricsAnimationStyle.NONE -> stringResource(R.string.none)
                                LyricsAnimationStyle.FADE -> stringResource(R.string.fade)
                                LyricsAnimationStyle.GLOW -> stringResource(R.string.glow)
                                LyricsAnimationStyle.SLIDE -> stringResource(R.string.slide)
                                LyricsAnimationStyle.KARAOKE -> stringResource(R.string.karaoke)
                                LyricsAnimationStyle.APPLE -> stringResource(R.string.apple_music_style)
                                LyricsAnimationStyle.APPLE_V2 -> stringResource(R.string.lyrics_animation_apple_v2)
                                LyricsAnimationStyle.VIVI_FLUID -> stringResource(R.string.lyrics_animation_vivi_fluid)
                                LyricsAnimationStyle.LYRICS_V2_FLUID -> stringResource(R.string.lyrics_animation_lyrics_v2_fluid)
                                LyricsAnimationStyle.METRO_LYRICS -> stringResource(R.string.lyrics_animation_metro_lyrics)
                            }
                            Text(animName)
                        },
                        onClick = { showLyricsAnimationStyleDialog = true }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.lyrics_text_size)) },
                        description = { Text("${lyricsTextSize.roundToInt()} sp") },
                        onClick = { showLyricsTextSizeDialog = true }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.lyrics_line_spacing)) },
                        description = { Text("${String.format(Locale.US, "%.1f", lyricsLineSpacing)}x") },
                        onClick = { showLyricsLineSpacingDialog = true }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.lyrics_text_position)) },
                        description = {
                            val posName = when (lyricsPosition) {
                                LyricsPosition.LEFT -> stringResource(R.string.left)
                                LyricsPosition.CENTER -> stringResource(R.string.center)
                                LyricsPosition.RIGHT -> stringResource(R.string.right)
                            }
                            Text(posName)
                        },
                        onClick = { showLyricsPositionDialog = true }
                    )
                ).filterNotNull()
            )

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
