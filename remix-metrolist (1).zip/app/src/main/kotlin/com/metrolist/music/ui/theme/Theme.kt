package com.metrolist.music.ui.theme

import android.graphics.Bitmap
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.saveable.Saver
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.materialkolor.PaletteStyle
import com.materialkolor.rememberDynamicColorScheme

val DefaultThemeColor = Color(0xFF6750A4)

val ColorSaver: Saver<Color, Int> = Saver(
    save = { it.toArgb() },
    restore = { Color(it) }
)

fun Bitmap.extractThemeColor(): Color {
    return DefaultThemeColor
}

@Composable
fun MetrolistTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    pureBlack: Boolean = false,
    themeColor: Color = DefaultThemeColor,
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = rememberDynamicColorScheme(
        seedColor = themeColor,
        isDark = darkTheme,
        style = PaletteStyle.TonalSpot
    )

    val finalScheme = if (darkTheme && pureBlack) {
        colorScheme.copy(
            background = Color.Black,
            surface = Color.Black,
            surfaceContainer = Color.Black,
            surfaceContainerLow = Color.Black,
            surfaceContainerLowest = Color.Black,
            surfaceContainerHigh = Color.Black,
            surfaceContainerHighest = Color.Black,
        )
    } else colorScheme

    MaterialTheme(
        colorScheme = finalScheme,
        content = content
    )
}

