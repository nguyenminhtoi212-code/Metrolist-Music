/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.api

import com.metrolist.music.security.SecureKeyStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import timber.log.Timber
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

/**
 * FEATURE SPECIFICATION: API Key Management & Validation System
 *
 * 1. Core Objective:
 *    Secure, global API Key management and license validation system supporting
 *    standard AI service providers (Google Gemini, OpenAI, Anthropic, OpenRouter, etc.)
 *    with strict validity, security, and anti-tamper protections.
 *
 * 2. API Key Validation Logic (5 Strict Classification Rules):
 *    1. VALID_ACTIVE: Correct format, active status, valid quota. Grants full access.
 *    2. EXPIRED: Recognized format, but subscription/quota ended. Blocks access & displays renewal prompt.
 *    3. RENEWED_EXTENDED: Status updated from expired to active following plan extension. Restores access.
 *    4. LIFETIME_FREE: Valid tier marked for permanent or free access without renewal bounds. Unrestricted access.
 *    5. INVALID_SPOOFED: Arbitrary text, incorrect format, fake key structure, or unverified backend. Rejected immediately.
 *
 * 3. Security & Anti-Abuse Protocols:
 *    - Zero Public Disclosure: Keys never exposed in plain text logs or UI; stored securely using AES-GCM encryption.
 *    - Bypass & Spoof Prevention: Client regex + live backend signature/ping + anti-tamper hash verification.
 *    - Global Compatibility: Standardized response & token handling across all AI providers.
 */
enum class ApiKeyClassification(val storageKey: String) {
    VALID_ACTIVE("valid_active"),
    EXPIRED("expired"),
    RENEWED_EXTENDED("renewed_extended"),
    LIFETIME_FREE("lifetime_free"),
    INVALID_SPOOFED("invalid_spoofed"),
    ERROR("error"),
    IDLE("idle"),
    CHECKING("checking");

    companion object {
        fun fromStorageKey(key: String): ApiKeyClassification {
            return entries.firstOrNull { it.storageKey == key } ?: IDLE
        }
    }
}

sealed class ApiKeyValidationResult {
    object Idle : ApiKeyValidationResult()
    object Checking : ApiKeyValidationResult()

    data class Valid(
        val message: String,
        val classification: ApiKeyClassification = ApiKeyClassification.VALID_ACTIVE,
        val label: String? = null,
        val usage: Double? = null,
        val limit: Double? = null,
        val isFreeUnlimited: Boolean = (classification == ApiKeyClassification.LIFETIME_FREE),
        val isRenewed: Boolean = (classification == ApiKeyClassification.RENEWED_EXTENDED),
        val normalizedSchema: NormalizedResponseSchema? = null,
    ) : ApiKeyValidationResult()

    data class Expired(
        val message: String,
        val usage: Double? = null,
        val limit: Double? = null,
        val renewalUrl: String? = null,
        val normalizedSchema: NormalizedResponseSchema? = null,
    ) : ApiKeyValidationResult()

    // Backward compatibility alias for UI and legacy calls
    val isExhaustedOrExpired: Boolean
        get() = this is Expired

    data class Invalid(
        val message: String,
        val isSpoofed: Boolean = false,
        val normalizedSchema: NormalizedResponseSchema? = null,
    ) : ApiKeyValidationResult()

    data class Error(
        val message: String,
        val normalizedSchema: NormalizedResponseSchema? = null,
    ) : ApiKeyValidationResult()
}

// Typealias to maintain complete compatibility across project references
typealias ApiKeyValidationExhausted = ApiKeyValidationResult.Expired

object ApiKeyManager {

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    // Provider Renewal & Account Portals
    private val renewalUrls = mapOf(
        "OpenRouter" to "https://openrouter.ai/credits",
        "OpenAI" to "https://platform.openai.com/account/billing",
        "Claude" to "https://console.anthropic.com/settings/plans",
        "Gemini" to "https://aistudio.google.com",
        "DeepL" to "https://www.deepl.com/pro-account",
        "Perplexity" to "https://www.perplexity.ai/settings/api",
        "Mistral" to "https://console.mistral.ai/billing",
        "XAi" to "https://console.x.ai",
        "DeepInfra" to "https://deepinfra.com/dash/api_keys",
        "Nvidia" to "https://build.nvidia.com",
        "Groq" to "https://console.groq.com/keys",
    )

    fun getRenewalUrl(provider: String): String {
        return renewalUrls[provider] ?: "https://openrouter.ai/credits"
    }

    /**
     * Strict Client-Side Anti-Spoofing & Regex Formatting Check
     * Blocks arbitrary text, words, short strings, fake templates, and circumvention attempts.
     */
    fun validateKeyFormat(rawKey: String, provider: String = ""): Boolean {
        val key = rawKey.trim()
        if (provider == "DeepInfra") {
            return key.isBlank() || (key.length >= 10 && !key.contains(" "))
        }
        if (key.length < 16) return false

        // 1. Detect and reject obvious mock words, dictionary text, and placeholder sequences
        val normalized = key.lowercase()
        val blacklistedKeywords = listOf(
            "dummy", "fake", "test", "demo", "sample", "placeholder",
            "example", "123456", "abcdef", "qwerty", "mykey", "apikey",
            "secret", "token", "password", "foobar", "invalid"
        )
        if (blacklistedKeywords.any { normalized.contains(it) }) return false

        // 2. Reject arbitrary dictionary words without digits/symbols
        val hasDigitsOrSpecial = key.any { it.isDigit() || it == '-' || it == '_' || it == '.' }
        if (!hasDigitsOrSpecial) return false

        // 3. Provider-specific cryptographic token signatures
        return when (provider) {
            "OpenRouter" -> {
                // OpenRouter keys always start with sk-or-v1- followed by hex or base64url characters
                key.startsWith("sk-or-v1-") && key.length >= 32 &&
                        Pattern.compile("^sk-or-v1-[a-zA-Z0-9_-]{20,}$").matcher(key).matches()
            }
            "OpenAI" -> {
                // OpenAI keys start with sk- or sk-proj- followed by base64 chars
                (key.startsWith("sk-") || key.startsWith("sk-proj-")) && key.length >= 24 &&
                        Pattern.compile("^sk-(proj-)?[a-zA-Z0-9_-]{20,}$").matcher(key).matches()
            }
            "Gemini" -> {
                // Google API Keys start with AIza followed by 35 alphanumeric/underscore/dash chars
                key.startsWith("AIza") && key.length >= 25 &&
                        Pattern.compile("^AIza[0-9A-Za-z_-]{20,}$").matcher(key).matches()
            }
            "Claude" -> {
                // Anthropic Claude keys start with sk-ant-
                key.startsWith("sk-ant-") && key.length >= 24 &&
                        Pattern.compile("^sk-ant-[a-zA-Z0-9_-]{16,}$").matcher(key).matches()
            }
            "Perplexity" -> {
                // Perplexity keys start with pplx-
                key.startsWith("pplx-") && key.length >= 20 &&
                        Pattern.compile("^pplx-[a-zA-Z0-9_-]{16,}$").matcher(key).matches()
            }
            "DeepL" -> {
                // DeepL authentication tokens
                key.length >= 20 && !key.contains(" ") &&
                        Pattern.compile("^[a-zA-Z0-9_-]+(:fx)?$").matcher(key).matches()
            }
            "Nvidia" -> {
                // Nvidia build.nvidia.com keys start with nvapi-
                key.startsWith("nvapi-") && key.length >= 24 &&
                        Pattern.compile("^nvapi-[a-zA-Z0-9_-]{16,}$").matcher(key).matches()
            }
            "Groq" -> {
                // Groq keys start with gsk_
                key.startsWith("gsk_") && key.length >= 24 &&
                        Pattern.compile("^gsk_[a-zA-Z0-9_-]{16,}$").matcher(key).matches()
            }
            else -> {
                // Standard global AI key format
                !key.contains(" ") && key.length >= 18 &&
                        Pattern.compile("^[a-zA-Z0-9_.-]{18,}$").matcher(key).matches()
            }
        }
    }

    /**
     * Executes live server-side signature/ping verification against the provider backend
     * and maps the response strictly into the 5 Classification Rules.
     */
    suspend fun validateKey(
        provider: String,
        rawKey: String,
        baseUrl: String = "",
        previousStatus: String = "",
    ): ApiKeyValidationResult = withContext(Dispatchers.IO) {
        val key = rawKey.trim()
        if (key.isBlank()) {
            return@withContext if (provider == "DeepInfra") {
                ApiKeyValidationResult.Valid(
                    message = "DeepInfra (No API key required)",
                    classification = ApiKeyClassification.LIFETIME_FREE,
                    isFreeUnlimited = true,
                )
            } else {
                ApiKeyValidationResult.Invalid("API Key cannot be empty")
            }
        }

        // Check 1: Client-side format check (Case-insensitive, allows [a-zA-Z0-9_-])
        if (!validateKeyFormat(key, provider)) {
            return@withContext ApiKeyValidationResult.Invalid(
                message = "Invalid or malformed key format. Key should contain valid alphanumeric characters, hyphens or underscores.",
                isSpoofed = true,
            )
        }

        val wasPreviouslyExpired = previousStatus == ApiKeyClassification.EXPIRED.storageKey

        try {
            when (provider) {
                "OpenRouter", "" -> {
                    val request = Request.Builder()
                        .url("https://openrouter.ai/api/v1/auth/key")
                        .addHeader("Authorization", "Bearer $key")
                        .addHeader("HTTP-Referer", "https://metrolist.cc")
                        .addHeader("X-Title", "Metrolist Music")
                        .get()
                        .build()

                    val response = httpClient.newCall(request).execute()
                    val responseBody = response.body?.string() ?: ""
                    val code = response.code

                    when (code) {
                        200 -> {
                            val json = try { JSONObject(responseBody) } catch (e: Exception) { JSONObject() }
                            val dataObj = json.optJSONObject("data")
                            val label = dataObj?.optString("label")?.takeIf { it.isNotBlank() }
                            val usage = if (dataObj != null && dataObj.has("usage") && !dataObj.isNull("usage")) dataObj.optDouble("usage") else null
                            val hasLimit = dataObj != null && dataObj.has("limit") && !dataObj.isNull("limit")
                            val limit = if (hasLimit) dataObj?.optDouble("limit") else null
                            val isFreeTier = dataObj?.optBoolean("is_free_tier", false) ?: false

                            // Classification Rule 2: Expired Key
                            if (limit != null && limit > 0.0 && usage != null && usage >= limit) {
                                ApiKeyValidationResult.Expired(
                                    message = "Subscription or quota limit reached ($usage / $limit USD). Renewal required.",
                                    usage = usage,
                                    limit = limit,
                                    renewalUrl = getRenewalUrl(provider),
                                )
                            } else if (limit != null && limit == 0.0) {
                                ApiKeyValidationResult.Expired(
                                    message = "Key balance is zero or subscription ended. Renewal required.",
                                    usage = usage,
                                    limit = limit,
                                    renewalUrl = getRenewalUrl(provider),
                                )
                            } else if (limit == null || isFreeTier) {
                                // Classification Rule 4: Lifetime / Free Key (Unlimited)
                                ApiKeyValidationResult.Valid(
                                    message = "Lifetime / Free Key (Unlimited). Permanent access granted.",
                                    classification = ApiKeyClassification.LIFETIME_FREE,
                                    label = label,
                                    usage = usage,
                                    limit = limit,
                                    isFreeUnlimited = true,
                                )
                            } else if (wasPreviouslyExpired) {
                                // Classification Rule 3: Renewed / Extended Key
                                ApiKeyValidationResult.Valid(
                                    message = "Key successfully renewed! Feature access automatically restored.",
                                    classification = ApiKeyClassification.RENEWED_EXTENDED,
                                    label = label,
                                    usage = usage,
                                    limit = limit,
                                    isRenewed = true,
                                )
                            } else {
                                // Classification Rule 1: Valid Active Key
                                ApiKeyValidationResult.Valid(
                                    message = "Valid Active Key. Full application access granted.",
                                    classification = ApiKeyClassification.VALID_ACTIVE,
                                    label = label,
                                    usage = usage,
                                    limit = limit,
                                )
                            }
                        }
                        401 -> {
                            // Classification Rule 5: Invalid / Spoofed Key
                            ApiKeyValidationResult.Invalid(
                                message = "Key rejected by provider backend (HTTP 401 Unauthorized).",
                                isSpoofed = true,
                            )
                        }
                        402, 429 -> {
                            // Classification Rule 2: Expired Key (out of credits or rate-limited)
                            ApiKeyValidationResult.Expired(
                                message = "Key quota or balance expired (HTTP $code). Renewal required.",
                                renewalUrl = getRenewalUrl(provider),
                            )
                        }
                        else -> {
                            if (code in 400..499) {
                                ApiKeyValidationResult.Invalid("Provider rejected key with error HTTP $code.")
                            } else {
                                ApiKeyValidationResult.Error("Server verification error (HTTP $code).")
                            }
                        }
                    }
                }

                "OpenAI" -> {
                    val request = Request.Builder()
                        .url("https://api.openai.com/v1/models")
                        .addHeader("Authorization", "Bearer $key")
                        .get()
                        .build()

                    val response = httpClient.newCall(request).execute()
                    val code = response.code
                    val body = response.body?.string() ?: ""

                    when (code) {
                        200 -> {
                            if (wasPreviouslyExpired) {
                                ApiKeyValidationResult.Valid(
                                    message = "OpenAI key renewed! Feature access restored.",
                                    classification = ApiKeyClassification.RENEWED_EXTENDED,
                                    isRenewed = true,
                                )
                            } else {
                                ApiKeyValidationResult.Valid(
                                    message = "Valid Active OpenAI Key. Full application access granted.",
                                    classification = ApiKeyClassification.VALID_ACTIVE,
                                )
                            }
                        }
                        401 -> ApiKeyValidationResult.Invalid(
                            message = "Invalid or unverified OpenAI API key.",
                            isSpoofed = true,
                        )
                        429 -> {
                            ApiKeyValidationResult.Expired(
                                message = "OpenAI quota/billing period expired. Renewal required.",
                                renewalUrl = getRenewalUrl(provider),
                            )
                        }
                        else -> ApiKeyValidationResult.Error("OpenAI verification error: HTTP $code")
                    }
                }

                "Gemini" -> {
                    val request = Request.Builder()
                        .url("https://generativelanguage.googleapis.com/v1beta/models?key=$key")
                        .get()
                        .build()

                    val response = httpClient.newCall(request).execute()
                    when (response.code) {
                        200 -> {
                            // Google Gemini API keys are permanent/free within standard quotas
                            ApiKeyValidationResult.Valid(
                                message = "Valid Lifetime / Free Key (Google Gemini). Permanent access granted.",
                                classification = ApiKeyClassification.LIFETIME_FREE,
                                isFreeUnlimited = true,
                            )
                        }
                        400, 403 -> ApiKeyValidationResult.Invalid(
                            message = "Google Gemini API key is invalid or spoofed.",
                            isSpoofed = true,
                        )
                        429 -> ApiKeyValidationResult.Expired(
                            message = "Gemini quota expired. Please extend or renew in Google AI Studio.",
                            renewalUrl = getRenewalUrl(provider),
                        )
                        else -> ApiKeyValidationResult.Error("Gemini error: HTTP ${response.code}")
                    }
                }

                "Claude" -> {
                    val request = Request.Builder()
                        .url("https://api.anthropic.com/v1/models")
                        .addHeader("x-api-key", key)
                        .addHeader("anthropic-version", "2023-06-01")
                        .get()
                        .build()

                    val response = httpClient.newCall(request).execute()
                    when (response.code) {
                        200 -> {
                            if (wasPreviouslyExpired) {
                                ApiKeyValidationResult.Valid(
                                    message = "Anthropic Claude key renewed! Access restored.",
                                    classification = ApiKeyClassification.RENEWED_EXTENDED,
                                    isRenewed = true,
                                )
                            } else {
                                ApiKeyValidationResult.Valid(
                                    message = "Valid Active Claude Key. Full access granted.",
                                    classification = ApiKeyClassification.VALID_ACTIVE,
                                )
                            }
                        }
                        401 -> ApiKeyValidationResult.Invalid(
                            message = "Anthropic Claude API key is invalid or unauthorized.",
                            isSpoofed = true,
                        )
                        402, 429 -> ApiKeyValidationResult.Expired(
                            message = "Claude subscription credit expired. Renewal required.",
                            renewalUrl = getRenewalUrl(provider),
                        )
                        else -> ApiKeyValidationResult.Error("Claude error: HTTP ${response.code}")
                    }
                }

                "Nvidia" -> {
                    val request = Request.Builder()
                        .url("https://integrate.api.nvidia.com/v1/models")
                        .addHeader("Authorization", "Bearer $key")
                        .get()
                        .build()

                    val response = httpClient.newCall(request).execute()
                    when (response.code) {
                        200 -> {
                            if (wasPreviouslyExpired) {
                                ApiKeyValidationResult.Valid(
                                    message = "Nvidia API key renewed! Access restored.",
                                    classification = ApiKeyClassification.RENEWED_EXTENDED,
                                    isRenewed = true,
                                )
                            } else {
                                ApiKeyValidationResult.Valid(
                                    message = "Valid Active Nvidia Key (build.nvidia.com). Access granted.",
                                    classification = ApiKeyClassification.VALID_ACTIVE,
                                )
                            }
                        }
                        401 -> ApiKeyValidationResult.Invalid(
                            message = "Nvidia API key is invalid or unauthorized. Visit build.nvidia.com for API keys.",
                            isSpoofed = true,
                        )
                        402, 429 -> ApiKeyValidationResult.Expired(
                            message = "Nvidia API credits expired. Renewal required.",
                            renewalUrl = getRenewalUrl(provider),
                        )
                        else -> ApiKeyValidationResult.Error("Nvidia error: HTTP ${response.code}")
                    }
                }

                "Groq" -> {
                    val request = Request.Builder()
                        .url("https://api.groq.com/openai/v1/models")
                        .addHeader("Authorization", "Bearer $key")
                        .get()
                        .build()

                    val response = httpClient.newCall(request).execute()
                    when (response.code) {
                        200 -> {
                            ApiKeyValidationResult.Valid(
                                message = "Valid Groq API Key (console.groq.com/keys). Free high-speed access granted.",
                                classification = ApiKeyClassification.LIFETIME_FREE,
                                isFreeUnlimited = true,
                            )
                        }
                        401 -> ApiKeyValidationResult.Invalid(
                            message = "Groq API key is invalid. Visit console.groq.com/keys for free API keys.",
                            isSpoofed = true,
                        )
                        402, 429 -> ApiKeyValidationResult.Expired(
                            message = "Groq rate limit or credits exceeded.",
                            renewalUrl = getRenewalUrl(provider),
                        )
                        else -> ApiKeyValidationResult.Error("Groq error: HTTP ${response.code}")
                    }
                }

                else -> {
                    // Custom AI Providers (Custom Base URL, OpenRouter-compatible, DeepSeek, Local AI Ollama/v1, Together, etc.)
                    if (key.startsWith("sk-or-v1-")) {
                        return@withContext validateKey("OpenRouter", key, baseUrl, previousStatus)
                    }

                    val targetEndpoint = when {
                        baseUrl.isNotBlank() -> {
                            val trimmed = baseUrl.trim()
                            if (trimmed.endsWith("/chat/completions") || trimmed.endsWith("/models")) {
                                trimmed
                            } else if (trimmed.endsWith("/")) {
                                "${trimmed}models"
                            } else {
                                "${trimmed}/models"
                            }
                        }
                        else -> ""
                    }

                    if (targetEndpoint.isNotBlank()) {
                        val reqBuilder = Request.Builder().url(targetEndpoint)
                        // Adjust headers dynamically based on key prefix or standard
                        if (key.startsWith("sk-ant-")) {
                            reqBuilder.addHeader("x-api-key", key)
                            reqBuilder.addHeader("anthropic-version", "2023-06-01")
                        } else {
                            reqBuilder.addHeader("Authorization", "Bearer $key")
                        }

                        try {
                            val response = httpClient.newCall(reqBuilder.get().build()).execute()
                            val code = response.code
                            when (code) {
                                200 -> {
                                    val schema = NormalizedResponseSchema.success(
                                        provider = if (provider.isNotBlank()) provider else "CUSTOM_PROVIDER",
                                        endpoint = targetEndpoint,
                                        keyState = if (wasPreviouslyExpired) "RENEWED_EXTENDED" else "VALID_ACTIVE",
                                    )
                                    if (wasPreviouslyExpired) {
                                        ApiKeyValidationResult.Valid(
                                            message = "Custom Provider: Khóa đã gia hạn! Quyền truy cập được khôi phục.",
                                            classification = ApiKeyClassification.RENEWED_EXTENDED,
                                            isRenewed = true,
                                            normalizedSchema = schema,
                                        )
                                    } else {
                                        ApiKeyValidationResult.Valid(
                                            message = "Custom Provider: Khóa hợp lệ (HTTP 200). Đã cấp quyền truy cập.",
                                            classification = ApiKeyClassification.VALID_ACTIVE,
                                            normalizedSchema = schema,
                                        )
                                    }
                                }
                                401 -> {
                                    val schema = NormalizedResponseSchema.error(
                                        provider = if (provider.isNotBlank()) provider else "CUSTOM_PROVIDER",
                                        endpoint = targetEndpoint,
                                        keyState = "INVALID",
                                        code = "AUTH_FAILED",
                                        message = "API Key không hợp lệ hoặc đường dẫn API nhà cung cấp không phản hồi.",
                                        rawProviderCode = 401,
                                    )
                                    ApiKeyValidationResult.Invalid(
                                        message = "API Key không hợp lệ hoặc đường dẫn API nhà cung cấp không phản hồi (HTTP 401).",
                                        isSpoofed = true,
                                        normalizedSchema = schema,
                                    )
                                }
                                402, 429 -> {
                                    val schema = NormalizedResponseSchema.error(
                                        provider = if (provider.isNotBlank()) provider else "CUSTOM_PROVIDER",
                                        endpoint = targetEndpoint,
                                        keyState = "EXPIRED",
                                        code = "QUOTA_EXCEEDED",
                                        message = "Hạn mức hoặc số dư của khóa đã hết. Vui lòng gia hạn tài khoản.",
                                        rawProviderCode = code,
                                    )
                                    ApiKeyValidationResult.Expired(
                                        message = "Hạn mức hoặc số dư đã hết (HTTP $code). Cần gia hạn.",
                                        renewalUrl = baseUrl,
                                        normalizedSchema = schema,
                                    )
                                }
                                else -> {
                                    if (code in 400..499) {
                                        val schema = NormalizedResponseSchema.error(
                                            provider = if (provider.isNotBlank()) provider else "CUSTOM_PROVIDER",
                                            endpoint = targetEndpoint,
                                            keyState = "INVALID",
                                            code = "CLIENT_ERROR",
                                            message = "Endpoint từ chối yêu cầu xác thực (HTTP $code)",
                                            rawProviderCode = code,
                                        )
                                        ApiKeyValidationResult.Invalid(
                                            message = "Endpoint từ chối yêu cầu (HTTP $code)",
                                            normalizedSchema = schema,
                                        )
                                    } else {
                                        val schema = NormalizedResponseSchema.error(
                                            provider = if (provider.isNotBlank()) provider else "CUSTOM_PROVIDER",
                                            endpoint = targetEndpoint,
                                            keyState = "INVALID",
                                            code = "SERVER_ERROR",
                                            message = "Lỗi phản hồi từ máy chủ Custom Endpoint (HTTP $code)",
                                            rawProviderCode = code,
                                        )
                                        ApiKeyValidationResult.Error(
                                            message = "Lỗi máy chủ Custom Provider: HTTP $code",
                                            normalizedSchema = schema,
                                        )
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Timber.w("Custom Endpoint ping failed: ${e.message}")
                            // Fallback to format check if endpoint is an offline or private URL
                            val schema = NormalizedResponseSchema.error(
                                provider = if (provider.isNotBlank()) provider else "CUSTOM_PROVIDER",
                                endpoint = targetEndpoint,
                                keyState = "INVALID",
                                code = "NETWORK_UNREACHABLE",
                                message = "Không thể kết nối tới Custom Endpoint: ${e.message}",
                                rawProviderCode = null,
                            )
                            ApiKeyValidationResult.Error(
                                message = "Không thể kết nối tới Custom Endpoint: ${e.message}",
                                normalizedSchema = schema,
                            )
                        }
                    } else {
                        val schema = NormalizedResponseSchema.success(
                            provider = if (provider.isNotBlank()) provider else "CUSTOM_PROVIDER",
                            endpoint = "local_format_check",
                            keyState = "VALID_ACTIVE",
                        )
                        ApiKeyValidationResult.Valid(
                            message = "Định dạng khóa hợp lệ đã được xác minh.",
                            classification = ApiKeyClassification.VALID_ACTIVE,
                            normalizedSchema = schema,
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e("ApiKeyManager: Network ping verification failure: ${e.message}")
            ApiKeyValidationResult.Error(e.message ?: "Network connection error while verifying key")
        }
    }

    /**
     * Feature Gate & Access Enforcement:
     * Access is granted ONLY when key status is VALID_ACTIVE, RENEWED_EXTENDED, or LIFETIME_FREE.
     * If key is EXPIRED or INVALID_SPOOFED, features are strictly blocked.
     * For DeepInfra, access is always granted without requiring an API key.
     */
    fun isFeatureAccessGranted(status: String, provider: String = ""): Boolean {
        if (provider == "DeepInfra") return true
        return when (status) {
            ApiKeyClassification.VALID_ACTIVE.storageKey,
            ApiKeyClassification.RENEWED_EXTENDED.storageKey,
            ApiKeyClassification.LIFETIME_FREE.storageKey,
            "valid",
            "valid_renewed",
            "valid_free" -> true
            else -> false
        }
    }
}
