/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.metrolist.music.BuildConfig
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.constants.AudioNormalizationKey
import com.metrolist.music.constants.AudioOffload
import com.metrolist.music.constants.AudioTrackPlaybackParamsKey
import com.metrolist.music.constants.AudioQuality
import com.metrolist.music.constants.AudioQualityKey
import com.metrolist.music.constants.AutoDownloadOnLikeKey
import com.metrolist.music.constants.CrossfadeDurationKey
import com.metrolist.music.constants.CrossfadeEnabledKey
import com.metrolist.music.constants.CrossfadeGaplessKey
import com.metrolist.music.constants.AutoLoadMoreKey
import com.metrolist.music.constants.AutoRadioQueueKey
import com.metrolist.music.constants.AutoSkipNextOnErrorKey
import com.metrolist.music.constants.AutoplayKey
import com.metrolist.music.constants.DisableLoadMoreWhenRepeatAllKey
import com.metrolist.music.constants.EnableGoogleCastKey
import com.metrolist.music.constants.HistoryDuration
import com.metrolist.music.constants.KeepScreenOn
import com.metrolist.music.constants.RealTimeVisualizerEnabledKey
import com.metrolist.music.constants.RealTimeVisualizerStyleKey
import com.metrolist.music.constants.LoudnessLevel
import com.metrolist.music.constants.LoudnessLevelKey
import com.metrolist.music.constants.PauseOnMute
import com.metrolist.music.constants.PersistentQueueKey
import com.metrolist.music.constants.PersistentShuffleAcrossQueuesKey
import com.metrolist.music.constants.PreventDuplicateTracksInQueueKey
import com.metrolist.music.constants.RememberShuffleAndRepeatKey
import com.metrolist.music.constants.ResumeOnBluetoothConnectKey
import com.metrolist.music.constants.SeekExtraSeconds
import com.metrolist.music.constants.ShufflePlaylistFirstKey
import com.metrolist.music.constants.SmartShuffleKey
import com.metrolist.music.constants.SimilarContent
import com.metrolist.music.constants.SkipSilenceInstantKey
import com.metrolist.music.constants.SkipSilenceKey
import com.metrolist.music.constants.StopMusicOnTaskClearKey
import com.metrolist.music.constants.VarispeedKey
import com.metrolist.music.ui.component.DefaultDialog
import com.metrolist.music.ui.component.EnumDialog
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.rememberEnumPreference
import com.metrolist.music.utils.rememberPreference
import kotlin.math.roundToInt
import com.metrolist.music.ui.component.SleepTimerDialog
import com.metrolist.music.constants.SleepTimerEnabledKey
import com.metrolist.music.constants.SleepTimerRepeatKey
import com.metrolist.music.constants.SleepTimerCustomDaysKey
import com.metrolist.music.constants.SleepTimerEndTimeKey
import com.metrolist.music.constants.SleepTimerStartTimeKey
import com.metrolist.music.constants.SleepTimerDayTimesKey
import com.metrolist.music.ui.component.decodeDayTimes
import com.metrolist.music.ui.component.encodeDayTimes
import com.metrolist.music.constants.SleepTimerFadeOutKey
import com.metrolist.music.constants.SleepTimerStopAfterCurrentSongKey
import com.metrolist.music.ui.utils.getLoudnessLevelLabel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerSettings(
    navController: NavController
) {
    val (audioQuality, onAudioQualityChange) = rememberEnumPreference(
        AudioQualityKey,
        defaultValue = AudioQuality.AUTO
    )
    val (crossfadeEnabled, onCrossfadeEnabledChange) = rememberPreference(
        CrossfadeEnabledKey,
        defaultValue = false
    )
    val (crossfadeDuration, onCrossfadeDurationChange) = rememberPreference(
        CrossfadeDurationKey,
        defaultValue = 5f
    )
    val (crossfadeGapless, onCrossfadeGaplessChange) = rememberPreference(
        CrossfadeGaplessKey,
        defaultValue = true
    )
    val (persistentQueue, onPersistentQueueChange) = rememberPreference(
        PersistentQueueKey,
        defaultValue = true
    )
    val (skipSilence, onSkipSilenceChange) = rememberPreference(
        SkipSilenceKey,
        defaultValue = false
    )
    val (skipSilenceInstant, onSkipSilenceInstantChange) = rememberPreference(
        SkipSilenceInstantKey,
        defaultValue = false
    )
    val (audioNormalization, onAudioNormalizationChange) = rememberPreference(
        AudioNormalizationKey,
        defaultValue = true
    )

    val (loudnessLevel, onLoudnessLevelChange) = rememberEnumPreference(
        LoudnessLevelKey,
        defaultValue = LoudnessLevel.BALANCED,
    )

    val (audioOffload, onAudioOffloadChange) = rememberPreference(
        key = AudioOffload,
        defaultValue = false
    )

    val (audioTrackPlaybackParams, onAudioTrackPlaybackParamsChange) = rememberPreference(
        key = AudioTrackPlaybackParamsKey,
        defaultValue = true
    )

    val (varispeed, onVarispeedChange) = rememberPreference(
        key = VarispeedKey,
        defaultValue = false
    )

    val (enableGoogleCast, onEnableGoogleCastChange) = rememberPreference(
        key = EnableGoogleCastKey,
        defaultValue = true
    )

    val (seekExtraSeconds, onSeekExtraSeconds) = rememberPreference(
        SeekExtraSeconds,
        defaultValue = false
    )

    val (autoLoadMore, onAutoLoadMoreChange) = rememberPreference(
        AutoLoadMoreKey,
        defaultValue = false
    )
    val (autoRadioQueue, onAutoRadioQueueChange) = rememberPreference(
        AutoRadioQueueKey,
        defaultValue = false
    )
    val (allowExternalPlay, onAllowExternalPlayChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("allowExternalPlay"),
        defaultValue = true
    )
    val (doubleTapToSeek, onDoubleTapToSeekChange) = rememberPreference(
        key = androidx.datastore.preferences.core.stringPreferencesKey("doubleTapToSeek"),
        defaultValue = "10 giây"
    )
    val (initialVolumeSetting, onInitialVolumeSettingChange) = rememberPreference(
        key = com.metrolist.music.constants.InitialVolumeSettingKey,
        defaultValue = "Theo hệ thống"
    )
    var showInitialVolumeDialog by remember { mutableStateOf(false) }
    var showDoubleTapToSeekDialog by remember { mutableStateOf(false) }

    val (hideVolumeSlider, onHideVolumeSliderChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("hide_volume_slider"),
        defaultValue = false
    )

    val (uniformVolume, onUniformVolumeChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("uniformVolume"),
        defaultValue = false
    )
    val (dynamicQueue, onDynamicQueueChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("dynamicQueue"),
        defaultValue = true
    )
    val (disableLoadMoreWhenRepeatAll, onDisableLoadMoreWhenRepeatAllChange) = rememberPreference(
        DisableLoadMoreWhenRepeatAllKey,
        defaultValue = false
    )
    val (autoDownloadOnLike, onAutoDownloadOnLikeChange) = rememberPreference(
        AutoDownloadOnLikeKey,
        defaultValue = false
    )
    val (similarContentEnabled, similarContentEnabledChange) = rememberPreference(
        key = SimilarContent,
        defaultValue = true
    )
    val (autoSkipNextOnError, onAutoSkipNextOnErrorChange) = rememberPreference(
        AutoSkipNextOnErrorKey,
        defaultValue = false
    )
    val (autoplay, onAutoplayChange) = rememberPreference(
        AutoplayKey,
        defaultValue = false
    )
    val (persistentShuffleAcrossQueues, onPersistentShuffleAcrossQueuesChange) = rememberPreference(
        PersistentShuffleAcrossQueuesKey,
        defaultValue = false
    )
    val (rememberShuffleAndRepeat, onRememberShuffleAndRepeatChange) = rememberPreference(
        RememberShuffleAndRepeatKey,
        defaultValue = true
    )
    val (shufflePlaylistFirst, onShufflePlaylistFirstChange) = rememberPreference(
        ShufflePlaylistFirstKey,
        defaultValue = false
    )
    val (smartShuffle, onSmartShuffleChange) = rememberPreference(
        SmartShuffleKey,
        defaultValue = false
    )
    val (preventDuplicateTracksInQueue, onPreventDuplicateTracksInQueueChange) = rememberPreference(
        PreventDuplicateTracksInQueueKey,
        defaultValue = false
    )
    val (stopMusicOnTaskClear, onStopMusicOnTaskClearChange) = rememberPreference(
        StopMusicOnTaskClearKey,
        defaultValue = false
    )
    val (pauseOnMute, onPauseOnMuteChange) = rememberPreference(
        PauseOnMute,
        defaultValue = false
    )
    val (resumeOnBluetoothConnect, onResumeOnBluetoothConnectChange) = rememberPreference(
        ResumeOnBluetoothConnectKey,
        defaultValue = false
    )
    val (keepScreenOn, onKeepScreenOnChange) = rememberPreference(
        KeepScreenOn,
        defaultValue = false
    )
    val (historyDuration, onHistoryDurationChange) = rememberPreference(
        HistoryDuration,
        defaultValue = 30f
    )

    var showAudioQualityDialog by remember {
        mutableStateOf(false)
    }

    var showLoudnessLevelDialog by remember {
        mutableStateOf(false)
    }

    // Preload settings state
    val (preloadNextSong, onPreloadNextSongChange) = rememberPreference(
        com.metrolist.music.constants.PreloadNextSongKey,
        defaultValue = true
    )
    val (preloadLimit, onPreloadLimitChange) = rememberPreference(
        com.metrolist.music.constants.PreloadLimitKey,
        defaultValue = 10
    )
    val (preloadLyrics, onPreloadLyricsChange) = rememberPreference(
        com.metrolist.music.constants.PreloadLyricsKey,
        defaultValue = true
    )
    val (exportAsMp3, onExportAsMp3Change) = rememberPreference(
        com.metrolist.music.constants.ExportAsMp3Key,
        defaultValue = true
    )

    // Equalizer settings state
    val (eqToggleProfessional, onEqToggleProfessionalChange) = rememberPreference(
        com.metrolist.music.constants.EqToggleProfessionalKey,
        defaultValue = true
    )
    val (eqAdvancedMode, onEqAdvancedModeChange) = rememberPreference(
        com.metrolist.music.constants.EqAdvancedModeKey,
        defaultValue = false
    )
    val (echoSignature, onEchoSignatureChange) = rememberPreference(
        com.metrolist.music.constants.EchoSignatureKey,
        defaultValue = "Signature"
    )
    val (dolbyAtmos, onDolbyAtmosChange) = rememberPreference(
        com.metrolist.music.constants.DolbyAtmosKey,
        defaultValue = "Dolby Rich"
    )
    val (diracAudio, onDiracAudioChange) = rememberPreference(
        com.metrolist.music.constants.DiracAudioKey,
        defaultValue = "Dirac Music"
    )
    val (echoExtractorLastUpdateTime, onEchoExtractorLastUpdateTimeChange) = rememberPreference(
        com.metrolist.music.constants.EchoExtractorLastUpdateTimeKey,
        defaultValue = System.currentTimeMillis() - 4 * 3600 * 1000
    )

    val (bass, onBassChange) = rememberPreference(
        com.metrolist.music.constants.BassKey,
        defaultValue = 0f
    )
    val (mids, onMidsChange) = rememberPreference(
        com.metrolist.music.constants.MidsKey,
        defaultValue = 0f
    )
    val (treble, onTrebleChange) = rememberPreference(
        com.metrolist.music.constants.TrebleKey,
        defaultValue = 0f
    )
    val (showAudioFallbackNotifications, onShowAudioFallbackNotificationsChange) = rememberPreference(
        com.metrolist.music.constants.ShowAudioFallbackNotificationsKey,
        defaultValue = true
    )
    val (audioFormatCodec, onAudioFormatCodecChange) = rememberPreference(
        com.metrolist.music.constants.AudioFormatCodecKey,
        defaultValue = "Opus"
    )

    var showPreloadLimitDialog by remember { mutableStateOf(false) }
    var showEchoSignatureDialog by remember { mutableStateOf(false) }
    var showDolbyAtmosDialog by remember { mutableStateOf(false) }
    var showDiracAudioDialog by remember { mutableStateOf(false) }
    var showAudioFormatCodecDialog by remember { mutableStateOf(false) }


    var echoExtractorUpdating by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()
    val localContext = LocalContext.current

    val (autoResumePlayback, onAutoResumePlaybackChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("autoResumePlayback"),
        defaultValue = false
    )
    val (repeatModeSetting, onRepeatModeSettingChange) = rememberPreference(
        key = androidx.datastore.preferences.core.stringPreferencesKey("repeatModeSetting"),
        defaultValue = "Tắt"
    )
    val (equalizerEnabled, onEqualizerEnabledChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("equalizerEnabled"),
        defaultValue = true
    )
    val (wifiOnlyStreaming, onWifiOnlyStreamingChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("wifiOnlyStreaming"),
        defaultValue = false
    )

    var showRepeatModeDialog by remember { mutableStateOf(false) }

    val powerManager = remember(localContext) { localContext.getSystemService(android.content.Context.POWER_SERVICE) as? android.os.PowerManager }
    val (batteryOptimizationKey, onBatteryOptimizationKeyChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("batteryOptimizationDisabled"),
        defaultValue = false
    )
    var isIgnoringBatteryOptimization by remember {
        mutableStateOf(powerManager?.isIgnoringBatteryOptimizations(localContext.packageName) == true)
    }
    LaunchedEffect(Unit) {
        isIgnoringBatteryOptimization = powerManager?.isIgnoringBatteryOptimizations(localContext.packageName) == true
    }

    val (realTimeVisualizerEnabled, onRealTimeVisualizerEnabledChange) = rememberPreference(
        key = RealTimeVisualizerEnabledKey,
        defaultValue = true
    )
    val (realTimeVisualizerStyle, onRealTimeVisualizerStyleChange) = rememberPreference(
        key = RealTimeVisualizerStyleKey,
        defaultValue = "spectrum"
    )

    var showVisualizerStyleDialog by remember { mutableStateOf(false) }

    if (showVisualizerStyleDialog) {
        com.metrolist.music.ui.component.DefaultDialog(
            onDismiss = { showVisualizerStyleDialog = false },
            content = {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.audio_visualizer_style),
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    listOf(
                        "spectrum" to stringResource(R.string.visualizer_style_spectrum),
                        "wave" to stringResource(R.string.visualizer_style_wave),
                        "pulse" to stringResource(R.string.visualizer_style_pulse)
                    ).forEach { (styleKey, label) ->
                        TextButton(
                            onClick = {
                                onRealTimeVisualizerStyleChange(styleKey)
                                showVisualizerStyleDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = label)
                        }
                    }
                }
            },
            buttons = {}
        )
    }

    if (showRepeatModeDialog) {
        com.metrolist.music.ui.component.DefaultDialog(
            onDismiss = { showRepeatModeDialog = false },
            content = {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Chọn chế độ phát lặp lại",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    for (mode in listOf("Tắt", "Lặp lại tất cả", "Lặp lại một bài")) {
                        TextButton(
                            onClick = {
                                onRepeatModeSettingChange(mode)
                                showRepeatModeDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = mode)
                        }
                    }
                }
            },
            buttons = {}
        )
    }

    if (showAudioQualityDialog) {
        EnumDialog(
            onDismiss = { showAudioQualityDialog = false },
            onSelect = {
                onAudioQualityChange(it)
                showAudioQualityDialog = false
            },
            title = stringResource(R.string.audio_quality),
            current = audioQuality,
            values = AudioQuality.values().toList(),
            valueText = {
                when (it) {
                    AudioQuality.AUTO -> stringResource(R.string.audio_quality_auto)
                    AudioQuality.HIGH -> stringResource(R.string.audio_quality_high)
                    AudioQuality.LOW -> stringResource(R.string.audio_quality_low)
                }
            }
        )
    }

    if (showLoudnessLevelDialog) {
        EnumDialog(
            onDismiss = { showLoudnessLevelDialog = false },
            onSelect = {
                onLoudnessLevelChange(it)
                showLoudnessLevelDialog = false
            },
            title = stringResource(R.string.loudness_level),
            current = loudnessLevel,
            values = LoudnessLevel.values().toList(),
            valueText = { getLoudnessLevelLabel(it) }
        )
    }

    if (showInitialVolumeDialog) {
        EnumDialog(
            onDismiss = { showInitialVolumeDialog = false },
            onSelect = {
                onInitialVolumeSettingChange(it)
                showInitialVolumeDialog = false
            },
            title = "Âm lượng đầu",
            current = initialVolumeSetting,
            values = listOf("Theo hệ thống", "Nhỏ (30%)", "Vừa (50%)", "Lớn (80%)", "Mặc định (100%)"),
            valueText = { it }
        )
    }

    if (showDoubleTapToSeekDialog) {
        EnumDialog(
            onDismiss = { showDoubleTapToSeekDialog = false },
            onSelect = {
                onDoubleTapToSeekChange(it)
                showDoubleTapToSeekDialog = false
            },
            title = "Nhấn đúp để tua",
            current = doubleTapToSeek,
            values = listOf("Tắt", "5 giây", "10 giây", "15 giây", "20 giây"),
            valueText = { it }
        )
    }

    if (showPreloadLimitDialog) {
        EnumDialog(
            onDismiss = { showPreloadLimitDialog = false },
            onSelect = {
                onPreloadLimitChange(it)
                showPreloadLimitDialog = false
            },
            title = "Giới hạn tải trước",
            current = preloadLimit,
            values = listOf(1, 2, 5, 10, 15, 20, 30, 50),
            valueText = { it.toString() }
        )
    }

    if (showEchoSignatureDialog) {
        EnumDialog(
            onDismiss = { showEchoSignatureDialog = false },
            onSelect = {
                onEchoSignatureChange(it)
                showEchoSignatureDialog = false
            },
            title = "Echo Signature",
            current = echoSignature,
            values = listOf("Flat", "Signature", "Acoustic", "Bass Boost", "Pure Clarity", "Soft Bass", "Electronic", "Rock", "Pop", "Jazz", "Voice"),
            valueText = { it }
        )
    }

    if (showDolbyAtmosDialog) {
        EnumDialog(
            onDismiss = { showDolbyAtmosDialog = false },
            onSelect = {
                onDolbyAtmosChange(it)
                showDolbyAtmosDialog = false
            },
            title = "Dolby Atmos",
            current = dolbyAtmos,
            values = listOf("Tắt", "Dolby Open", "Dolby Rich", "Dolby Focused"),
            valueText = { it }
        )
    }

    if (showDiracAudioDialog) {
        EnumDialog(
            onDismiss = { showDiracAudioDialog = false },
            onSelect = {
                onDiracAudioChange(it)
                showDiracAudioDialog = false
            },
            title = "Dirac Audio",
            current = diracAudio,
            values = listOf("Tắt", "Dirac Music", "Dirac Movie", "Dirac Game"),
            valueText = { it }
        )
    }

    if (showAudioFormatCodecDialog) {
        EnumDialog(
            onDismiss = { showAudioFormatCodecDialog = false },
            onSelect = {
                onAudioFormatCodecChange(it)
                showAudioFormatCodecDialog = false
            },
            title = "Chất lượng âm thanh",
            current = audioFormatCodec,
            values = listOf("Opus", "Lossless"),
            valueText = { it }
        )
    }


    Column(
        Modifier
            .windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top
                )
            )
        )

        Material3SettingsGroup(
            title = stringResource(R.string.player),
            items = buildList {
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.play),
                    title = { Text("Tự động tiếp tục phát") },
                    trailingContent = {
                        Switch(
                            checked = autoResumePlayback,
                            onCheckedChange = onAutoResumePlaybackChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (autoResumePlayback) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAutoResumePlaybackChange(!autoResumePlayback) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.settings),
                    title = { Text("Tối ưu hóa pin (Battery Optimization)") },
                    description = {
                        Text(
                            if (isIgnoringBatteryOptimization || batteryOptimizationKey)
                                "Đã tắt tối ưu hóa pin. Dịch vụ chạy nền sẽ phát nhạc liên tục mà không bị hệ thống gián đoạn."
                            else
                                "Cho phép dịch vụ trình phát chạy nền liên tục, ngăn hệ thống tạm dừng phát nhạc."
                        )
                    },
                    trailingContent = {
                        Switch(
                            checked = isIgnoringBatteryOptimization || batteryOptimizationKey,
                            onCheckedChange = { checked ->
                                onBatteryOptimizationKeyChange(checked)
                                try {
                                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                                        val intent = android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                            data = android.net.Uri.parse("package:${localContext.packageName}")
                                        }
                                        localContext.startActivity(intent)
                                    } else {
                                        localContext.startActivity(android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                                    }
                                } catch (_: Exception) {
                                    try {
                                        localContext.startActivity(android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                                    } catch (_: Exception) {
                                        Toast.makeText(localContext, "Không thể mở cài đặt tối ưu hóa pin", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (isIgnoringBatteryOptimization || batteryOptimizationKey) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = {
                        val newState = !(isIgnoringBatteryOptimization || batteryOptimizationKey)
                        onBatteryOptimizationKeyChange(newState)
                        try {
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                                val intent = android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                    data = android.net.Uri.parse("package:${localContext.packageName}")
                                }
                                localContext.startActivity(intent)
                            } else {
                                localContext.startActivity(android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                            }
                        } catch (_: Exception) {
                            try {
                                localContext.startActivity(android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                            } catch (_: Exception) {
                                Toast.makeText(localContext, "Không thể mở cài đặt tối ưu hóa pin", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.restore),
                    title = { Text("Chế độ phát lặp lại") },
                    description = { Text(repeatModeSetting) },
                    onClick = { showRepeatModeDialog = true }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.equalizer),
                    title = { Text("Bộ chỉnh âm (Equalizer)") },
                    trailingContent = {
                        Switch(
                            checked = equalizerEnabled,
                            onCheckedChange = onEqualizerEnabledChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (equalizerEnabled) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { navController.navigate("equalizer") }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.equalizer),
                    title = { Text(stringResource(R.string.audio_visualizer)) },
                    description = { Text(stringResource(R.string.audio_visualizer_desc)) },
                    trailingContent = {
                        Switch(
                            checked = realTimeVisualizerEnabled,
                            onCheckedChange = onRealTimeVisualizerEnabledChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (realTimeVisualizerEnabled) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onRealTimeVisualizerEnabledChange(!realTimeVisualizerEnabled) }
                ))
                if (realTimeVisualizerEnabled) {
                    val styleLabel = when (realTimeVisualizerStyle) {
                        "spectrum" -> stringResource(R.string.visualizer_style_spectrum)
                        "wave" -> stringResource(R.string.visualizer_style_wave)
                        "pulse" -> stringResource(R.string.visualizer_style_pulse)
                        else -> realTimeVisualizerStyle
                    }
                    add(Material3SettingsItem(
                        icon = painterResource(R.drawable.palette),
                        title = { Text(stringResource(R.string.audio_visualizer_style)) },
                        description = { Text(styleLabel) },
                        onClick = { showVisualizerStyleDialog = true }
                    ))
                }
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.cloud),
                    title = { Text("Phát qua Wi-Fi") },
                    trailingContent = {
                        Switch(
                            checked = wifiOnlyStreaming,
                            onCheckedChange = onWifiOnlyStreamingChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (wifiOnlyStreaming) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onWifiOnlyStreamingChange(!wifiOnlyStreaming) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.graphic_eq),
                    title = { Text(stringResource(R.string.audio_quality)) },
                    description = {
                        Text(
                            when (audioQuality) {
                                AudioQuality.AUTO -> stringResource(R.string.audio_quality_auto)
                                AudioQuality.HIGH -> stringResource(R.string.audio_quality_high)
                                AudioQuality.LOW -> stringResource(R.string.audio_quality_low)
                            }
                        )
                    },
                    onClick = { showAudioQualityDialog = true }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.music_note),
                    title = { Text("Chất lượng âm thanh") },
                    description = { Text(audioFormatCodec) },
                    onClick = { showAudioFormatCodecDialog = true }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.notification),
                    title = { Text("Show audio fallback notifications") },
                    description = { Text("Show a toast notification when falling back to a lower stream quality") },
                    trailingContent = {
                        Switch(
                            checked = showAudioFallbackNotifications,
                            onCheckedChange = onShowAudioFallbackNotificationsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (showAudioFallbackNotifications) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onShowAudioFallbackNotificationsChange(!showAudioFallbackNotifications) }
                ))

                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.linear_scale),
                    title = { Text(stringResource(R.string.crossfade)) },
                    description = { Text(stringResource(R.string.crossfade_desc)) },
                    trailingContent = {
                        Switch(
                            checked = crossfadeEnabled,
                            onCheckedChange = onCrossfadeEnabledChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (crossfadeEnabled) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onCrossfadeEnabledChange(!crossfadeEnabled) }
                ))
                if (crossfadeEnabled) {
                    add(Material3SettingsItem(
                        icon = painterResource(R.drawable.timer),
                        title = { Text(stringResource(R.string.crossfade_duration)) },
                        description = {
                            Column {
                                Text(pluralStringResource(R.plurals.seconds, crossfadeDuration.toInt(), crossfadeDuration.toInt()))
                                Slider(
                                    value = crossfadeDuration,
                                    onValueChange = onCrossfadeDurationChange,
                                    valueRange = 1f..15f,
                                    steps = 14
                                )
                            }
                        }
                    ))
                    add(Material3SettingsItem(
                        icon = painterResource(R.drawable.album),
                        title = { Text(stringResource(R.string.crossfade_gapless)) },
                        description = { Text(stringResource(R.string.crossfade_gapless_desc)) },
                        trailingContent = {
                            Switch(
                                checked = crossfadeGapless,
                                onCheckedChange = onCrossfadeGaplessChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (crossfadeGapless) R.drawable.check else R.drawable.close
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize)
                                    )
                                }
                            )
                        },
                        onClick = { onCrossfadeGaplessChange(!crossfadeGapless) }
                    ))
                }
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.history),
                    title = { Text(stringResource(R.string.history_duration)) },
                    description = {
                        Column {
                            Text(historyDuration.roundToInt().toString())
                            Slider(
                                value = historyDuration,
                                onValueChange = onHistoryDurationChange,
                                valueRange = 1f..100f
                            )
                        }
                    }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.fast_forward),
                    title = { Text(stringResource(R.string.skip_silence)) },
                    description = { Text(stringResource(R.string.skip_silence_desc)) },
                    trailingContent = {
                        Switch(
                            checked = skipSilence,
                            onCheckedChange = onSkipSilenceChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (skipSilence) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onSkipSilenceChange(!skipSilence) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.skip_next),
                    title = { Text(stringResource(R.string.skip_silence_instant)) },
                    description = { Text(stringResource(R.string.skip_silence_instant_desc)) },
                    trailingContent = {
                        Switch(
                            checked = skipSilenceInstant,
                            onCheckedChange = { onSkipSilenceInstantChange(it) },
                            enabled = skipSilence,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (skipSilenceInstant) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { if (skipSilence) onSkipSilenceInstantChange(!skipSilenceInstant) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.volume_up),
                    title = { Text(stringResource(R.string.audio_normalization)) },
                    description = { Text(stringResource(R.string.audio_normalization_desc)) },
                    trailingContent = {
                        Switch(
                            checked = audioNormalization,
                            onCheckedChange = onAudioNormalizationChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (audioNormalization) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAudioNormalizationChange(!audioNormalization) }
                ))
                if (audioNormalization) {
                    add(Material3SettingsItem(
                        icon = painterResource(R.drawable.volume_up),
                        title = { Text(stringResource(R.string.loudness_level)) },
                        description = {
                            Text(getLoudnessLevelLabel(loudnessLevel))
                        },
                        onClick = { showLoudnessLevelDialog = true }
                    ))
                }
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.volume_off),
                    title = { Text(stringResource(R.string.hide_volume_slider)) },
                    description = { Text(stringResource(R.string.hide_volume_slider_desc)) },
                    trailingContent = {
                        Switch(
                            checked = hideVolumeSlider,
                            onCheckedChange = onHideVolumeSliderChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (hideVolumeSlider) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onHideVolumeSliderChange(!hideVolumeSlider) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.graphic_eq),
                    title = { Text(stringResource(R.string.audio_offload)) },
                    description = {
                        Text(
                            if (crossfadeEnabled) stringResource(R.string.audio_offload_disabled_by_crossfade)
                            else stringResource(R.string.audio_offload_description)
                        )
                    },
                    trailingContent = {
                        Switch(
                            checked = if (crossfadeEnabled) false else audioOffload,
                            onCheckedChange = onAudioOffloadChange,
                            enabled = !crossfadeEnabled,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (!crossfadeEnabled && audioOffload) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { if (!crossfadeEnabled) onAudioOffloadChange(!audioOffload) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.graphic_eq),
                    title = { Text(stringResource(R.string.varispeed)) },
                    description = {
                        Text(
                            stringResource(R.string.varispeed_description)
                        )
                    },
                    trailingContent = {
                        Switch(
                            checked = varispeed,
                            onCheckedChange = onVarispeedChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (varispeed) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onVarispeedChange(!varispeed) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.speed),
                    title = { Text(stringResource(R.string.audio_track_playback_params)) },
                    description = {
                        Text(stringResource(R.string.audio_track_playback_params_description))
                    },
                    trailingContent = {
                        Switch(
                            checked = audioTrackPlaybackParams,
                            onCheckedChange = onAudioTrackPlaybackParamsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (audioTrackPlaybackParams) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAudioTrackPlaybackParamsChange(!audioTrackPlaybackParams) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.cast),
                    title = { Text(stringResource(R.string.google_cast)) },
                    description = { Text(stringResource(R.string.google_cast_description)) },
                    trailingContent = {
                        Switch(
                            checked = enableGoogleCast,
                            onCheckedChange = onEnableGoogleCastChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (enableGoogleCast) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onEnableGoogleCastChange(!enableGoogleCast) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.arrow_forward),
                    title = { Text(stringResource(R.string.seek_seconds_addup)) },
                    description = { Text(stringResource(R.string.seek_seconds_addup_description)) },
                    trailingContent = {
                        Switch(
                            checked = seekExtraSeconds,
                            onCheckedChange = onSeekExtraSeconds,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (seekExtraSeconds) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onSeekExtraSeconds(!seekExtraSeconds) }
                ))
            }
        )

        Spacer(modifier = Modifier.height(27.dp))

        var showSleepTimerDialog by remember { mutableStateOf(false) }

        val (sleepTimerEnabled, onSleepTimerEnabledChange) = rememberPreference(
            SleepTimerEnabledKey,
            defaultValue = false
        )
        val (sleepTimerRepeat, onSleepTimerRepeatChange) = rememberPreference(
            SleepTimerRepeatKey,
            defaultValue = "daily"
        )
        val (sleepTimerStartTime, onSleepTimerStartTimeChange) = rememberPreference(
            SleepTimerStartTimeKey,
            defaultValue = "22:00"
        )
        val (sleepTimerEndTime, onSleepTimerEndTimeChange) = rememberPreference(
            SleepTimerEndTimeKey,
            defaultValue = "06:00"
        )
        val (sleepTimerCustomDays, onSleepTimerCustomDaysChange) = rememberPreference(
            SleepTimerCustomDaysKey,
            defaultValue = "0,1,2,3,4"
        )
        // Per-day time ranges used in custom mode
        val (sleepTimerDayTimes, onSleepTimerDayTimesChange) = rememberPreference(
            SleepTimerDayTimesKey,
            defaultValue = ""
        )

        val (sleepTimerStopAfterCurrentSong, onSleepTimerStopAfterCurrentSongChange) = rememberPreference (
        SleepTimerStopAfterCurrentSongKey,
        defaultValue = false)
        val (sleepTimerFadeOut, onSleepTimerFadeOutChange) = rememberPreference(
            SleepTimerFadeOutKey,
            false
        )

        if (showSleepTimerDialog) {
            val customDays = sleepTimerCustomDays.split(",").mapNotNull { it.toIntOrNull() }
            val dayTimesMap = decodeDayTimes(sleepTimerDayTimes)

            SleepTimerDialog(
                isVisible = true,
                onDismiss = { showSleepTimerDialog = false },
                onConfirm = { repeat, startTime, endTime, days, dayTimes ->
                    onSleepTimerRepeatChange(repeat)
                    onSleepTimerStartTimeChange(startTime)
                    onSleepTimerEndTimeChange(endTime)
                    onSleepTimerCustomDaysChange(days?.joinToString(",") ?: "0,1,2,3,4")
                    onSleepTimerDayTimesChange(encodeDayTimes(dayTimes))
                    showSleepTimerDialog = false
                },
                initialRepeat = sleepTimerRepeat,
                initialStartTime = sleepTimerStartTime,
                initialEndTime = sleepTimerEndTime,
                initialCustomDays = customDays,
                initialDayTimes = dayTimesMap
            )
        }

        Material3SettingsGroup(
            title = stringResource(R.string.sleep_timer),
            items = buildList {
                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.time_auto),
                        title = { Text(stringResource(R.string.enable_automatic_sleeptimer)) },
                        description = { Text(stringResource(R.string.sleeptimer_description)) },
                        trailingContent = {
                            Switch(
                                checked = sleepTimerEnabled,
                                onCheckedChange = onSleepTimerEnabledChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (sleepTimerEnabled) R.drawable.check else R.drawable.close
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize)
                                    )
                                }
                            )
                        },
                        onClick = { onSleepTimerEnabledChange(!sleepTimerEnabled) }
                    )
                )

                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.baseline_event_repeat_24),
                            title = { Text(stringResource(R.string.sleep_timer_repeat)) },
                            description = {
                                Text(
                                    stringResource(R.string.sleep_timer_repeat_description)
                                )
                            },
                            trailingContent = {
                                Switch(
                                    checked = sleepTimerEnabled,
                                    onCheckedChange = {showSleepTimerDialog = true},
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(
                                                id = if (sleepTimerEnabled) R.drawable.check else R.drawable.close
                                            ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize)
                                        )
                                    }
                                )
                            },
                            onClick = { showSleepTimerDialog = true }
                        )
                    )


                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.more_time),
                        title = { Text(stringResource(R.string.sleep_timer_stop_after_current_song_title)) },
                        description = { Text(stringResource(R.string.sleep_timer_stop_after_current_song_description)) },
                        trailingContent = {
                            Switch(
                                checked = sleepTimerStopAfterCurrentSong,
                                onCheckedChange = onSleepTimerStopAfterCurrentSongChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (sleepTimerStopAfterCurrentSong) R.drawable.check else R.drawable.close
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize)
                                    )
                                }
                            )
                        },
                        onClick = { onSleepTimerStopAfterCurrentSongChange(!sleepTimerStopAfterCurrentSong) }
                    )
                )

                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.timer_arrow_down),
                        title = { Text(stringResource(R.string.sleep_timer_fade_out_title)) },
                        description = { Text(stringResource(R.string.sleep_timer_fade_out_description)) },
                        trailingContent = {
                            Switch(
                                checked = sleepTimerFadeOut,
                                onCheckedChange = onSleepTimerFadeOutChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (sleepTimerFadeOut) R.drawable.check else R.drawable.close
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize)
                                    )
                                }
                            )
                        },
                        onClick = { onSleepTimerFadeOutChange(!sleepTimerFadeOut) }
                    )
                )

            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        AlarmSettingsSection()

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.queue),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.queue_music),
                    title = { Text(stringResource(R.string.persistent_queue)) },
                    description = { Text(stringResource(R.string.persistent_queue_desc)) },
                    trailingContent = {
                        Switch(
                            checked = persistentQueue,
                            onCheckedChange = onPersistentQueueChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (persistentQueue) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPersistentQueueChange(!persistentQueue) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.playlist_add),
                    title = { Text(stringResource(R.string.auto_load_more)) },
                    description = { Text(stringResource(R.string.auto_load_more_desc)) },
                    trailingContent = {
                        Switch(
                            checked = autoLoadMore,
                            onCheckedChange = onAutoLoadMoreChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (autoLoadMore) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAutoLoadMoreChange(!autoLoadMore) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.radio),
                    title = { Text(stringResource(R.string.auto_radio_queue)) },
                    description = { Text(stringResource(R.string.auto_radio_queue_desc)) },
                    trailingContent = {
                        Switch(
                            checked = autoRadioQueue,
                            onCheckedChange = onAutoRadioQueueChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (autoRadioQueue) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAutoRadioQueueChange(!autoRadioQueue) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.skip_next),
                    title = { Text(stringResource(R.string.autoplay)) },
                    description = { Text(stringResource(R.string.autoplay_desc)) },
                    trailingContent = {
                        Switch(
                            checked = autoplay,
                            onCheckedChange = onAutoplayChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (autoplay) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAutoplayChange(!autoplay) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.repeat),
                    title = { Text(stringResource(R.string.disable_load_more_when_repeat_all)) },
                    description = { Text(stringResource(R.string.disable_load_more_when_repeat_all_desc)) },
                    trailingContent = {
                        Switch(
                            checked = disableLoadMoreWhenRepeatAll,
                            onCheckedChange = onDisableLoadMoreWhenRepeatAllChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (disableLoadMoreWhenRepeatAll) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onDisableLoadMoreWhenRepeatAllChange(!disableLoadMoreWhenRepeatAll) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.download),
                    title = { Text(stringResource(R.string.auto_download_on_like)) },
                    description = { Text(stringResource(R.string.auto_download_on_like_desc)) },
                    trailingContent = {
                        Switch(
                            checked = autoDownloadOnLike,
                            onCheckedChange = onAutoDownloadOnLikeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (autoDownloadOnLike) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAutoDownloadOnLikeChange(!autoDownloadOnLike) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.similar),
                    title = { Text(stringResource(R.string.enable_similar_content)) },
                    description = { Text(stringResource(R.string.similar_content_desc)) },
                    trailingContent = {
                        Switch(
                            checked = similarContentEnabled,
                            onCheckedChange = similarContentEnabledChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (similarContentEnabled) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { similarContentEnabledChange(!similarContentEnabled) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.shuffle),
                    title = { Text(stringResource(R.string.persistent_shuffle_title)) },
                    description = { Text(stringResource(R.string.persistent_shuffle_desc)) },
                    trailingContent = {
                        Switch(
                            checked = persistentShuffleAcrossQueues,
                            onCheckedChange = onPersistentShuffleAcrossQueuesChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (persistentShuffleAcrossQueues) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPersistentShuffleAcrossQueuesChange(!persistentShuffleAcrossQueues) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.shuffle),
                    title = { Text(stringResource(R.string.remember_shuffle_and_repeat)) },
                    description = { Text(stringResource(R.string.remember_shuffle_and_repeat_desc)) },
                    trailingContent = {
                        Switch(
                            checked = rememberShuffleAndRepeat,
                            onCheckedChange = onRememberShuffleAndRepeatChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (rememberShuffleAndRepeat) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onRememberShuffleAndRepeatChange(!rememberShuffleAndRepeat) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.shuffle),
                    title = { Text(stringResource(R.string.shuffle_playlist_first)) },
                    description = { Text(stringResource(R.string.shuffle_playlist_first_desc)) },
                    trailingContent = {
                        Switch(
                            checked = shufflePlaylistFirst,
                            onCheckedChange = onShufflePlaylistFirstChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (shufflePlaylistFirst) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onShufflePlaylistFirstChange(!shufflePlaylistFirst) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.shuffle),
                    title = { Text("Smart Shuffle") },
                    description = { Text("Prioritize frequently played tracks in the shuffle algorithm") },
                    trailingContent = {
                        Switch(
                            checked = smartShuffle,
                            onCheckedChange = onSmartShuffleChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (smartShuffle) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onSmartShuffleChange(!smartShuffle) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.queue_music),
                    title = { Text(stringResource(R.string.prevent_duplicate_tracks_in_queue)) },
                    description = { Text(stringResource(R.string.prevent_duplicate_tracks_in_queue_desc)) },
                    trailingContent = {
                        Switch(
                            checked = preventDuplicateTracksInQueue,
                            onCheckedChange = onPreventDuplicateTracksInQueueChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (preventDuplicateTracksInQueue) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPreventDuplicateTracksInQueueChange(!preventDuplicateTracksInQueue) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.skip_next),
                    title = { Text(stringResource(R.string.auto_skip_next_on_error)) },
                    description = { Text(stringResource(R.string.auto_skip_next_on_error_desc)) },
                    trailingContent = {
                        Switch(
                            checked = autoSkipNextOnError,
                            onCheckedChange = onAutoSkipNextOnErrorChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (autoSkipNextOnError) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAutoSkipNextOnErrorChange(!autoSkipNextOnError) }
                )
            )
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.misc),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.clear_all),
                    title = { Text(stringResource(R.string.stop_music_on_task_clear)) },
                    trailingContent = {
                        Switch(
                            checked = stopMusicOnTaskClear,
                            onCheckedChange = onStopMusicOnTaskClearChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (stopMusicOnTaskClear) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onStopMusicOnTaskClearChange(!stopMusicOnTaskClear) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.volume_off_pause),
                    title = { Text(stringResource(R.string.pause_music_when_media_is_muted)) },
                    trailingContent = {
                        Switch(
                            checked = pauseOnMute,
                            onCheckedChange = onPauseOnMuteChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (pauseOnMute) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPauseOnMuteChange(!pauseOnMute) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.bluetooth),
                    title = { Text(stringResource(R.string.resume_on_bluetooth_connect)) },
                    trailingContent = {
                        Switch(
                            checked = resumeOnBluetoothConnect,
                            onCheckedChange = onResumeOnBluetoothConnectChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (resumeOnBluetoothConnect) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onResumeOnBluetoothConnectChange(!resumeOnBluetoothConnect) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.screenshot),
                    title = { Text(stringResource(R.string.keep_screen_on_when_player_is_expanded)) },
                    trailingContent = {
                        Switch(
                            checked = keepScreenOn,
                            onCheckedChange = onKeepScreenOnChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (keepScreenOn) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onKeepScreenOnChange(!keepScreenOn) }
                )
            )
        )

        Material3SettingsGroup(
            title = "Tính năng phát (Playback Features)",
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.equalizer),
                    title = { Text("Bộ chỉnh âm") },
                    description = { Text("Điều chỉnh các tùy chọn cài đặt âm thanh") },
                    trailingContent = {
                        Switch(
                            checked = equalizerEnabled,
                            onCheckedChange = onEqualizerEnabledChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (equalizerEnabled) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { navController.navigate("equalizer") }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.play),
                    title = { Text("Cho phép thiết bị bên ngoài bắt đầu phát") },
                    description = { Text("Ví dụ: Bluetooth trên ô tô, tai nghe có dây") },
                    trailingContent = {
                        Switch(
                            checked = allowExternalPlay,
                            onCheckedChange = onAllowExternalPlayChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (allowExternalPlay) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAllowExternalPlayChange(!allowExternalPlay) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.restore),
                    title = { Text("Nhấn đúp để tua") },
                    description = { Text(doubleTapToSeek) },
                    onClick = { showDoubleTapToSeekDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.volume_off_pause),
                    title = { Text("Âm lượng đồng đều") },
                    description = { Text("Chuẩn hoá âm lượng giữa các bản âm thanh") },
                    trailingContent = {
                        Switch(
                            checked = uniformVolume,
                            onCheckedChange = onUniformVolumeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (uniformVolume) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onUniformVolumeChange(!uniformVolume) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.volume_up),
                    title = { Text("Âm lượng đầu") },
                    description = { Text("Chọn mức âm lượng mặc định khi phát nhạc: $initialVolumeSetting") },
                    onClick = { showInitialVolumeDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.queue_music),
                    title = { Text("Danh sách chờ linh động") },
                    description = { Text("Cập nhật danh sách chờ và đài phát dựa trên thói quen nghe của bạn") },
                    trailingContent = {
                        Switch(
                            checked = dynamicQueue,
                            onCheckedChange = onDynamicQueueChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (dynamicQueue) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onDynamicQueueChange(!dynamicQueue) }
                )
            )
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = "Tải trước và Bộ nhớ đệm (Preload & Cache)",
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.download),
                    title = { Text("Tải trước bài tiếp theo (Preload Next Song)") },
                    description = { Text("Cache bài hát tiếp theo để phát mượt mà không khoảng lặng (gapless)") },
                    trailingContent = {
                        Switch(
                            checked = preloadNextSong,
                            onCheckedChange = onPreloadNextSongChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (preloadNextSong) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPreloadNextSongChange(!preloadNextSong) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.timer),
                    title = { Text("Giới hạn tải trước (Preload Limit)") },
                    description = { Text("Số lượng bài hát tối đa được tải trước: $preloadLimit bài") },
                    onClick = { showPreloadLimitDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.cached),
                    title = { Text("Tải trước lời bài hát (Preload Lyrics)") },
                    description = { Text("Tự động lưu trữ lời bài hát cho các bài nhạc đã tải trước") },
                    trailingContent = {
                        Switch(
                            checked = preloadLyrics,
                            onCheckedChange = onPreloadLyricsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (preloadLyrics) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPreloadLyricsChange(!preloadLyrics) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.download),
                    title = { Text("Xuất dưới dạng MP3 (Export as MP3)") },
                    description = { Text("Hiển thị tùy chọn 'Xuất dưới dạng MP3' trong menu bài hát") },
                    trailingContent = {
                        Switch(
                            checked = exportAsMp3,
                            onCheckedChange = onExportAsMp3Change,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (exportAsMp3) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onExportAsMp3Change(!exportAsMp3) }
                )
            )
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = "Bộ chỉnh âm & Hiệu ứng âm thanh (Advanced Equalizer)",
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.equalizer),
                    title = { Text("Chế độ Equalizer chuyên nghiệp") },
                    description = { Text("Bật xử lý hiệu ứng âm thanh tiên tiến") },
                    trailingContent = {
                        Switch(
                            checked = eqToggleProfessional,
                            onCheckedChange = onEqToggleProfessionalChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (eqToggleProfessional) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onEqToggleProfessionalChange(!eqToggleProfessional) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.graphic_eq),
                    title = { Text("Chế độ nâng cao (Simple / Advanced)") },
                    description = { Text(if (eqAdvancedMode) "Advanced (Nâng cao)" else "Simple (Cơ bản)") },
                    trailingContent = {
                        Switch(
                            checked = eqAdvancedMode,
                            onCheckedChange = onEqAdvancedModeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (eqAdvancedMode) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onEqAdvancedModeChange(!eqAdvancedMode) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.music_note),
                    title = { Text("Echo Signature") },
                    description = { Text("Chữ ký âm thanh: $echoSignature") },
                    onClick = { showEchoSignatureDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.volume_up),
                    title = { Text("Dolby Atmos") },
                    description = { Text("Cấu hình Dolby: $dolbyAtmos") },
                    onClick = { showDolbyAtmosDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.radio),
                    title = { Text("Dirac Audio") },
                    description = { Text("Cấu hình Dirac: $diracAudio") },
                    onClick = { showDiracAudioDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.equalizer),
                    title = { Text("Bass") },
                    description = {
                        Column {
                            val bassText = "${if (bass >= 0) "+" else ""}${bass.roundToInt()}"
                            Text(bassText)
                            Slider(
                                value = bass,
                                onValueChange = onBassChange,
                                valueRange = -12f..12f,
                                steps = 24
                            )
                        }
                    }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.equalizer),
                    title = { Text("Mids") },
                    description = {
                        Column {
                            val midsText = "${if (mids >= 0) "+" else ""}${mids.roundToInt()}"
                            Text(midsText)
                            Slider(
                                value = mids,
                                onValueChange = onMidsChange,
                                valueRange = -12f..12f,
                                steps = 24
                            )
                        }
                    }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.equalizer),
                    title = { Text("Treble") },
                    description = {
                        Column {
                            val trebleText = "${if (treble >= 0) "+" else ""}${treble.roundToInt()}"
                            Text(trebleText)
                            Slider(
                                value = treble,
                                onValueChange = onTrebleChange,
                                valueRange = -12f..12f,
                                steps = 24
                            )
                        }
                    }
                )

            )
        )

        Spacer(modifier = Modifier.height(27.dp))

        val lastUpdateText = remember(echoExtractorLastUpdateTime) {
            val instant = java.time.Instant.ofEpochMilli(echoExtractorLastUpdateTime)
            val formatter = java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss dd/MM/yyyy")
                .withZone(java.time.ZoneId.systemDefault())
            formatter.format(instant)
        }

        val nextUpdateText = remember(echoExtractorLastUpdateTime) {
            val nextTime = echoExtractorLastUpdateTime + 24 * 3600 * 1000
            val instant = java.time.Instant.ofEpochMilli(nextTime)
            val formatter = java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss dd/MM/yyyy")
                .withZone(java.time.ZoneId.systemDefault())
            formatter.format(instant)
        }

        Material3SettingsGroup(
            title = "Bộ trích xuất Echo (Echo Extractor)",
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.cloud),
                    title = { Text("Cấu hình bộ trích xuất Echo") },
                    description = {
                        Column {
                            Text("Cập nhật lần cuối: $lastUpdateText")
                            Text("Tự động cập nhật kế tiếp: $nextUpdateText")
                            if (echoExtractorUpdating) {
                                Text("Đang tải dữ liệu cấu hình mới nhất...", color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    },
                    trailingContent = {
                        Button(
                            onClick = {
                                val now = System.currentTimeMillis()
                                if (now - echoExtractorLastUpdateTime < 15000) {
                                    Toast.makeText(localContext, "Thao tác quá nhanh! Vui lòng đợi 15 giây cooldown.", Toast.LENGTH_SHORT).show()
                                } else {
                                    coroutineScope.launch {
                                        echoExtractorUpdating = true
                                        delay(1500)
                                        onEchoExtractorLastUpdateTimeChange(System.currentTimeMillis())
                                        echoExtractorUpdating = false
                                        Toast.makeText(localContext, "Đã cập nhật cấu hình Echo Extractor thành công!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            enabled = !echoExtractorUpdating
                        ) {
                            Text("Cập nhật ngay")
                        }
                    },
                    onClick = {}
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))
    }

    TopAppBar(
        title = { Text(stringResource(R.string.player_and_audio)) },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain
            ) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null
                )
            }
        }
    )
}
