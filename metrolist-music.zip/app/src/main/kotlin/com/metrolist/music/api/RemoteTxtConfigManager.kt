/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.api

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import timber.log.Timber
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

/**
 * Remote Config Model representing parsed instructions and access rules from a remote .txt file.
 */
data class RemoteTxtConfig(
    val url: String,
    val endpoints: List<String> = emptyList(),
    val allowedKeyPrefixes: List<String> = emptyList(),
    val exactAllowedKeys: Set<String> = emptySet(),
    val keyStateOverrides: Map<String, String> = emptyMap(), // key -> state ("LIFETIME_FREE", "EXPIRED", "RENEWED_EXTENDED", etc.)
    val customBaseUrl: String? = null,
    val recommendedModel: String? = null,
    val regexPatterns: List<String> = emptyList(),
    val rawLinesCount: Int = 0,
    val lastFetchedTimestamp: Long = System.currentTimeMillis(),
)

sealed class RemoteConfigResult {
    data class Success(val config: RemoteTxtConfig, val rawContentPreview: String) : RemoteConfigResult()
    data class Error(val normalizedSchema: NormalizedResponseSchema) : RemoteConfigResult()
}

/**
 * RemoteTxtConfigManager:
 * 1. Downloads .txt configuration files from remote URL (e.g., https://example.com/api_config.txt)
 * 2. Parses key-value pairs, endpoints, allowed keys, regex rules, and provider configurations
 * 3. Normalizes all network errors and parsing failures into the NormalizedResponseSchema
 */
object RemoteTxtConfigManager {

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    // Cached remote configuration in memory
    @Volatile
    private var cachedConfig: RemoteTxtConfig? = null

    fun getCachedConfig(): RemoteTxtConfig? = cachedConfig

    fun clearCache() {
        cachedConfig = null
    }

    /**
     * Fetches and parses a remote .txt file.
     * Supports formats:
     * - Key-Value format: KEY=VALUE, e.g.
     *     ENDPOINT=https://api.together.xyz/v1
     *     MODEL=deepseek/deepseek-v3.1-terminus:exacto
     *     ALLOWED_KEY=sk-proj-demo1234567890
     *     KEY_STATE:sk-proj-demo1234567890=LIFETIME_FREE
     *     REGEX=^sk-[a-zA-Z0-9_-]{20,}$
     * - Plain Key list: Each line is a known API key or prefix
     * - JSON lines / comments with # or //
     */
    suspend fun fetchAndParseFromUrl(url: String): RemoteConfigResult = withContext(Dispatchers.IO) {
        val trimmedUrl = url.trim()
        if (trimmedUrl.isBlank() || (!trimmedUrl.startsWith("http://") && !trimmedUrl.startsWith("https://"))) {
            val errorSchema = NormalizedResponseSchema.error(
                provider = "REMOTE_TXT_CONFIG",
                endpoint = trimmedUrl,
                keyState = "INVALID",
                code = "INVALID_URL",
                message = "Đường dẫn URL tệp .txt không hợp lệ. URL phải bắt đầu bằng http:// hoặc https://",
                rawProviderCode = null,
            )
            return@withContext RemoteConfigResult.Error(errorSchema)
        }

        try {
            val request = Request.Builder()
                .url(trimmedUrl)
                .header("User-Agent", "Metrolist-Music-AI-Client/2.0")
                .header("Accept", "text/plain, application/json, */*")
                .get()
                .build()

            val response = httpClient.newCall(request).execute()
            val code = response.code
            val body = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                val errorSchema = NormalizedResponseSchema.error(
                    provider = "REMOTE_TXT_CONFIG",
                    endpoint = trimmedUrl,
                    keyState = "INVALID",
                    code = "HTTP_FETCH_FAILED",
                    message = "Không thể tải tệp cấu hình từ URL (Mã phản hồi HTTP $code)",
                    rawProviderCode = code,
                )
                return@withContext RemoteConfigResult.Error(errorSchema)
            }

            if (body.isBlank()) {
                val errorSchema = NormalizedResponseSchema.error(
                    provider = "REMOTE_TXT_CONFIG",
                    endpoint = trimmedUrl,
                    keyState = "INVALID",
                    code = "EMPTY_FILE",
                    message = "Tệp cấu hình .txt tải về trống rỗng hoặc không có nội dung.",
                    rawProviderCode = 200,
                )
                return@withContext RemoteConfigResult.Error(errorSchema)
            }

            val parsed = parseContent(trimmedUrl, body)
            cachedConfig = parsed
            RemoteConfigResult.Success(parsed, body.take(500))
        } catch (e: Exception) {
            Timber.e("RemoteTxtConfigManager fetch failed: ${e.message}")
            val errorSchema = NormalizedResponseSchema.error(
                provider = "REMOTE_TXT_CONFIG",
                endpoint = trimmedUrl,
                keyState = "INVALID",
                code = "NETWORK_EXCEPTION",
                message = "Lỗi kết nối khi tải tệp .txt: ${e.message ?: "Không thể kết nối máy chủ"}",
                rawProviderCode = null,
            )
            RemoteConfigResult.Error(errorSchema)
        }
    }

    /**
     * Parses raw text content line-by-line.
     */
    fun parseContent(url: String, content: String): RemoteTxtConfig {
        val endpoints = mutableListOf<String>()
        val allowedKeyPrefixes = mutableListOf<String>()
        val exactAllowedKeys = mutableSetOf<String>()
        val keyStateOverrides = mutableMapOf<String, String>()
        val regexPatterns = mutableListOf<String>()
        var customBaseUrl: String? = null
        var recommendedModel: String? = null

        val lines = content.lines()
        var lineCount = 0

        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.isBlank() || line.startsWith("#") || line.startsWith("//")) {
                continue
            }
            lineCount++

            when {
                line.startsWith("ENDPOINT=", ignoreCase = true) -> {
                    val ep = line.substringAfter("=").trim()
                    if (ep.isNotBlank()) endpoints.add(ep)
                }
                line.startsWith("BASE_URL=", ignoreCase = true) -> {
                    customBaseUrl = line.substringAfter("=").trim()
                }
                line.startsWith("MODEL=", ignoreCase = true) -> {
                    recommendedModel = line.substringAfter("=").trim()
                }
                line.startsWith("ALLOWED_PREFIX=", ignoreCase = true) -> {
                    val prefix = line.substringAfter("=").trim()
                    if (prefix.isNotBlank()) allowedKeyPrefixes.add(prefix)
                }
                line.startsWith("ALLOWED_KEY=", ignoreCase = true) -> {
                    val key = line.substringAfter("=").trim()
                    if (key.isNotBlank()) exactAllowedKeys.add(key)
                }
                line.startsWith("KEY_STATE:", ignoreCase = true) -> {
                    // Format: KEY_STATE:keyString=STATE
                    val remainder = line.substringAfter(":")
                    val key = remainder.substringBefore("=").trim()
                    val state = remainder.substringAfter("=").trim().uppercase()
                    if (key.isNotBlank() && state.isNotBlank()) {
                        keyStateOverrides[key] = state
                    }
                }
                line.startsWith("REGEX=", ignoreCase = true) -> {
                    val pattern = line.substringAfter("=").trim()
                    if (pattern.isNotBlank()) regexPatterns.add(pattern)
                }
                line.contains("=") -> {
                    val key = line.substringBefore("=").trim()
                    val value = line.substringAfter("=").trim()
                    if (key.length >= 16) {
                        exactAllowedKeys.add(key)
                        keyStateOverrides[key] = value.uppercase()
                    }
                }
                else -> {
                    // Direct key line or endpoint line
                    if (line.startsWith("http://") || line.startsWith("https://")) {
                        endpoints.add(line)
                    } else if (line.length >= 16) {
                        exactAllowedKeys.add(line)
                    }
                }
            }
        }

        return RemoteTxtConfig(
            url = url,
            endpoints = endpoints,
            allowedKeyPrefixes = allowedKeyPrefixes,
            exactAllowedKeys = exactAllowedKeys,
            keyStateOverrides = keyStateOverrides,
            customBaseUrl = customBaseUrl,
            recommendedModel = recommendedModel,
            regexPatterns = regexPatterns,
            rawLinesCount = lineCount,
        )
    }

    /**
     * Cross-references an API key against the remote/cached configuration.
     * Returns:
     * - A matching classification if found in the remote configuration
     * - Null if no specific match/override is registered
     */
    fun crossReferenceKey(key: String, config: RemoteTxtConfig? = cachedConfig): RemoteKeyCheckResult {
        if (config == null) return RemoteKeyCheckResult.NotConfigured

        val trimmed = key.trim()

        // 1. Direct key state override
        config.keyStateOverrides[trimmed]?.let { stateStr ->
            return when (stateStr) {
                "LIFETIME_FREE", "FREE", "UNLIMITED" -> RemoteKeyCheckResult.Matched(
                    classification = ApiKeyClassification.LIFETIME_FREE,
                    description = "Key được cấp phép vĩnh viễn/miễn phí từ tệp cấu hình từ xa (.txt)",
                )
                "VALID_ACTIVE", "VALID", "ACTIVE" -> RemoteKeyCheckResult.Matched(
                    classification = ApiKeyClassification.VALID_ACTIVE,
                    description = "Key hợp lệ và đang hoạt động từ tệp cấu hình từ xa (.txt)",
                )
                "EXPIRED", "EXHAUSTED" -> RemoteKeyCheckResult.Matched(
                    classification = ApiKeyClassification.EXPIRED,
                    description = "Key đã hết hạn ngạch hoặc thời hạn theo cấu hình từ xa (.txt)",
                )
                "RENEWED_EXTENDED", "RENEWED" -> RemoteKeyCheckResult.Matched(
                    classification = ApiKeyClassification.RENEWED_EXTENDED,
                    description = "Key đã được gia hạn thành công theo cấu hình từ xa (.txt)",
                )
                "INVALID", "INVALID_SPOOFED", "BLOCKED" -> RemoteKeyCheckResult.Matched(
                    classification = ApiKeyClassification.INVALID_SPOOFED,
                    description = "Key bị từ chối hoặc nằm trong danh sách chặn của tệp .txt",
                )
                else -> RemoteKeyCheckResult.Matched(
                    classification = ApiKeyClassification.VALID_ACTIVE,
                    description = "Trạng thái $stateStr từ tệp cấu hình từ xa",
                )
            }
        }

        // 2. Exact match in allowed keys set
        if (config.exactAllowedKeys.contains(trimmed)) {
            return RemoteKeyCheckResult.Matched(
                classification = ApiKeyClassification.VALID_ACTIVE,
                description = "Key khớp chính xác trong danh sách được phép của tệp .txt",
            )
        }

        // 3. Prefix matching
        if (config.allowedKeyPrefixes.any { trimmed.startsWith(it) }) {
            return RemoteKeyCheckResult.Matched(
                classification = ApiKeyClassification.VALID_ACTIVE,
                description = "Tiền tố khóa khớp với cấu hình cho phép của tệp .txt",
            )
        }

        // 4. Custom Regex rules
        for (patternStr in config.regexPatterns) {
            try {
                if (Pattern.compile(patternStr).matcher(trimmed).matches()) {
                    return RemoteKeyCheckResult.Matched(
                        classification = ApiKeyClassification.VALID_ACTIVE,
                        description = "Key phù hợp với biểu thức chính quy (Regex: $patternStr)",
                    )
                }
            } catch (e: Exception) {
                Timber.w("Invalid regex in remote config: $patternStr")
            }
        }

        return RemoteKeyCheckResult.NoMatch
    }
}

sealed class RemoteKeyCheckResult {
    object NotConfigured : RemoteKeyCheckResult()
    object NoMatch : RemoteKeyCheckResult()
    data class Matched(
        val classification: ApiKeyClassification,
        val description: String,
    ) : RemoteKeyCheckResult()
}
