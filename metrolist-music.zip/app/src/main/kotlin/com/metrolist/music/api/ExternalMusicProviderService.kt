/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.api

import android.content.Context
import com.metrolist.innertube.YouTube
import com.metrolist.innertube.models.Album
import com.metrolist.innertube.models.Artist
import com.metrolist.innertube.models.SongItem
import com.metrolist.music.unified.AppleMusicAdapter
import com.metrolist.music.unified.SpotifyAdapter
import com.metrolist.music.unified.UnifiedArtist
import com.metrolist.music.unified.UnifiedMusicRepository
import com.metrolist.music.unified.UnifiedPlaylist
import com.metrolist.music.unified.UnifiedTrack
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import timber.log.Timber
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

enum class MusicSourceProvider {
    ALL,
    YOUTUBE,
    SPOTIFY,
    APPLE_MUSIC,
    ;

    val displayName: String
        get() = when (this) {
            ALL -> "All"
            YOUTUBE -> "YouTube Music"
            SPOTIFY -> "Spotify"
            APPLE_MUSIC -> "Apple Music"
        }
}

enum class MusicCountry(val code: String, val displayName: String, val flag: String) {
    VIETNAM("vn", "Việt Nam", "🇻🇳"),
    US("us", "Toàn cầu / US", "🇺🇸"),
    UK("gb", "Vương quốc Anh", "🇬🇧"),
    JAPAN("jp", "Nhật Bản", "🇯🇵"),
    KOREA("kr", "Hàn Quốc", "🇰🇷"),
    FRANCE("fr", "Pháp", "🇫🇷"),
}

enum class MusicCategory(val id: String, val title: String, val emoji: String, val isKidsFamily: Boolean = false) {
    ALL("all", "Tất cả", "🌟"),
    KIDS_FAMILY("kids", "Thiếu nhi & Cho Cháu", "👶", isKidsFamily = true),
    VPOP("vpop", "V-Pop & Trữ tình", "🇻🇳"),
    POP_GLOBAL("pop", "Pop & US-UK", "🌍"),
    KPOP_JPOP("asian", "K-Pop & J-Pop", "🌸"),
    CHILL_ACOUSTIC("chill", "Thư giãn & Acoustic", "☕"),
    EDM_DANCE("dance", "Sôi động & EDM", "⚡"),
}

data class ExternalTrack(
    val id: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val thumbnailUrl: String = "",
    val durationSeconds: Int? = null,
    val provider: MusicSourceProvider,
    val previewUrl: String? = null,
    val externalUrl: String? = null,
    val isExplicit: Boolean = false,
    val resolvedVideoId: String? = null,
    val countryCode: String = "vn",
    val categoryId: String = "all",
) {
    val uniqueId: String
        get() {
            val prefix = when (provider) {
                MusicSourceProvider.SPOTIFY -> "sp_"
                MusicSourceProvider.APPLE_MUSIC -> "am_"
                MusicSourceProvider.YOUTUBE -> "yt_"
                else -> "ext_"
            }
            val cleanId = id.replace(Regex("[^a-zA-Z0-9_]"), "")
            return if (cleanId.startsWith("sp_") || cleanId.startsWith("am_") || cleanId.startsWith("yt_")) {
                cleanId
            } else {
                "$prefix$cleanId"
            }
        }

    fun toSongItem(resolvedId: String? = null): SongItem {
        val targetId = resolvedId ?: resolvedVideoId ?: uniqueId
        return SongItem(
            id = targetId,
            title = title,
            artists = listOf(Artist(name = artist, id = null)),
            album = if (album.isNotBlank()) Album(name = album, id = "") else null,
            duration = durationSeconds,
            thumbnail = thumbnailUrl,
            explicit = isExplicit
        )
    }
}

data class ExternalPlaylist(
    val id: String,
    val title: String,
    val description: String = "",
    val thumbnailUrl: String = "",
    val trackCount: Int? = null,
    val provider: MusicSourceProvider,
    val externalUrl: String? = null,
)

data class ExternalArtist(
    val id: String,
    val name: String,
    val thumbnailUrl: String = "",
    val followers: String? = null,
    val genres: List<String> = emptyList(),
    val provider: MusicSourceProvider,
    val externalUrl: String? = null,
)

data class UserComment(
    val id: String,
    val authorName: String,
    val authorAvatarUrl: String = "",
    val content: String,
    val publishedTime: String = "",
    val likeCount: String = "",
)

@Singleton
class ExternalMusicProviderService @Inject constructor(
    @ApplicationContext private val context: Context,
    val spotifyAdapter: SpotifyAdapter = SpotifyAdapter(),
    val appleMusicAdapter: AppleMusicAdapter = AppleMusicAdapter(),
) {
    val unifiedRepository: UnifiedMusicRepository = UnifiedMusicRepository(spotifyAdapter, appleMusicAdapter)

    /**
     * Search songs from Spotify API via SpotifyAdapter.
     */
    suspend fun searchSpotify(query: String, limit: Int = 25): List<ExternalTrack> {
        return spotifyAdapter.searchTracks(query, limit).map { it.toExternalTrack() }
    }

    /**
     * Search songs from Apple Music / iTunes API via AppleMusicAdapter.
     */
    suspend fun searchAppleMusic(query: String, limit: Int = 25): List<ExternalTrack> {
        return appleMusicAdapter.searchTracks(query, limit).map { it.toExternalTrack() }
    }

    /**
     * Search Artists from Spotify and Apple Music API via Unified Music Interface.
     */
    suspend fun searchArtists(
        query: String,
        provider: MusicSourceProvider = MusicSourceProvider.ALL
    ): List<ExternalArtist> {
        return unifiedRepository.searchArtists(query, provider).map { it.toExternalArtist() }
    }

    /**
     * Search Playlists from Spotify and Apple Music API via Unified Music Interface.
     */
    suspend fun searchPlaylists(
        query: String,
        provider: MusicSourceProvider = MusicSourceProvider.ALL
    ): List<ExternalPlaylist> {
        return unifiedRepository.searchPlaylists(query, provider).map { it.toExternalPlaylist() }
    }

    /**
     * Finds the matching Spotify track metadata for any song title and artist.
     */
    suspend fun findSpotifyTrack(title: String, artist: String): ExternalTrack? = withContext(Dispatchers.IO) {
        val cleanTitle = title.replace(Regex("\\(.*?\\)|\\[.*?\\]"), "").trim()
        val query = if (artist.isNotBlank() && !artist.equals("Unknown Artist", ignoreCase = true)) {
            "$cleanTitle $artist"
        } else {
            cleanTitle
        }
        val searchResults = searchSpotify(query, limit = 5)
        if (searchResults.isNotEmpty()) {
            return@withContext searchResults.firstOrNull {
                it.title.contains(cleanTitle, ignoreCase = true) || cleanTitle.contains(it.title, ignoreCase = true)
            } ?: searchResults.first()
        }
        return@withContext null
    }

    /**
     * Fetches a specific Spotify track by Spotify ID directly from SpotifyAdapter.
     */
    suspend fun getSpotifyTrack(spotifyTrackId: String): ExternalTrack? {
        return spotifyAdapter.getTrackById(spotifyTrackId)?.toExternalTrack()
    }

    /**
     * Fetches Spotify Recommendations based on selected Country & Category.
     */
    suspend fun getSpotifyRecommendations(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
    ): List<ExternalTrack> {
        return spotifyAdapter.getRecommendations(country, category).map { it.toExternalTrack() }
    }

    /**
     * Fetches Apple Music Top Hits & Charts based on selected Country & Category.
     */
    suspend fun getAppleMusicCharts(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
    ): List<ExternalTrack> {
        return appleMusicAdapter.getRecommendations(country, category).map { it.toExternalTrack() }
    }

    /**
     * Fetches Spotify Featured Playlists based on selected Country & Category.
     */
    suspend fun getSpotifyFeaturedPlaylists(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
    ): List<ExternalPlaylist> {
        return spotifyAdapter.getFeaturedPlaylists(country, category).map { it.toExternalPlaylist() }
    }

    /**
     * Fetches Apple Music Top Playlists based on selected Country & Category.
     */
    suspend fun getAppleMusicPlaylists(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
    ): List<ExternalPlaylist> {
        return appleMusicAdapter.getFeaturedPlaylists(country, category).map { it.toExternalPlaylist() }
    }

    /**
     * Fetches Top Artists on Spotify based on selected Country & Category.
     */
    suspend fun getTopSpotifyArtists(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
    ): List<ExternalArtist> {
        return spotifyAdapter.getTopArtists(country, category).map { it.toExternalArtist() }
    }

    /**
     * Resolves an external track to a playable YouTube videoId with concurrent thread-safe cache.
     */
    suspend fun resolveToPlayableVideoId(title: String, artist: String): String? {
        return unifiedRepository.resolveToPlayableVideoId(title, artist)
    }

    /**
     * Fetches real user comments for a song/video in real time.
     */
    suspend fun fetchCommentsForVideo(videoId: String): List<UserComment> {
        return unifiedRepository.fetchCommentsForVideo(videoId)
    }
}
