/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.component

import android.app.Activity
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import coil3.compose.AsyncImage
import com.metrolist.innertube.YouTube
import com.metrolist.music.LocalDatabase
import com.metrolist.music.R
import com.metrolist.music.db.entities.Playlist
import com.metrolist.music.ui.screens.playlist.uriToByteArray
import com.metrolist.music.utils.CoverOverlayStyle
import com.metrolist.music.utils.CoverPalette
import com.metrolist.music.utils.PaletteCategory
import com.metrolist.music.utils.PlaylistCoverGenerator
import com.metrolist.music.utils.reportException
import com.yalantis.ucrop.UCrop
import io.ktor.client.plugins.ClientRequestException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDateTime
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PlaylistCoverCustomizerDialog(
    playlist: Playlist,
    onDismiss: () -> Unit,
    onCoverUpdated: (String?) -> Unit,
) {
    val context = LocalContext.current
    val database = LocalDatabase.current
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedCategory by remember { mutableStateOf(PaletteCategory.ALL) }
    var selectedPalette by remember { mutableStateOf(PlaylistCoverGenerator.PRESET_PALETTES.first()) }
    var selectedStyle by remember { mutableStateOf(CoverOverlayStyle.ICON) }
    var selectedIconRes by remember { mutableIntStateOf(R.drawable.music_note) }
    var customInitialsText by remember {
        mutableStateOf(PlaylistCoverGenerator.getInitials(playlist.playlist.name))
    }

    var pickedImageUri by remember { mutableStateOf<Uri?>(null) }
    var pendingCropDestUri by remember { mutableStateOf<Uri?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    val isCustomCoverCurrentlySet = playlist.playlist.thumbnailUrl != null

    val colorScheme = MaterialTheme.colorScheme

    // UCrop launcher
    val cropLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val output = res.data?.let { UCrop.getOutput(it) } ?: pendingCropDestUri
            if (output != null) {
                pickedImageUri = output
                selectedTab = 1 // Switch to image tab to preview
            }
        }
    }

    // Photo picker launcher
    val pickLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { sourceUri ->
            val destFile = File(context.cacheDir, "playlist_cover_crop_${System.currentTimeMillis()}.jpg")
            val destUri = FileProvider.getUriForFile(context, "${context.packageName}.FileProvider", destFile)
            pendingCropDestUri = destUri

            val surfaceColor = colorScheme.surface.toArgb()
            val onSurfaceColor = colorScheme.onSurface.toArgb()

            val options = UCrop.Options().apply {
                setCompressionFormat(Bitmap.CompressFormat.JPEG)
                setCompressionQuality(92)
                setHideBottomControls(true)
                setToolbarTitle(context.getString(R.string.edit_playlist_cover))
                setToolbarColor(surfaceColor)
                setToolbarWidgetColor(onSurfaceColor)
                setRootViewBackgroundColor(surfaceColor)
                setLogoColor(surfaceColor)
            }

            val intent = UCrop.of(sourceUri, destUri)
                .withAspectRatio(1f, 1f)
                .withMaxResultSize(1080, 1080)
                .withOptions(options)
                .getIntent(context)
            intent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            intent.addFlags(android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            cropLauncher.launch(intent)
        }
    }

    fun applyPaletteCover() {
        if (isSaving) return
        isSaving = true
        scope.launch(Dispatchers.IO) {
            try {
                val bitmap = PlaylistCoverGenerator.generateCoverBitmap(
                    context = context,
                    palette = selectedPalette,
                    style = selectedStyle,
                    playlistName = playlist.playlist.name,
                    selectedIconRes = selectedIconRes,
                    customInitials = customInitialsText,
                    size = 1080
                )
                val fileUri = PlaylistCoverGenerator.saveCoverBitmap(context, playlist.playlist.id, bitmap)
                val uriString = fileUri.toString()
                val browseId = playlist.playlist.browseId

                if (browseId == null) {
                    database.query {
                        update(
                            playlist.playlist.copy(
                                thumbnailUrl = uriString,
                                lastUpdateTime = LocalDateTime.now()
                            )
                        )
                    }
                    withContext(Dispatchers.Main) {
                        isSaving = false
                        Toast.makeText(context, R.string.playlist_cover_updated_success, Toast.LENGTH_SHORT).show()
                        onCoverUpdated(uriString)
                        onDismiss()
                    }
                } else {
                    val bytes = uriToByteArray(context, fileUri)
                    if (bytes != null) {
                        YouTube.uploadCustomThumbnailLink(browseId, bytes)
                            .onSuccess { newThumbnailUrl ->
                                database.query {
                                    update(
                                        playlist.playlist.copy(
                                            thumbnailUrl = newThumbnailUrl,
                                            lastUpdateTime = LocalDateTime.now()
                                        )
                                    )
                                }
                                withContext(Dispatchers.Main) {
                                    isSaving = false
                                    Toast.makeText(context, R.string.playlist_cover_updated_success, Toast.LENGTH_SHORT).show()
                                    onCoverUpdated(newThumbnailUrl)
                                    onDismiss()
                                }
                            }
                            .onFailure {
                                reportException(it)
                                withContext(Dispatchers.Main) {
                                    isSaving = false
                                    Toast.makeText(context, "Error: ${it.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                    } else {
                        withContext(Dispatchers.Main) { isSaving = false }
                    }
                }
            } catch (e: Exception) {
                reportException(e)
                withContext(Dispatchers.Main) {
                    isSaving = false
                    Toast.makeText(context, "Failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun applyPickedImageCover(imageUri: Uri) {
        if (isSaving) return
        isSaving = true
        scope.launch(Dispatchers.IO) {
            try {
                val savedUri = PlaylistCoverGenerator.saveCustomImageFile(context, playlist.playlist.id, imageUri)
                val uriString = savedUri.toString()
                val browseId = playlist.playlist.browseId

                if (browseId == null) {
                    database.query {
                        update(
                            playlist.playlist.copy(
                                thumbnailUrl = uriString,
                                lastUpdateTime = LocalDateTime.now()
                            )
                        )
                    }
                    withContext(Dispatchers.Main) {
                        isSaving = false
                        Toast.makeText(context, R.string.playlist_cover_updated_success, Toast.LENGTH_SHORT).show()
                        onCoverUpdated(uriString)
                        onDismiss()
                    }
                } else {
                    val bytes = uriToByteArray(context, savedUri)
                    if (bytes != null) {
                        YouTube.uploadCustomThumbnailLink(browseId, bytes)
                            .onSuccess { newThumbnailUrl ->
                                database.query {
                                    update(
                                        playlist.playlist.copy(
                                            thumbnailUrl = newThumbnailUrl,
                                            lastUpdateTime = LocalDateTime.now()
                                        )
                                    )
                                }
                                withContext(Dispatchers.Main) {
                                    isSaving = false
                                    Toast.makeText(context, R.string.playlist_cover_updated_success, Toast.LENGTH_SHORT).show()
                                    onCoverUpdated(newThumbnailUrl)
                                    onDismiss()
                                }
                            }
                            .onFailure {
                                reportException(it)
                                withContext(Dispatchers.Main) {
                                    isSaving = false
                                    Toast.makeText(context, "Error: ${it.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                    } else {
                        withContext(Dispatchers.Main) { isSaving = false }
                    }
                }
            } catch (e: Exception) {
                reportException(e)
                withContext(Dispatchers.Main) {
                    isSaving = false
                    Toast.makeText(context, "Failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun removeCustomCover() {
        if (isSaving) return
        isSaving = true
        scope.launch(Dispatchers.IO) {
            try {
                PlaylistCoverGenerator.removeCustomCoverFiles(context, playlist.playlist.id)
                val browseId = playlist.playlist.browseId
                if (browseId == null) {
                    database.query {
                        update(
                            playlist.playlist.copy(
                                thumbnailUrl = null,
                                lastUpdateTime = LocalDateTime.now()
                            )
                        )
                    }
                    withContext(Dispatchers.Main) {
                        isSaving = false
                        Toast.makeText(context, R.string.playlist_cover_removed_success, Toast.LENGTH_SHORT).show()
                        onCoverUpdated(null)
                        onDismiss()
                    }
                } else {
                    YouTube.removeThumbnailPlaylist(browseId)
                        .onSuccess { newThumb ->
                            database.query {
                                update(
                                    playlist.playlist.copy(
                                        thumbnailUrl = newThumb,
                                        lastUpdateTime = LocalDateTime.now()
                                    )
                                )
                            }
                            withContext(Dispatchers.Main) {
                                isSaving = false
                                Toast.makeText(context, R.string.playlist_cover_removed_success, Toast.LENGTH_SHORT).show()
                                onCoverUpdated(newThumb)
                                onDismiss()
                            }
                        }
                        .onFailure {
                            reportException(it)
                            withContext(Dispatchers.Main) {
                                isSaving = false
                                Toast.makeText(context, "Error: ${it.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                }
            } catch (e: Exception) {
                reportException(e)
                withContext(Dispatchers.Main) {
                    isSaving = false
                }
            }
        }
    }

    val filteredPalettes = remember(selectedCategory) {
        if (selectedCategory == PaletteCategory.ALL) {
            PlaylistCoverGenerator.PRESET_PALETTES
        } else {
            PlaylistCoverGenerator.PRESET_PALETTES.filter { it.category == selectedCategory }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 720.dp),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.custom_playlist_cover_title),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = playlist.playlist.name,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            painter = painterResource(R.drawable.close),
                            contentDescription = stringResource(R.string.close),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Interactive Live Preview
                LiveCoverPreviewBox(
                    isImageTab = selectedTab == 1 && pickedImageUri != null,
                    imageUri = pickedImageUri ?: (if (isCustomCoverCurrentlySet && selectedTab == 1) playlist.playlist.thumbnailUrl?.let { Uri.parse(it) } else null),
                    palette = selectedPalette,
                    style = selectedStyle,
                    iconRes = selectedIconRes,
                    initials = customInitialsText
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Tabs: Palette vs Local Image
                PrimaryTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.palette),
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = stringResource(R.string.playlist_cover_tab_palette),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.insert_photo),
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = stringResource(R.string.playlist_cover_tab_local_image),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Tab Content
                if (selectedTab == 0) {
                    // PALETTE TAB
                    // 1. Categories
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp)
                    ) {
                        items(PaletteCategory.entries) { category ->
                            val label = when (category) {
                                PaletteCategory.ALL -> stringResource(R.string.playlist_cover_category_all)
                                PaletteCategory.VIBRANT -> stringResource(R.string.playlist_cover_category_vibrant)
                                PaletteCategory.WARM -> stringResource(R.string.playlist_cover_category_warm)
                                PaletteCategory.CHILL -> stringResource(R.string.playlist_cover_category_chill)
                                PaletteCategory.DARK -> stringResource(R.string.playlist_cover_category_dark)
                                PaletteCategory.PASTEL -> stringResource(R.string.playlist_cover_category_pastel)
                            }
                            FilterChip(
                                selected = selectedCategory == category,
                                onClick = { selectedCategory = category },
                                label = { Text(label, style = MaterialTheme.typography.labelMedium) },
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 2. Swatches Grid
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        maxItemsInEachRow = 4
                    ) {
                        filteredPalettes.forEach { palette ->
                            val isSelected = selectedPalette.id == palette.id
                            val borderCol by animateColorAsState(
                                targetValue = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent
                            )

                            Box(
                                modifier = Modifier
                                    .size(62.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        Brush.linearGradient(
                                            colors = palette.colors,
                                            start = Offset(0f, 0f),
                                            end = Offset(100f, 100f)
                                        )
                                    )
                                    .border(
                                        width = if (isSelected) 3.dp else 1.dp,
                                        color = if (isSelected) borderCol else Color.White.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(14.dp)
                                    )
                                    .clickable { selectedPalette = palette },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Surface(
                                        shape = CircleShape,
                                        color = Color.Black.copy(alpha = 0.5f),
                                        modifier = Modifier.size(26.dp)
                                    ) {
                                        Icon(
                                            painter = painterResource(R.drawable.check),
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.padding(5.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 3. Overlay Style Selector
                    Text(
                        text = stringResource(R.string.playlist_cover_overlay_style),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.align(Alignment.Start)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedStyle == CoverOverlayStyle.CLEAN,
                            onClick = { selectedStyle = CoverOverlayStyle.CLEAN },
                            label = { Text(stringResource(R.string.playlist_cover_style_clean), style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = selectedStyle == CoverOverlayStyle.ICON,
                            onClick = { selectedStyle = CoverOverlayStyle.ICON },
                            label = { Text(stringResource(R.string.playlist_cover_style_icon), style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = selectedStyle == CoverOverlayStyle.INITIALS,
                            onClick = { selectedStyle = CoverOverlayStyle.INITIALS },
                            label = { Text(stringResource(R.string.playlist_cover_style_initials), style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = selectedStyle == CoverOverlayStyle.GEOMETRIC_WAVES,
                            onClick = { selectedStyle = CoverOverlayStyle.GEOMETRIC_WAVES },
                            label = { Text(stringResource(R.string.playlist_cover_style_waves), style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Style detail customizer
                    AnimatedVisibility(
                        visible = selectedStyle == CoverOverlayStyle.ICON,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        Column(modifier = Modifier.padding(top = 10.dp)) {
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(PlaylistCoverGenerator.AVAILABLE_ICONS) { iconOption ->
                                    val isSelected = selectedIconRes == iconOption.iconRes
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer,
                                        border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clickable { selectedIconRes = iconOption.iconRes }
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                painter = painterResource(iconOption.iconRes),
                                                contentDescription = iconOption.label,
                                                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(22.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    AnimatedVisibility(
                        visible = selectedStyle == CoverOverlayStyle.INITIALS,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        Column(modifier = Modifier.padding(top = 10.dp)) {
                            OutlinedTextField(
                                value = customInitialsText,
                                onValueChange = { if (it.length <= 4) customInitialsText = it.uppercase() },
                                label = { Text(stringResource(R.string.playlist_cover_custom_initials)) },
                                placeholder = { Text(stringResource(R.string.playlist_cover_custom_initials_hint)) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                } else {
                    // IMAGE PICKER TAB
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainer
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.insert_photo),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(44.dp)
                            )
                            Text(
                                text = stringResource(R.string.playlist_cover_pick_from_device),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = stringResource(R.string.playlist_cover_pick_from_device_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            Button(
                                onClick = {
                                    pickLauncher.launch(
                                        PickVisualMediaRequest(
                                            mediaType = ActivityResultContracts.PickVisualMedia.ImageOnly
                                        )
                                    )
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary
                                )
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.crop),
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(stringResource(R.string.choose_from_library))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Bottom Action Buttons
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            if (selectedTab == 0) {
                                applyPaletteCover()
                            } else {
                                pickedImageUri?.let { applyPickedImageCover(it) }
                            }
                        },
                        enabled = !isSaving && (selectedTab == 0 || pickedImageUri != null),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        if (isSaving) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text(
                            text = stringResource(R.string.playlist_cover_apply_button),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (isCustomCoverCurrentlySet) {
                        OutlinedButton(
                            onClick = { removeCustomCover() },
                            enabled = !isSaving,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.error
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.delete),
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(stringResource(R.string.playlist_cover_remove_button))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveCoverPreviewBox(
    isImageTab: Boolean,
    imageUri: Uri?,
    palette: CoverPalette,
    style: CoverOverlayStyle,
    iconRes: Int,
    initials: String,
) {
    Surface(
        modifier = Modifier
            .size(168.dp)
            .aspectRatio(1f)
            .shadow(
                elevation = 12.dp,
                shape = RoundedCornerShape(18.dp),
                spotColor = palette.colors.first().copy(alpha = 0.5f)
            ),
        shape = RoundedCornerShape(18.dp),
    ) {
        if (isImageTab && imageUri != null) {
            AsyncImage(
                model = imageUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            colors = palette.colors,
                            start = Offset(0f, 0f),
                            end = Offset(400f, 400f)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Background decorative rings
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.12f),
                        radius = size.width * 0.4f,
                        center = Offset(size.width * 0.85f, size.height * 0.15f),
                        style = Stroke(width = 2f)
                    )
                    drawCircle(
                        color = Color.White.copy(alpha = 0.08f),
                        radius = size.width * 0.3f,
                        center = Offset(size.width * 0.15f, size.height * 0.85f)
                    )
                }

                when (style) {
                    CoverOverlayStyle.CLEAN -> {
                        // Just beautiful gradient & subtle rings
                    }

                    CoverOverlayStyle.GEOMETRIC_WAVES -> {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val wavePath = Path()
                            for (i in 0..4) {
                                val y = size.height * (0.25f + i * 0.15f)
                                wavePath.reset()
                                wavePath.moveTo(0f, y)
                                wavePath.cubicTo(
                                    size.width * 0.3f, y - 25f,
                                    size.width * 0.7f, y + 25f,
                                    size.width, y
                                )
                                drawPath(
                                    path = wavePath,
                                    color = Color.White.copy(alpha = 0.2f),
                                    style = Stroke(width = 4f)
                                )
                            }
                        }
                    }

                    CoverOverlayStyle.ICON -> {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.22f),
                            border = BorderStroke(1.5.dp, Color.White.copy(alpha = 0.45f)),
                            modifier = Modifier.size(68.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    painter = painterResource(iconRes),
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }
                    }

                    CoverOverlayStyle.INITIALS -> {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.24f),
                            border = BorderStroke(2.dp, Color.White.copy(alpha = 0.5f)),
                            modifier = Modifier.size(68.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = initials.take(3),
                                    color = Color.White,
                                    fontSize = if (initials.length > 2) 20.sp else 24.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
