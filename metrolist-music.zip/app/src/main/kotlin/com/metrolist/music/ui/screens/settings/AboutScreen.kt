/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialShapes
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.toShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.graphics.shapes.RoundedPolygon
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import com.metrolist.music.BuildConfig
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.utils.backToMain
import java.util.Locale

private data class Contributor(
    val name: String,
    val roleRes: Int,
    val githubHandle: String,
    val avatarUrl: String = "https://github.com/$githubHandle.png",
    val githubUrl: String = "https://github.com/$githubHandle",
    val sponsorUrl: String? = null,
    val polygon: RoundedPolygon? = null,
)

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
private val customizerDeveloper = Contributor(
    name = "Nguyễn Minh Tới",
    roleRes = R.string.credits_secondary_developer_role,
    githubHandle = "nguyenminhtoi212-code",
    polygon = MaterialShapes.Cookie12Sided,
)

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
private val leadDeveloper = Contributor(
    name = "Mo Agamy",
    roleRes = R.string.credits_original_lead_developer,
    githubHandle = "mostafaalagamy",
    polygon = MaterialShapes.Cookie9Sided,
)

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
private val collaborators = listOf(
    Contributor(
        name = "Adriel O'Connel",
        roleRes = R.string.credits_collaborator,
        githubHandle = "adrielGGmotion",
        sponsorUrl = "https://github.com/sponsors/adrielGGmotion",
        polygon = MaterialShapes.Cookie4Sided
    ),
    Contributor(
        name = "Nyx",
        roleRes = R.string.credits_collaborator,
        githubHandle = "nyxiereal",
        sponsorUrl = "https://github.com/sponsors/nyxiereal",
        polygon = MaterialShapes.Cookie12Sided
    ),
)

@Composable
private fun ContributorAvatar(
    avatarUrl: String,
    sizeDp: Int,
    modifier: Modifier = Modifier,
    shape: Shape = CircleShape,
    contentDescription: String? = null,
) {
    val fallback = painterResource(R.drawable.about_icon)
    Surface(
        modifier = modifier.size(sizeDp.dp),
        shape = shape,
        color = MaterialTheme.colorScheme.surfaceContainerHighest,
        tonalElevation = 4.dp,
    ) {
        AsyncImage(
            model = avatarUrl,
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
            placeholder = fallback,
            fallback = fallback,
            error = fallback,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun AboutScreen(
    navController: NavController,
) {
    val uriHandler = LocalUriHandler.current
    val snackbarHostState = remember { SnackbarHostState() }
    val windowInsets = LocalPlayerAwareWindowInsets.current

    val metrolistName = stringResource(R.string.metrolist)
        .lowercase(Locale.getDefault())
        .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.about),
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = navController::navigateUp,
                        onLongClick = navController::backToMain,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.arrow_back),
                            contentDescription = stringResource(R.string.cd_back),
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        snackbarHost = {
            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier.windowInsetsPadding(
                    windowInsets.only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal)
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .windowInsetsPadding(windowInsets.only(WindowInsetsSides.Horizontal))
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Compact App Banner Hero Card
            ElevatedCard(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                ),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // App Logo
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(56.dp)
                            .background(
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                shape = CircleShape
                            )
                    ) {
                        Image(
                            painter = painterResource(R.drawable.ic_logo_oval),
                            contentDescription = null,
                            colorFilter = ColorFilter.tint(
                                color = MaterialTheme.colorScheme.primary,
                                blendMode = BlendMode.SrcIn,
                            ),
                            modifier = Modifier.size(52.dp)
                        )
                        Image(
                            painter = painterResource(R.drawable.about_icon),
                            contentDescription = stringResource(R.string.metrolist),
                            colorFilter = ColorFilter.tint(
                                color = MaterialTheme.colorScheme.onPrimary,
                                blendMode = BlendMode.SrcIn,
                            ),
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = metrolistName,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Text(
                                    text = "v${BuildConfig.VERSION_NAME}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = stringResource(R.string.about_subtitle),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 2.dp)
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(top = 6.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.secondaryContainer
                            ) {
                                Text(
                                    text = BuildConfig.ARCHITECTURE.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Group 1: Secondary Developer (Placed on top)
            Material3SettingsGroup(
                title = stringResource(R.string.credits_secondary_developer_group),
                items = listOf(
                    Material3SettingsItem(
                        leadingContent = {
                            ContributorAvatar(
                                avatarUrl = customizerDeveloper.avatarUrl,
                                sizeDp = 44,
                                shape = customizerDeveloper.polygon?.toShape() ?: CircleShape,
                                contentDescription = customizerDeveloper.name,
                            )
                        },
                        title = { Text(customizerDeveloper.name, fontWeight = FontWeight.Bold) },
                        description = { Text(stringResource(customizerDeveloper.roleRes)) },
                        trailingContent = {
                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                IconButton(onClick = { uriHandler.openUri("https://github.com/nguyenminhtoi212-code") }, onLongClick = {}) {
                                    Icon(painterResource(R.drawable.github), contentDescription = "GitHub", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        },
                        onClick = null
                    )
                )
            )

            // Group 2: Special Thanks to Original Creator & Collaborators
            Material3SettingsGroup(
                title = stringResource(R.string.credits_special_thanks_section),
                items = listOf(
                    // Original Lead Dev (Mo Agamy)
                    Material3SettingsItem(
                        leadingContent = {
                            ContributorAvatar(
                                avatarUrl = leadDeveloper.avatarUrl,
                                sizeDp = 44,
                                shape = leadDeveloper.polygon?.toShape() ?: CircleShape,
                                contentDescription = leadDeveloper.name,
                            )
                        },
                        title = { Text(leadDeveloper.name, fontWeight = FontWeight.Bold) },
                        description = { Text("${stringResource(leadDeveloper.roleRes)} • @${leadDeveloper.githubHandle}") },
                        trailingContent = {
                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                IconButton(onClick = { uriHandler.openUri("https://metrolist.cc") }, onLongClick = {}) {
                                    Icon(painterResource(R.drawable.language), contentDescription = "Website", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                IconButton(onClick = { uriHandler.openUri("https://github.com/mostafaalagamy") }, onLongClick = {}) {
                                    Icon(painterResource(R.drawable.github), contentDescription = "GitHub", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                IconButton(onClick = { uriHandler.openUri("https://buymeacoffee.com/mostafaalagamy") }, onLongClick = {}) {
                                    Icon(painterResource(R.drawable.buymeacoffee), contentDescription = "Buy Coffee", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        },
                        onClick = null
                    )
                ) + collaborators.map { contributor ->
                    Material3SettingsItem(
                        leadingContent = {
                            ContributorAvatar(
                                avatarUrl = contributor.avatarUrl,
                                sizeDp = 40,
                                shape = contributor.polygon?.toShape() ?: CircleShape,
                                contentDescription = contributor.name,
                            )
                        },
                        title = { Text(contributor.name, fontWeight = FontWeight.Medium) },
                        description = { Text("${stringResource(contributor.roleRes)} • @${contributor.githubHandle}") },
                        trailingContent = {
                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                if (contributor.sponsorUrl != null) {
                                    IconButton(onClick = { uriHandler.openUri(contributor.sponsorUrl) }, onLongClick = {}) {
                                        Icon(painterResource(R.drawable.buymeacoffee), contentDescription = "Sponsor", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                IconButton(onClick = { uriHandler.openUri(contributor.githubUrl) }, onLongClick = {}) {
                                    Icon(painterResource(R.drawable.github), contentDescription = "GitHub", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        },
                        onClick = null
                    )
                }
            )

            // Group 3: License, Terms & Privacy
            Material3SettingsGroup(
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.info),
                        title = { Text(stringResource(R.string.credits_license_name), fontWeight = FontWeight.Medium) },
                        description = { Text(stringResource(R.string.credits_license_desc)) },
                        onClick = { navController.navigate("settings/license") }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.info),
                        title = { Text(stringResource(R.string.terms_and_privacy), fontWeight = FontWeight.Medium) },
                        onClick = { navController.navigate("settings/terms_privacy") }
                    )
                )
            )

            // Compact Footer
            Text(
                text = stringResource(R.string.about_footer),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
            )
        }
    }
}
