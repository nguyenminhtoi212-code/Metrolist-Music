/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import android.net.TrafficStats
import android.os.Build
import android.os.Process
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import android.content.pm.PackageManager.PERMISSION_GRANTED
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.LocalPlayerConnection
import com.metrolist.music.R
import com.metrolist.music.constants.*
import com.metrolist.music.playback.StreamingDataTracker
import com.metrolist.music.ui.component.DefaultDialog
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.rememberPreference
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DataSaverSettings(
    navController: NavController
) {
    val context = LocalContext.current
    val downloadCache = LocalPlayerConnection.current?.service?.downloadCache

    // 1. Data Saver Mode settings
    val (dataSaverBeta, onDataSaverBetaChange) = rememberPreference(DataSaverModeBetaKey, defaultValue = false)
    val (disableLyrics, onDisableLyricsChange) = rememberPreference(DataSaverDisableLyricsKey, defaultValue = false)
    val (disableVideos, onDisableVideosChange) = rememberPreference(DataSaverDisableVideosKey, defaultValue = false)
    val (disablePreloading, onDisablePreloadingChange) = rememberPreference(DataSaverDisablePreloadingKey, defaultValue = false)
    val (disableBackgroundSync, onDisableBackgroundSyncChange) = rememberPreference(DataSaverDisableBackgroundSyncKey, defaultValue = false)
    val (forceOpusAudio, onForceOpusAudioChange) = rememberPreference(DataSaverForceOpusKey, defaultValue = false)

    val (limitMobileData, onLimitMobileDataChange) = rememberPreference(LimitMobileDataUsageKey, defaultValue = false)
    val (onlyPlayHdOnWifi, onOnlyPlayHdOnWifiChange) = rememberPreference(OnlyPlayHdVideoOnWifiKey, defaultValue = false)
    val (onlyPlayOverWifi, onOnlyPlayOverWifiChange) = rememberPreference(OnlyPlayOverWifiKey, defaultValue = false)
    val (streamOverWifiUnmetered, onStreamOverWifiUnmeteredChange) = rememberPreference(StreamOverWifiAndUnmeteredOnlyKey, defaultValue = false)
    val (noPlayPodcastVideo, onNoPlayPodcastVideoChange) = rememberPreference(DoNotPlayPodcastVideosKey, defaultValue = false)
    val (convertPodcastToAudio, onConvertPodcastToAudioChange) = rememberPreference(ConvertVideoPodcastsToAudioOnlyKey, defaultValue = false)

    // 2. Download and Quality settings
    val (downloadOverWifi, onDownloadOverWifiChange) = rememberPreference(DownloadOverWifiOnlyKey, defaultValue = false)
    val (onlyDownloadAudio, onOnlyDownloadAudioChange) = rememberPreference(OnlyDownloadAudioIfPossibleKey, defaultValue = false)
    val (audioQuality, onAudioQualityChange) = rememberPreference(AudioQualityKey, defaultValue = AudioQuality.AUTO.name)
    val (downloadQuality, onDownloadQualityChange) = rememberPreference(DownloadQualityKey, defaultValue = "YTM_AAC")
    val (videoQuality, onVideoQualityChange) = rememberPreference(VideoQualityKey, defaultValue = "STANDARD")

    // 3. Storage and files
    val (showFilesOnDevice, onShowFilesOnDeviceChange) = rememberPreference(booleanPreferencesKey("showFilesOnDevice"), defaultValue = false)
    val (showAllAudioFiles, onShowAllAudioFilesChange) = rememberPreference(booleanPreferencesKey("showAllAudioFiles"), defaultValue = false)

    // 4. Voice & History
    val (voiceInterface, onVoiceInterfaceChange) = rememberPreference(booleanPreferencesKey("voiceInterfaceEnabled"), defaultValue = false)
    val (previousWatched, onPreviousWatchedChange) = rememberPreference(booleanPreferencesKey("previousWatchedEnabled"), defaultValue = true)

    // Background Streaming Data Tracker State
    val streamingMobileBytes by StreamingDataTracker.streamingMobileBytes.collectAsStateWithLifecycle()
    val streamingWifiBytes by StreamingDataTracker.streamingWifiBytes.collectAsStateWithLifecycle()
    val downloadMobileBytes by StreamingDataTracker.downloadMobileBytes.collectAsStateWithLifecycle()
    val downloadWifiBytes by StreamingDataTracker.downloadWifiBytes.collectAsStateWithLifecycle()
    val totalMobileBytes by StreamingDataTracker.totalMobileBytes.collectAsStateWithLifecycle()
    val totalWifiBytes by StreamingDataTracker.totalWifiBytes.collectAsStateWithLifecycle()
    val grandTotalBytes by StreamingDataTracker.grandTotalBytes.collectAsStateWithLifecycle()
    val currentSpeedBps by StreamingDataTracker.currentSpeedBps.collectAsStateWithLifecycle()
    val activeNetworkType by StreamingDataTracker.activeNetworkType.collectAsStateWithLifecycle()
    val lastResetTimestamp by StreamingDataTracker.lastResetTimestamp.collectAsStateWithLifecycle()
    var showResetTrackerDialog by rememberSaveable { mutableStateOf(false) }

    // State for Dialogs
    var showPermissionDialog by rememberSaveable { mutableStateOf(false) }
    var showDeleteConfirmDialog by rememberSaveable { mutableStateOf(false) }
    var audioQualityExpanded by remember { mutableStateOf(false) }
    var downloadQualityExpanded by remember { mutableStateOf(false) }
    var videoQualityExpanded by remember { mutableStateOf(false) }

    // Check storage permission state
    val permissionsToRequest = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(android.Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    var isStoragePermissionGranted by remember {
        mutableStateOf(
            permissionsToRequest.all {
                ContextCompat.checkSelfPermission(context, it) == PERMISSION_GRANTED
            }
        )
    }

    val storagePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions.values.all { it }
        isStoragePermissionGranted = granted
        if (granted) {
            Toast.makeText(context, context.getString(R.string.storage_permission_granted_toast), Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, context.getString(R.string.storage_permission_denied_toast), Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.data_saver_mode)) },
                navigationIcon = {
                    IconButton(
                        onClick = { navController.backToMain() }
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.arrow_back),
                            contentDescription = null
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            Modifier
                .padding(innerPadding)
                .windowInsetsPadding(
                    LocalPlayerAwareWindowInsets.current.only(
                        WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom,
                    ),
                )
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Real-Time Data Usage Tracker
            DataUsageTrackerCard(
                streamingMobileBytes = streamingMobileBytes,
                streamingWifiBytes = streamingWifiBytes,
                downloadMobileBytes = downloadMobileBytes,
                downloadWifiBytes = downloadWifiBytes,
                totalMobileBytes = totalMobileBytes,
                totalWifiBytes = totalWifiBytes,
                grandTotalBytes = grandTotalBytes,
                currentSpeedBps = currentSpeedBps,
                activeNetworkType = activeNetworkType,
                lastResetTimestamp = lastResetTimestamp,
                downloadCacheBytes = downloadCache?.cacheSpace ?: 0L,
                onResetClick = { showResetTrackerDialog = true }
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Section 1: Data Saver Mode (Beta)
            Material3SettingsGroup(
                title = stringResource(R.string.datasaver_group_beta),
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.sliders),
                        title = { Text(stringResource(R.string.datasaver_mode_beta_title)) },
                        description = { Text(stringResource(R.string.datasaver_mode_beta_desc)) },
                        trailingContent = {
                            Switch(
                                checked = dataSaverBeta,
                                onCheckedChange = { active ->
                                    onDataSaverBetaChange(active)
                                    if (active) {
                                        onDisableLyricsChange(true)
                                        onDisableVideosChange(true)
                                        onDisablePreloadingChange(true)
                                        onDisableBackgroundSyncChange(true)
                                        onForceOpusAudioChange(true)
                                    }
                                },
                            )
                        },
                        onClick = {
                            val active = !dataSaverBeta
                            onDataSaverBetaChange(active)
                            if (active) {
                                onDisableLyricsChange(true)
                                onDisableVideosChange(true)
                                onDisablePreloadingChange(true)
                                onDisableBackgroundSyncChange(true)
                                onForceOpusAudioChange(true)
                            }
                        }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.datasaver_disable_lyrics_title)) },
                        description = { Text(stringResource(R.string.datasaver_disable_lyrics_desc)) },
                        trailingContent = {
                            Switch(
                                checked = disableLyrics,
                                onCheckedChange = onDisableLyricsChange,
                            )
                        },
                        onClick = { onDisableLyricsChange(!disableLyrics) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.slow_motion_video),
                        title = { Text(stringResource(R.string.datasaver_disable_videos_title)) },
                        description = { Text(stringResource(R.string.datasaver_disable_videos_desc)) },
                        trailingContent = {
                            Switch(
                                checked = disableVideos,
                                onCheckedChange = onDisableVideosChange,
                            )
                        },
                        onClick = { onDisableVideosChange(!disableVideos) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.cloud),
                        title = { Text(stringResource(R.string.datasaver_disable_preloading_title)) },
                        description = { Text(stringResource(R.string.datasaver_disable_preloading_desc)) },
                        trailingContent = {
                            Switch(
                                checked = disablePreloading,
                                onCheckedChange = onDisablePreloadingChange,
                            )
                        },
                        onClick = { onDisablePreloadingChange(!disablePreloading) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.restore),
                        title = { Text(stringResource(R.string.datasaver_disable_sync_title)) },
                        description = { Text(stringResource(R.string.datasaver_disable_sync_desc)) },
                        trailingContent = {
                            Switch(
                                checked = disableBackgroundSync,
                                onCheckedChange = onDisableBackgroundSyncChange,
                            )
                        },
                        onClick = { onDisableBackgroundSyncChange(!disableBackgroundSync) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.graphic_eq),
                        title = { Text(stringResource(R.string.datasaver_force_opus_title)) },
                        description = { Text(stringResource(R.string.datasaver_force_opus_desc)) },
                        trailingContent = {
                            Switch(
                                checked = forceOpusAudio,
                                onCheckedChange = onForceOpusAudioChange,
                            )
                        },
                        onClick = { onForceOpusAudioChange(!forceOpusAudio) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.sliders),
                        title = { Text(stringResource(R.string.limit_mobile_data)) },
                        trailingContent = {
                            Switch(
                                checked = limitMobileData,
                                onCheckedChange = onLimitMobileDataChange,
                            )
                        },
                        onClick = { onLimitMobileDataChange(!limitMobileData) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.cloud),
                        title = { Text(stringResource(R.string.only_play_over_wifi)) },
                        trailingContent = {
                            Switch(
                                checked = onlyPlayOverWifi,
                                onCheckedChange = onOnlyPlayOverWifiChange,
                            )
                        },
                        onClick = { onOnlyPlayOverWifiChange(!onlyPlayOverWifi) }
                    )
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section 2: Sound Quality & Download Quality
            Material3SettingsGroup(
                title = stringResource(R.string.datasaver_sound_download_quality_group),
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.download),
                        title = { Text(stringResource(R.string.download_over_wifi_only)) },
                        trailingContent = {
                            Switch(
                                checked = downloadOverWifi,
                                onCheckedChange = onDownloadOverWifiChange,
                            )
                        },
                        onClick = { onDownloadOverWifiChange(!downloadOverWifi) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.music_note),
                        title = { Text(stringResource(R.string.only_download_audio_if_possible)) },
                        trailingContent = {
                            Switch(
                                checked = onlyDownloadAudio,
                                onCheckedChange = onOnlyDownloadAudioChange,
                            )
                        },
                        onClick = { onOnlyDownloadAudioChange(!onlyDownloadAudio) }
                    ),
                    // Audio Quality / Sound Quality dropdown
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.graphic_eq),
                        title = { Text(stringResource(R.string.datasaver_sound_quality_item_title)) },
                        description = {
                            Text(
                                when (audioQuality) {
                                    "OPUS" -> stringResource(R.string.quality_opus)
                                    "HIGH" -> stringResource(R.string.quality_high) + " (256kbps)"
                                    "LOW" -> stringResource(R.string.quality_low) + " (128kbps)"
                                    else -> stringResource(R.string.quality_auto)
                                }
                            )
                        },
                        onClick = { audioQualityExpanded = true }
                    ),
                    // Download Quality dropdown
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.download),
                        title = { Text(stringResource(R.string.datasaver_download_quality_item_title)) },
                        description = {
                            Text(
                                when (downloadQuality) {
                                    "YTM_AAC" -> stringResource(R.string.download_quality_ytm_aac)
                                    "OPUS" -> stringResource(R.string.download_quality_opus)
                                    "HIGH" -> stringResource(R.string.download_quality_high)
                                    "LOW" -> stringResource(R.string.download_quality_low)
                                    else -> stringResource(R.string.download_quality_ytm_aac)
                                }
                            )
                        },
                        onClick = { downloadQualityExpanded = true }
                    ),
                    // Clear downloads button
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.delete),
                        title = { Text(stringResource(R.string.clear_downloaded_music_title)) },
                        description = { Text(stringResource(R.string.clear_downloaded_music_desc)) },
                        onClick = { showDeleteConfirmDialog = true }
                    )
                )
            )

            // Audio Quality Dropdown Menu
            Box {
                DropdownMenu(
                    expanded = audioQualityExpanded,
                    onDismissRequest = { audioQualityExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.quality_opus)) },
                        onClick = {
                            onAudioQualityChange("OPUS")
                            audioQualityExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.quality_high) + " (256kbps)") },
                        onClick = {
                            onAudioQualityChange(AudioQuality.HIGH.name)
                            audioQualityExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.audio_quality_standard) + " (160kbps)") },
                        onClick = {
                            onAudioQualityChange(AudioQuality.LOW.name)
                            audioQualityExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.quality_auto)) },
                        onClick = {
                            onAudioQualityChange(AudioQuality.AUTO.name)
                            audioQualityExpanded = false
                        }
                    )
                }
            }

            // Download Quality Dropdown Menu
            Box {
                DropdownMenu(
                    expanded = downloadQualityExpanded,
                    onDismissRequest = { downloadQualityExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.download_quality_ytm_aac)) },
                        onClick = {
                            onDownloadQualityChange("YTM_AAC")
                            downloadQualityExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.download_quality_opus)) },
                        onClick = {
                            onDownloadQualityChange("OPUS")
                            downloadQualityExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.download_quality_high)) },
                        onClick = {
                            onDownloadQualityChange("HIGH")
                            downloadQualityExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.download_quality_low)) },
                        onClick = {
                            onDownloadQualityChange("LOW")
                            downloadQualityExpanded = false
                        }
                    )
                }
            }

            // Video Quality Dropdown Menu
            Box {
                DropdownMenu(
                    expanded = videoQualityExpanded,
                    onDismissRequest = { videoQualityExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("HD") },
                        onClick = {
                            onVideoQualityChange("HD")
                            videoQualityExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.quality_standard)) },
                        onClick = {
                            onVideoQualityChange("STANDARD")
                            videoQualityExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.quality_low)) },
                        onClick = {
                            onVideoQualityChange("LOW")
                            videoQualityExpanded = false
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Section 3: Storage Permissions & Device Files
            Material3SettingsGroup(
                title = stringResource(R.string.storage_permission_device_files_title),
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.security),
                        title = { Text(stringResource(R.string.request_storage_permission_title)) },
                        description = {
                            Text(
                                if (isStoragePermissionGranted) stringResource(R.string.permission_granted_status)
                                else stringResource(R.string.permission_not_granted_status)
                            )
                        },
                        onClick = {
                            if (!isStoragePermissionGranted) {
                                showPermissionDialog = true
                            } else {
                                Toast.makeText(context, context.getString(R.string.storage_permission_granted_toast), Toast.LENGTH_SHORT).show()
                            }
                        }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.list),
                        title = { Text(stringResource(R.string.show_files_on_device)) },
                        trailingContent = {
                            Switch(
                                checked = showFilesOnDevice,
                                onCheckedChange = onShowFilesOnDeviceChange,
                            )
                        },
                        onClick = { onShowFilesOnDeviceChange(!showFilesOnDevice) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.list),
                        title = { Text(stringResource(R.string.show_all_audio_files)) },
                        trailingContent = {
                            Switch(
                                checked = showAllAudioFiles,
                                onCheckedChange = onShowAllAudioFilesChange,
                            )
                        },
                        onClick = { onShowAllAudioFilesChange(!showAllAudioFiles) }
                    )
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section 4: History & Voice
            Material3SettingsGroup(
                title = stringResource(R.string.advanced_features_group_title),
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.mic),
                        title = { Text(stringResource(R.string.voice_interface)) },
                        description = { Text(stringResource(R.string.voice_search_desc)) },
                        trailingContent = {
                            Switch(
                                checked = voiceInterface,
                                onCheckedChange = onVoiceInterfaceChange,
                            )
                        },
                        onClick = { onVoiceInterfaceChange(!voiceInterface) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.history),
                        title = { Text(stringResource(R.string.previous_watched_mode)) },
                        description = { Text(stringResource(R.string.previous_watched_mode_desc)) },
                        trailingContent = {
                            Switch(
                                checked = previousWatched,
                                onCheckedChange = onPreviousWatchedChange,
                            )
                        },
                        onClick = { onPreviousWatchedChange(!previousWatched) }
                    )
                )
            )

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    // Storage permission custom alert dialog
    if (showPermissionDialog) {
        DefaultDialog(
            onDismiss = { showPermissionDialog = false },
            icon = {
                Icon(
                    painter = painterResource(R.drawable.security),
                    contentDescription = null
                )
            },
            title = { Text(stringResource(R.string.request_storage_permission_title)) },
            buttons = {
                TextButton(
                    onClick = { showPermissionDialog = false }
                ) {
                    Text(stringResource(android.R.string.cancel))
                }
                TextButton(
                    onClick = {
                        showPermissionDialog = false
                        storagePermissionLauncher.launch(permissionsToRequest)
                    }
                ) {
                    Text(stringResource(R.string.grant_permission_btn))
                }
            }
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
            ) {
                Text(
                    text = stringResource(R.string.storage_permission_explain_desc),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    // Delete downloads confirmation dialog
    if (showDeleteConfirmDialog) {
        DefaultDialog(
            onDismiss = { showDeleteConfirmDialog = false },
            icon = {
                Icon(
                    painter = painterResource(R.drawable.delete),
                    contentDescription = null
                )
            },
            title = { Text(stringResource(R.string.clear_downloads_confirm_title)) },
            buttons = {
                TextButton(
                    onClick = { showDeleteConfirmDialog = false }
                ) {
                    Text(stringResource(android.R.string.cancel))
                }
                TextButton(
                    onClick = {
                        showDeleteConfirmDialog = false
                        try {
                            downloadCache?.keys?.forEach { key ->
                                downloadCache.removeResource(key)
                            }
                            Toast.makeText(context, context.getString(R.string.clear_downloads_success_toast), Toast.LENGTH_SHORT).show()
                        } catch (e: Exception) {
                            Toast.makeText(context, context.getString(R.string.clear_downloads_error_toast), Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text(stringResource(R.string.clear_btn))
                }
            }
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
            ) {
                Text(
                    text = stringResource(R.string.clear_downloads_explain_desc),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    // Reset Data Usage Tracker Confirmation Dialog
    if (showResetTrackerDialog) {
        DefaultDialog(
            onDismiss = { showResetTrackerDialog = false },
            icon = {
                Icon(
                    painter = painterResource(R.drawable.restore),
                    contentDescription = null
                )
            },
            title = { Text(stringResource(R.string.data_usage_reset_btn)) },
            buttons = {
                TextButton(
                    onClick = { showResetTrackerDialog = false }
                ) {
                    Text(stringResource(android.R.string.cancel))
                }
                TextButton(
                    onClick = {
                        showResetTrackerDialog = false
                        StreamingDataTracker.resetStats()
                        Toast.makeText(context, context.getString(R.string.data_usage_reset_success), Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Text(stringResource(R.string.reset))
                }
            }
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
            ) {
                Text(
                    text = stringResource(R.string.data_usage_reset_confirm),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun DataUsageTrackerCard(
    streamingMobileBytes: Long,
    streamingWifiBytes: Long,
    downloadMobileBytes: Long,
    downloadWifiBytes: Long,
    totalMobileBytes: Long,
    totalWifiBytes: Long,
    grandTotalBytes: Long,
    currentSpeedBps: Long,
    activeNetworkType: StreamingDataTracker.NetworkType,
    lastResetTimestamp: Long,
    downloadCacheBytes: Long,
    onResetClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val formattedGrandTotal = remember(grandTotalBytes) { Formatter.formatFileSize(context, grandTotalBytes) }
    val formattedTotalMobile = remember(totalMobileBytes) { Formatter.formatFileSize(context, totalMobileBytes) }
    val formattedTotalWifi = remember(totalWifiBytes) { Formatter.formatFileSize(context, totalWifiBytes) }

    val formattedStreamingMobile = remember(streamingMobileBytes) { Formatter.formatFileSize(context, streamingMobileBytes) }
    val formattedDownloadMobile = remember(downloadMobileBytes) { Formatter.formatFileSize(context, downloadMobileBytes) }

    val formattedStreamingWifi = remember(streamingWifiBytes) { Formatter.formatFileSize(context, streamingWifiBytes) }
    val formattedDownloadWifi = remember(downloadWifiBytes) { Formatter.formatFileSize(context, downloadWifiBytes) }

    val formattedCache = remember(downloadCacheBytes) { Formatter.formatFileSize(context, downloadCacheBytes) }

    val formattedSpeed = remember(currentSpeedBps) {
        if (currentSpeedBps > 0) "${Formatter.formatFileSize(context, currentSpeedBps)}/s" else "0 B/s"
    }

    val networkStatusText = when (activeNetworkType) {
        StreamingDataTracker.NetworkType.MOBILE -> stringResource(R.string.data_usage_network_mobile)
        StreamingDataTracker.NetworkType.WIFI -> stringResource(R.string.data_usage_network_wifi)
        StreamingDataTracker.NetworkType.DISCONNECTED -> stringResource(R.string.data_usage_network_offline)
        StreamingDataTracker.NetworkType.OTHER -> stringResource(R.string.data_usage_active_network_status)
    }

    val lastResetText = remember(lastResetTimestamp) {
        if (lastResetTimestamp > 0L) {
            val dateStr = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(lastResetTimestamp))
            context.getString(R.string.data_usage_last_reset_format, dateStr)
        } else {
            context.getString(R.string.data_usage_never_reset)
        }
    }

    // Pulse animation for Live Traffic indicator
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.speed),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Text(
                            text = stringResource(R.string.data_usage_tracker_title),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.5.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (activeNetworkType == StreamingDataTracker.NetworkType.DISCONNECTED)
                                            MaterialTheme.colorScheme.error
                                        else
                                            MaterialTheme.colorScheme.primary
                                    )
                            )
                            Text(
                                text = networkStatusText,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Live status chip with transfer speed
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = pulseAlpha))
                        )
                        Text(
                            text = if (currentSpeedBps > 0) "${stringResource(R.string.data_usage_live_badge)} • $formattedSpeed" else stringResource(R.string.data_usage_live_badge),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            ),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Total Big Counter
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.75f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.data_usage_total_consumed),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = lastResetText,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = formattedGrandTotal,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )

                    // Distribution progress bar
                    if (grandTotalBytes > 0L) {
                        Spacer(modifier = Modifier.height(8.dp))
                        val mobileRatio = (totalMobileBytes.toFloat() / grandTotalBytes.toFloat()).coerceIn(0f, 1f)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(50))
                                .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.35f))
                        ) {
                            if (mobileRatio > 0f) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .weight(mobileRatio)
                                        .background(MaterialTheme.colorScheme.primary)
                                )
                            }
                            if (1f - mobileRatio > 0f) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .weight(1f - mobileRatio)
                                        .background(MaterialTheme.colorScheme.tertiary)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Two Cards: Mobile Data vs Wi-Fi Data
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Card 1: Mobile Data (Cellular)
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.ic_cell_tower),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = stringResource(R.string.data_usage_mobile_data_title),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1
                            )
                        }

                        Text(
                            text = formattedTotalMobile,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        // Sub-metrics: Streaming vs Downloads
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = stringResource(R.string.data_usage_streaming_music),
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = formattedStreamingMobile,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 10.5.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = stringResource(R.string.data_usage_offline_downloads),
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = formattedDownloadMobile,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 10.5.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Card 2: Wi-Fi Data
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.ic_wifi_full),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = stringResource(R.string.data_usage_wifi_data_title),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.tertiary,
                                maxLines = 1
                            )
                        }

                        Text(
                            text = formattedTotalWifi,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        // Sub-metrics: Streaming vs Downloads
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = stringResource(R.string.data_usage_streaming_music),
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = formattedStreamingWifi,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 10.5.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = stringResource(R.string.data_usage_offline_downloads),
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = formattedDownloadWifi,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 10.5.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Footer Row: Cache size & Reset Action
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.storage),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "${stringResource(R.string.data_usage_cache_label)}: $formattedCache",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                OutlinedButton(
                    onClick = onResetClick,
                    shape = RoundedCornerShape(50),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.restore),
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = stringResource(R.string.data_usage_reset_btn),
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                    }
                }
            }
        }
    }
}

