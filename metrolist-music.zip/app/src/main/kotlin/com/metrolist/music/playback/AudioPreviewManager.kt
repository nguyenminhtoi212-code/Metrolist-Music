/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.playback

import android.media.AudioAttributes
import android.media.MediaPlayer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import timber.log.Timber

object AudioPreviewManager {
    private var mediaPlayer: MediaPlayer? = null

    private val _currentPlayingTrackId = MutableStateFlow<String?>(null)
    val currentPlayingTrackId: StateFlow<String?> = _currentPlayingTrackId.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    fun playPreview(trackId: String, previewUrl: String?, onComplete: (() -> Unit)? = null) {
        if (previewUrl.isNullOrBlank()) {
            stopPreview()
            return
        }

        // If already playing this track, toggle pause/stop
        if (_currentPlayingTrackId.value == trackId && _isPlaying.value) {
            stopPreview()
            return
        }

        try {
            stopPreview()

            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(previewUrl)
                setOnPreparedListener { mp ->
                    mp.start()
                    _currentPlayingTrackId.value = trackId
                    _isPlaying.value = true
                }
                setOnCompletionListener {
                    stopPreview()
                    onComplete?.invoke()
                }
                setOnErrorListener { _, what, extra ->
                    Timber.e("Preview MediaPlayer error: what=$what, extra=$extra")
                    stopPreview()
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed playing preview url: $previewUrl")
            stopPreview()
        }
    }

    fun stopPreview() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            Timber.w(e, "Error stopping preview MediaPlayer")
        } finally {
            mediaPlayer = null
            _currentPlayingTrackId.value = null
            _isPlaying.value = false
        }
    }
}
