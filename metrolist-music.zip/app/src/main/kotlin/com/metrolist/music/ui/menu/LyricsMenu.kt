/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.menu

import android.app.SearchManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.widget.Toast
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.metrolist.music.LocalDatabase
import com.metrolist.music.R
import com.metrolist.music.db.entities.LyricsEntity
import com.metrolist.music.db.entities.SongEntity
import com.metrolist.music.lyrics.LyricsTranslationHelper
import com.metrolist.music.lyrics.LyricsUtils
import com.metrolist.music.models.MediaMetadata
import com.metrolist.music.ui.component.DefaultDialog
import com.metrolist.music.ui.component.ListDialog
import com.metrolist.music.ui.component.Material3MenuGroup
import com.metrolist.music.ui.component.Material3MenuItemData
import com.metrolist.music.ui.component.NewAction
import com.metrolist.music.ui.component.NewActionGrid
import com.metrolist.music.ui.component.TextFieldDialog
import com.metrolist.music.viewmodels.LyricsMenuViewModel
import com.metrolist.music.constants.OpenRouterApiKey
import com.metrolist.music.constants.DeepInfraBaseUrl
import com.metrolist.music.constants.DeepInfraDefaultModel
import com.metrolist.music.constants.GroqBaseUrl
import com.metrolist.music.constants.GroqDefaultModel
import com.metrolist.music.constants.NvidiaBaseUrl
import com.metrolist.music.constants.NvidiaDefaultModel
import com.metrolist.music.constants.DeeplApiKey
import com.metrolist.music.constants.AiProviderKey
import com.metrolist.music.constants.TranslateLanguageKey
import com.metrolist.music.constants.TranslateModeKey
import com.metrolist.music.constants.RespectAgentPositioningKey
import com.metrolist.music.constants.ShowIntervalIndicatorKey
import com.metrolist.music.constants.OpenRouterBaseUrlKey
import com.metrolist.music.constants.OpenRouterDefaultBaseUrl
import com.metrolist.music.constants.OpenRouterDefaultModel
import com.metrolist.music.constants.OpenRouterModelKey
import com.metrolist.music.constants.OpenRouterModelTierKey
import com.metrolist.music.constants.OpenRouterTierStable
import com.metrolist.music.constants.DeeplFormalityKey
import com.metrolist.music.constants.LanguageCodeToName
import com.metrolist.music.ui.component.EnumDialog
import com.metrolist.music.ui.component.LyricsTranslationDebugDialog
import com.metrolist.music.ui.component.OpenRouterModelDialog
import com.metrolist.music.ui.component.TextFieldDialog
import com.metrolist.music.api.OpenRouterModelManager
import com.metrolist.music.utils.rememberPreference

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LyricsMenu(
    lyricsProvider: () -> LyricsEntity?,
    songProvider: () -> SongEntity?,
    mediaMetadataProvider: () -> MediaMetadata,
    onDismiss: () -> Unit,
    onShowOffsetDialog: () -> Unit = {},
    viewModel: LyricsMenuViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val database = LocalDatabase.current
    
    var openRouterApiKey by rememberPreference(OpenRouterApiKey, "")
    var deeplApiKey by rememberPreference(DeeplApiKey, "")
    var aiProvider by rememberPreference(AiProviderKey, "OpenRouter")
    var translateLanguage by rememberPreference(TranslateLanguageKey, "en")
    var translateMode by rememberPreference(TranslateModeKey, "Literal")
    var openRouterBaseUrl by rememberPreference(OpenRouterBaseUrlKey, OpenRouterDefaultBaseUrl)
    var openRouterModel by rememberPreference(OpenRouterModelKey, OpenRouterDefaultModel)
    var openRouterModelTier by rememberPreference(OpenRouterModelTierKey, OpenRouterTierStable)
    var deeplFormality by rememberPreference(DeeplFormalityKey, "default")
    var respectAgentPositioning by rememberPreference(RespectAgentPositioningKey, true)
    var showIntervalIndicator by rememberPreference(ShowIntervalIndicatorKey, true)

    val hasApiKey = if (aiProvider == "DeepL") deeplApiKey.isNotBlank() else openRouterApiKey.isNotBlank()
    
    // Observe the authoritative translation-active state from the singleton; this persists
    // correctly across menu open/close cycles and avoids the lyricsProvider() race condition.
    val hasTranslations by LyricsTranslationHelper.hasActiveTranslations.collectAsStateWithLifecycle()

    var showLanguageDialog by rememberSaveable { mutableStateOf(false) }
    var showProviderDialog by rememberSaveable { mutableStateOf(false) }
    var showApiKeyDialog by rememberSaveable { mutableStateOf(false) }
    var showTranslateModeDialog by rememberSaveable { mutableStateOf(false) }
    var showModelDialog by rememberSaveable { mutableStateOf(false) }
    var showCustomModelInput by rememberSaveable { mutableStateOf(false) }
    var showDebugDialog by rememberSaveable { mutableStateOf(false) }

    val aiProvidersList = listOf(
        "OpenRouter",
        "DeepInfra",
        "Nvidia",
        "Groq",
        "OpenAI",
        "Perplexity",
        "Claude",
        "Gemini",
        "XAi",
        "Mistral",
        "DeepL",
        "Custom",
    )

    val defaultBaseUrls = mapOf(
        "OpenRouter" to "https://openrouter.ai/api/v1/chat/completions",
        "DeepInfra" to DeepInfraBaseUrl,
        "Nvidia" to NvidiaBaseUrl,
        "Groq" to GroqBaseUrl,
        "OpenAI" to "https://api.openai.com/v1/chat/completions",
        "Perplexity" to "https://api.perplexity.ai/chat/completions",
        "Claude" to "https://api.anthropic.com/v1/messages",
        "Gemini" to "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
        "XAi" to "https://api.x.ai/v1/chat/completions",
        "Mistral" to "https://api.mistral.ai/v1/chat/completions",
        "DeepL" to "https://api.deepl.com/v2/translate",
        "Custom" to "",
    )

    val defaultModels = mapOf(
        "OpenRouter" to "google/gemini-2.5-flash-lite",
        "DeepInfra" to DeepInfraDefaultModel,
        "Nvidia" to NvidiaDefaultModel,
        "Groq" to GroqDefaultModel,
        "OpenAI" to "gpt-4o-mini",
        "Gemini" to "gemini-2.5-flash-lite",
        "Perplexity" to "sonar",
        "Claude" to "claude-haiku-4-5-20251001",
        "XAi" to "grok-4-1-fast",
        "Mistral" to "mistral-small-latest",
    )

    if (showLanguageDialog) {
        EnumDialog(
            onDismiss = { showLanguageDialog = false },
            onSelect = {
                translateLanguage = it
                showLanguageDialog = false
            },
            title = stringResource(R.string.ai_target_language),
            current = translateLanguage,
            values = LanguageCodeToName.keys.sortedBy { LanguageCodeToName[it] },
            valueText = { LanguageCodeToName[it] ?: it },
        )
    }

    if (showProviderDialog) {
        EnumDialog(
            onDismiss = { showProviderDialog = false },
            onSelect = { selectedProvider ->
                aiProvider = selectedProvider
                if (selectedProvider != "Custom" && selectedProvider != "DeepL") {
                    openRouterBaseUrl = defaultBaseUrls[selectedProvider] ?: ""
                } else {
                    openRouterBaseUrl = ""
                }
                openRouterModel = defaultModels[selectedProvider] ?: ""
                showProviderDialog = false
            },
            title = stringResource(R.string.ai_provider),
            current = aiProvider,
            values = aiProvidersList,
            valueText = { it },
        )
    }

    if (showApiKeyDialog) {
        val currentKey = if (aiProvider == "DeepL") deeplApiKey else openRouterApiKey
        TextFieldDialog(
            title = { Text(stringResource(R.string.ai_api_key)) },
            icon = { Icon(painterResource(R.drawable.key), null) },
            initialTextFieldValue = TextFieldValue(text = currentKey),
            onDone = { key ->
                if (aiProvider == "DeepL") {
                    deeplApiKey = key
                } else {
                    openRouterApiKey = key
                }
                showApiKeyDialog = false
            },
            onDismiss = { showApiKeyDialog = false },
        )
    }

    if (showTranslateModeDialog) {
        EnumDialog(
            onDismiss = { showTranslateModeDialog = false },
            onSelect = {
                translateMode = it
                showTranslateModeDialog = false
            },
            title = stringResource(R.string.ai_translation_mode),
            current = translateMode,
            values = listOf("Literal", "Transcribed"),
            valueText = {
                when (it) {
                    "Literal" -> stringResource(R.string.ai_translation_literal)
                    "Transcribed" -> stringResource(R.string.ai_translation_transcribed)
                    else -> it
                }
            },
        )
    }

    if (showModelDialog) {
        if (aiProvider == "OpenRouter") {
            OpenRouterModelDialog(
                currentModel = openRouterModel,
                initialTier = openRouterModelTier,
                onDismiss = { showModelDialog = false },
                onSelectModel = { selected ->
                    openRouterModel = selected
                    showModelDialog = false
                },
                onCustomInput = {
                    showModelDialog = false
                    showCustomModelInput = true
                },
            )
        } else {
            TextFieldDialog(
                title = { Text(stringResource(R.string.ai_model)) },
                icon = { Icon(painterResource(R.drawable.discover_tune), null) },
                initialTextFieldValue = TextFieldValue(text = openRouterModel),
                onDone = {
                    openRouterModel = it
                    showModelDialog = false
                },
                onDismiss = { showModelDialog = false },
            )
        }
    }

    if (showCustomModelInput) {
        TextFieldDialog(
            title = { Text(stringResource(R.string.ai_model)) },
            icon = { Icon(painterResource(R.drawable.discover_tune), null) },
            initialTextFieldValue = TextFieldValue(text = openRouterModel),
            onDone = {
                openRouterModel = it
                showCustomModelInput = false
            },
            onDismiss = { showCustomModelInput = false },
        )
    }

    if (showDebugDialog) {
        LyricsTranslationDebugDialog(
            onDismiss = { showDebugDialog = false },
            currentSongLyrics = lyricsProvider()?.lyrics,
            currentSongTitle = mediaMetadataProvider().title,
            currentSongArtist = mediaMetadataProvider().artists.joinToString(", ") { it.name },
        )
    }

    var showEditDialog by rememberSaveable {
        mutableStateOf(false)
    }

    if (showEditDialog) {
        TextFieldDialog(
            onDismiss = { showEditDialog = false },
            icon = { Icon(painter = painterResource(R.drawable.edit), contentDescription = null) },
            title = { Text(text = mediaMetadataProvider().title) },
            initialTextFieldValue = TextFieldValue(lyricsProvider()?.lyrics.orEmpty()),
            singleLine = false,
            onDone = {
                database.query {
                    upsert(
                        LyricsEntity(
                            id = mediaMetadataProvider().id,
                            lyrics = it,
                            provider = lyricsProvider()?.provider ?: "Manual",
                        ),
                    )
                }
            },
        )
    }

    var showSearchDialog by rememberSaveable {
        mutableStateOf(false)
    }
    var showSearchResultDialog by rememberSaveable {
        mutableStateOf(false)
    }

    val searchMediaMetadata =
        remember(showSearchDialog) {
            mediaMetadataProvider()
        }
    val (titleField, onTitleFieldChange) =
        rememberSaveable(showSearchDialog, stateSaver = TextFieldValue.Saver) {
            mutableStateOf(
                TextFieldValue(
                    text = mediaMetadataProvider().title,
                ),
            )
        }
    val (artistField, onArtistFieldChange) =
        rememberSaveable(showSearchDialog, stateSaver = TextFieldValue.Saver) {
            mutableStateOf(
                TextFieldValue(
                    text = mediaMetadataProvider().artists.joinToString { it.name },
                ),
            )
        }

    val isNetworkAvailable by viewModel.isNetworkAvailable.collectAsStateWithLifecycle()

    if (showSearchDialog) {
        DefaultDialog(
            modifier = Modifier.verticalScroll(rememberScrollState()),
            onDismiss = { showSearchDialog = false },
            icon = {
                Icon(
                    painter = painterResource(R.drawable.search),
                    contentDescription = null
                )
            },
            title = { Text(stringResource(R.string.search_lyrics)) },
            buttons = {
                TextButton(
                    onClick = { showSearchDialog = false },
                ) {
                    Text(stringResource(android.R.string.cancel))
                }

                Spacer(Modifier.width(8.dp))

                TextButton(
                    onClick = {
                        showSearchDialog = false
                        onDismiss()
                        try {
                            context.startActivity(
                                Intent(Intent.ACTION_WEB_SEARCH).apply {
                                    putExtra(
                                        SearchManager.QUERY,
                                        "${artistField.text} ${titleField.text} lyrics"
                                    )
                                },
                            )
                        } catch (_: Exception) {
                        }
                    },
                ) {
                    Text(stringResource(R.string.search_online))
                }

                Spacer(Modifier.width(8.dp))

                TextButton(
                    onClick = {
                        // Try search regardless of network status indicator
                        // as it might be a false negative
                        viewModel.search(
                            searchMediaMetadata.id,
                            titleField.text,
                            artistField.text,
                            searchMediaMetadata.duration,
                            searchMediaMetadata.album?.title
                        )
                        showSearchResultDialog = true
                        
                        // Show warning only if network is definitely unavailable
                        if (!isNetworkAvailable) {
                            Toast.makeText(context, context.getString(R.string.error_no_internet), Toast.LENGTH_SHORT).show()
                        }
                    },
                ) {
                    Text(stringResource(android.R.string.ok))
                }
            },
        ) {
            OutlinedTextField(
                value = titleField,
                onValueChange = onTitleFieldChange,
                singleLine = true,
                label = { Text(stringResource(R.string.song_title)) },
            )

            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = artistField,
                onValueChange = onArtistFieldChange,
                singleLine = true,
                label = { Text(stringResource(R.string.song_artists)) },
            )
        }
    }

    if (showSearchResultDialog) {
        val results by viewModel.results.collectAsStateWithLifecycle()
        val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()

        var expandedItemIndex by rememberSaveable {
            mutableIntStateOf(-1)
        }

        ListDialog(
            onDismiss = { showSearchResultDialog = false },
        ) {
            itemsIndexed(results) { index, result ->
                Row(
                    modifier =
                    Modifier
                        .fillMaxWidth()
                        .clickable {
                            onDismiss()
                            viewModel.cancelSearch()
                            database.query {
                                upsert(
                                    LyricsEntity(
                                        id = searchMediaMetadata.id,
                                        lyrics = result.lyrics,
                                        provider = result.providerName,
                                    ),
                                )
                            }
                        }
                        .padding(12.dp)
                        .animateContentSize(),
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(
                            text = result.lyrics,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = if (index == expandedItemIndex) Int.MAX_VALUE else 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(bottom = 4.dp),
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = result.providerName,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.secondary,
                                maxLines = 1,
                            )
                            if (result.lyrics.startsWith("[")) {
                                Icon(
                                    painter = painterResource(R.drawable.sync),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier =
                                    Modifier
                                        .padding(start = 4.dp)
                                        .size(18.dp),
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = {
                            expandedItemIndex = if (expandedItemIndex == index) -1 else index
                        },
                    ) {
                        Icon(
                            painter = painterResource(if (index == expandedItemIndex) R.drawable.expand_less else R.drawable.expand_more),
                            contentDescription = null,
                        )
                    }
                }
            }

            if (isLoading) {
                item {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        CircularProgressIndicator()
                    }
                }
            }

            if (!isLoading && results.isEmpty()) {
                item {
                    Text(
                        text = stringResource(R.string.lyrics_not_found),
                        textAlign = TextAlign.Center,
                        modifier =
                        Modifier
                            .fillMaxWidth(),
                    )
                }
            }
        }
    }

    var showRomanizationDialog by rememberSaveable {
        mutableStateOf(false)
    }

    var showRomanization by rememberSaveable { mutableStateOf(false) }
    var isChecked by remember { mutableStateOf(songProvider()?.romanizeLyrics ?: true) }

    var lyricsOffset by rememberSaveable { mutableIntStateOf(songProvider()?.lyricsOffset ?: 0) }

    // Sync isChecked with song changes
    LaunchedEffect(songProvider()) {
        isChecked = songProvider()?.romanizeLyrics ?: true
    }

    LaunchedEffect(songProvider()) {
        lyricsOffset = songProvider()?.lyricsOffset ?: 0
    }

    val configuration = LocalConfiguration.current
    val isPortrait = configuration.orientation == Configuration.ORIENTATION_PORTRAIT

    LazyColumn(
        contentPadding = PaddingValues(
            start = 0.dp,
            top = 0.dp,
            end = 0.dp,
            bottom = 8.dp + WindowInsets.systemBars.asPaddingValues().calculateBottomPadding(),
        ),
    ) {
        item {
            NewActionGrid(
                actions =
                    listOf(
                        NewAction(
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.edit),
                                    contentDescription = null,
                                    modifier = Modifier.size(28.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            },
                            text = stringResource(R.string.edit),
                            onClick = {
                                showEditDialog = true
                            },
                        ),
                        NewAction(
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.cached),
                                    contentDescription = null,
                                    modifier = Modifier.size(28.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            },
                            text = stringResource(R.string.refetch),
                            onClick = {
                                onDismiss()
                                viewModel.refetchLyrics(mediaMetadataProvider(), lyricsProvider())
                            },
                        ),
                        NewAction(
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.search),
                                    contentDescription = null,
                                    modifier = Modifier.size(28.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            },
                            text = stringResource(R.string.search),
                            onClick = {
                                showSearchDialog = true
                            },
                        ),
                        NewAction(
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.content_copy),
                                    contentDescription = null,
                                    modifier = Modifier.size(28.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            },
                            text = stringResource(R.string.copy),
                            onClick = {
                                Toast.makeText(context, context.getString(R.string.copy_lyrics_restricted), Toast.LENGTH_SHORT).show()
                            },
                        ),
                    ),
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 16.dp),
                columns = 4,
            )
        }

        item {
            Material3MenuGroup(
                items = buildList {
                    // Add translation toggle option (always visible!)
                    add(
                        Material3MenuItemData(
                            title = { Text(stringResource(R.string.ai_lyrics_translation)) },
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.translate),
                                    contentDescription = null,
                                )
                            },
                            onClick = {
                                if (hasTranslations) {
                                    // Remove translations
                                    lyricsProvider()?.let { lyrics ->
                                        val clearedLyrics = LyricsTranslationHelper.clearTranslations(lyrics)
                                        database.query {
                                            upsert(clearedLyrics)
                                        }
                                        // Resets hasActiveTranslations and clears in-memory translations
                                        LyricsTranslationHelper.triggerClearTranslations()
                                    }
                                } else {
                                    // Trigger translation
                                    LyricsTranslationHelper.triggerManualTranslation()
                                }
                            },
                            trailingContent = {
                                Switch(
                                    checked = hasTranslations,
                                    onCheckedChange = { newCheckedState ->
                                        if (newCheckedState) {
                                            // Enable translations – hasActiveTranslations updates when done
                                            LyricsTranslationHelper.triggerManualTranslation()
                                        } else {
                                            // Disable translations – triggerClearTranslations resets hasActiveTranslations
                                            lyricsProvider()?.let { lyrics ->
                                                val clearedLyrics = LyricsTranslationHelper.clearTranslations(lyrics)
                                                database.query {
                                                    upsert(clearedLyrics)
                                                }
                                                LyricsTranslationHelper.triggerClearTranslations()
                                            }
                                        }
                                    },
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(
                                                id = if (hasTranslations) R.drawable.check else R.drawable.close
                                            ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize)
                                        )
                                    },
                                    colors = SwitchDefaults.colors(
                                        uncheckedThumbColor = MaterialTheme.colorScheme.primaryContainer,
                                        checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                                        checkedTrackColor = MaterialTheme.colorScheme.primary
                                    )
                                )
                            }
                        )
                    )

                    // Always show configuration items for AI Translation so they are easy to adjust on the spot!
                    add(
                        Material3MenuItemData(
                            title = { Text(stringResource(R.string.ai_target_language)) },
                            description = { Text(LanguageCodeToName[translateLanguage] ?: translateLanguage) },
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.language),
                                    contentDescription = null,
                                )
                            },
                            onClick = {
                                showLanguageDialog = true
                            }
                        )
                    )

                    add(
                        Material3MenuItemData(
                            title = { Text(stringResource(R.string.ai_translation_mode)) },
                            description = {
                                Text(
                                    when (translateMode) {
                                        "Literal" -> stringResource(R.string.ai_translation_literal)
                                        "Transcribed" -> stringResource(R.string.ai_translation_transcribed)
                                        else -> translateMode
                                    }
                                )
                            },
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.tune),
                                    contentDescription = null,
                                )
                            },
                            onClick = {
                                showTranslateModeDialog = true
                            }
                        )
                    )

                    if (aiProvider != "DeepL") {
                        add(
                            Material3MenuItemData(
                                title = { Text(stringResource(R.string.ai_model)) },
                                description = { Text(openRouterModel.ifBlank { "google/gemini-2.5-flash-lite" }) },
                                icon = {
                                    Icon(
                                        painter = painterResource(R.drawable.discover_tune),
                                        contentDescription = null,
                                    )
                                },
                                onClick = {
                                    showModelDialog = true
                                }
                            )
                        )
                    }

                    add(
                        Material3MenuItemData(
                            title = { Text(stringResource(R.string.ai_debug_title)) },
                            description = { Text(stringResource(R.string.ai_debug_desc)) },
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.bug_report),
                                    contentDescription = null,
                                )
                            },
                            onClick = {
                                showDebugDialog = true
                            }
                        )
                    )
                    
                    add(
                        Material3MenuItemData(
                            title = { Text(stringResource(R.string.respect_agent_positioning)) },
                            description = { Text(stringResource(R.string.respect_agent_positioning_desc)) },
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.lyrics),
                                    contentDescription = null,
                                )
                            },
                            onClick = {
                                respectAgentPositioning = !respectAgentPositioning
                            },
                            trailingContent = {
                                Switch(
                                    checked = respectAgentPositioning,
                                    onCheckedChange = { newCheckedState ->
                                        respectAgentPositioning = newCheckedState
                                    },
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(
                                                id = if (respectAgentPositioning) R.drawable.check else R.drawable.close
                                            ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize)
                                        )
                                    },
                                    colors = SwitchDefaults.colors(
                                        uncheckedThumbColor = MaterialTheme.colorScheme.primaryContainer,
                                        checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                                        checkedTrackColor = MaterialTheme.colorScheme.primary
                                    )
                                )
                            }
                        )
                    )
                    
                    add(
                        Material3MenuItemData(
                            title = { Text(stringResource(R.string.show_interval_indicator)) },
                            description = { Text(stringResource(R.string.show_interval_indicator_desc)) },
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.lyrics),
                                    contentDescription = null,
                                )
                            },
                            onClick = {
                                showIntervalIndicator = !showIntervalIndicator
                            },
                            trailingContent = {
                                Switch(
                                    checked = showIntervalIndicator,
                                    onCheckedChange = { newCheckedState ->
                                        showIntervalIndicator = newCheckedState
                                    },
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(
                                                id = if (showIntervalIndicator) R.drawable.check else R.drawable.close
                                            ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize)
                                        )
                                    },
                                    colors = SwitchDefaults.colors(
                                        uncheckedThumbColor = MaterialTheme.colorScheme.primaryContainer,
                                        checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                                        checkedTrackColor = MaterialTheme.colorScheme.primary
                                    )
                                )
                            }
                        )
                    )
                    
                    add(
                        Material3MenuItemData(
                            title = { Text(stringResource(R.string.lyrics_offset)) },
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.fast_forward),
                                    contentDescription = null,
                                )
                            },
                            onClick = {
                                onDismiss()
                                onShowOffsetDialog()
                            },
                            trailingContent = {
                                Text(
                                    text = "${if (lyricsOffset >= 0) "+" else ""}${lyricsOffset}ms",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        )
                    )
                    
                    add(
                        Material3MenuItemData(
                            title = { Text(text = stringResource(R.string.romanize_current_track)) },
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.language_korean_latin),
                                    contentDescription = null,
                                )
                            },
                            onClick = {
                                isChecked = !isChecked
                                songProvider()?.let { song ->
                                    database.query {
                                        upsert(song.copy(romanizeLyrics = isChecked))
                                    }
                                }
                            },
                            trailingContent = {
                                Switch(
                                    checked = isChecked,
                                    onCheckedChange = { newCheckedState ->
                                        isChecked = newCheckedState
                                        songProvider()?.let { song ->
                                            database.query {
                                                upsert(song.copy(romanizeLyrics = newCheckedState))
                                            }
                                        }
                                    },
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(
                                                id = if (isChecked) R.drawable.check else R.drawable.close
                                            ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize)
                                        )
                                    },
                                    colors = SwitchDefaults.colors(
                                        uncheckedThumbColor = MaterialTheme.colorScheme.primaryContainer,
                                        checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                                        checkedTrackColor = MaterialTheme.colorScheme.primary
                                    )
                                )
                            }
                        )
                    )
                }
            )
        }
    }
}
