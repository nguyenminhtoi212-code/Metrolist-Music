/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.component

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.metrolist.music.BuildConfig
import com.metrolist.music.R
import com.metrolist.music.utils.AppUpdateStatus
import com.metrolist.music.utils.AppUpdateStatusHelper

val StatusGreen = Color(0xFF34C759)
val StatusAmber = Color(0xFFFF9500)
val StatusBlue = Color(0xFF007AFF)

/**
 * A persistent, sleek dot indicator that reflects whether the app is up to date
 * or if a new version was recently detected by the background worker.
 */
@Composable
fun AppUpdateStatusDot(
    modifier: Modifier = Modifier,
    status: AppUpdateStatus,
    dotSize: Dp = 9.dp,
    showPulseWhenUpdateAvailable: Boolean = true,
) {
    val isUpdate = status.hasDetectedUpdate
    val dotColor = if (isUpdate) StatusAmber else StatusGreen

    if (isUpdate && showPulseWhenUpdateAvailable) {
        val infiniteTransition = rememberInfiniteTransition(label = "updatePulse")
        val pulseScale by infiniteTransition.animateFloat(
            initialValue = 1f,
            targetValue = 1.6f,
            animationSpec = infiniteRepeatable(
                animation = tween(1200, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulseScale"
        )
        val pulseAlpha by infiniteTransition.animateFloat(
            initialValue = 0.6f,
            targetValue = 0.1f,
            animationSpec = infiniteRepeatable(
                animation = tween(1200, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulseAlpha"
        )

        Box(
            modifier = modifier.size(dotSize * 1.6f),
            contentAlignment = Alignment.Center
        ) {
            // Pulsing outer halo
            Box(
                modifier = Modifier
                    .size(dotSize)
                    .scale(pulseScale)
                    .background(dotColor.copy(alpha = pulseAlpha), CircleShape)
            )
            // Solid inner dot
            Box(
                modifier = Modifier
                    .size(dotSize)
                    .background(dotColor, CircleShape)
                    .border(1.5.dp, MaterialTheme.colorScheme.surface, CircleShape)
            )
        }
    } else {
        Box(
            modifier = modifier
                .size(dotSize)
                .background(dotColor, CircleShape)
                .border(1.5.dp, MaterialTheme.colorScheme.surface, CircleShape)
        )
    }
}

/**
 * A compact interactive badge / pill displaying status text and dot.
 */
@Composable
fun AppUpdateStatusChip(
    modifier: Modifier = Modifier,
    status: AppUpdateStatus,
    onClick: () -> Unit,
) {
    val isUpdate = status.hasDetectedUpdate
    val backgroundColor = if (isUpdate) {
        StatusAmber.copy(alpha = 0.15f)
    } else {
        StatusGreen.copy(alpha = 0.12f)
    }
    val contentColor = if (isUpdate) StatusAmber else StatusGreen
    val borderColor = if (isUpdate) StatusAmber.copy(alpha = 0.35f) else StatusGreen.copy(alpha = 0.3f)

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = backgroundColor,
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            AppUpdateStatusDot(
                status = status,
                dotSize = 7.dp,
                showPulseWhenUpdateAvailable = true
            )
            Text(
                text = if (isUpdate) {
                    stringResource(R.string.updater_status_update_detected, status.latestVersion)
                } else {
                    stringResource(R.string.updater_status_up_to_date)
                },
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                color = contentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * A full-width persistent status card for Settings / Updater / Account screens.
 */
@Composable
fun AppUpdateStatusCard(
    modifier: Modifier = Modifier,
    status: AppUpdateStatus,
    onClick: () -> Unit,
) {
    val context = LocalContext.current
    val isUpdate = status.hasDetectedUpdate
    val relativeTime = remember(status.lastCheckedTimeMs) {
        AppUpdateStatusHelper.formatLastCheckedRelative(context, status.lastCheckedTimeMs)
    }
    val sourceLabel = remember(status.source) {
        AppUpdateStatusHelper.getSourceLabel(context, status.source)
    }

    val cardBg = if (isUpdate) {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
    } else {
        MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.6f)
    }
    val cardBorder = if (isUpdate) {
        StatusAmber.copy(alpha = 0.4f)
    } else {
        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = androidx.compose.foundation.BorderStroke(1.dp, cardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(
                        if (isUpdate) StatusAmber.copy(alpha = 0.18f) else StatusGreen.copy(alpha = 0.15f),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(
                        if (isUpdate) R.drawable.update else R.drawable.check
                    ),
                    contentDescription = null,
                    tint = if (isUpdate) StatusAmber else StatusGreen,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AppUpdateStatusDot(status = status, dotSize = 8.dp)
                    Text(
                        text = if (isUpdate) {
                            stringResource(R.string.updater_status_update_detected, status.latestVersion)
                        } else {
                            stringResource(R.string.updater_status_up_to_date)
                        },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Text(
                    text = if (isUpdate) {
                        stringResource(R.string.updater_status_update_detected_by_worker, status.latestVersion) + " • " + relativeTime
                    } else {
                        "v${BuildConfig.VERSION_NAME} • $relativeTime ($sourceLabel)"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Icon(
                painter = painterResource(R.drawable.navigate_next),
                contentDescription = stringResource(R.string.updater_status_view_details),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

/**
 * An informational dialog showing detailed status when clicking the indicator.
 */
@Composable
fun AppUpdateStatusDialog(
    status: AppUpdateStatus,
    onDismiss: () -> Unit,
    onNavigateToUpdater: () -> Unit,
) {
    val context = LocalContext.current
    val isUpdate = status.hasDetectedUpdate
    val relativeTime = remember(status.lastCheckedTimeMs) {
        AppUpdateStatusHelper.formatLastCheckedRelative(context, status.lastCheckedTimeMs)
    }
    val sourceLabel = remember(status.source) {
        AppUpdateStatusHelper.getSourceLabel(context, status.source)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            tonalElevation = 6.dp,
            modifier = Modifier
                .padding(24.dp)
                .fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .background(
                            if (isUpdate) StatusAmber.copy(alpha = 0.18f) else StatusGreen.copy(alpha = 0.15f),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(if (isUpdate) R.drawable.update else R.drawable.check),
                        contentDescription = null,
                        tint = if (isUpdate) StatusAmber else StatusGreen,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = if (isUpdate) {
                        stringResource(R.string.updater_status_update_available)
                    } else {
                        stringResource(R.string.updater_status_up_to_date)
                    },
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (isUpdate) {
                        stringResource(R.string.updater_status_update_detected_by_worker, status.latestVersion)
                    } else {
                        stringResource(R.string.updater_status_running_newest, BuildConfig.VERSION_NAME)
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = stringResource(R.string.updater_current_version),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "v${BuildConfig.VERSION_NAME}",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = stringResource(R.string.updater_latest_detected),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = if (status.latestVersion.startsWith("v")) status.latestVersion else "v${status.latestVersion}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Medium,
                                    color = if (isUpdate) StatusAmber else MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = stringResource(R.string.updater_last_checked),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "$relativeTime ($sourceLabel)",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(stringResource(R.string.close))
                    }
                    Button(
                        onClick = {
                            onDismiss()
                            onNavigateToUpdater()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isUpdate) StatusAmber else MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(stringResource(R.string.updater_status_view_details))
                    }
                }
            }
        }
    }
}
