/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.component

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.metrolist.music.R
import com.metrolist.music.constants.AiProviderKey
import com.metrolist.music.constants.AiSystemPromptKey
import com.metrolist.music.constants.DeeplApiKey
import com.metrolist.music.constants.DeeplFormalityKey
import com.metrolist.music.constants.OpenRouterApiKey
import com.metrolist.music.constants.OpenRouterBaseUrlKey
import com.metrolist.music.constants.OpenRouterModelKey
import com.metrolist.music.constants.OpenRouterModelTierKey
import com.metrolist.music.constants.OpenRouterTierStable
import com.metrolist.music.constants.TranslateLanguageKey
import com.metrolist.music.constants.TranslateModeKey
import com.metrolist.music.lyrics.LyricsTranslationHelper
import com.metrolist.music.lyrics.LyricsTranslationHelper.DebugTranslationResult
import com.metrolist.music.utils.rememberPreference
import com.metrolist.music.viewmodels.ModelViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

private data class LyricsPreset(
    val title: String,
    val artist: String,
    val language: String,
    val lyrics: String,
)

private val SAMPLE_PRESETS = listOf(
    LyricsPreset(
        title = "Idol (アイドル)",
        artist = "YOASOBI",
        language = "Japanese",
        lyrics = """誰もが目を奪われていく
君は完璧で究極のアイドル
金輪際現れない
一番星の生まれ変わり
その笑顔で愛で誰も彼も虜にしていく
その瞳がその言葉が嘘でもそれは完全なアイ""",
    ),
    LyricsPreset(
        title = "Spring Day (봄날)",
        artist = "BTS",
        language = "Korean",
        lyrics = """보고 싶다 이렇게 말하니까 더 보고 싶다
너희 사진을 보고 있어도 보고 싶다
너무 야속한 시간 나는 우리가 밉다
이젠 얼굴 한 번 보는 것조차 힘들어진 우리가
여긴 온통 겨울 뿐이야 8월에도 겨울이 와""",
    ),
    LyricsPreset(
        title = "Chúng Ta Của Hiện Tại",
        artist = "Sơn Tùng M-TP",
        language = "Vietnamese",
        lyrics = """Mùa thu mang giấc mơ quay về
Vẫn nguyên vẹn như hôm nào
Lời hẹn ước dưới ánh hoàng hôn
Từng ngọt ngào trao nhau ấm êm
Giờ chỉ còn là những ký ức phai nhòa""",
    ),
    LyricsPreset(
        title = "Bohemian Rhapsody",
        artist = "Queen",
        language = "English",
        lyrics = """Is this the real life?
Is this just fantasy?
Caught in a landslide, no escape from reality
Open your eyes, look up to the skies and see
I'm just a poor boy, I need no sympathy
Because I'm easy come, easy go, little high, little low""",
    ),
)

private val TARGET_LANGUAGES = listOf(
    "vi" to "Tiếng Việt (vi)",
    "en" to "English (en)",
    "ja" to "日本語 (ja)",
    "ko" to "한국어 (ko)",
    "es" to "Español (es)",
    "fr" to "Français (fr)",
    "zh" to "中文 (zh)",
    "de" to "Deutsch (de)",
    "ru" to "Русский (ru)",
)

private val TRANSLATION_MODES = listOf("Literal", "Transcribed", "Romanized")

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LyricsTranslationDebugDialog(
    onDismiss: () -> Unit,
    currentSongLyrics: String? = null,
    currentSongTitle: String? = null,
    currentSongArtist: String? = null,
    modelViewModel: ModelViewModel? = null,
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var aiProvider by rememberPreference(AiProviderKey, "OpenRouter")
    var openRouterApiKey by rememberPreference(OpenRouterApiKey, "")
    var openRouterBaseUrl by rememberPreference(OpenRouterBaseUrlKey, "https://openrouter.ai/api/v1/chat/completions")
    var openRouterModel by rememberPreference(OpenRouterModelKey, "google/gemini-2.5-flash-lite")
    var openRouterModelTier by rememberPreference(OpenRouterModelTierKey, OpenRouterTierStable)
    var translateLanguage by rememberPreference(TranslateLanguageKey, "en")
    var translateMode by rememberPreference(TranslateModeKey, "Literal")
    var deeplApiKey by rememberPreference(DeeplApiKey, "")
    var deeplFormality by rememberPreference(DeeplFormalityKey, "default")
    var aiSystemPrompt by rememberPreference(AiSystemPromptKey, "")

    // Dialog-local overrides allowing swift experimentation
    var testModel by rememberSaveable { mutableStateOf(openRouterModel) }
    var testTargetLang by rememberSaveable { mutableStateOf(translateLanguage) }
    var testMode by rememberSaveable { mutableStateOf(translateMode) }

    // Selected preset (-1 = Current Song, 0..3 = Samples, 99 = Custom)
    var selectedPresetIndex by rememberSaveable {
        mutableIntStateOf(if (!currentSongLyrics.isNullOrBlank()) -1 else 0)
    }

    val initialLyrics = remember(currentSongLyrics) {
        if (!currentSongLyrics.isNullOrBlank()) {
            currentSongLyrics.lines().filter { it.isNotBlank() }.take(12).joinToString("\n")
        } else {
            SAMPLE_PRESETS[0].lyrics
        }
    }
    var lyricsInput by rememberSaveable { mutableStateOf(initialLyrics) }
    var isInputExpanded by rememberSaveable { mutableStateOf(false) }

    // View mode: 0 = Paired Lines, 1 = Two Columns, 2 = Raw Output
    var selectedViewTab by rememberSaveable { mutableIntStateOf(0) }

    // Execution state
    var isTranslating by remember { mutableStateOf(false) }
    var elapsedSeconds by remember { mutableLongStateOf(0L) }
    var translationResult by remember { mutableStateOf<DebugTranslationResult?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var activeJob by remember { mutableStateOf<Job?>(null) }

    // Live elapsed timer
    LaunchedEffect(isTranslating) {
        if (isTranslating) {
            elapsedSeconds = 0L
            val start = System.currentTimeMillis()
            while (isActive && isTranslating) {
                delay(100)
                elapsedSeconds = (System.currentTimeMillis() - start) / 100
            }
        }
    }

    fun startTranslation() {
        if (lyricsInput.isBlank()) {
            Toast.makeText(context, context.getString(R.string.ai_debug_no_lyrics_warning), Toast.LENGTH_SHORT).show()
            return
        }
        activeJob?.cancel()
        isTranslating = true
        errorMessage = null
        translationResult = null

        activeJob = scope.launch {
            val res = LyricsTranslationHelper.testTranslate(
                text = lyricsInput,
                targetLanguage = testTargetLang,
                apiKey = openRouterApiKey,
                baseUrl = openRouterBaseUrl,
                model = testModel,
                mode = testMode,
                provider = aiProvider,
                deeplApiKey = deeplApiKey,
                deeplFormality = deeplFormality,
                systemPrompt = aiSystemPrompt,
            )

            isTranslating = false
            res.onSuccess { debugResult ->
                translationResult = debugResult
                errorMessage = null
            }.onFailure { error ->
                translationResult = null
                errorMessage = error.localizedMessage ?: error.message ?: "Unknown error occurred during translation"
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .fillMaxWidth(0.96f)
            .fillMaxHeight(0.92f)
            .testTag("lyrics_translation_debug_dialog"),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(38.dp),
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                painter = painterResource(R.drawable.bug_report),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(20.dp),
                            )
                        }
                    }
                    Column {
                        Text(
                            text = stringResource(R.string.ai_debug_title),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = stringResource(R.string.ai_debug_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        painter = painterResource(R.drawable.close),
                        contentDescription = stringResource(R.string.cancel),
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(vertical = 4.dp),
            ) {
                // Section 1: Configuration bar (Provider, Model, Key status)
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        // Header row: Provider & Key Status
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                ) {
                                    Text(
                                        text = aiProvider,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (openRouterApiKey.isNotBlank() || deeplApiKey.isNotBlank()) {
                                        Color(0xFF2E7D32).copy(alpha = 0.15f)
                                    } else {
                                        Color(0xFFE65100).copy(alpha = 0.15f)
                                    },
                                ) {
                                    Text(
                                        text = if (openRouterApiKey.isNotBlank() || deeplApiKey.isNotBlank()) {
                                            stringResource(R.string.ai_debug_key_configured)
                                        } else {
                                            stringResource(R.string.ai_debug_free_mode)
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (openRouterApiKey.isNotBlank() || deeplApiKey.isNotBlank()) {
                                            Color(0xFF2E7D32)
                                        } else {
                                            Color(0xFFE65100)
                                        },
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                    )
                                }
                            }

                            // Model tier badge
                            if (aiProvider == "OpenRouter") {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                ) {
                                    Text(
                                        text = openRouterModelTier,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    )
                                }
                            }
                        }

                        // Model info & quick edit
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                text = "${stringResource(R.string.ai_debug_model_label)}:",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text(
                                text = testModel.ifBlank { "google/gemini-2.5-flash-lite" },
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }

                        // Target Language & Translation Mode Chips
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            // Target Language Selector
                            TARGET_LANGUAGES.forEach { (code, label) ->
                                FilterChip(
                                    selected = testTargetLang == code,
                                    onClick = { testTargetLang = code },
                                    label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                    ),
                                    modifier = Modifier.height(32.dp),
                                )
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "Mode:",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            TRANSLATION_MODES.forEach { mode ->
                                FilterChip(
                                    selected = testMode == mode,
                                    onClick = { testMode = mode },
                                    label = { Text(mode, style = MaterialTheme.typography.labelSmall) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.tertiaryContainer,
                                        selectedLabelColor = MaterialTheme.colorScheme.onTertiaryContainer,
                                    ),
                                    modifier = Modifier.height(30.dp),
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Section 2: Song / Lyrics Source Selector
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    // Current Song Chip (if available)
                    if (!currentSongLyrics.isNullOrBlank()) {
                        FilterChip(
                            selected = selectedPresetIndex == -1,
                            onClick = {
                                selectedPresetIndex = -1
                                lyricsInput = currentSongLyrics.lines()
                                    .filter { it.isNotBlank() }
                                    .take(12)
                                    .joinToString("\n")
                            },
                            leadingIcon = {
                                Icon(
                                    painter = painterResource(R.drawable.play),
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp),
                                )
                            },
                            label = {
                                Text(
                                    text = currentSongTitle?.let { "$it (Current)" }
                                        ?: stringResource(R.string.ai_debug_current_song),
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1,
                                )
                            },
                        )
                    }

                    // Sample Presets
                    SAMPLE_PRESETS.forEachIndexed { index, preset ->
                        FilterChip(
                            selected = selectedPresetIndex == index,
                            onClick = {
                                selectedPresetIndex = index
                                lyricsInput = preset.lyrics
                            },
                            label = {
                                Text(
                                    text = "${preset.title} (${preset.language})",
                                    style = MaterialTheme.typography.labelSmall,
                                )
                            },
                        )
                    }

                    // Custom Input Chip
                    FilterChip(
                        selected = selectedPresetIndex == 99,
                        onClick = {
                            selectedPresetIndex = 99
                            isInputExpanded = true
                        },
                        leadingIcon = {
                            Icon(
                                painter = painterResource(R.drawable.edit),
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                            )
                        },
                        label = {
                            Text(
                                stringResource(R.string.ai_debug_custom_input),
                                style = MaterialTheme.typography.labelSmall,
                            )
                        },
                    )
                }

                // Collapsible Lyrics Input Area (so user can edit or inspect input)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    val lineCount = remember(lyricsInput) {
                        lyricsInput.lines().count { it.isNotBlank() }
                    }
                    Text(
                        text = "${stringResource(R.string.ai_debug_original_lyrics)} ($lineCount lines)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    TextButton(
                        onClick = { isInputExpanded = !isInputExpanded },
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    ) {
                        Text(
                            text = if (isInputExpanded) "Collapse Input ▲" else "Edit / Expand Input ▼",
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                }

                AnimatedVisibility(
                    visible = isInputExpanded,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut(),
                ) {
                    OutlinedTextField(
                        value = lyricsInput,
                        onValueChange = {
                            lyricsInput = it
                            selectedPresetIndex = 99
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 100.dp, max = 160.dp),
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                        ),
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Section 3: Run / Cancel Translation Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Button(
                        onClick = { startTranslation() },
                        enabled = !isTranslating && lyricsInput.isNotBlank(),
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("btn_run_debug_translation"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                        ),
                    ) {
                        if (isTranslating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp,
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            val secFormatted = (elapsedSeconds / 10.0)
                            Text(
                                text = "${stringResource(R.string.ai_debug_action_testing)} (${secFormatted}s)",
                                style = MaterialTheme.typography.labelLarge,
                            )
                        } else {
                            Icon(
                                painter = painterResource(R.drawable.translate),
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.ai_debug_action_test),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }

                    if (isTranslating) {
                        OutlinedButton(
                            onClick = {
                                activeJob?.cancel()
                                isTranslating = false
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.height(46.dp),
                        ) {
                            Text(stringResource(R.string.ai_debug_cancel))
                        }
                    }
                }

                // Error Card (if failed)
                errorMessage?.let { err ->
                    Spacer(modifier = Modifier.height(10.dp))
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer,
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.info),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Translation Error",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                )
                                Text(
                                    text = err,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                )
                            }
                            TextButton(onClick = { startTranslation() }) {
                                Text(
                                    text = stringResource(R.string.ai_debug_retry),
                                    color = MaterialTheme.colorScheme.error,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                        }
                    }
                }

                // Section 4: Translation Output & Side-by-Side Comparison
                translationResult?.let { result ->
                    Spacer(modifier = Modifier.height(10.dp))

                    // Metrics & Diagnostics Header
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f),
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            // Latency Badge
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Text(
                                    text = "⚡",
                                    fontSize = 13.sp,
                                )
                                Text(
                                    text = stringResource(R.string.ai_debug_latency, result.latencyMs),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                )
                            }

                            // Alignment status
                            val isAligned = result.originalLines.size == result.translatedLines.size
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (isAligned) Color(0xFF2E7D32).copy(alpha = 0.15f) else Color(0xFFC62828).copy(alpha = 0.15f),
                            ) {
                                Text(
                                    text = if (isAligned) {
                                        stringResource(R.string.ai_debug_lines_matched, result.originalLines.size, result.translatedLines.size)
                                    } else {
                                        stringResource(R.string.ai_debug_lines_mismatch, result.originalLines.size, result.translatedLines.size)
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isAligned) Color(0xFF2E7D32) else Color(0xFFC62828),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                )
                            }

                            // Copy actions
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(
                                    onClick = {
                                        clipboardManager.setText(
                                            AnnotatedString(result.translatedLines.joinToString("\n"))
                                        )
                                        Toast.makeText(context, context.getString(R.string.ai_debug_copy_success), Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .testTag("btn_copy_debug_translation"),
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.content_copy),
                                        contentDescription = stringResource(R.string.ai_debug_copy_translation),
                                        modifier = Modifier.size(16.dp),
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        val bilingual = buildString {
                                            val maxLines = maxOf(result.originalLines.size, result.translatedLines.size)
                                            for (i in 0 until maxLines) {
                                                val orig = result.originalLines.getOrNull(i) ?: ""
                                                val trans = result.translatedLines.getOrNull(i) ?: ""
                                                appendLine("${i + 1}. $orig")
                                                appendLine("   → $trans")
                                            }
                                        }
                                        clipboardManager.setText(AnnotatedString(bilingual))
                                        Toast.makeText(context, context.getString(R.string.ai_debug_copy_success), Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(32.dp),
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.ic_compare_arrows),
                                        contentDescription = stringResource(R.string.ai_debug_copy_bilingual),
                                        modifier = Modifier.size(18.dp),
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // View Switcher Tabs: Paired Lines | Two Columns | Raw Output
                    PrimaryTabRow(
                        selectedTabIndex = selectedViewTab,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Tab(
                            selected = selectedViewTab == 0,
                            onClick = { selectedViewTab = 0 },
                            text = { Text(stringResource(R.string.ai_debug_paired_rows), style = MaterialTheme.typography.labelMedium) },
                            modifier = Modifier.testTag("tab_debug_paired_rows"),
                        )
                        Tab(
                            selected = selectedViewTab == 1,
                            onClick = { selectedViewTab = 1 },
                            text = { Text(stringResource(R.string.ai_debug_dual_column), style = MaterialTheme.typography.labelMedium) },
                            modifier = Modifier.testTag("tab_debug_dual_column"),
                        )
                        Tab(
                            selected = selectedViewTab == 2,
                            onClick = { selectedViewTab = 2 },
                            text = { Text(stringResource(R.string.ai_debug_view_json), style = MaterialTheme.typography.labelMedium) },
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Display Content according to selected tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                    ) {
                        when (selectedViewTab) {
                            0 -> {
                                // Paired Lines View (Synchronized Line-by-Line cards)
                                val maxLines = maxOf(result.originalLines.size, result.translatedLines.size)
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    items(maxLines) { index ->
                                        val originalLine = result.originalLines.getOrNull(index) ?: ""
                                        val translatedLine = result.translatedLines.getOrNull(index)

                                        Card(
                                            shape = RoundedCornerShape(10.dp),
                                            colors = CardDefaults.cardColors(
                                                containerColor = MaterialTheme.colorScheme.surface,
                                            ),
                                            border = androidx.compose.foundation.BorderStroke(
                                                1.dp,
                                                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
                                            ),
                                            modifier = Modifier.fillMaxWidth(),
                                        ) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(10.dp),
                                                verticalArrangement = Arrangement.spacedBy(6.dp),
                                            ) {
                                                // Line header badge
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                ) {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = MaterialTheme.colorScheme.primaryContainer,
                                                    ) {
                                                        Text(
                                                            text = String.format(java.util.Locale.ROOT, "#%02d", index + 1),
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                        )
                                                    }
                                                    Text(
                                                        text = stringResource(R.string.ai_debug_original_lyrics),
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    )
                                                }

                                                // Original text
                                                Text(
                                                    text = originalLine,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.Normal,
                                                    color = MaterialTheme.colorScheme.onSurface,
                                                    modifier = Modifier.padding(start = 4.dp),
                                                )

                                                HorizontalDivider(
                                                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                                                    thickness = 0.5.dp,
                                                )

                                                // Translated text
                                                Row(
                                                    verticalAlignment = Alignment.Top,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                ) {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = MaterialTheme.colorScheme.tertiaryContainer,
                                                    ) {
                                                        Text(
                                                            text = "AI",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                        )
                                                    }
                                                    if (translatedLine != null) {
                                                        Text(
                                                            text = translatedLine,
                                                            style = MaterialTheme.typography.bodyMedium,
                                                            fontWeight = FontWeight.SemiBold,
                                                            color = MaterialTheme.colorScheme.primary,
                                                        )
                                                    } else {
                                                        Text(
                                                            text = "(No translation line returned)",
                                                            style = MaterialTheme.typography.bodySmall,
                                                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                                            color = MaterialTheme.colorScheme.error,
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            1 -> {
                                // Two Columns View (Side-by-side)
                                val maxLines = maxOf(result.originalLines.size, result.translatedLines.size)
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    // Column headers
                                    item {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(
                                                    MaterialTheme.colorScheme.surfaceVariant,
                                                    RoundedCornerShape(8.dp),
                                                )
                                                .padding(horizontal = 8.dp, vertical = 6.dp),
                                        ) {
                                            Text(
                                                text = stringResource(R.string.ai_debug_original_lyrics),
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.weight(1f),
                                            )
                                            Text(
                                                text = stringResource(R.string.ai_debug_translated_lyrics),
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.weight(1f),
                                            )
                                        }
                                    }

                                    items(maxLines) { index ->
                                        val originalLine = result.originalLines.getOrNull(index) ?: ""
                                        val translatedLine = result.translatedLines.getOrNull(index) ?: ""

                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(
                                                    if (index % 2 == 0) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                                                    else Color.Transparent,
                                                    RoundedCornerShape(6.dp),
                                                )
                                                .padding(horizontal = 8.dp, vertical = 4.dp),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        ) {
                                            Text(
                                                text = "${index + 1}. $originalLine",
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.weight(1f),
                                            )
                                            Text(
                                                text = "${index + 1}. $translatedLine",
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.Medium,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.weight(1f),
                                            )
                                        }
                                    }
                                }
                            }

                            2 -> {
                                // Raw Output Tab
                                val rawJson = remember(result) {
                                    buildString {
                                        appendLine("=== DEBUG TRANSLATION REPORT ===")
                                        appendLine("Provider: ${result.provider}")
                                        appendLine("Model: ${result.model}")
                                        appendLine("Latency: ${result.latencyMs} ms")
                                        appendLine("Input Lines: ${result.originalLines.size}")
                                        appendLine("Output Lines: ${result.translatedLines.size}")
                                        appendLine("Target Language: $testTargetLang")
                                        appendLine("Translation Mode: $testMode")
                                        appendLine("Free Fallback: ${result.isGoogleFreeFallback}")
                                        appendLine("\n--- TRANSLATED ARRAY ---")
                                        result.translatedLines.forEachIndexed { idx, line ->
                                            appendLine("[$idx] \"$line\"")
                                        }
                                    }
                                }

                                Card(
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                    ),
                                    modifier = Modifier.fillMaxSize(),
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(12.dp)
                                            .verticalScroll(rememberScrollState()),
                                    ) {
                                        Text(
                                            text = rawJson,
                                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                if (translationResult == null && !isTranslating && errorMessage == null) {
                    // Empty guide state
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(16.dp),
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                                modifier = Modifier.size(52.dp),
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        painter = painterResource(R.drawable.translate),
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(28.dp),
                                    )
                                }
                            }
                            Text(
                                text = "Ready to Test Translation",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                text = "Tap \"Run Translation Test\" above to send these lyrics to your selected AI model (${testModel}) and compare the translated results side-by-side with line preservation tracking.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.widthIn(max = 380.dp),
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.close))
            }
        },
    )
}
