/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil3.SingletonImageLoader
import coil3.annotation.DelicateCoilApi
import coil3.annotation.ExperimentalCoilApi
import coil3.imageLoader
import com.metrolist.music.LocalDatabase
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.LocalPlayerConnection
import com.metrolist.music.R
import com.metrolist.music.constants.AutoClearCacheEnabledKey
import com.metrolist.music.constants.AutoClearCacheThresholdKey
import com.metrolist.music.constants.AutoClearImageCacheKey
import com.metrolist.music.constants.AutoClearNetworkCacheKey
import com.metrolist.music.constants.EnableSongCacheKey
import com.metrolist.music.constants.MaxImageCacheSizeKey
import com.metrolist.music.constants.MaxSongCacheSizeKey
import com.metrolist.music.utils.CacheAutoManager
import com.metrolist.music.extensions.tryOrNull
import com.metrolist.music.ui.component.ActionPromptDialog
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import android.text.format.Formatter
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.rememberPreference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okio.ByteString.Companion.encodeUtf8
import java.io.File
import kotlin.math.roundToInt

@OptIn(ExperimentalCoilApi::class, ExperimentalMaterial3Api::class, DelicateCoilApi::class)
@Composable
fun StorageSettings(
    navController: NavController
) {
    val context = LocalContext.current
    val database = LocalDatabase.current
    val imageDiskCache = context.imageLoader.diskCache ?: return
    val playerCache = LocalPlayerConnection.current?.service?.playerCache ?: return
    val downloadCache = LocalPlayerConnection.current?.service?.downloadCache ?: return

    val coroutineScope = rememberCoroutineScope()

    val permissionsToRequest = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                android.Manifest.permission.READ_MEDIA_AUDIO,
                android.Manifest.permission.POST_NOTIFICATIONS
            )
        } else {
            arrayOf(
                android.Manifest.permission.READ_EXTERNAL_STORAGE,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
        }
    }

    var isStoragePermissionGranted by remember {
        mutableStateOf(
            permissionsToRequest.all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }
        )
    }

    val storagePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        isStoragePermissionGranted = permissions.values.all { it }
        if (isStoragePermissionGranted) {
            Toast.makeText(context, "Cấp quyền bộ nhớ thành công!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Quyền bộ nhớ bị từ chối!", Toast.LENGTH_SHORT).show()
        }
    }
    val songCacheString = stringResource(R.string.song_cache).lowercase()
    val imageCacheString = stringResource(R.string.image_cache).lowercase()
    val (maxImageCacheSize, onMaxImageCacheSizeChange) = rememberPreference(
        key = MaxImageCacheSizeKey,
        defaultValue = 512
    )
    val (maxSongCacheSize, onMaxSongCacheSizeChange) = rememberPreference(
        key = MaxSongCacheSizeKey,
        defaultValue = 1024
    )
    val (enableSongCache, onEnableSongCacheChange) = rememberPreference(
        key = EnableSongCacheKey,
        defaultValue = true
    )
    val (autoClearCacheEnabled, onAutoClearCacheEnabledChange) = rememberPreference(
        key = AutoClearCacheEnabledKey,
        defaultValue = true
    )
    val (autoClearCacheThresholdMB, onAutoClearCacheThresholdChange) = rememberPreference(
        key = AutoClearCacheThresholdKey,
        defaultValue = 512
    )
    val (autoClearImageCache, onAutoClearImageCacheChange) = rememberPreference(
        key = AutoClearImageCacheKey,
        defaultValue = true
    )
    val (autoClearNetworkCache, onAutoClearNetworkCacheChange) = rememberPreference(
        key = AutoClearNetworkCacheKey,
        defaultValue = true
    )

    var clearDownloads by remember { mutableStateOf(false) }
    var clearCacheDialog by remember { mutableStateOf(false) }
    var clearImageCacheDialog by remember { mutableStateOf(false) }
    var clearAllCacheDialog by remember { mutableStateOf(false) }

    // State for the confirmation dialog
    var showCacheWarningDialog by remember { mutableStateOf(false) }
    var cacheType by remember { mutableStateOf("") }
    var cacheUsage by remember { androidx.compose.runtime.mutableLongStateOf(0L) }
    var onConfirmAction by remember { mutableStateOf<() -> Unit>({}) }

    var imageCacheSize by remember {
        androidx.compose.runtime.mutableLongStateOf(imageDiskCache.size)
    }
    var playerCacheSize by remember {
        androidx.compose.runtime.mutableLongStateOf(tryOrNull { playerCache.cacheSpace } ?: 0)
    }
    var downloadCacheSize by remember {
        mutableLongStateOf(tryOrNull { downloadCache.cacheSpace } ?: 0)
    }
    var networkCacheSize by remember {
        mutableLongStateOf(CacheAutoManager.getNetworkCacheSize(context))
    }
    val totalImageAndNetworkCacheSize = imageCacheSize + networkCacheSize
    val autoClearProgress by animateFloatAsState(
        targetValue =
            (totalImageAndNetworkCacheSize.toFloat() / (autoClearCacheThresholdMB * 1024 * 1024L)).coerceIn(
                0f,
                1f,
            ),
        label = "autoClearProgress",
    )
    val imageCacheProgress by animateFloatAsState(
        targetValue =
            (imageCacheSize.toFloat() / (maxImageCacheSize * 1024 * 1024L)).coerceIn(
                0f,
                1f,
            ),
        label = "imageCacheProgress",
    )
    val playerCacheProgress by animateFloatAsState(
        targetValue =
            (playerCacheSize.toFloat() / (maxSongCacheSize * 1024 * 1024L)).coerceIn(
                0f,
                1f,
            ),
        label = "playerCacheProgress",
    )

    LaunchedEffect(maxImageCacheSize) {
        SingletonImageLoader.reset()
        if (maxImageCacheSize == 0) {
            coroutineScope.launch(Dispatchers.IO) {
                imageDiskCache.clear()
            }
        }
    }
    LaunchedEffect(maxSongCacheSize) {
        if (maxSongCacheSize == 0) {
            coroutineScope.launch(Dispatchers.IO) {
                playerCache.keys.forEach { key ->
                    playerCache.removeResource(key)
                }
            }
        }
    }

    LaunchedEffect(imageDiskCache) {
        while (isActive) {
            delay(500)
            imageCacheSize = CacheAutoManager.getImageCacheSize(context)
            networkCacheSize = CacheAutoManager.getNetworkCacheSize(context)
        }
    }
    LaunchedEffect(playerCache) {
        while (isActive) {
            delay(500)
            playerCacheSize = tryOrNull { playerCache.cacheSpace } ?: 0
        }
    }
    LaunchedEffect(downloadCache) {
        while (isActive) {
            delay(500)
            downloadCacheSize = tryOrNull { downloadCache.cacheSpace } ?: 0
        }
    }

    if (clearDownloads) {
        ActionPromptDialog(
            title = stringResource(R.string.clear_all_downloads),
            onDismiss = { clearDownloads = false },
            onConfirm = {
                coroutineScope.launch(Dispatchers.IO) {
                    downloadCache.keys.forEach { key ->
                        downloadCache.removeResource(key)
                    }
                }
                clearDownloads = false
            },
            onCancel = { clearDownloads = false },
            content = {
                Text(text = stringResource(R.string.clear_downloads_dialog))
            },
        )
    }
    if (clearCacheDialog) {
        ActionPromptDialog(
            title = stringResource(R.string.clear_song_cache),
            onDismiss = { clearCacheDialog = false },
            onConfirm = {
                coroutineScope.launch(Dispatchers.IO) {
                    playerCache.keys.forEach { key ->
                        playerCache.removeResource(key)
                    }
                }
                clearCacheDialog = false
            },
            onCancel = { clearCacheDialog = false },
            content = {
                Text(text = stringResource(R.string.clear_song_cache_dialog))
            },
        )
    }
    if (clearImageCacheDialog) {
        ActionPromptDialog(
            title = stringResource(R.string.clear_image_cache),
            onDismiss = { clearImageCacheDialog = false },
            onConfirm = {
                coroutineScope.launch(Dispatchers.IO) {
                    val urlsToPreserve = mutableSetOf<String>()
                    val downloadedSongs =
                        try {
                            database.downloadedSongsByNameAsc().first()
                        } catch (e: Exception) {
                            emptyList()
                        }
                    downloadedSongs.forEach { song ->
                        song.song.thumbnailUrl?.let { urlsToPreserve.add(it.encodeUtf8().sha256().hex()) }
                        song.album?.thumbnailUrl?.let { urlsToPreserve.add(it.encodeUtf8().sha256().hex()) }
                    }
                    val directory = imageDiskCache.directory.toFile()
                    if (directory.exists() && directory.isDirectory) {
                        directory.listFiles()?.forEach { file ->
                            if (file.isFile && !file.name.startsWith("journal")) {
                                val isPreserved = urlsToPreserve.any { hash -> file.name.startsWith(hash) }
                                if (!isPreserved) {
                                    file.delete()
                                }
                            }
                        }
                    }
                    imageDiskCache.clear()
                }
                clearImageCacheDialog = false
            },
            onCancel = { clearImageCacheDialog = false },
            content = {
                Text(text = stringResource(R.string.clear_image_cache_dialog))
            },
        )
    }
    if (clearAllCacheDialog) {
        ActionPromptDialog(
            title = "Dọn dẹp bộ nhớ tạm (Clear Cache)",
            onDismiss = { clearAllCacheDialog = false },
            onConfirm = {
                coroutineScope.launch(Dispatchers.IO) {
                    tryOrNull { imageDiskCache.clear() }
                    tryOrNull {
                        playerCache.keys.forEach { key ->
                            playerCache.removeResource(key)
                        }
                    }
                    tryOrNull {
                        context.cacheDir?.listFiles()?.forEach { file ->
                            file.deleteRecursively()
                        }
                    }
                    tryOrNull {
                        context.externalCacheDir?.listFiles()?.forEach { file ->
                            file.deleteRecursively()
                        }
                    }
                    kotlinx.coroutines.withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Đã dọn dẹp toàn bộ bộ nhớ đệm và tệp tạm!", Toast.LENGTH_SHORT).show()
                    }
                }
                clearAllCacheDialog = false
            },
            onCancel = { clearAllCacheDialog = false },
            content = {
                Text(text = "Bạn có chắc chắn muốn xóa bộ nhớ đệm hình ảnh Coil, các tệp truyền thông tạm thời và dữ liệu đệm bài hát không?")
            },
        )
    }

    // Confirmation Dialog
    if (showCacheWarningDialog) {
        AlertDialog(
            onDismissRequest = { showCacheWarningDialog = false },
            title = { Text(stringResource(R.string.cache_size_warning_title)) },
            text = {
                Text(
                    stringResource(
                        R.string.cache_size_warning_message,
                        Formatter.formatShortFileSize(context, cacheUsage),
                        cacheType,
                    ),
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onConfirmAction()
                        showCacheWarningDialog = false
                    },
                ) {
                    Text(
                        stringResource(R.string.cache_size_warning_confirm),
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showCacheWarningDialog = false }) {
                    Text(stringResource(id = android.R.string.cancel))
                }
            },
        )
    }

    Column(
        Modifier
            .windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom,
                ),
            ).verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top,
                ),
            ),
        )
        Material3SettingsGroup(
            title = "Tự động dọn dẹp bộ nhớ đệm (Auto-Clear Cache)",
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.cached),
                    title = { Text("Tự động dọn dẹp bộ nhớ đệm (Auto-clear cache)") },
                    description = { Text("Tự động xóa cache hình ảnh và mạng khi vượt quá giới hạn thiết lập để duy trì tính ổn định của ứng dụng") },
                    trailingContent = {
                        Switch(
                            checked = autoClearCacheEnabled,
                            onCheckedChange = onAutoClearCacheEnabledChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (autoClearCacheEnabled) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAutoClearCacheEnabledChange(!autoClearCacheEnabled) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.manage_search),
                    title = { Text("Ngưỡng giới hạn dọn dẹp (Threshold limit)") },
                    enabled = autoClearCacheEnabled,
                    description = {
                        val thresholdValues = remember { listOf(128, 256, 512, 1024, 2048, 4096) }
                        Column {
                            Text(
                                text = Formatter.formatShortFileSize(context, autoClearCacheThresholdMB * 1024 * 1024L),
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Slider(
                                value = thresholdValues.indexOf(autoClearCacheThresholdMB).coerceAtLeast(0).toFloat(),
                                enabled = autoClearCacheEnabled,
                                onValueChange = {
                                    val newValue = thresholdValues[it.roundToInt()]
                                    onAutoClearCacheThresholdChange(newValue)
                                },
                                steps = thresholdValues.size - 2,
                                valueRange = 0f..(thresholdValues.size - 1).toFloat(),
                            )
                            LinearProgressIndicator(
                                progress = { autoClearProgress },
                                modifier = Modifier.fillMaxWidth(),
                                strokeCap = StrokeCap.Round,
                            )
                            Spacer(modifier = Modifier.padding(2.dp))
                            Text(
                                text = "${Formatter.formatShortFileSize(context, totalImageAndNetworkCacheSize)} / ${
                                    Formatter.formatShortFileSize(context, autoClearCacheThresholdMB * 1024 * 1024L)
                                }",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.hide_image),
                    title = { Text("Tự động xóa cache hình ảnh (Image Cache)") },
                    description = { Text("Bao gồm bộ nhớ đệm ảnh Coil và ảnh thu nhỏ") },
                    enabled = autoClearCacheEnabled,
                    trailingContent = {
                        Switch(
                            checked = autoClearImageCache,
                            enabled = autoClearCacheEnabled,
                            onCheckedChange = onAutoClearImageCacheChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (autoClearImageCache) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { if (autoClearCacheEnabled) onAutoClearImageCacheChange(!autoClearImageCache) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.cloud),
                    title = { Text("Tự động xóa cache mạng (Network Cache)") },
                    description = { Text("Bao gồm cache phản hồi HTTP API, WebView và tệp truyền thông tạm thời") },
                    enabled = autoClearCacheEnabled,
                    trailingContent = {
                        Switch(
                            checked = autoClearNetworkCache,
                            enabled = autoClearCacheEnabled,
                            onCheckedChange = onAutoClearNetworkCacheChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (autoClearNetworkCache) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { if (autoClearCacheEnabled) onAutoClearNetworkCacheChange(!autoClearNetworkCache) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.refresh),
                    title = { Text("Dọn dẹp ngay bây giờ (Clear Cache Now)") },
                    description = { Text("Kiểm tra và xóa toàn bộ cache hình ảnh & mạng vượt ngưỡng lập tức") },
                    onClick = {
                        coroutineScope.launch(Dispatchers.IO) {
                            val cleared = CacheAutoManager.checkAndAutoClearCache(context, force = true)
                            val formattedCleared = Formatter.formatShortFileSize(context, cleared)
                            kotlinx.coroutines.withContext(Dispatchers.Main) {
                                Toast.makeText(
                                    context,
                                    "Đã dọn dẹp $formattedCleared bộ nhớ đệm!",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
                )
            )
        )
        Material3SettingsGroup(
            title = "Dọn dẹp bộ nhớ đệm (Clear Cache)",
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.clear_all),
                    title = { Text("Xóa bộ nhớ đệm & tệp tạm (Clear Cache)") },
                    description = { Text("Xóa toàn bộ bộ nhớ đệm hình ảnh Coil, cache bài hát và tệp truyền thông tạm thời") },
                    onClick = { clearAllCacheDialog = true }
                )
            )
        )
        Material3SettingsGroup(
            title = stringResource(R.string.storage),
            items =
                listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.storage),
                        title = { Text(stringResource(R.string.downloaded_songs)) },
                        description = {
                            Text(text = Formatter.formatShortFileSize(context, downloadCacheSize))
                        },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.clear_all),
                        title = { Text(stringResource(R.string.clear_all_downloads)) },
                        onClick = {
                            clearDownloads = true
                        },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.security),
                        title = { Text(stringResource(R.string.grant_storage_permission)) },
                        description = {
                            Text(
                                text = if (isStoragePermissionGranted) {
                                    stringResource(R.string.storage_permission_granted)
                                } else {
                                    stringResource(R.string.storage_permission_not_granted)
                                }
                            )
                        },
                        onClick = {
                            if (!isStoragePermissionGranted) {
                                storagePermissionLauncher.launch(permissionsToRequest)
                            } else {
                                Toast.makeText(context, "Quyền bộ nhớ đã được cấp!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                ),
        )

        Material3SettingsGroup(
            title = stringResource(R.string.song_cache),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.cached),
                    title = { Text(stringResource(R.string.enable_song_cache)) },
                    description = { Text(stringResource(R.string.enable_song_cache_desc)) },
                    trailingContent = {
                        Switch(
                            checked = enableSongCache,
                            onCheckedChange = onEnableSongCacheChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (enableSongCache) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onEnableSongCacheChange(!enableSongCache) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.cached),
                    title = { Text(stringResource(R.string.max_song_cache_size)) },
                    enabled = enableSongCache,
                    description = {
                        val songCacheValues =
                            remember { listOf(0, 128, 256, 512, 1024, 2048, 4096, 8192, -1) }
                        Column {
                            Text(
                                text = when (maxSongCacheSize) {
                                    0 -> stringResource(R.string.disable)
                                    -1 -> stringResource(R.string.unlimited)
                                    else -> Formatter.formatShortFileSize(context, maxSongCacheSize * 1024 * 1024L)
                                }
                            )
                            Slider(
                                value = songCacheValues.indexOf(maxSongCacheSize).toFloat(),
                                enabled = enableSongCache,
                                onValueChange = {
                                    val newValue = songCacheValues[it.roundToInt()]
                                    val newLimitInBytes = if (newValue == -1) {
                                        Long.MAX_VALUE
                                    } else {
                                        newValue * 1024 * 1024L
                                    }

                                        if (newLimitInBytes < playerCacheSize) {
                                            cacheUsage = playerCacheSize
                                            cacheType = songCacheString
                                            onConfirmAction = { onMaxSongCacheSizeChange(newValue) }
                                            showCacheWarningDialog = true
                                        } else {
                                            onMaxSongCacheSizeChange(newValue)
                                        }
                                    },
                                    steps = songCacheValues.size - 2,
                                    valueRange = 0f..(songCacheValues.size - 1).toFloat(),
                                )
                                LinearProgressIndicator(
                                    progress = { playerCacheProgress },
                                    modifier = Modifier.fillMaxWidth(),
                                    strokeCap = StrokeCap.Round,
                                )
                                Spacer(modifier = Modifier.padding(2.dp))
                                Text(
                                    text =
                                        if (maxSongCacheSize == -1) {
                                            Formatter.formatShortFileSize(context, playerCacheSize)
                                        } else {
                                            "${Formatter.formatShortFileSize(context, playerCacheSize)} / ${
                                                Formatter.formatShortFileSize(context, 
                                                    maxSongCacheSize * 1024 * 1024L,
                                                )
                                            }"
                                        },
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                            }
                        },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.clear_all),
                        title = { Text(stringResource(R.string.clear_song_cache)) },
                        onClick = {
                            clearCacheDialog = true
                        },
                    ),
                ),
        )

        Material3SettingsGroup(
            title = stringResource(R.string.image_cache),
            items =
                listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.manage_search),
                        title = { Text(stringResource(R.string.max_image_cache_size)) },
                        description = {
                            val imageCacheValues =
                                remember { listOf(0, 128, 256, 512, 1024, 2048, 4096, 8192) }
                            Column {
                                Text(
                                    text =
                                        when (maxImageCacheSize) {
                                            0 -> stringResource(R.string.disable)
                                            else -> Formatter.formatShortFileSize(context, maxImageCacheSize * 1024 * 1024L)
                                        },
                                )
                                Slider(
                                    value = imageCacheValues.indexOf(maxImageCacheSize).toFloat(),
                                    onValueChange = {
                                        val newValue = imageCacheValues[it.roundToInt()]
                                        val newLimitInBytes = newValue * 1024 * 1024L

                                        if (newLimitInBytes < imageCacheSize) {
                                            cacheUsage = imageCacheSize
                                            cacheType = imageCacheString
                                            onConfirmAction = { onMaxImageCacheSizeChange(newValue) }
                                            showCacheWarningDialog = true
                                        } else {
                                            onMaxImageCacheSizeChange(newValue)
                                        }
                                    },
                                    steps = imageCacheValues.size - 2,
                                    valueRange = 0f..(imageCacheValues.size - 1).toFloat(),
                                )
                                LinearProgressIndicator(
                                    progress = { imageCacheProgress },
                                    modifier = Modifier.fillMaxWidth(),
                                    strokeCap = StrokeCap.Round,
                                )
                                Spacer(modifier = Modifier.padding(2.dp))
                                Text(
                                    text = "${Formatter.formatShortFileSize(context, imageCacheSize)} / ${
                                        Formatter.formatShortFileSize(context, 
                                            maxImageCacheSize * 1024 * 1024L,
                                        )
                                    }",
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                            }
                        },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.clear_all),
                        title = { Text(stringResource(R.string.clear_image_cache)) },
                        onClick = {
                            clearImageCacheDialog = true
                        },
                    ),
                ),
        )
    }

    TopAppBar(
        title = { Text(stringResource(R.string.storage)) },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain,
            ) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                )
            }
        },
    )
}
