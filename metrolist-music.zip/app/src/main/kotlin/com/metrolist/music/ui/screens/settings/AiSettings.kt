/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.constants.AiProviderKey
import com.metrolist.music.constants.AiSystemPromptKey
import com.metrolist.music.constants.AutoTranslateKey
import com.metrolist.music.constants.AiRecommendationsKey
import com.metrolist.music.constants.DEFAULT_AI_SYSTEM_PROMPT
import com.metrolist.music.constants.DeepInfraBaseUrl
import com.metrolist.music.constants.DeepInfraDefaultModel
import com.metrolist.music.constants.DeeplApiKey
import com.metrolist.music.constants.DeeplFormalityKey
import com.metrolist.music.constants.GroqBaseUrl
import com.metrolist.music.constants.GroqDefaultModel
import com.metrolist.music.constants.LanguageCodeToName
import com.metrolist.music.constants.NvidiaBaseUrl
import com.metrolist.music.constants.NvidiaDefaultModel
import com.metrolist.music.constants.OpenRouterApiKey
import com.metrolist.music.constants.OpenRouterBaseUrlKey
import com.metrolist.music.constants.OpenRouterModelKey
import com.metrolist.music.constants.OpenRouterModelTierKey
import com.metrolist.music.constants.OpenRouterTierStable
import com.metrolist.music.constants.MiniAssistantEnabledKey
import com.metrolist.music.constants.TranslateLanguageKey
import com.metrolist.music.constants.TranslateModeKey
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.metrolist.music.ui.component.EnumDialog
import com.metrolist.music.ui.component.ApiKeyManagementDialog
import com.metrolist.music.ui.component.DeepInfraModelDialog
import androidx.compose.ui.graphics.Color
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metrolist.music.LocalPlayerConnection
import com.metrolist.music.ui.component.LyricsTranslationDebugDialog
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.component.ModelSelector
import com.metrolist.music.ui.component.OpenRouterModelDialog
import com.metrolist.music.ui.component.OpenRouterModelDropdown
import com.metrolist.music.ui.component.TextFieldDialog
import com.metrolist.music.utils.rememberPreference
import com.metrolist.music.viewmodels.ModelViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiSettings(
    navController: NavController,
    modelViewModel: ModelViewModel = hiltViewModel(),
) {
    var aiProvider by rememberPreference(AiProviderKey, "OpenRouter")
    var openRouterApiKey by rememberPreference(OpenRouterApiKey, "")
    var openRouterBaseUrl by rememberPreference(OpenRouterBaseUrlKey, "https://openrouter.ai/api/v1/chat/completions")
    var openRouterModel by rememberPreference(OpenRouterModelKey, "google/gemini-2.5-flash-lite")
    var openRouterModelTier by rememberPreference(OpenRouterModelTierKey, OpenRouterTierStable)
    var translateLanguage by rememberPreference(TranslateLanguageKey, "en")
    var translateMode by rememberPreference(TranslateModeKey, "Literal")
    var deeplApiKey by rememberPreference(DeeplApiKey, "")
    var deeplFormality by rememberPreference(DeeplFormalityKey, "default")
    var aiSystemPrompt by rememberPreference(AiSystemPromptKey, "")
    var autoTranslate by rememberPreference(AutoTranslateKey, false)
    var aiRecommendations by rememberPreference(AiRecommendationsKey, true)
    var miniAssistantEnabled by rememberPreference(MiniAssistantEnabledKey, true)
    val apiKeyStatus by modelViewModel.apiKeyStatus.collectAsStateWithLifecycle()
    val isDark = isSystemInDarkTheme()
    val statusSuccessColor = if (isDark) Color(0xFF81C784) else Color(0xFF2E7D32)
    val statusWarningColor = if (isDark) Color(0xFFFFB74D) else Color(0xFFE65100)
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val aiProviders =
        mapOf(
            "OpenRouter" to "https://openrouter.ai/api/v1/chat/completions",
            "DeepInfra" to DeepInfraBaseUrl,
            "Nvidia" to NvidiaBaseUrl,
            "Groq" to GroqBaseUrl,
            "OpenAI" to "https://api.openai.com/v1/chat/completions",
            "Perplexity" to "https://api.perplexity.ai/chat/completions",
            "Claude" to "https://api.anthropic.com/v1/messages",
            "Gemini" to "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
            "XAi" to "https://api.x.ai/v1/chat/completions",
            "Mistral" to "https://api.mistral.ai/v1/chat/completions",
            "DeepL" to "https://api.deepl.com/v2/translate",
            "Custom" to "",
        )

    val providerHelpText =
        mapOf(
            "OpenRouter" to stringResource(R.string.ai_provider_openrouter_help),
            "DeepInfra" to stringResource(R.string.ai_provider_deepinfra_help),
            "Nvidia" to stringResource(R.string.ai_provider_nvidia_help),
            "Groq" to stringResource(R.string.ai_provider_groq_help),
            "OpenAI" to stringResource(R.string.ai_provider_openai_help),
            "Perplexity" to stringResource(R.string.ai_provider_perplexity_help),
            "Claude" to stringResource(R.string.ai_provider_claude_help),
            "Gemini" to stringResource(R.string.ai_provider_gemini_help),
            "XAi" to stringResource(R.string.ai_provider_xai_help),
            "Mistral" to stringResource(R.string.ai_provider_mistral_help),
            "DeepL" to stringResource(R.string.ai_provider_deepl_help),
            "Custom" to "",
        )

    val modelsByProvider =
        mapOf(
            "OpenRouter" to
                listOf(
                    "google/gemini-2.5-flash-lite",
                    "google/gemini-2.5-flash",
                    "x-ai/grok-4.1-fast",
                    "deepseek/deepseek-v3.1-terminus:exacto",
                    "openai/gpt-4o-mini",
                    "meta-llama/llama-4-scout",
                    "openai/gpt-5-nano",
                    "openai/gpt-oss-120b",
                    "google/gemini-3-flash-preview",
                ),
            "DeepInfra" to
                listOf(
                    "deepseek-ai/DeepSeek-V4-Flash",
                    "deepseek-ai/DeepSeek-V4-Pro",
                    "meta-llama/Llama-4-Scout-17B-16E-Instruct",
                    "meta-llama/Llama-3.3-70B-Instruct-Turbo",
                    "meta-llama/Meta-Llama-3.1-8B-Instruct",
                    "Qwen/Qwen2.5-72B-Instruct",
                    "Qwen/Qwen3-32B",
                    "mistralai/Mistral-Nemo-Instruct-2407",
                    "google/gemma-4-31B-it-turbo",
                    "deepseek-ai/DeepSeek-R1-0528",
                    "google/gemma-3-12b-it",
                    "MiniMaxAI/MiniMax-M2.7-Turbo",
                ),
            "Nvidia" to
                listOf(
                    "meta/llama-3.3-70b-instruct",
                    "meta/llama-3.1-405b-instruct",
                    "meta/llama-3.1-70b-instruct",
                    "meta/llama-3.1-8b-instruct",
                    "nvidia/llama-3.1-nemotron-70b-instruct",
                    "deepseek-ai/deepseek-r1",
                    "qwen/qwen2.5-72b-instruct",
                    "mistralai/mistral-large-2-instruct",
                ),
            "Groq" to
                listOf(
                    "llama-3.3-70b-versatile",
                    "llama-3.1-8b-instant",
                    "llama3-70b-8192",
                    "llama3-8b-8192",
                    "mixtral-8x7b-32768",
                    "gemma2-9b-it",
                    "deepseek-r1-distill-llama-70b",
                ),
            "OpenAI" to
                listOf(
                    "gpt-4o-mini",
                    "gpt-4o",
                    "gpt-4-turbo",
                ),
            "Claude" to
                listOf(
                    "claude-opus-4-6",
                    "claude-sonnet-4-6",
                    "claude-haiku-4-5-20251001",
                ),
            "Gemini" to
                listOf(
                    "gemini-flash-lite-latest",
                    "gemini-2.5-flash-lite",
                    "gemini-flash-latest",
                    "gemini-2.5-flash",
                    "gemini-3-flash-preview",
                ),
            "Perplexity" to
                listOf(
                    "sonar",
                    "sonar-pro",
                    "sonar-reasoning",
                ),
            "XAi" to
                listOf(
                    "grok-4-1-fast",
                    "grok-vision-beta",
                ),
            "Mistral" to
                listOf(
                    "mistral-large-latest",
                    "mistral-medium-latest",
                    "mistral-small-latest",
                    "mistral-tiny-latest",
                ),
            "DeepL" to listOf(),
            "Custom" to listOf(),
        )

    val commonModels = modelsByProvider[aiProvider] ?: listOf()

    var showProviderDialog by rememberSaveable { mutableStateOf(false) }
    var showProviderHelpDialog by rememberSaveable { mutableStateOf(false) }
    var showTranslateModeDialog by rememberSaveable { mutableStateOf(false) }
    var showTranslateModeHelpDialog by rememberSaveable { mutableStateOf(false) }
    var showLanguageDialog by rememberSaveable { mutableStateOf(false) }
    var showApiKeyDialog by rememberSaveable { mutableStateOf(false) }
    var showDeeplApiKeyDialog by rememberSaveable { mutableStateOf(false) }
    var showDeeplFormalityDialog by rememberSaveable { mutableStateOf(false) }
    var showBaseUrlDialog by rememberSaveable { mutableStateOf(false) }
    var showModelDialog by rememberSaveable { mutableStateOf(false) }
    var showCustomModelInput by rememberSaveable { mutableStateOf(false) }
    var showSystemPromptDialog by rememberSaveable { mutableStateOf(false) }
    var showDebugDialog by rememberSaveable { mutableStateOf(false) }

    if (showProviderHelpDialog) {
        AlertDialog(
            onDismissRequest = { showProviderHelpDialog = false },
            confirmButton = {
                TextButton(onClick = { showProviderHelpDialog = false }) {
                    Text(stringResource(android.R.string.ok))
                }
            },
            icon = { Icon(painterResource(R.drawable.info), null) },
            title = { Text(stringResource(R.string.ai_provider_help)) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                ) {
                    // API key notice card / Bảng thông tin lưu ý trước khi sử dụng API key
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        ),
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.security),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp),
                                )
                                Text(
                                    text = stringResource(R.string.ai_api_key_note_title),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Text(
                                text = stringResource(R.string.ai_api_key_note_content),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }

                    Text(
                        text = stringResource(R.string.ai_provider_help_list_title),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 6.dp),
                    )

                    providerHelpText.forEach { (provider, help) ->
                        if (help.isNotEmpty()) {
                            val primaryColor = MaterialTheme.colorScheme.primary
                            val annotatedString =
                                buildAnnotatedString {
                                    append("$provider: ")
                                    // Extract URL from text
                                    val urlRegex = "(https?://[^\\s]+|[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}(/[^\\s]*)?)".toRegex()
                                    val match = urlRegex.find(help)
                                    if (match != null) {
                                        val rawUrl = match.value
                                        val fullUrl = if (rawUrl.startsWith("http://") || rawUrl.startsWith("https://")) rawUrl else "https://$rawUrl"
                                        val beforeUrl = help.substring(0, match.range.first)
                                        val afterUrl = help.substring(match.range.last + 1)

                                        append(beforeUrl)
                                        withLink(
                                            LinkAnnotation.Url(
                                                url = fullUrl,
                                                styles =
                                                    TextLinkStyles(
                                                        style =
                                                            SpanStyle(
                                                                color = primaryColor,
                                                                textDecoration = TextDecoration.Underline,
                                                            ),
                                                    ),
                                            ),
                                        ) {
                                            append(rawUrl)
                                        }
                                        append(afterUrl)
                                    } else {
                                        append(help)
                                    }
                                }

                            Text(
                                text = annotatedString,
                                style =
                                    MaterialTheme.typography.bodyMedium.copy(
                                        color = MaterialTheme.colorScheme.onSurface,
                                    ),
                                modifier = Modifier.padding(vertical = 4.dp),
                            )
                        }
                    }
                }
            },
        )
    }

    if (showTranslateModeHelpDialog) {
        AlertDialog(
            onDismissRequest = { showTranslateModeHelpDialog = false },
            confirmButton = {
                TextButton(onClick = { showTranslateModeHelpDialog = false }) {
                    Text(stringResource(android.R.string.ok))
                }
            },
            icon = { Icon(painterResource(R.drawable.info), null) },
            title = { Text(stringResource(R.string.ai_translation_mode)) },
            text = {
                Column {
                    Text(
                        text = "${stringResource(R.string.ai_translation_literal)}:",
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                    Text(
                        text = stringResource(R.string.ai_translation_literal_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(bottom = 12.dp),
                    )

                    Text(
                        text = "${stringResource(R.string.ai_translation_transcribed)}:",
                        style = MaterialTheme.typography.titleSmall,
                    )
                    Text(
                        text = stringResource(R.string.ai_translation_transcribed_desc),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            },
        )
    }

    if (showProviderDialog) {
        EnumDialog(
            onDismiss = { showProviderDialog = false },
            onSelect = {
                aiProvider = it
                if (it != "Custom" && it != "DeepL") {
                    openRouterBaseUrl = aiProviders[it] ?: ""
                } else {
                    openRouterBaseUrl = ""
                }
                // Set model to first available model for the selected provider
                val modelsForProvider = modelsByProvider[it] ?: listOf()
                openRouterModel =
                    if (it == "OpenRouter") {
                        if (openRouterModel.isBlank()) "google/gemini-2.5-flash-lite" else openRouterModel
                    } else if (it == "DeepInfra") {
                        if (openRouterModel.isBlank() || !openRouterModel.contains("/")) DeepInfraDefaultModel else openRouterModel
                    } else if (it == "Nvidia") {
                        NvidiaDefaultModel
                    } else if (it == "Groq") {
                        GroqDefaultModel
                    } else if (modelsForProvider.isNotEmpty()) {
                        modelsForProvider[0]
                    } else {
                        ""
                    }
                showProviderDialog = false
            },
            title = stringResource(R.string.ai_provider),
            current = aiProvider,
            values = aiProviders.keys.toList(),
            valueText = { it },
        )
    }

    if (showTranslateModeDialog) {
        EnumDialog(
            onDismiss = { showTranslateModeDialog = false },
            onSelect = {
                translateMode = it
                showTranslateModeDialog = false
            },
            title = stringResource(R.string.ai_translation_mode),
            current = translateMode,
            values = listOf("Literal", "Transcribed"),
            valueText = {
                when (it) {
                    "Literal" -> stringResource(R.string.ai_translation_literal)
                    "Transcribed" -> stringResource(R.string.ai_translation_transcribed)
                    else -> it
                }
            },
        )
    }

    if (showLanguageDialog) {
        EnumDialog(
            onDismiss = { showLanguageDialog = false },
            onSelect = {
                translateLanguage = it
                showLanguageDialog = false
            },
            title = stringResource(R.string.ai_target_language),
            current = translateLanguage,
            values = LanguageCodeToName.keys.sortedBy { LanguageCodeToName[it] },
            valueText = { LanguageCodeToName[it] ?: it },
        )
    }

    if (showApiKeyDialog) {
        ApiKeyManagementDialog(
            provider = aiProvider,
            initialApiKey = openRouterApiKey,
            initialStatus = apiKeyStatus,
            baseUrl = openRouterBaseUrl,
            onDismiss = { showApiKeyDialog = false },
            onSaveKey = { key, status ->
                openRouterApiKey = key
                if (status.isNotBlank()) {
                    modelViewModel.setApiKeyStatus(status)
                }
                showApiKeyDialog = false
            },
            viewModel = modelViewModel,
        )
    }

    if (showDeeplApiKeyDialog) {
        ApiKeyManagementDialog(
            provider = "DeepL",
            initialApiKey = deeplApiKey,
            initialStatus = "",
            baseUrl = "",
            onDismiss = { showDeeplApiKeyDialog = false },
            onSaveKey = { key, _ ->
                deeplApiKey = key
                showDeeplApiKeyDialog = false
            },
            viewModel = modelViewModel,
        )
    }

    if (showDeeplFormalityDialog) {
        EnumDialog(
            onDismiss = { showDeeplFormalityDialog = false },
            onSelect = {
                deeplFormality = it
                showDeeplFormalityDialog = false
            },
            title = stringResource(R.string.ai_deepl_formality),
            current = deeplFormality,
            values = listOf("default", "more", "less"),
            valueText = {
                when (it) {
                    "default" -> stringResource(R.string.ai_deepl_formality_default)
                    "more" -> stringResource(R.string.ai_deepl_formality_more)
                    "less" -> stringResource(R.string.ai_deepl_formality_less)
                    else -> it
                }
            },
        )
    }

    if (showBaseUrlDialog && aiProvider == "Custom") {
        TextFieldDialog(
            title = { Text(stringResource(R.string.ai_base_url)) },
            icon = { Icon(painterResource(R.drawable.link), null) },
            initialTextFieldValue = TextFieldValue(text = openRouterBaseUrl),
            onDone = {
                openRouterBaseUrl = it
                showBaseUrlDialog = false
            },
            onDismiss = { showBaseUrlDialog = false },
        )
    }

    if (showModelDialog) {
        if (aiProvider == "OpenRouter") {
            OpenRouterModelDialog(
                currentModel = openRouterModel,
                initialTier = openRouterModelTier,
                viewModel = modelViewModel,
                onDismiss = { showModelDialog = false },
                onSelectModel = { selected ->
                    openRouterModel = selected
                    showModelDialog = false
                },
                onCustomInput = {
                    showModelDialog = false
                    showCustomModelInput = true
                },
            )
        } else if (aiProvider == "DeepInfra") {
            DeepInfraModelDialog(
                currentModel = openRouterModel,
                onDismiss = { showModelDialog = false },
                onSelectModel = { selected ->
                    openRouterModel = selected
                    showModelDialog = false
                },
                onCustomInput = {
                    showModelDialog = false
                    showCustomModelInput = true
                },
            )
        } else {
            EnumDialog(
                onDismiss = { showModelDialog = false },
                onSelect = {
                    if (it == "custom_input") {
                        showCustomModelInput = true
                        showModelDialog = false
                    } else {
                        openRouterModel = it
                        showModelDialog = false
                    }
                },
                title = stringResource(R.string.ai_model),
                current = if (openRouterModel in commonModels) openRouterModel else "custom_input",
                values = commonModels + "custom_input",
                valueText = {
                    if (it == "custom_input") "Custom" else it
                },
            )
        }
    }

    if (showCustomModelInput) {
        TextFieldDialog(
            title = { Text(stringResource(R.string.ai_model)) },
            icon = { Icon(painterResource(R.drawable.discover_tune), null) },
            initialTextFieldValue = TextFieldValue(text = openRouterModel),
            onDone = {
                openRouterModel = it
                showCustomModelInput = false
            },
            onDismiss = { showCustomModelInput = false },
        )
    }

    if (showSystemPromptDialog) {
        TextFieldDialog(
            title = { Text(stringResource(R.string.ai_system_prompt)) },
            icon = { Icon(painterResource(R.drawable.edit), null) },
            initialTextFieldValue = TextFieldValue(text = aiSystemPrompt.ifBlank { DEFAULT_AI_SYSTEM_PROMPT }),
            singleLine = false,
            maxLines = 12,
            isInputValid = { true },
            onDone = {
                // Treat saving the unmodified default (or blank) as "use default"
                aiSystemPrompt = if (it.isBlank() || it == DEFAULT_AI_SYSTEM_PROMPT) "" else it
                showSystemPromptDialog = false
            },
            onDismiss = { showSystemPromptDialog = false },
            extraContent = {
                if (aiSystemPrompt.isNotBlank()) {
                    Row(
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.End,
                    ) {
                        TextButton(
                            onClick = {
                                aiSystemPrompt = ""
                                showSystemPromptDialog = false
                            },
                        ) {
                            Text(stringResource(R.string.ai_system_prompt_reset))
                        }
                    }
                }
            },
        )
    }

    if (showDebugDialog) {
        val playerConnection = LocalPlayerConnection.current
        val lyricsEntity by playerConnection?.currentLyrics?.collectAsStateWithLifecycle(initialValue = null)
            ?: remember { mutableStateOf(null) }
        val mediaMetadata by playerConnection?.mediaMetadata?.collectAsStateWithLifecycle(initialValue = null)
            ?: remember { mutableStateOf(null) }

        LyricsTranslationDebugDialog(
            onDismiss = { showDebugDialog = false },
            currentSongLyrics = lyricsEntity?.lyrics,
            currentSongTitle = mediaMetadata?.title,
            currentSongArtist = mediaMetadata?.artists?.joinToString(", ") { it.name },
            modelViewModel = modelViewModel,
        )
    }

    Column(
        Modifier
            .windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom,
                ),
            ).verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top,
                ),
            ),
        )

        val isVietnamese = java.util.Locale.getDefault().language == "vi"
        val bannerText = if (isVietnamese) {
            "Tối ưu hóa trải nghiệm âm nhạc với dịch lời bài hát AI và Romanization thông minh."
        } else {
            "Optimize your music experience with AI lyrics translation and smart Romanization."
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .background(
                            MaterialTheme.colorScheme.primary,
                            shape = RoundedCornerShape(16.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.translate),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(32.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = stringResource(R.string.ai_lyrics_translation),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = bannerText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        Material3SettingsGroup(
            title = stringResource(R.string.mini_assistant_title),
            items =
                listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.explore_outlined),
                        title = { Text(stringResource(R.string.mini_assistant_enabled_title)) },
                        description = { Text(stringResource(R.string.mini_assistant_desc)) },
                        onClick = { miniAssistantEnabled = !miniAssistantEnabled },
                        trailingContent = {
                            Switch(
                                checked = miniAssistantEnabled,
                                onCheckedChange = { miniAssistantEnabled = it },
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (miniAssistantEnabled) R.drawable.check else R.drawable.close
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize)
                                    )
                                }
                            )
                        },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.mic),
                        title = { Text(stringResource(R.string.mini_assistant_model_title)) },
                        description = { Text(if (aiProvider == "Custom") openRouterModel else "$aiProvider ($openRouterModel)") },
                        onClick = { showProviderDialog = true },
                    ),
                ),
        )

        Material3SettingsGroup(
            title = stringResource(R.string.ai_provider),
            items =
                listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.explore_outlined),
                        title = { Text(stringResource(R.string.ai_provider)) },
                        description = { Text(aiProvider) },
                        onClick = { showProviderDialog = true },
                        trailingContent = {
                            IconButton(onClick = { showProviderHelpDialog = true }) {
                                Icon(
                                    painterResource(R.drawable.info),
                                    contentDescription = stringResource(R.string.ai_provider_help),
                                    modifier = Modifier.size(20.dp),
                                )
                            }
                        },
                    ),
                    if (aiProvider == "Custom") {
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.link),
                            title = { Text(stringResource(R.string.ai_base_url)) },
                            description = { Text(openRouterBaseUrl.ifBlank { stringResource(R.string.not_set) }) },
                            onClick = { showBaseUrlDialog = true },
                        )
                    } else {
                        null
                    },
                ).filterNotNull(),
        )

        Spacer(modifier = Modifier.height(27.dp))

        // Security Warning Card for API Key Protection
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.errorContainer,
            ),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    painter = painterResource(R.drawable.security),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(22.dp),
                )
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = stringResource(R.string.ai_api_key_security_warning_title),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.error,
                    )
                    Text(
                        text = stringResource(R.string.ai_api_key_security_warning_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        text = stringResource(R.string.ai_api_key_security_censored_hint),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.ai_setup_guide),
            items =
                buildList {
                    if (aiProvider == "DeepL") {
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.key),
                                title = {
                                    Text(
                                        text = "DeepL ${stringResource(R.string.ai_api_key)}",
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                description = {
                                    Text(
                                        text = if (deeplApiKey.isNotEmpty()) {
                                            "•".repeat(minOf(deeplApiKey.length, 8))
                                        } else {
                                            stringResource(R.string.not_set)
                                        },
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                onClick = { showDeeplApiKeyDialog = true },
                            ),
                        )
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.tune),
                                title = {
                                    Text(
                                        text = stringResource(R.string.ai_deepl_formality),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                description = {
                                    Text(
                                        text = when (deeplFormality) {
                                            "default" -> stringResource(R.string.ai_deepl_formality_default)
                                            "more" -> stringResource(R.string.ai_deepl_formality_more)
                                            "less" -> stringResource(R.string.ai_deepl_formality_less)
                                            else -> deeplFormality
                                        },
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                onClick = { showDeeplFormalityDialog = true },
                            ),
                        )
                    } else if (aiProvider == "OpenRouter") {
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.key),
                                title = {
                                    Text(
                                        text = stringResource(R.string.ai_api_key),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                description = {
                                    val statusSuffix = when (apiKeyStatus) {
                                        "valid", "valid_active" -> " • " + stringResource(R.string.ai_api_key_status_valid)
                                        "valid_renewed", "renewed_extended" -> " • " + stringResource(R.string.ai_api_key_status_valid_renewed)
                                        "valid_free", "lifetime_free" -> " • " + stringResource(R.string.ai_api_key_status_valid_free)
                                        "invalid", "invalid_spoofed" -> " • " + stringResource(R.string.ai_api_key_status_invalid)
                                        "exhausted", "expired" -> " • " + stringResource(R.string.ai_api_key_status_exhausted)
                                        else -> ""
                                    }
                                    Text(
                                        text = if (openRouterApiKey.isNotEmpty()) {
                                            "•".repeat(minOf(openRouterApiKey.length, 8)) + statusSuffix
                                        } else {
                                            stringResource(R.string.not_set)
                                        },
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                trailingContent = {
                                    if (openRouterApiKey.isNotEmpty()) {
                                        when (apiKeyStatus) {
                                            "valid", "valid_active", "valid_renewed", "renewed_extended", "valid_free", "lifetime_free" -> Icon(
                                                painter = painterResource(R.drawable.check),
                                                contentDescription = stringResource(R.string.ai_api_key_status_valid),
                                                tint = statusSuccessColor,
                                                modifier = Modifier.size(20.dp),
                                            )
                                            "invalid", "invalid_spoofed" -> Icon(
                                                painter = painterResource(R.drawable.error),
                                                contentDescription = stringResource(R.string.ai_api_key_status_invalid),
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(20.dp),
                                            )
                                            "exhausted", "expired" -> Icon(
                                                painter = painterResource(R.drawable.warning),
                                                contentDescription = stringResource(R.string.ai_api_key_status_exhausted),
                                                tint = statusWarningColor,
                                                modifier = Modifier.size(20.dp),
                                            )
                                            else -> {}
                                        }
                                    }
                                },
                                onClick = { showApiKeyDialog = true },
                            ),
                        )
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.shuffle),
                                title = { Text(stringResource(R.string.ai_model_random_recommend)) },
                                description = { Text(stringResource(R.string.ai_model_random_recommend_desc)) },
                                onClick = {
                                    modelViewModel.recommendRandomModel(forceRefresh = true) { item ->
                                        openRouterModel = item.id
                                        Toast.makeText(
                                            context,
                                            context.getString(R.string.ai_model_random_recommended_toast, item.name.ifBlank { item.id }),
                                            Toast.LENGTH_LONG,
                                        ).show()
                                    }
                                },
                            ),
                        )
                    } else {
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.key),
                                title = {
                                    Text(
                                        text = stringResource(R.string.ai_api_key),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                description = {
                                    if (aiProvider == "DeepInfra" && openRouterApiKey.isEmpty()) {
                                        Text(
                                            text = stringResource(R.string.ai_deepinfra_key_desc),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    } else {
                                        val statusSuffix = when (apiKeyStatus) {
                                            "valid", "valid_active" -> " • " + stringResource(R.string.ai_api_key_status_valid)
                                            "valid_renewed", "renewed_extended" -> " • " + stringResource(R.string.ai_api_key_status_valid_renewed)
                                            "valid_free", "lifetime_free" -> " • " + stringResource(R.string.ai_api_key_status_valid_free)
                                            "invalid", "invalid_spoofed" -> " • " + stringResource(R.string.ai_api_key_status_invalid)
                                            "exhausted", "expired" -> " • " + stringResource(R.string.ai_api_key_status_exhausted)
                                            else -> ""
                                        }
                                        Text(
                                            text = if (openRouterApiKey.isNotEmpty()) {
                                                "•".repeat(minOf(openRouterApiKey.length, 8)) + statusSuffix
                                            } else {
                                                stringResource(R.string.not_set)
                                            },
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    }
                                },
                                trailingContent = {
                                    if (openRouterApiKey.isNotEmpty()) {
                                        when (apiKeyStatus) {
                                            "valid", "valid_active", "valid_renewed", "renewed_extended", "valid_free", "lifetime_free" -> Icon(
                                                painter = painterResource(R.drawable.check),
                                                contentDescription = stringResource(R.string.ai_api_key_status_valid),
                                                tint = statusSuccessColor,
                                                modifier = Modifier.size(20.dp),
                                            )
                                            "invalid", "invalid_spoofed" -> Icon(
                                                painter = painterResource(R.drawable.error),
                                                contentDescription = stringResource(R.string.ai_api_key_status_invalid),
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(20.dp),
                                            )
                                            "exhausted", "expired" -> Icon(
                                                painter = painterResource(R.drawable.warning),
                                                contentDescription = stringResource(R.string.ai_api_key_status_exhausted),
                                                tint = statusWarningColor,
                                                modifier = Modifier.size(20.dp),
                                            )
                                            else -> {}
                                        }
                                    }
                                },
                                onClick = { showApiKeyDialog = true },
                            ),
                        )
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.discover_tune),
                                title = { Text(stringResource(R.string.ai_model)) },
                                description = { Text(openRouterModel.ifBlank { stringResource(R.string.not_set) }) },
                                onClick = { showModelDialog = true },
                            ),
                        )
                    }
                },
        )

        if (aiProvider == "OpenRouter") {
            Spacer(modifier = Modifier.height(14.dp))
            OpenRouterModelDropdown(
                viewModel = modelViewModel,
                selectedTier = openRouterModelTier,
                onTierSelected = { openRouterModelTier = it },
                selectedModel = openRouterModel,
                onModelSelected = { openRouterModel = it },
                onCustomModelClick = { showCustomModelInput = true },
            )
        } else if (aiProvider == "DeepInfra") {
            Spacer(modifier = Modifier.height(14.dp))
            ModelSelector(
                selectedModel = openRouterModel,
                onModelSelected = { openRouterModel = it },
                onCustomModelClick = { showCustomModelInput = true },
                viewModel = modelViewModel,
            )
        }

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.ai_translation_mode),
            items =
                buildList {
                    if (aiProvider != "DeepL") {
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.translate),
                                title = { Text(stringResource(R.string.ai_translation_mode)) },
                                description = {
                                    Text(
                                        when (translateMode) {
                                            "Literal" -> stringResource(R.string.ai_translation_literal)
                                            "Transcribed" -> stringResource(R.string.ai_translation_transcribed)
                                            else -> translateMode
                                        },
                                    )
                                },
                                onClick = { showTranslateModeDialog = true },
                                trailingContent = {
                                    IconButton(onClick = { showTranslateModeHelpDialog = true }) {
                                        Icon(
                                            painterResource(R.drawable.info),
                                            contentDescription = null,
                                            modifier = Modifier.size(20.dp),
                                        )
                                    }
                                },
                            ),
                        )
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.edit),
                                title = { Text(stringResource(R.string.ai_system_prompt)) },
                                description = {
                                    Text(
                                        if (aiSystemPrompt.isNotBlank()) {
                                            aiSystemPrompt.take(60).let {
                                                if (aiSystemPrompt.length > 60) "$it…" else it
                                            }
                                        } else {
                                            stringResource(R.string.ai_system_prompt_default)
                                        },
                                    )
                                },
                                onClick = { showSystemPromptDialog = true },
                            ),
                        )
                    }
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.language),
                            title = { Text(stringResource(R.string.ai_target_language)) },
                            description = { Text(LanguageCodeToName[translateLanguage] ?: translateLanguage) },
                            onClick = { showLanguageDialog = true },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.translate),
                            title = { Text(stringResource(R.string.auto_translate)) },
                            description = { Text(stringResource(R.string.auto_translate_desc)) },
                            trailingContent = {
                                Switch(
                                    checked = autoTranslate,
                                    onCheckedChange = { autoTranslate = it },
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(id = if (autoTranslate) R.drawable.check else R.drawable.close),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    }
                                )
                            },
                            onClick = { autoTranslate = !autoTranslate }
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.bug_report),
                            title = { Text(stringResource(R.string.ai_debug_title)) },
                            description = { Text(stringResource(R.string.ai_debug_desc)) },
                            onClick = { showDebugDialog = true },
                        ),
                    )
                },
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.ai_recommendations),
            items =
                listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.explore_outlined),
                        title = { Text(stringResource(R.string.ai_recommendations)) },
                        description = { Text(stringResource(R.string.ai_recommendations_desc)) },
                        trailingContent = {
                            Switch(
                                checked = aiRecommendations,
                                onCheckedChange = { aiRecommendations = it },
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(id = if (aiRecommendations) R.drawable.check else R.drawable.close),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                }
                            )
                        },
                        onClick = { aiRecommendations = !aiRecommendations }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.sync),
                        title = { Text(stringResource(R.string.refresh_recommendations)) },
                        onClick = {
                            coroutineScope.launch {
                                Toast.makeText(context, context.getString(R.string.refreshing_recommendations), Toast.LENGTH_SHORT).show()
                                delay(1200)
                                Toast.makeText(context, context.getString(R.string.recommendations_refreshed), Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                )
        )

        Spacer(modifier = Modifier.height(16.dp))
    }

    TopAppBar(
        title = { Text(stringResource(R.string.ai_hub)) },
        navigationIcon = {
            IconButton(onClick = { navController.navigateUp() }) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                )
            }
        },
    )
}
