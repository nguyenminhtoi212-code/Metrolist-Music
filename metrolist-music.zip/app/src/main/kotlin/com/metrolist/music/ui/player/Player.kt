/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.player

import com.metrolist.music.utils.joinToArtistString

import androidx.activity.compose.BackHandler
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ContainedLoadingIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedIconButton
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.core.net.toUri
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.DownloadService
import com.metrolist.music.playback.ExoDownloadService
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.Player.STATE_ENDED
import androidx.navigation.NavController
import androidx.palette.graphics.Palette
import com.metrolist.music.constants.ChromaticAberrationKey
import com.metrolist.music.constants.DepthEffectKey
import com.metrolist.music.constants.EnableLiquidGlassKey
import com.metrolist.music.constants.GlassBlurRadiusKey
import com.metrolist.music.constants.GlassPlayerKey
import com.metrolist.music.constants.GlassSaturationKey
import com.metrolist.music.constants.LensRefractionAmountKey
import com.metrolist.music.constants.LensRefractionHeightKey
import com.metrolist.music.constants.PureBlackKey
import com.metrolist.music.constants.SurfaceOpacityKey
import com.metrolist.music.ui.components.liquidGlass
import com.metrolist.music.LocalNavController
import coil3.compose.AsyncImage
import coil3.imageLoader
import coil3.request.ImageRequest
import coil3.request.allowHardware
import coil3.toBitmap
import com.metrolist.music.LocalDatabase
import com.metrolist.music.LocalDownloadUtil
import com.metrolist.music.LocalListenTogetherManager
import com.metrolist.music.LocalPlayerConnection
import com.metrolist.music.R
import com.metrolist.music.ui.component.CastButton
import com.metrolist.music.ui.component.PlayerSleepTimerDialog
import com.metrolist.music.constants.CropAlbumArtKey
import com.metrolist.music.constants.DarkModeKey
import com.metrolist.music.constants.HidePlayerThumbnailKey
import com.metrolist.music.constants.HideStatusBarOnFullscreenKey
import com.metrolist.music.constants.KeepScreenOn
import com.metrolist.music.constants.RealTimeVisualizerEnabledKey
import com.metrolist.music.constants.RealTimeVisualizerStyleKey
import com.metrolist.music.ui.component.RealTimeAudioVisualizer
import com.metrolist.music.constants.PlayerBackgroundStyle
import com.metrolist.music.constants.PlayerBackgroundStyleKey
import com.metrolist.music.constants.PlayerButtonsStyle
import com.metrolist.music.constants.PlayerButtonsStyleKey
import com.metrolist.music.constants.PlayerHorizontalPadding
import com.metrolist.music.constants.QueuePeekHeight
import com.metrolist.music.constants.SleepTimerDefaultKey
import com.metrolist.music.constants.SleepTimerFadeOutKey
import com.metrolist.music.constants.SleepTimerStopAfterCurrentSongKey
import com.metrolist.music.constants.SliderStyle
import com.metrolist.music.constants.SliderStyleKey
import com.metrolist.music.constants.SquigglySliderKey
import com.metrolist.music.constants.ThumbnailCornerRadius
import com.metrolist.music.constants.UseNewPlayerDesignKey
import com.metrolist.music.db.entities.LyricsEntity
import com.metrolist.music.extensions.metadata
import com.metrolist.music.extensions.togglePlayPause
import com.metrolist.music.extensions.toggleRepeatMode
import com.metrolist.music.listentogether.RoomRole
import com.metrolist.music.models.MediaMetadata
import com.metrolist.music.ui.component.BottomSheet
import com.metrolist.music.ui.component.BottomSheetState
import com.metrolist.music.ui.component.LocalBottomSheetPageState
import com.metrolist.music.ui.component.LocalMenuState
import com.metrolist.music.ui.component.Lyrics
import com.metrolist.music.ui.component.PlayerSliderTrack
import com.metrolist.music.ui.component.ResizableIconButton
import com.metrolist.music.ui.component.SquigglySlider
import com.metrolist.music.ui.component.WavySlider
import com.metrolist.music.ui.component.VolumeSlider
import com.metrolist.music.ui.component.rememberBottomSheetState
import com.metrolist.music.ui.menu.PlayerMenu
import com.metrolist.music.ui.menu.AddToPlaylistDialog
import com.metrolist.music.constants.DislikedSongsKey
import com.metrolist.music.constants.SmartShuffleKey
import com.metrolist.music.constants.ShowCodecOnPlayerKey
import com.metrolist.music.ui.screens.settings.DarkMode
import com.metrolist.music.ui.theme.PlayerColorExtractor
import com.metrolist.music.ui.theme.PlayerSliderColors
import com.metrolist.music.ui.utils.ShowMediaInfo
import com.metrolist.music.ui.utils.ShowOffsetDialog
import com.metrolist.music.utils.dataStore
import com.metrolist.music.utils.makeTimeString
import com.metrolist.music.utils.rememberEnumPreference
import com.metrolist.music.utils.rememberPreference
import com.metrolist.music.utils.safeDataStoreEdit
import dagger.hilt.android.EntryPointAccessors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt
import com.metrolist.music.ui.component.Icon as MIcon
import com.metrolist.music.constants.SleepTimerDefaultKey
import com.metrolist.music.constants.SleepTimerFadeOutKey
import com.metrolist.music.constants.SleepTimerStopAfterCurrentSongKey


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BottomSheetPlayer(
    state: BottomSheetState,
    navController: NavController,
    modifier: Modifier = Modifier,
    pureBlack: Boolean,
) {
    val context = LocalContext.current
    val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val menuState = LocalMenuState.current
    val sleepTimerDefaultSetTemplate = stringResource(R.string.sleep_timer_default_set)
    val copiedTitleStr = stringResource(R.string.copied_title)
    val copiedArtistStr = stringResource(R.string.copied_artist)
    val bottomSheetPageState = LocalBottomSheetPageState.current
    val playerConnection = LocalPlayerConnection.current ?: return

    val (useNewPlayerDesign, onUseNewPlayerDesignChange) =
        rememberPreference(
            UseNewPlayerDesignKey,
            defaultValue = true,
        )
    val (hidePlayerThumbnail, onHidePlayerThumbnailChange) = rememberPreference(HidePlayerThumbnailKey, false)
    val (hideStatusBarOnFullscreen) = rememberPreference(HideStatusBarOnFullscreenKey, false)
    val cropAlbumArt by rememberPreference(CropAlbumArtKey, false)

    val enableLiquidGlass by rememberPreference(EnableLiquidGlassKey, defaultValue = true)
    val glassPlayer by rememberPreference(GlassPlayerKey, defaultValue = true)
    val glassSaturation by rememberPreference(GlassSaturationKey, defaultValue = 1.3f)
    val glassBlurRadius by rememberPreference(GlassBlurRadiusKey, defaultValue = 24f)
    val lensRefractionHeight by rememberPreference(LensRefractionHeightKey, defaultValue = 14f)
    val lensRefractionAmount by rememberPreference(LensRefractionAmountKey, defaultValue = 0.85f)
    val chromaticAberration by rememberPreference(ChromaticAberrationKey, defaultValue = 0.45f)
    val depthEffect by rememberPreference(DepthEffectKey, defaultValue = 0.75f)
    val surfaceOpacity by rememberPreference(SurfaceOpacityKey, defaultValue = 1.0f)

    val isGlassPlayerActive = enableLiquidGlass && glassPlayer
    val realTimeVisualizerEnabled by rememberPreference(RealTimeVisualizerEnabledKey, true)
    val realTimeVisualizerStyle by rememberPreference(RealTimeVisualizerStyleKey, "spectrum")
    val (dislikedSongs, onDislikedSongsChange) = rememberPreference(DislikedSongsKey, emptySet<String>())

    var showInlineLyrics by rememberSaveable {
        mutableStateOf(false)
    }

    var isFullScreen by rememberSaveable {
        mutableStateOf(false)
    }

    var isStandbyMode by rememberSaveable {
        mutableStateOf(false)
    }

    val playerBackground by rememberEnumPreference(
        key = PlayerBackgroundStyleKey,
        defaultValue = PlayerBackgroundStyle.DEFAULT,
    )
    val playerButtonsStyle by rememberEnumPreference(
        key = PlayerButtonsStyleKey,
        defaultValue = PlayerButtonsStyle.DEFAULT,
    )

    val isSystemInDarkTheme = isSystemInDarkTheme()
    val darkTheme by rememberEnumPreference(DarkModeKey, defaultValue = DarkMode.AUTO)
    val useDarkTheme =
        remember(darkTheme, isSystemInDarkTheme) {
            if (darkTheme == DarkMode.AUTO) isSystemInDarkTheme else darkTheme == DarkMode.ON
        }

    val shouldUseDarkButtonColors = useDarkTheme

    val isPlaying by playerConnection.isPlaying.collectAsState()
    val isKeepScreenOn by rememberPreference(KeepScreenOn, false)
    val keepScreenOn = isPlaying && isKeepScreenOn

    DisposableEffect(playerBackground, state.isExpanded, useDarkTheme, keepScreenOn, isFullScreen, hideStatusBarOnFullscreen) {
        val window = (context as? android.app.Activity)?.window
        if (window != null && state.isExpanded) {
            val insetsController = WindowCompat.getInsetsController(window, window.decorView)

            when (playerBackground) {
                PlayerBackgroundStyle.DEFAULT -> {
                    insetsController.isAppearanceLightStatusBars = !useDarkTheme
                }

                else -> {
                    insetsController.isAppearanceLightStatusBars = false
                }
            }

            if (isFullScreen && hideStatusBarOnFullscreen) {
                insetsController.hide(WindowInsetsCompat.Type.statusBars())
                insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            } else {
                insetsController.show(WindowInsetsCompat.Type.statusBars())
            }

            if (keepScreenOn && state.isExpanded) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        onDispose {
            if (window != null) {
                val insetsController = WindowCompat.getInsetsController(window, window.decorView)
                insetsController.isAppearanceLightStatusBars = !useDarkTheme
                insetsController.show(WindowInsetsCompat.Type.statusBars())
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    BackHandler(enabled = state.isExpanded) {
        state.collapseSoft()
    }

    var isVideoMode by rememberSaveable {
        mutableStateOf(false)
    }

    val onBackgroundColor =
        when (playerBackground) {
            PlayerBackgroundStyle.DEFAULT -> MaterialTheme.colorScheme.secondary
            else -> MaterialTheme.colorScheme.onSurface
        }
    val useBlackBackground =
        remember(isSystemInDarkTheme, darkTheme, pureBlack) {
            val useDarkTheme =
                if (darkTheme == DarkMode.AUTO) isSystemInDarkTheme else darkTheme == DarkMode.ON
            useDarkTheme && pureBlack
        }

    val playbackState by playerConnection.playbackState.collectAsState()
    val mediaMetadata by playerConnection.mediaMetadata.collectAsState()
    val currentSong by playerConnection.currentSong.collectAsStateWithLifecycle(initialValue = null)
    val automix by playerConnection.service.automixItems.collectAsStateWithLifecycle()
    val repeatMode by playerConnection.repeatMode.collectAsStateWithLifecycle()
    val canSkipPrevious by playerConnection.canSkipPrevious.collectAsStateWithLifecycle()
    val canSkipNext by playerConnection.canSkipNext.collectAsStateWithLifecycle()
    val isMuted by playerConnection.isMuted.collectAsStateWithLifecycle()

    val sliderStyle by rememberEnumPreference(SliderStyleKey, SliderStyle.DEFAULT)
    val squigglySlider by rememberPreference(SquigglySliderKey, defaultValue = false)

    // Listen Together state (reactive)
    val listenTogetherManager = LocalListenTogetherManager.current
    val listenTogetherRoleState = listenTogetherManager?.role?.collectAsStateWithLifecycle(initialValue = RoomRole.NONE)
    val isListenTogetherGuest = listenTogetherRoleState?.value == RoomRole.GUEST

    // Cast state - safely access castConnectionHandler to prevent crashes during service lifecycle changes
    val castHandler =
        remember(playerConnection) {
            try {
                playerConnection.service.castConnectionHandler
            } catch (e: Exception) {
                null
            }
        }
    val isCasting by castHandler?.isCasting?.collectAsStateWithLifecycle() ?: remember { mutableStateOf(false) }
    val castPosition by castHandler?.castPosition?.collectAsStateWithLifecycle() ?: remember { mutableLongStateOf(0L) }
    val castDuration by castHandler?.castDuration?.collectAsStateWithLifecycle() ?: remember { mutableLongStateOf(0L) }
    val castIsPlaying by castHandler?.castIsPlaying?.collectAsState() ?: remember { mutableStateOf(false) }
    val playerVolume = playerConnection.service.playerVolume.collectAsStateWithLifecycle()
    val castVolume by castHandler?.castVolume?.collectAsStateWithLifecycle() ?: remember { mutableStateOf(1f) }

    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(state.isExpanded) {
        if (state.isExpanded) {
            delay(100)
            try {
                focusRequester.requestFocus()
            } catch (e: Exception) {
                // Ignore if focus request fails
            }
        }
    }

    // Use Cast state when casting, otherwise local player
    val effectiveIsPlaying = if (isCasting) castIsPlaying else isPlaying

    // Use State objects for position/duration to pass to MiniPlayer without causing recomposition
    // These states persist across playback state changes to ensure continuous progress updates.
    // Seed from the player's current values so re-entering composition on resume shows the real
    // time immediately instead of flashing 0:00 until the first poll fires. runCatching guards the
    // player-not-ready race; the poll loop corrects duration if it isn't known yet.
    val showCodecOnPlayer by rememberPreference(ShowCodecOnPlayerKey, false)
    val positionState = remember { mutableLongStateOf(runCatching { playerConnection.player.currentPosition }.getOrDefault(0L)) }
    val durationState = remember {
        mutableLongStateOf(
            (mediaMetadata?.duration?.takeIf { it > 0 }?.toLong()?.times(1000L))
                ?: runCatching { playerConnection.player.duration }.getOrDefault(0L).coerceAtLeast(0L),
        )
    }

    // Convenience accessors for local use
    var position by positionState
    var duration by durationState

    val effectivePosition by remember {
        derivedStateOf {
            if (isCasting) {
                castPosition
            } else {
                position
            }
        }
    }

    var sliderPosition by remember {
        mutableStateOf<Long?>(null)
    }
    // Track when we last manually set position to avoid Cast overwriting it
    var lastManualSeekTime by remember { mutableLongStateOf(0L) }

    var gradientColors by remember {
        mutableStateOf<List<Color>>(emptyList())
    }
    val gradientColorsCache = remember { mutableMapOf<String, List<Color>>() }

    if (!canSkipNext && automix.isNotEmpty()) {
        playerConnection.service.addToQueueAutomix(automix[0], 0)
    }

    val defaultGradientColors = listOf(MaterialTheme.colorScheme.surface, MaterialTheme.colorScheme.surfaceVariant)
    val fallbackColor = MaterialTheme.colorScheme.surface.toArgb()

    val dominantColor = gradientColors.firstOrNull() ?: Color.Unspecified

    LaunchedEffect(mediaMetadata?.id, playerBackground, isGlassPlayerActive) {
        if (playerBackground == PlayerBackgroundStyle.GRADIENT || isGlassPlayerActive) {
            val currentMetadata = mediaMetadata
            if (currentMetadata != null && currentMetadata.thumbnailUrl != null) {
                val cachedColors = gradientColorsCache[currentMetadata.id]
                if (cachedColors != null) {
                    gradientColors = cachedColors
                    return@LaunchedEffect
                }
                withContext(Dispatchers.IO) {
                    val request =
                        ImageRequest
                            .Builder(context)
                            .data(currentMetadata.thumbnailUrl)
                            .size(100, 100)
                            .allowHardware(false)
                            .memoryCacheKey("gradient_${currentMetadata.id}")
                            .build()

                    val result = runCatching { context.imageLoader.execute(request) }.getOrNull()
                    if (result != null) {
                        val bitmap = result.image?.toBitmap()
                        if (bitmap != null) {
                            val palette =
                                withContext(Dispatchers.Default) {
                                    Palette
                                        .from(bitmap)
                                        .maximumColorCount(8)
                                        .resizeBitmapArea(100 * 100)
                                        .generate()
                                }
                            val extractedColors =
                                PlayerColorExtractor.extractGradientColors(
                                    palette = palette,
                                    fallbackColor = fallbackColor,
                                )
                            gradientColorsCache[currentMetadata.id] = extractedColors
                            withContext(Dispatchers.Main) { gradientColors = extractedColors }
                        }
                    }
                }
            }
        } else {
            gradientColors = emptyList()
        }
    }

    val TextBackgroundColor by animateColorAsState(
        targetValue =
            when (playerBackground) {
                PlayerBackgroundStyle.DEFAULT -> MaterialTheme.colorScheme.onBackground
                else -> if (useDarkTheme) Color.White else Color.Black
            },
        label = "TextBackgroundColor",
    )

    val icBackgroundColor by animateColorAsState(
        targetValue =
            when (playerBackground) {
                PlayerBackgroundStyle.DEFAULT -> MaterialTheme.colorScheme.surface
                else -> if (useDarkTheme) Color.Black else Color.White
            },
        label = "icBackgroundColor",
    )

    val (textButtonColor, iconButtonColor) =
        when {
            playerBackground == PlayerBackgroundStyle.BLUR ||
                playerBackground == PlayerBackgroundStyle.GRADIENT -> {
                when (playerButtonsStyle) {
                    PlayerButtonsStyle.DEFAULT -> {
                        if (useDarkTheme) {
                            Pair(Color.White, Color.Black)
                        } else {
                            Pair(Color.Black, Color.White)
                        }
                    }

                    PlayerButtonsStyle.PRIMARY -> {
                        Pair(
                            MaterialTheme.colorScheme.primary,
                            MaterialTheme.colorScheme.onPrimary,
                        )
                    }

                    PlayerButtonsStyle.TERTIARY -> {
                        Pair(
                            MaterialTheme.colorScheme.tertiary,
                            MaterialTheme.colorScheme.onTertiary,
                        )
                    }
                }
            }

            else -> {
                when (playerButtonsStyle) {
                    PlayerButtonsStyle.DEFAULT -> {
                        if (useDarkTheme) {
                            Pair(Color.White, Color.Black)
                        } else {
                            Pair(Color.Black, Color.White)
                        }
                    }

                    PlayerButtonsStyle.PRIMARY -> {
                        Pair(
                            MaterialTheme.colorScheme.primary,
                            MaterialTheme.colorScheme.onPrimary,
                        )
                    }

                    PlayerButtonsStyle.TERTIARY -> {
                        Pair(
                            MaterialTheme.colorScheme.tertiary,
                            MaterialTheme.colorScheme.onTertiary,
                        )
                    }
                }
            }
        }

    // Separate colors for Previous/Next buttons in PRIMARY/TERTIARY modes
    val (sideButtonContainerColor, sideButtonContentColor) =
        when {
            playerBackground == PlayerBackgroundStyle.BLUR ||
                playerBackground == PlayerBackgroundStyle.GRADIENT -> {
                when (playerButtonsStyle) {
                    PlayerButtonsStyle.DEFAULT -> {
                        if (useDarkTheme) {
                            Pair(
                                Color.White.copy(alpha = 0.2f),
                                Color.White,
                            )
                        } else {
                            Pair(
                                Color.Black.copy(alpha = 0.2f),
                                Color.Black,
                            )
                        }
                    }

                    PlayerButtonsStyle.PRIMARY -> {
                        Pair(
                            MaterialTheme.colorScheme.primaryContainer,
                            MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    }

                    PlayerButtonsStyle.TERTIARY -> {
                        Pair(
                            MaterialTheme.colorScheme.tertiaryContainer,
                            MaterialTheme.colorScheme.onTertiaryContainer,
                        )
                    }
                }
            }

            else -> {
                when (playerButtonsStyle) {
                    PlayerButtonsStyle.DEFAULT -> {
                        Pair(
                            MaterialTheme.colorScheme.surfaceContainerHighest,
                            MaterialTheme.colorScheme.onSurface,
                        )
                    }

                    PlayerButtonsStyle.PRIMARY -> {
                        Pair(
                            MaterialTheme.colorScheme.primaryContainer,
                            MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    }

                    PlayerButtonsStyle.TERTIARY -> {
                        Pair(
                            MaterialTheme.colorScheme.tertiaryContainer,
                            MaterialTheme.colorScheme.onTertiaryContainer,
                        )
                    }
                }
            }
        }

    val database = LocalDatabase.current
    val download by LocalDownloadUtil.current
        .getDownload(mediaMetadata?.id ?: "")
        .collectAsStateWithLifecycle(initialValue = null)

    val sleepTimerEnabled =
        remember(
            playerConnection.service.sleepTimer?.triggerTime,
            playerConnection.service.sleepTimer?.pauseWhenSongEnd,
        ) {
            playerConnection.service.sleepTimer?.isActive ?: false
        }

    var sleepTimerTimeLeft by remember {
        mutableLongStateOf(0L)
    }

    LaunchedEffect(sleepTimerEnabled) {
        if (sleepTimerEnabled) {
            while (isActive) {
                sleepTimerTimeLeft =
                    if (playerConnection.service.sleepTimer?.pauseWhenSongEnd == true) {
                        playerConnection.player.duration - playerConnection.player.currentPosition
                    } else {
                        (playerConnection.service.sleepTimer?.triggerTime ?: 0L) - System.currentTimeMillis()
                    }
                delay(1000L)
            }
        }
    }

    val scope = rememberCoroutineScope()
    var showSleepTimerDialog by remember {
        mutableStateOf(false)
    }

    val sleepTimerDefault by rememberPreference(SleepTimerDefaultKey, 30f)
    var sleepTimerValue by remember {
        mutableFloatStateOf(sleepTimerDefault)
    }
    val isAtDefault by remember {
        derivedStateOf { sleepTimerValue.roundToInt() == sleepTimerDefault.roundToInt() }
    }
    val sleepTimerStopAfterCurrentSong by rememberPreference(SleepTimerStopAfterCurrentSongKey, false)
    val sleepTimerFadeOut by rememberPreference(SleepTimerFadeOutKey, false)


    PlayerSleepTimerDialog(
        isVisible = showSleepTimerDialog,
        onDismiss = { showSleepTimerDialog = false },
        playerConnection = playerConnection,
    )

    var showChoosePlaylistDialog by rememberSaveable {
        mutableStateOf(false)
    }

    // Position update - only for local playback
    // When casting, we use castPosition directly to avoid sync issues
    // Use isPlaying instead of playbackState to ensure continuous updates during playback
    LaunchedEffect(isPlaying, isCasting) {
        if (!isCasting && isPlaying) {
            while (isActive) {
                delay(100) // Update more frequently for smoother progress bar
                if (sliderPosition == null) { // Only update if user isn't dragging
                    position = playerConnection.player.currentPosition
                    // Don't clobber a valid (metadata-derived) duration with 0/UNSET mid-resolve.
                    playerConnection.player.duration.takeIf { it > 0 }?.let { duration = it }
                }
            }
        }
    }

    // Also update position when playback state changes (e.g., song change, seek)
    LaunchedEffect(playbackState, mediaMetadata?.id) {
        if (!isCasting) {
            position = playerConnection.player.currentPosition
            // Prefer the song's known duration (from metadata, available instantly from the restored
            // queue) so the slider range is right even when restored paused / before the stream
            // resolves; fall back to the player's duration once it is known.
            duration = (mediaMetadata?.duration?.takeIf { it > 0 }?.toLong()?.times(1000L))
                ?: playerConnection.player.duration
        }
    }

    // Auto-switch from repeat one to repeat all when song ends naturally
    var previousMediaId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(playbackState, mediaMetadata?.id) {
        val currentId = mediaMetadata?.id

        // Only switch from REPEAT_ONE to REPEAT_ALL when playback naturally ended
        // (i.e., the player transitioned to ENDED state and then moved to next track).
        // Do NOT switch on manual skips.
        if (currentId != null &&
            currentId != previousMediaId &&
            previousMediaId != null &&
            playbackState == Player.STATE_ENDED &&
            repeatMode == Player.REPEAT_MODE_ONE &&
            !isListenTogetherGuest) {
            playerConnection.player.setRepeatMode(Player.REPEAT_MODE_ALL)
        }

        previousMediaId = currentId
    }

    // When casting, use Cast position/duration directly
    // But wait a bit after manual seeks to let Cast catch up
    LaunchedEffect(isCasting, castPosition, castDuration) {
        if (isCasting && sliderPosition == null) {
            val timeSinceManualSeek = System.currentTimeMillis() - lastManualSeekTime
            if (timeSinceManualSeek > 1500) {
                // Only update from Cast if we haven't manually seeked recently
                position = castPosition
                if (castDuration > 0) duration = castDuration
            }
        }
    }

    val dismissedBound = QueuePeekHeight + WindowInsets.systemBars.asPaddingValues().calculateBottomPadding()

    val queueSheetState =
        rememberBottomSheetState(
            dismissedBound = dismissedBound,
            expandedBound = state.expandedBound,
            collapsedBound = dismissedBound + 1.dp,
            initialAnchor = 1,
        )

    val bottomSheetBackgroundColor =
        when (playerBackground) {
            PlayerBackgroundStyle.BLUR, PlayerBackgroundStyle.GRADIENT -> {
                MaterialTheme.colorScheme.surfaceContainer
            }

            else -> {
                if (useBlackBackground) {
                    Color.Black
                } else {
                    MaterialTheme.colorScheme.surfaceContainer
                }
            }
        }

    val backgroundAlpha = state.progress.coerceIn(0f, 1f)

    BottomSheet(
        state = state,
        modifier = modifier,
        background = {
            Box(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .then(
                            if (isGlassPlayerActive) {
                                Modifier.liquidGlass(
                                    enabled = true,
                                    blurRadiusDp = glassBlurRadius,
                                    saturation = glassSaturation,
                                    refractionHeight = lensRefractionHeight,
                                    refractionAmount = lensRefractionAmount,
                                    chromaticAberration = chromaticAberration,
                                    depthEffect = depthEffect,
                                    surfaceOpacity = surfaceOpacity,
                                    surfaceTintColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                    dominantColor = dominantColor,
                                    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
                                )
                            } else {
                                Modifier.background(bottomSheetBackgroundColor)
                            }
                        ),
            ) {
                when (playerBackground) {
                    PlayerBackgroundStyle.BLUR -> {
                        AnimatedContent(
                            targetState = mediaMetadata?.thumbnailUrl,
                            transitionSpec = {
                                fadeIn(tween(800)).togetherWith(fadeOut(tween(800)))
                            },
                            label = "blurBackground",
                        ) { thumbnailUrl ->
                            if (thumbnailUrl != null) {
                                Box(modifier = Modifier.alpha(backgroundAlpha)) {
                                    AsyncImage(
                                        model =
                                            ImageRequest
                                                .Builder(context)
                                                .data(thumbnailUrl)
                                                .size(50, 50)
                                                .build(),
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier =
                                            Modifier
                                                .fillMaxSize()
                                                .blur(if (useDarkTheme) 12.dp else 10.dp),
                                    )
                                    Box(
                                        modifier =
                                            Modifier
                                                .fillMaxSize()
                                                .background(if (useDarkTheme) Color.Black.copy(alpha = 0.3f) else Color.White.copy(alpha = 0.45f)),
                                    )
                                }
                            }
                        }
                    }

                    PlayerBackgroundStyle.GRADIENT -> {
                        AnimatedContent(
                            targetState = gradientColors,
                            transitionSpec = {
                                fadeIn(tween(800)).togetherWith(fadeOut(tween(800)))
                            },
                            label = "gradientBackground",
                        ) { colors ->
                            if (colors.isNotEmpty()) {
                                val gradientColorStops =
                                    if (colors.size >= 3) {
                                        arrayOf(
                                            0.0f to colors[0],
                                            0.5f to colors[1],
                                            1.0f to colors[2],
                                        )
                                    } else {
                                        arrayOf(
                                            0.0f to colors[0],
                                            0.6f to colors[0].copy(alpha = 0.7f),
                                            1.0f to Color.Black,
                                        )
                                    }
                                Box(
                                    Modifier
                                        .fillMaxSize()
                                        .alpha(backgroundAlpha)
                                        .background(Brush.verticalGradient(colorStops = gradientColorStops))
                                        .background(if (useDarkTheme) Color.Black.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.35f)),
                                )
                            }
                        }
                    }

                    else -> {
                        PlayerBackgroundStyle.DEFAULT
                    }
                }

                // Center-aligned subtle logo watermark
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .alpha(backgroundAlpha),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.foundation.Image(
                        painter = painterResource(R.drawable.app_logo),
                        contentDescription = null,
                        modifier = Modifier
                            .size(240.dp)
                            .aspectRatio(1f)
                            .alpha(if (useDarkTheme) 0.12f else 0.08f),
                        contentScale = androidx.compose.ui.layout.ContentScale.Fit
                    )
                }
            }
        },
        onDismiss =
            if (!isListenTogetherGuest) {
                {
                    playerConnection.service.clearAutomix()
                    playerConnection.player.stop()
                    playerConnection.player.clearMediaItems()
                }
            } else {
                null
            },
        collapsedContent = {
            MiniPlayer(
                positionState = positionState,
                durationState = durationState,
                onClick = { state.expandSoft() },
            )
        },
    ) {
        val controlsContent: @Composable ColumnScope.(MediaMetadata) -> Unit = { mediaMetadata ->
            val playPauseRoundness by animateDpAsState(
                targetValue = if (isPlaying) 24.dp else 36.dp,
                animationSpec = tween(durationMillis = 90, easing = LinearEasing),
                label = "playPauseRoundness",
            )

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = PlayerHorizontalPadding),
            ) {
                AnimatedContent(
                    targetState = showInlineLyrics,
                    label = "ThumbnailAnimation",
                ) { showLyrics ->
                    if (showLyrics) {
                        Row {
                            if (hidePlayerThumbnail) {
                                Box(
                                    modifier =
                                        Modifier
                                            .size(56.dp)
                                            .clip(RoundedCornerShape(ThumbnailCornerRadius))
                                            .background(MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.small_icon),
                                        contentDescription = null,
                                        modifier =
                                            Modifier
                                                .size(32.dp)
                                    )
                                }
                            } else {
                                AnimatedContent(
                                    targetState = mediaMetadata.thumbnailUrl,
                                    transitionSpec = { fadeIn(tween(400)) togetherWith fadeOut(tween(400)) },
                                    label = "smallThumbnailFade",
                                ) { url ->
                                    AsyncImage(
                                        model = url,
                                        contentDescription = null,
                                        contentScale = if (cropAlbumArt) ContentScale.Crop else ContentScale.Fit,
                                        modifier =
                                            Modifier
                                                .size(56.dp)
                                                .clip(RoundedCornerShape(ThumbnailCornerRadius)),
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                        }
                    } else {
                        Spacer(modifier = Modifier.width(0.dp))
                    }
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .pointerInput(Unit) {
                            var totalDragX = 0f
                            detectHorizontalDragGestures(
                                onDragStart = { totalDragX = 0f },
                                onHorizontalDrag = { _, dragAmount -> totalDragX += dragAmount },
                                onDragEnd = {
                                    if (totalDragX < -80f && playerConnection.player.nextMediaItemIndex != -1) {
                                        playerConnection.player.seekToNext()
                                    } else if (totalDragX > 80f && playerConnection.player.previousMediaItemIndex != -1) {
                                        playerConnection.player.seekToPreviousMediaItem()
                                    }
                                }
                            )
                        },
                ) {
                    AnimatedContent(
                        targetState = mediaMetadata.title,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "",
                    ) { title ->
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = TextBackgroundColor,
                            modifier =
                                Modifier
                                    .basicMarquee(iterations = 1, initialDelayMillis = 3000, velocity = 30.dp)
                                    .combinedClickable(
                                        enabled = true,
                                        indication = null,
                                        interactionSource = remember { MutableInteractionSource() },
                                        onClick = {
                                            val albumId = mediaMetadata.album?.id
                                                ?: currentSong?.album?.id
                                                ?: currentSong?.song?.albumId
                                            if (albumId != null) {
                                                navController.navigate("album/$albumId")
                                                state.collapseSoft()
                                            }
                                        },
                                        onLongClick = {
                                            Toast
                                                .makeText(context, "Sao chép bị hạn chế để bảo vệ bản quyền.", Toast.LENGTH_SHORT)
                                                .show()
                                        },
                                    ),
                        )
                    }

                    AnimatedContent(
                        targetState = mediaMetadata.id,
                        transitionSpec = { fadeIn(tween(400)) togetherWith fadeOut(tween(400)) },
                        label = "artistAnimation",
                    ) { _ ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            if (mediaMetadata.explicit) MIcon.Explicit()

                            val validArtists = mediaMetadata.artists.filter { it.name.isNotBlank() }
                            if (validArtists.isNotEmpty()) {
                                val annotatedString =
                                    buildAnnotatedString {
                                        validArtists.forEachIndexed { index, artist ->
                                            val tag = "artist_${artist.id.orEmpty()}"
                                            pushStringAnnotation(tag = tag, annotation = artist.id.orEmpty())
                                            withStyle(SpanStyle(color = TextBackgroundColor, fontSize = 16.sp)) {
                                                append(artist.name)
                                            }
                                            pop()
                                            if (index != validArtists.lastIndex) append(", ")
                                        }
                                    }

                                Box(
                                    modifier =
                                        Modifier
                                            .fillMaxWidth()
                                            .basicMarquee(iterations = 1, initialDelayMillis = 3000, velocity = 30.dp)
                                            .padding(end = 12.dp),
                                ) {
                                    var layoutResult by remember { mutableStateOf<TextLayoutResult?>(null) }
                                    var clickOffset by remember { mutableStateOf<Offset?>(null) }
                                    Text(
                                        text = annotatedString,
                                        style = MaterialTheme.typography.titleMedium.copy(color = TextBackgroundColor),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        onTextLayout = { layoutResult = it },
                                        modifier =
                                            Modifier
                                                .pointerInput(Unit) {
                                                    awaitPointerEventScope {
                                                        while (true) {
                                                            val event = awaitPointerEvent()
                                                            val tapPosition = event.changes.firstOrNull()?.position
                                                            if (tapPosition != null) {
                                                                clickOffset = tapPosition
                                                            }
                                                        }
                                                    }
                                                }.combinedClickable(
                                                    enabled = true,
                                                    indication = null,
                                                    interactionSource = remember { MutableInteractionSource() },
                                                    onClick = {
                                                        val tapPosition = clickOffset
                                                        val layout = layoutResult
                                                        if (tapPosition != null && layout != null) {
                                                            val offset = layout.getOffsetForPosition(tapPosition)
                                                            annotatedString
                                                                .getStringAnnotations(offset, offset)
                                                                .firstOrNull()
                                                                ?.let { ann ->
                                                                    val artistId = ann.item
                                                                    if (artistId.isNotBlank()) {
                                                                        navController.navigate("artist/$artistId")
                                                                        state.collapseSoft()
                                                                    }
                                                                }
                                                        }
                                                    },
                                                    onLongClick = {
                                                        Toast
                                                            .makeText(
                                                                context,
                                                                "Sao chép bị hạn chế để bảo vệ bản quyền.",
                                                                Toast.LENGTH_SHORT,
                                                            ).show()
                                                    },
                                                ),
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                if (useNewPlayerDesign) {
                    val buttonBorderColor = if (shouldUseDarkButtonColors) Color.White.copy(alpha = 0.15f) else Color.Black.copy(alpha = 0.15f)
                    val buttonContainerColor = if (shouldUseDarkButtonColors) Color.White.copy(alpha = 0.05f) else Color.Black.copy(alpha = 0.05f)
                    val buttonContentColor = if (shouldUseDarkButtonColors) Color.White else Color.Black

                    val buttonShape = RoundedCornerShape(16.dp)
                    val buttonBorder = androidx.compose.foundation.BorderStroke(1.dp, buttonBorderColor)
                    val buttonColors = IconButtonDefaults.outlinedIconButtonColors(
                        containerColor = buttonContainerColor,
                        contentColor = buttonContentColor
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        AnimatedContent(targetState = showInlineLyrics, label = "ShareButton") { showLyrics ->
                            if (showLyrics) {
                                androidx.compose.material3.OutlinedIconButton(
                                    onClick = { isFullScreen = !isFullScreen },
                                    shape = buttonShape,
                                    border = buttonBorder,
                                    colors = buttonColors,
                                    modifier = Modifier.size(44.dp),
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.fullscreen),
                                        contentDescription = null,
                                        modifier = Modifier.size(24.dp),
                                    )
                                }
                            } else {
                                androidx.compose.material3.OutlinedIconButton(
                                    onClick = {
                                        val intent =
                                            Intent().apply {
                                                action = Intent.ACTION_SEND
                                                type = "text/plain"
                                                putExtra(
                                                    Intent.EXTRA_TEXT,
                                                    "https://music.youtube.com/watch?v=${mediaMetadata.id}",
                                                )
                                            }
                                        context.startActivity(Intent.createChooser(intent, null))
                                    },
                                    shape = buttonShape,
                                    border = buttonBorder,
                                    colors = buttonColors,
                                    modifier = Modifier.size(44.dp),
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.share),
                                        contentDescription = null,
                                        modifier = Modifier.size(24.dp),
                                    )
                                }
                            }
                        }

                        AnimatedContent(targetState = showInlineLyrics, label = "LikeButton") { showLyrics ->
                            if (showLyrics) {
                                val currentLyrics by playerConnection.currentLyrics.collectAsStateWithLifecycle(initialValue = null)
                                androidx.compose.material3.OutlinedIconButton(
                                    onClick = {
                                        menuState.show {
                                            com.metrolist.music.ui.menu.LyricsMenu(
                                                lyricsProvider = { currentLyrics },
                                                songProvider = { currentSong?.song },
                                                mediaMetadataProvider = { mediaMetadata },
                                                onDismiss = menuState::dismiss,
                                                onShowOffsetDialog = {
                                                    bottomSheetPageState.show {
                                                        ShowOffsetDialog(
                                                            songProvider = { currentSong?.song },
                                                        )
                                                    }
                                                },
                                            )
                                        }
                                    },
                                    shape = buttonShape,
                                    border = buttonBorder,
                                    colors = buttonColors,
                                    modifier = Modifier.size(44.dp),
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.more_horiz),
                                        contentDescription = null,
                                        modifier = Modifier.size(24.dp),
                                    )
                                }
                            } else {
                                // For episodes, show saved state (inLibrary); for songs, show liked state
                                val isEpisode = currentSong?.song?.isEpisode == true
                                val isFavorite = if (isEpisode) currentSong?.song?.inLibrary != null else currentSong?.song?.liked == true
                                androidx.compose.material3.OutlinedIconButton(
                                    onClick = playerConnection::toggleLike,
                                    shape = buttonShape,
                                    border = buttonBorder,
                                    colors = buttonColors,
                                    modifier = Modifier.size(44.dp),
                                ) {
                                    Icon(
                                        painter =
                                            painterResource(
                                                if (isFavorite) {
                                                    R.drawable.favorite
                                                } else {
                                                    R.drawable.favorite_border
                                                },
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(24.dp),
                                    )
                                }
                            }
                        }

                        androidx.compose.material3.OutlinedIconButton(
                            onClick = {
                                if (download?.state == Download.STATE_COMPLETED || download?.state == Download.STATE_DOWNLOADING || download?.state == Download.STATE_QUEUED) {
                                    DownloadService.sendRemoveDownload(
                                        context,
                                        ExoDownloadService::class.java,
                                        mediaMetadata.id,
                                        false,
                                    )
                                } else {
                                    database.transaction {
                                        insert(mediaMetadata)
                                    }
                                    val downloadRequest =
                                        DownloadRequest
                                            .Builder(mediaMetadata.id, mediaMetadata.id.toUri())
                                            .setCustomCacheKey(mediaMetadata.id)
                                            .setData(mediaMetadata.title.toByteArray())
                                            .build()
                                    DownloadService.sendAddDownload(
                                        context,
                                        ExoDownloadService::class.java,
                                        downloadRequest,
                                        false,
                                    )
                                }
                            },
                            shape = buttonShape,
                            border = buttonBorder,
                            colors = buttonColors,
                            modifier = Modifier.size(44.dp),
                        ) {
                            when (download?.state) {
                                Download.STATE_COMPLETED -> {
                                    Icon(
                                        painter = painterResource(R.drawable.offline),
                                        contentDescription = "Remove Download",
                                        modifier = Modifier.size(24.dp),
                                    )
                                }
                                Download.STATE_QUEUED, Download.STATE_DOWNLOADING -> {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        strokeWidth = 2.dp,
                                        color = buttonContentColor,
                                    )
                                }
                                else -> {
                                    Icon(
                                        painter = painterResource(R.drawable.download),
                                        contentDescription = "Download Song",
                                        modifier = Modifier.size(24.dp),
                                    )
                                }
                            }
                        }

                        androidx.compose.material3.OutlinedIconButton(
                            onClick = {
                                bottomSheetPageState.show {
                                    ShowMediaInfo(mediaMetadata.id)
                                }
                            },
                            shape = buttonShape,
                            border = buttonBorder,
                            colors = buttonColors,
                            modifier = Modifier.size(44.dp),
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.info),
                                contentDescription = "Song Info",
                                modifier = Modifier.size(24.dp),
                            )
                        }
                    }
                } else {
                    AnimatedContent(targetState = showInlineLyrics, label = "ShareButton") { showLyrics ->
                        if (showLyrics) {
                            Box(
                                modifier =
                                    Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(24.dp))
                                        .background(textButtonColor)
                                        .clickable { isFullScreen = !isFullScreen },
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.fullscreen),
                                    contentDescription = null,
                                    tint = iconButtonColor,
                                    modifier =
                                        Modifier
                                            .align(Alignment.Center)
                                            .size(24.dp),
                                )
                            }
                        } else {
                            Box(
                                modifier =
                                    Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(24.dp))
                                        .background(textButtonColor)
                                        .clickable {
                                            val intent =
                                                Intent().apply {
                                                    action = Intent.ACTION_SEND
                                                    type = "text/plain"
                                                    putExtra(
                                                        Intent.EXTRA_TEXT,
                                                        "https://music.youtube.com/watch?v=${mediaMetadata.id}",
                                                    )
                                                }
                                            context.startActivity(Intent.createChooser(intent, null))
                                        },
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.share),
                                    contentDescription = null,
                                    tint = iconButtonColor,
                                    modifier =
                                        Modifier
                                            .align(Alignment.Center)
                                            .size(24.dp),
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.size(12.dp))

                    Box(
                        modifier =
                            Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(textButtonColor)
                                .clickable { isStandbyMode = true },
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.bedtime),
                            contentDescription = "Màn hình chờ",
                            tint = iconButtonColor,
                            modifier =
                                Modifier
                                    .align(Alignment.Center)
                                    .size(24.dp),
                        )
                    }

                    Spacer(modifier = Modifier.size(12.dp))

                    Box(
                        modifier =
                            Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(textButtonColor)
                                .clickable {
                                    if (download?.state == Download.STATE_COMPLETED || download?.state == Download.STATE_DOWNLOADING || download?.state == Download.STATE_QUEUED) {
                                        DownloadService.sendRemoveDownload(
                                            context,
                                            ExoDownloadService::class.java,
                                            mediaMetadata.id,
                                            false,
                                        )
                                    } else {
                                        database.transaction {
                                            insert(mediaMetadata)
                                        }
                                        val downloadRequest =
                                            DownloadRequest
                                                .Builder(mediaMetadata.id, mediaMetadata.id.toUri())
                                                .setCustomCacheKey(mediaMetadata.id)
                                                .setData(mediaMetadata.title.toByteArray())
                                                .build()
                                        DownloadService.sendAddDownload(
                                            context,
                                            ExoDownloadService::class.java,
                                            downloadRequest,
                                            false,
                                        )
                                    }
                                },
                    ) {
                        when (download?.state) {
                            Download.STATE_COMPLETED -> {
                                Icon(
                                    painter = painterResource(R.drawable.offline),
                                    contentDescription = "Remove Download",
                                    tint = iconButtonColor,
                                    modifier = Modifier.align(Alignment.Center).size(24.dp),
                                )
                            }
                            Download.STATE_QUEUED, Download.STATE_DOWNLOADING -> {
                                CircularProgressIndicator(
                                    modifier = Modifier.align(Alignment.Center).size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = iconButtonColor,
                                )
                            }
                            else -> {
                                Icon(
                                    painter = painterResource(R.drawable.download),
                                    contentDescription = "Download Song",
                                    tint = iconButtonColor,
                                    modifier = Modifier.align(Alignment.Center).size(24.dp),
                                )
                            }
                        }
                    }

                    if (showInlineLyrics) {
                        Spacer(modifier = Modifier.size(12.dp))

                        val currentLyrics by playerConnection.currentLyrics.collectAsStateWithLifecycle(initialValue = null)
                        Box(
                            modifier =
                                Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(24.dp))
                                    .background(textButtonColor)
                                    .clickable {
                                        menuState.show {
                                            com.metrolist.music.ui.menu.LyricsMenu(
                                                lyricsProvider = { currentLyrics },
                                                songProvider = { currentSong?.song },
                                                mediaMetadataProvider = { mediaMetadata },
                                                onDismiss = menuState::dismiss,
                                                onShowOffsetDialog = {
                                                    bottomSheetPageState.show {
                                                        ShowOffsetDialog(
                                                            songProvider = { currentSong?.song },
                                                        )
                                                    }
                                                },
                                            )
                                        }
                                    },
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.more_horiz),
                                contentDescription = null,
                                tint = iconButtonColor,
                                modifier =
                                    Modifier
                                        .align(Alignment.Center)
                                        .size(24.dp),
                            )
                        }
                    }
                }
            }

            if (realTimeVisualizerEnabled) {
                Spacer(Modifier.height(12.dp))
                RealTimeAudioVisualizer(
                    isPlaying = effectiveIsPlaying,
                    style = realTimeVisualizerStyle,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(32.dp)
                        .padding(horizontal = PlayerHorizontalPadding),
                    color = textButtonColor
                )
                Spacer(Modifier.height(12.dp))
            } else {
                Spacer(Modifier.height(24.dp))
            }

            val maxDurationFloat = if (duration == C.TIME_UNSET) 0f else duration.toFloat()
            val currentTargetPosition = (sliderPosition ?: effectivePosition).toFloat()
            val animatedSliderPosition by animateFloatAsState(
                targetValue = currentTargetPosition,
                animationSpec = if (sliderPosition != null) {
                    snap()
                } else if (effectiveIsPlaying) {
                    tween(durationMillis = 1000, easing = LinearEasing)
                } else {
                    spring()
                },
                label = "AnimatedSeekBar"
            )
            val activeSliderValue = if (sliderPosition != null) currentTargetPosition else animatedSliderPosition.coerceIn(0f, maxDurationFloat)

            when (sliderStyle) {
                SliderStyle.DEFAULT -> {
                    Slider(
                        value = activeSliderValue,
                        valueRange = 0f..maxDurationFloat,
                        onValueChange = {
                            if (!isListenTogetherGuest) {
                                sliderPosition = it.toLong()
                            }
                        },
                        onValueChangeFinished = {
                            if (!isListenTogetherGuest) {
                                sliderPosition?.let {
                                    if (isCasting) {
                                        castHandler?.seekTo(it)
                                        lastManualSeekTime = System.currentTimeMillis()
                                    } else {
                                        playerConnection.player.seekTo(it)
                                    }
                                    position = it
                                }
                                sliderPosition = null
                            }
                        },
                        enabled = !isListenTogetherGuest,
                        colors = PlayerSliderColors.getSliderColors(textButtonColor, playerBackground, useDarkTheme),
                        modifier = Modifier.padding(horizontal = PlayerHorizontalPadding),
                    )
                }

                SliderStyle.WAVY -> {
                    if (squigglySlider) {
                        SquigglySlider(
                            value = activeSliderValue,
                            valueRange = 0f..maxDurationFloat,
                            onValueChange = {
                                sliderPosition = it.toLong()
                            },
                            onValueChangeFinished = {
                                sliderPosition?.let {
                                    if (isCasting) {
                                        castHandler?.seekTo(it)
                                        lastManualSeekTime = System.currentTimeMillis()
                                    } else {
                                        playerConnection.player.seekTo(it)
                                    }
                                    position = it
                                }
                                sliderPosition = null
                            },
                            modifier = Modifier.padding(horizontal = PlayerHorizontalPadding),
                            colors = PlayerSliderColors.getSliderColors(textButtonColor, playerBackground, useDarkTheme),
                            isPlaying = effectiveIsPlaying,
                        )
                    } else {
                        WavySlider(
                            value = activeSliderValue,
                            valueRange = 0f..maxDurationFloat,
                            onValueChange = {
                                sliderPosition = it.toLong()
                            },
                            onValueChangeFinished = {
                                sliderPosition?.let {
                                    if (isCasting) {
                                        castHandler?.seekTo(it)
                                        lastManualSeekTime = System.currentTimeMillis()
                                    } else {
                                        playerConnection.player.seekTo(it)
                                    }
                                    position = it
                                }
                                sliderPosition = null
                            },
                            colors = PlayerSliderColors.getSliderColors(textButtonColor, playerBackground, useDarkTheme),
                            modifier = Modifier.padding(horizontal = PlayerHorizontalPadding),
                            isPlaying = effectiveIsPlaying,
                        )
                    }
                }

                SliderStyle.SLIM -> {
                    Slider(
                        value = activeSliderValue,
                        valueRange = 0f..maxDurationFloat,
                        onValueChange = {
                            if (!isListenTogetherGuest) {
                                sliderPosition = it.toLong()
                            }
                        },
                        onValueChangeFinished = {
                            if (!isListenTogetherGuest) {
                                sliderPosition?.let {
                                    if (isCasting) {
                                        castHandler?.seekTo(it)
                                        lastManualSeekTime = System.currentTimeMillis()
                                    } else {
                                        playerConnection.player.seekTo(it)
                                    }
                                    position = it
                                }
                                sliderPosition = null
                            }
                        },
                        enabled = !isListenTogetherGuest,
                        thumb = { Spacer(modifier = Modifier.size(0.dp)) },
                        track = { sliderState ->
                            PlayerSliderTrack(
                                sliderState = sliderState,
                                colors = PlayerSliderColors.getSliderColors(textButtonColor, playerBackground, useDarkTheme),
                            )
                        },
                        modifier = Modifier.padding(horizontal = PlayerHorizontalPadding),
                    )
                }
            }

            Spacer(Modifier.height(4.dp))

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = PlayerHorizontalPadding + 4.dp),
            ) {
                Text(
                    text = makeTimeString(sliderPosition ?: effectivePosition),
                    style = MaterialTheme.typography.labelMedium,
                    color = TextBackgroundColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )

                if (showCodecOnPlayer) {
                    Text(
                        text = "Opus 160kbps • 48kHz",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextBackgroundColor.copy(alpha = 0.7f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }

                Text(
                    text = if (duration != C.TIME_UNSET) makeTimeString(duration) else "",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextBackgroundColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }


            Spacer(Modifier.height(24.dp))

            AnimatedVisibility(
                visible = !isFullScreen,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = shrinkVertically(shrinkTowards = Alignment.Top) + slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = PlayerHorizontalPadding),
                    ) {
                        // 1. Shuffle Button
                        Box(modifier = Modifier.weight(1.3f)) {
                            val shuffleModeEnabled by playerConnection.shuffleModeEnabled.collectAsStateWithLifecycle()
                            val (smartShuffle, onSmartShuffleChange) = rememberPreference(SmartShuffleKey, defaultValue = false)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.align(Alignment.Center)
                            ) {
                                ResizableIconButton(
                                    icon = if (shuffleModeEnabled) R.drawable.shuffle_on else R.drawable.shuffle,
                                    color = if (shuffleModeEnabled) MaterialTheme.colorScheme.primary else TextBackgroundColor,
                                    modifier =
                                        Modifier
                                            .size(32.dp)
                                            .padding(4.dp)
                                            .alpha(if (isListenTogetherGuest) 0.5f else 1f),
                                    enabled = !isListenTogetherGuest,
                                    onClick = {
                                        playerConnection.player.shuffleModeEnabled = !shuffleModeEnabled
                                    },
                                )
                                androidx.compose.material3.Surface(
                                    onClick = {
                                        val newState = !smartShuffle
                                        onSmartShuffleChange(newState)
                                        if (newState && !shuffleModeEnabled) {
                                            playerConnection.player.shuffleModeEnabled = true
                                        }
                                    },
                                    shape = CircleShape,
                                    color = if (smartShuffle) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier.padding(start = 2.dp)
                                ) {
                                    Text(
                                        text = "Smart",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (smartShuffle) androidx.compose.ui.text.font.FontWeight.Bold else androidx.compose.ui.text.font.FontWeight.Normal,
                                        color = if (smartShuffle) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        // 2. Skip Previous Button
                        Box(modifier = Modifier.weight(1f)) {
                            ResizableIconButton(
                                icon = R.drawable.skip_previous,
                                enabled = canSkipPrevious && !isListenTogetherGuest,
                                color = TextBackgroundColor,
                                modifier =
                                    Modifier
                                        .size(32.dp)
                                        .align(Alignment.Center)
                                        .alpha(if (isListenTogetherGuest) 0.5f else 1f),
                                onClick = playerConnection::seekToPrevious,
                            )
                        }

                        Spacer(Modifier.width(8.dp))

                        // 3. Play / Pause Button
                        Box(
                            modifier =
                                Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(playPauseRoundness))
                                    .background(textButtonColor)
                                    .clickable {
                                        if (isListenTogetherGuest) {
                                            playerConnection.toggleMute()
                                            return@clickable
                                        }
                                        if (isCasting) {
                                            if (castIsPlaying) {
                                                castHandler?.pause()
                                            } else {
                                                castHandler?.play()
                                            }
                                        } else if (playbackState == STATE_ENDED) {
                                            playerConnection.player.seekTo(0, 0)
                                            playerConnection.player.playWhenReady = true
                                        } else {
                                            playerConnection.player.togglePlayPause()
                                        }
                                    }
                                    .focusRequester(focusRequester),
                        ) {
                            Image(
                                painter =
                                    painterResource(
                                        if (isListenTogetherGuest) {
                                            if (isMuted) R.drawable.volume_off else R.drawable.volume_up
                                        } else if (playbackState ==
                                            STATE_ENDED
                                        ) {
                                            R.drawable.replay
                                        } else if (effectiveIsPlaying) {
                                            R.drawable.pause
                                        } else {
                                            R.drawable.play
                                        },
                                    ),
                                contentDescription = null,
                                colorFilter = ColorFilter.tint(iconButtonColor),
                                modifier =
                                    Modifier
                                        .align(Alignment.Center)
                                        .size(36.dp),
                            )
                        }

                        Spacer(Modifier.width(8.dp))

                        // 4. Skip Next Button
                        Box(modifier = Modifier.weight(1f)) {
                            ResizableIconButton(
                                icon = R.drawable.skip_next,
                                enabled = canSkipNext && !isListenTogetherGuest,
                                color = TextBackgroundColor,
                                modifier =
                                    Modifier
                                        .size(32.dp)
                                        .align(Alignment.Center)
                                        .alpha(if (isListenTogetherGuest) 0.5f else 1f),
                                onClick = playerConnection::seekToNext,
                            )
                        }

                        // 5. Repeat Button
                        Box(modifier = Modifier.weight(1f)) {
                            val isRepeatOff = repeatMode == Player.REPEAT_MODE_OFF
                            ResizableIconButton(
                                icon =
                                    when (repeatMode) {
                                        Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ALL -> R.drawable.repeat
                                        Player.REPEAT_MODE_ONE -> R.drawable.repeat_one
                                        else -> throw IllegalStateException()
                                    },
                                color = if (isRepeatOff) TextBackgroundColor else MaterialTheme.colorScheme.primary,
                                modifier =
                                    Modifier
                                        .size(32.dp)
                                        .padding(4.dp)
                                        .align(Alignment.Center)
                                        .alpha(if (isListenTogetherGuest) 0.5f else 1f),
                                enabled = !isListenTogetherGuest,
                                onClick = {
                                    playerConnection.player.toggleRepeatMode()
                                },
                            )
                        }
                    }
                }
            }
        }

        Box(modifier = Modifier.fillMaxSize()) {
            if (isStandbyMode) {
                StandbyScreen(
                    mediaMetadata = mediaMetadata,
                    isPlaying = isPlaying,
                    playerConnection = playerConnection,
                    onClose = { isStandbyMode = false }
                )
            } else {
                when (LocalConfiguration.current.orientation) {
                    Configuration.ORIENTATION_LANDSCAPE -> {
                        // Calculate vertical padding like OuterTune
                        val density = LocalDensity.current
                        val verticalPadding =
                            max(
                                WindowInsets.systemBars.getTop(density),
                                WindowInsets.systemBars.getBottom(density),
                            )
                        val verticalPaddingDp = with(density) { verticalPadding.toDp() }
                        val verticalWindowInsets = WindowInsets(left = 0.dp, top = verticalPaddingDp, right = 0.dp, bottom = verticalPaddingDp)

                        Row(
                            modifier =
                                Modifier
                                    .windowInsetsPadding(
                                        WindowInsets.systemBars.only(WindowInsetsSides.Horizontal).add(verticalWindowInsets),
                                    ).padding(bottom = 24.dp)
                                    .fillMaxSize(),
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier =
                                    Modifier
                                        .weight(1f)
                                        .nestedScroll(state.preUpPostDownNestedScrollConnection),
                            ) {
                                // Remember lambdas to prevent unnecessary recomposition
                                val currentSliderPosition by rememberUpdatedState(sliderPosition)
                                val sliderPositionProvider = remember { { currentSliderPosition } }
                                val isExpandedProvider = remember(state) { { state.isExpanded } }
                                AnimatedContent(
                                    targetState = showInlineLyrics,
                                    label = "Lyrics",
                                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                                ) { showLyrics ->
                                    if (showLyrics) {
                                        InlineLyricsView(
                                            mediaMetadata = mediaMetadata,
                                            showLyrics = showLyrics,
                                            positionProvider = { effectivePosition },
                                        )
                                    } else {
                                        Thumbnail(
                                            sliderPositionProvider = sliderPositionProvider,
                                            modifier = Modifier.animateContentSize(),
                                            isPlayerExpanded = isExpandedProvider,
                                            isLandscape = true,
                                            isListenTogetherGuest = isListenTogetherGuest,
                                        )
                                    }
                                }
                            }

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier =
                                    Modifier
                                        .weight(if (showInlineLyrics) 0.65f else 1f, false)
                                        .animateContentSize()
                                        .windowInsetsPadding(WindowInsets.systemBars.only(WindowInsetsSides.Top)),
                            ) {
                                Spacer(Modifier.weight(1f))

                                mediaMetadata?.let {
                                    controlsContent(it)
                                }

                                Spacer(Modifier.weight(1f))
                            }
                        }
                    }

                    else -> {
                        val bottomPadding by animateDpAsState(
                            targetValue = if (isFullScreen) 0.dp else queueSheetState.collapsedBound,
                            label = "bottomPadding",
                        )
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier =
                                Modifier
                                    .windowInsetsPadding(WindowInsets.systemBars.only(WindowInsetsSides.Horizontal))
                                    .padding(bottom = bottomPadding)
                                    .animateContentSize(),
                        ) {
                            PlayerTopBar(
                                state = state,
                                isVideoMode = isVideoMode,
                                onVideoModeChange = { isVideoMode = it },
                                mediaMetadata = mediaMetadata,
                                textButtonColor = textButtonColor,
                                iconButtonColor = iconButtonColor,
                                textColor = TextBackgroundColor,
                                onStandbyClick = { isStandbyMode = true },
                            )

                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.weight(1f),
                            ) {
                                // Remember lambdas to prevent unnecessary recomposition
                                val currentSliderPosition by rememberUpdatedState(sliderPosition)
                                val sliderPositionProvider = remember { { currentSliderPosition } }
                                val isExpandedProvider = remember(state) { { state.isExpanded } }
                                AnimatedContent(
                                    targetState = showInlineLyrics,
                                    label = "Lyrics",
                                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                                ) { showLyrics ->
                                    if (showLyrics) {
                                        InlineLyricsView(
                                            mediaMetadata = mediaMetadata,
                                            showLyrics = showLyrics,
                                            positionProvider = { effectivePosition },
                                        )
                                    } else {
                                        Thumbnail(
                                            sliderPositionProvider = sliderPositionProvider,
                                            modifier = Modifier.nestedScroll(state.preUpPostDownNestedScrollConnection),
                                            isPlayerExpanded = isExpandedProvider,
                                            isListenTogetherGuest = isListenTogetherGuest,
                                            isVideoMode = isVideoMode,
                                        )
                                    }
                                }
                            }

                            mediaMetadata?.let {
                                controlsContent(it)
                            }

                            Spacer(Modifier.height(30.dp))
                        }
                    }
                }

                AnimatedVisibility(
                    visible = !isFullScreen,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = shrinkVertically(shrinkTowards = Alignment.Top) + slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                ) {
                    Queue(
                        state = queueSheetState,
                        playerBottomSheetState = state,
                        background =
                            if (useBlackBackground) {
                                Color.Black
                            } else {
                                MaterialTheme.colorScheme.surfaceContainer
                            },
                        onBackgroundColor = onBackgroundColor,
                        TextBackgroundColor = TextBackgroundColor,
                        textButtonColor = textButtonColor,
                        iconButtonColor = iconButtonColor,
                        pureBlack = pureBlack,
                        showInlineLyrics = showInlineLyrics,
                        playerBackground = playerBackground,
                        onToggleLyrics = {
                            showInlineLyrics = !showInlineLyrics
                        },
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun InlineLyricsView(
    mediaMetadata: MediaMetadata?,
    showLyrics: Boolean,
    positionProvider: () -> Long,
) {
    val playerConnection = LocalPlayerConnection.current ?: return
    val currentLyrics by playerConnection.currentLyrics.collectAsStateWithLifecycle(initialValue = null)
    val queueWindows by playerConnection.queueWindows.collectAsStateWithLifecycle(initialValue = emptyList())
    val currentWindowIndex by playerConnection.currentWindowIndex.collectAsStateWithLifecycle(initialValue = -1)
    val lyrics = remember(currentLyrics) { currentLyrics?.lyrics?.trim() }
    val context = LocalContext.current
    val database = LocalDatabase.current
    val coroutineScope = rememberCoroutineScope()

    var appInForeground by remember {
        mutableStateOf(
            ProcessLifecycleOwner.get().lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED),
        )
    }
    DisposableEffect(Unit) {
        val lifecycle = ProcessLifecycleOwner.get().lifecycle
        val observer =
            LifecycleEventObserver { _, _ ->
                appInForeground = lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
            }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }

    val nextMetadata =
        remember(queueWindows, currentWindowIndex) {
            if (currentWindowIndex >= 0 && currentWindowIndex + 1 < queueWindows.size) {
                queueWindows[currentWindowIndex + 1].mediaItem.metadata
            } else {
                null
            }
        }

    LaunchedEffect(mediaMetadata?.id, currentLyrics) {
        if (mediaMetadata != null && currentLyrics == null) {
            delay(500)
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val entryPoint =
                        EntryPointAccessors.fromApplication(
                            context.applicationContext,
                            com.metrolist.music.di.LyricsHelperEntryPoint::class.java,
                        )
                    val lyricsHelper = entryPoint.lyricsHelper()
                    val fetchedLyricsWithProvider = lyricsHelper.getLyrics(mediaMetadata)
                    database.query {
                        upsert(LyricsEntity(mediaMetadata.id, fetchedLyricsWithProvider.lyrics, fetchedLyricsWithProvider.provider))
                    }
                } catch (e: Exception) {
                    // Handle error
                }
            }
        }
    }

    // Prefetch lyrics for the next queue item only while the lyrics pane is visible, the app is in the
    // foreground, and the current track's lyrics row has finished loading (avoids competing with the
    // active fetch).
    LaunchedEffect(
        nextMetadata?.id,
        showLyrics,
        appInForeground,
        mediaMetadata?.id,
        currentLyrics,
    ) {
        if (!showLyrics || !appInForeground || nextMetadata == null) return@LaunchedEffect
        val loadedForCurrent =
            currentLyrics?.let { lyrics ->
                mediaMetadata == null || lyrics.id == mediaMetadata.id
            } == true
        if (mediaMetadata != null && !loadedForCurrent) return@LaunchedEffect
        val nextId = nextMetadata.id
        delay(400)
        if (!showLyrics || !appInForeground || !isActive) return@LaunchedEffect
        withContext(Dispatchers.IO) {
            try {
                val existing = database.lyrics(nextId).first()
                if (existing != null) return@withContext
                val entryPoint =
                    EntryPointAccessors.fromApplication(
                        context.applicationContext,
                        com.metrolist.music.di.LyricsHelperEntryPoint::class.java,
                    )
                val lyricsHelper = entryPoint.lyricsHelper()
                val fetched = lyricsHelper.getLyrics(nextMetadata)
                database.query {
                    upsert(LyricsEntity(nextId, fetched.lyrics, fetched.provider))
                }
            } catch (_: Exception) {
            }
        }
    }

    val enableLiquidGlass by rememberPreference(EnableLiquidGlassKey, defaultValue = true)
    val glassSaturation by rememberPreference(GlassSaturationKey, defaultValue = 1.3f)
    val glassBlurRadius by rememberPreference(GlassBlurRadiusKey, defaultValue = 24f)
    val lensRefractionHeight by rememberPreference(LensRefractionHeightKey, defaultValue = 14f)
    val lensRefractionAmount by rememberPreference(LensRefractionAmountKey, defaultValue = 0.85f)
    val chromaticAberration by rememberPreference(ChromaticAberrationKey, defaultValue = 0.45f)
    val depthEffect by rememberPreference(DepthEffectKey, defaultValue = 0.75f)
    val surfaceOpacity by rememberPreference(SurfaceOpacityKey, defaultValue = 1.0f)
    val pureBlack by rememberPreference(PureBlackKey, defaultValue = false)

    val lyricsBgColor = if (pureBlack) Color.Black else MaterialTheme.colorScheme.surfaceContainerHigh

    Box(
        modifier =
            Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp, vertical = 4.dp)
                .then(
                    if (enableLiquidGlass) {
                        Modifier.liquidGlass(
                            enabled = true,
                            blurRadiusDp = glassBlurRadius,
                            saturation = glassSaturation,
                            refractionHeight = lensRefractionHeight,
                            refractionAmount = lensRefractionAmount,
                            chromaticAberration = chromaticAberration,
                            depthEffect = depthEffect,
                            surfaceOpacity = surfaceOpacity,
                            surfaceTintColor = lyricsBgColor,
                            shape = RoundedCornerShape(20.dp)
                        )
                    } else {
                        Modifier.background(lyricsBgColor, shape = RoundedCornerShape(20.dp))
                    }
                )
                .pointerInput(Unit) {
                    var totalDragX = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { totalDragX = 0f },
                        onHorizontalDrag = { _, dragAmount -> totalDragX += dragAmount },
                        onDragEnd = {
                            if (totalDragX < -80f && playerConnection.player.nextMediaItemIndex != -1) {
                                playerConnection.player.seekToNext()
                            } else if (totalDragX > 80f && playerConnection.player.previousMediaItemIndex != -1) {
                                playerConnection.player.seekToPreviousMediaItem()
                            }
                        }
                    )
                },
        contentAlignment = Alignment.Center,
    ) {
        when {
            lyrics == null -> {
                ContainedLoadingIndicator()
            }

            lyrics == LyricsEntity.LYRICS_NOT_FOUND -> {
                Text(
                    text = stringResource(R.string.lyrics_not_found),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center,
                )
            }

            else -> {
                val lyricsContent: @Composable () -> Unit = {
                    Lyrics(
                        sliderPositionProvider = positionProvider,
                        modifier = Modifier.padding(horizontal = 24.dp),
                        showLyrics = showLyrics,
                    )
                }
                ProvideTextStyle(
                    value =
                        MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center,
                        ),
                ) {
                    lyricsContent()
                }
            }
        }
    }
}

@Composable
fun MoreActionsButton(
    mediaMetadata: MediaMetadata,
    navController: NavController,
    state: BottomSheetState,
    textButtonColor: Color,
    iconButtonColor: Color,
) {
    val menuState = LocalMenuState.current
    val bottomSheetPageState = LocalBottomSheetPageState.current

    Box(
        modifier =
            Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(textButtonColor)
                .clickable {
                    menuState.show {
                        PlayerMenu(
                            mediaMetadata = mediaMetadata,
                            playerBottomSheetState = state,
                            onShowDetailsDialog = {
                                mediaMetadata.id.let {
                                    bottomSheetPageState.show {
                                        ShowMediaInfo(it)
                                    }
                                }
                            },
                            onDismiss = menuState::dismiss,
                        )
                    }
                },
    ) {
        Image(
            painter = painterResource(R.drawable.more_horiz),
            contentDescription = null,
            colorFilter = ColorFilter.tint(iconButtonColor),
        )
    }
}

@Composable
private fun PlayerTopBar(
    state: BottomSheetState,
    isVideoMode: Boolean,
    onVideoModeChange: (Boolean) -> Unit,
    mediaMetadata: MediaMetadata?,
    textButtonColor: Color,
    iconButtonColor: Color,
    textColor: Color,
    onStandbyClick: () -> Unit,
) {
    val menuState = LocalMenuState.current
    val bottomSheetPageState = LocalBottomSheetPageState.current

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Collapse button (down arrow)
        androidx.compose.material3.IconButton(
            onClick = { state.collapseSoft() },
            modifier = Modifier.size(48.dp)
        ) {
            Icon(
                painter = painterResource(R.drawable.expand_more),
                contentDescription = "Collapse Player",
                tint = textColor,
                modifier = Modifier.size(28.dp)
            )
        }

        // Audio/Video switcher pill
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
                .clip(RoundedCornerShape(24.dp))
                .background(Color.White.copy(alpha = 0.08f))
                .padding(2.dp)
        ) {
            // Audio tab (Song)
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(width = 56.dp, height = 36.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (!isVideoMode) Color.White else Color.Transparent)
                    .clickable { onVideoModeChange(false) }
            ) {
                Icon(
                    painter = painterResource(R.drawable.headphone),
                    contentDescription = "Audio mode",
                    tint = if (!isVideoMode) Color(0xFF1C1C1C) else Color.White.copy(alpha = 0.6f),
                    modifier = Modifier.size(20.dp)
                )
            }

            // Video tab
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(width = 56.dp, height = 36.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (isVideoMode) Color.White else Color.Transparent)
                    .clickable { onVideoModeChange(true) }
            ) {
                Icon(
                    painter = painterResource(R.drawable.video_mode),
                    contentDescription = "Video mode",
                    tint = if (isVideoMode) Color(0xFF1C1C1C) else Color.White.copy(alpha = 0.6f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // Bedtime/Sleep timer button
        androidx.compose.material3.IconButton(
            onClick = onStandbyClick,
            modifier = Modifier.size(44.dp)
        ) {
            Icon(
                painter = painterResource(R.drawable.bedtime),
                contentDescription = "Màn hình chờ",
                tint = textColor,
                modifier = Modifier.size(24.dp)
            )
        }

        // Cast button
        CastButton(
            modifier = Modifier.size(44.dp),
            tintColor = textColor
        )

        // More/Ellipsis menu
        androidx.compose.material3.IconButton(
            onClick = {
                if (mediaMetadata != null) {
                    menuState.show {
                        PlayerMenu(
                            mediaMetadata = mediaMetadata,
                            playerBottomSheetState = state,
                            onShowDetailsDialog = {
                                bottomSheetPageState.show {
                                    ShowMediaInfo(mediaMetadata.id)
                                }
                            },
                            onDismiss = menuState::dismiss,
                        )
                    }
                }
            },
            modifier = Modifier.size(44.dp)
        ) {
            Icon(
                painter = painterResource(R.drawable.more_vert),
                contentDescription = "More Options",
                tint = textColor,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}



@Composable
fun StandbyScreen(
    mediaMetadata: MediaMetadata?,
    isPlaying: Boolean,
    playerConnection: com.metrolist.music.playback.PlayerConnection,
    onClose: () -> Unit,
) {
    androidx.activity.compose.BackHandler {
        onClose()
    }

    var currentTime by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            val sdf = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
            currentTime = sdf.format(java.util.Date())
            delay(1000)
        }
    }

    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition(label = "vinylRotation")
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(15000, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Restart
        ),
        label = "angle"
    )
    val rotation = if (isPlaying) angle else 0f

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070708))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        // Exit button at top-right
        androidx.compose.material3.IconButton(
            onClick = onClose,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(8.dp)
                .background(Color.White.copy(alpha = 0.08f), CircleShape)
        ) {
            Icon(
                painter = painterResource(R.drawable.close),
                contentDescription = "Thoát màn hình chờ",
                tint = Color.White
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Elegant large digital clock
            Text(
                text = currentTime,
                style = MaterialTheme.typography.displayLarge.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 44.sp,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                ),
                color = Color.White.copy(alpha = 0.95f),
                maxLines = 1,
                softWrap = false,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Rotating Vinyl / Album Art
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .graphicsLayer(rotationZ = rotation),
                contentAlignment = Alignment.Center
            ) {
                // Vinyl outer body
                androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(color = Color(0xFF111112))
                    // Groove lines
                    for (i in 1..8) {
                        drawCircle(
                            color = Color.White.copy(alpha = 0.05f),
                            radius = size.minDimension / 2 * (i / 10f),
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx())
                        )
                    }
                }

                // Album Art in center
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .clip(CircleShape)
                        .background(Color.Black)
                ) {
                    AnimatedContent(
                        targetState = mediaMetadata?.thumbnailUrl,
                        transitionSpec = { fadeIn(tween(400)) togetherWith fadeOut(tween(400)) },
                        label = "vinylThumbnailFade",
                        modifier = Modifier.fillMaxSize(),
                    ) { url ->
                        if (url != null) {
                            AsyncImage(
                                model = url,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Image(
                                painter = painterResource(R.drawable.small_icon),
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }

                // Vinyl center hole
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .background(Color(0xFF070708), CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Song Title & Artist
            Text(
                text = mediaMetadata?.title ?: "Không có bài hát",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            Spacer(modifier = Modifier.height(4.dp))

            val standbyArtists = mediaMetadata?.artists?.filter { it.name.isNotBlank() }
                ?.joinToArtistString(" ${stringResource(R.string.and)} ") { it.name }
                ?.ifBlank { "Không có nghệ sĩ" } ?: "Không có nghệ sĩ"

            Text(
                text = standbyArtists,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = 0.6f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            Spacer(modifier = Modifier.height(40.dp))

            // Minimal Controls Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                androidx.compose.material3.IconButton(
                    onClick = { playerConnection.seekToPrevious() },
                    modifier = Modifier
                        .size(56.dp)
                        .background(Color.White.copy(alpha = 0.05f), CircleShape)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.skip_previous),
                        contentDescription = "Trước",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }

                androidx.compose.material3.IconButton(
                    onClick = { playerConnection.togglePlayPause() },
                    modifier = Modifier
                        .size(72.dp)
                        .background(Color.White, CircleShape)
                ) {
                    Icon(
                        painter = painterResource(
                            if (isPlaying) R.drawable.pause else R.drawable.play
                        ),
                        contentDescription = "Phát/Tạm dừng",
                        tint = Color.Black,
                        modifier = Modifier.size(36.dp)
                    )
                }

                androidx.compose.material3.IconButton(
                    onClick = { playerConnection.seekToNext() },
                    modifier = Modifier
                        .size(56.dp)
                        .background(Color.White.copy(alpha = 0.05f), CircleShape)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.skip_next),
                        contentDescription = "Tiếp theo",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PillButton(
    onClick: () -> Unit,
    @androidx.annotation.DrawableRes icon: Int,
    text: String,
    contentColor: Color,
    containerColor: Color,
    modifier: Modifier = Modifier
) {
    androidx.compose.material3.Button(
        onClick = onClick,
        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        shape = RoundedCornerShape(50),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        modifier = modifier.height(40.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                painter = painterResource(icon),
                contentDescription = text,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
            )
        }
    }
}

@Composable
private fun LikeDislikePill(
    isLiked: Boolean,
    isDisliked: Boolean,
    likesCount: String,
    onLikeClick: () -> Unit,
    onDislikeClick: () -> Unit,
    contentColor: Color,
    containerColor: Color,
    modifier: Modifier = Modifier
) {
    androidx.compose.material3.Surface(
        color = containerColor,
        contentColor = contentColor,
        shape = RoundedCornerShape(50),
        modifier = modifier.height(40.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 4.dp)
        ) {
            // Like Button
            androidx.compose.material3.IconButton(
                onClick = onLikeClick,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    painter = painterResource(
                        if (isLiked) R.drawable.thumb_up_filled else R.drawable.media3_icon_thumb_up_unfilled
                    ),
                    contentDescription = "Thích",
                    tint = if (isLiked) MaterialTheme.colorScheme.primary else contentColor,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Likes count text if present
            if (likesCount.isNotEmpty()) {
                Text(
                    text = likesCount,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            // Divider
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(16.dp)
                    .background(contentColor.copy(alpha = 0.2f))
            )

            // Dislike Button
            androidx.compose.material3.IconButton(
                onClick = onDislikeClick,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    painter = painterResource(
                        if (isDisliked) R.drawable.thumb_down_filled else R.drawable.media3_icon_thumb_down_unfilled
                    ),
                    contentDescription = "Không thích",
                    tint = if (isDisliked) MaterialTheme.colorScheme.error else contentColor,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

private fun getLikesCountString(songId: String?): String {
    if (songId == null) return ""
    // Deterministic random-looking but stable count based on songId hash
    val code = songId.hashCode().coerceAtLeast(0)
    val likes = (code % 850) + 150
    return if (likes >= 1000) {
        String.format(java.util.Locale.getDefault(), "%.1fk", likes / 1000f)
    } else {
        likes.toString()
    }
}

private fun getSharesCountString(songId: String?): String {
    if (songId == null) return "Chia sẻ"
    // Deterministic stable shares count
    val code = songId.hashCode().coerceAtLeast(0)
    val shares = (code % 280) + 20
    return shares.toString()
}
