/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.component

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialogDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.util.Locale
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metrolist.music.R
import com.metrolist.music.api.ApiKeyClassification
import com.metrolist.music.api.ApiKeyManager
import com.metrolist.music.api.ApiKeyValidationResult
import com.metrolist.music.security.SecureKeyStorage
import com.metrolist.music.viewmodels.ModelViewModel

/**
 * FEATURE SPECIFICATION: API Key Management & Validation System (Settings Module)
 *
 * Implements strict classification rules & 100% solid (non-transparent / non-see-through) visual design:
 * - Completely solid, opaque background container with crisp borders (Zero xuyên thấu / Zero transparency).
 * - Perfectly centered, compact and neat dialog (clamped width, no misalignment).
 * - Zero Public Disclosure: Masked toggle, encrypted storage, censored display.
 * - Anti-tamper signature & client/server verification.
 * - Theme-adaptive dynamic solid status cards for 5 classification rules:
 *   1. Valid Active Key
 *   2. Expired Key (with direct renewal link)
 *   3. Renewed / Extended Key
 *   4. Lifetime / Free Key (Unlimited)
 *   5. Invalid / Spoofed / Malformed Key
 */
@Composable
fun ApiKeyManagementDialog(
    provider: String,
    initialApiKey: String,
    initialStatus: String = "",
    baseUrl: String = "",
    onDismiss: () -> Unit,
    onSaveKey: (key: String, status: String) -> Unit,
    viewModel: ModelViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val isDark = isSystemInDarkTheme()
    val decryptedInitial = remember(initialApiKey) { SecureKeyStorage.decrypt(initialApiKey) }
    var keyText by remember(decryptedInitial) { mutableStateOf(decryptedInitial) }
    var isPasswordVisible by remember { mutableStateOf(false) }
    val clipboardManager = LocalClipboardManager.current
    val validationState by viewModel.apiKeyValidation.collectAsStateWithLifecycle()

    // 100% Solid Adaptive Colors (Light vs Dark mode - No alpha, No transparency)
    val successColor = if (isDark) Color(0xFF81C784) else Color(0xFF2E7D32)
    val warningColor = if (isDark) Color(0xFFFFB74D) else Color(0xFFE65100)
    val errorColor = MaterialTheme.colorScheme.error

    val validBg = if (isDark) Color(0xFF1B3820) else Color(0xFFE8F5E9)
    val validBorder = if (isDark) Color(0xFF2E7D32) else Color(0xFF81C784)
    val validText = if (isDark) Color(0xFFA5D6A7) else Color(0xFF1B5E20)

    val freeBg = if (isDark) Color(0xFF003831) else Color(0xFFE0F2F1)
    val freeBorder = if (isDark) Color(0xFF00796B) else Color(0xFF80CBC4)
    val freeText = if (isDark) Color(0xFF80CBC4) else Color(0xFF004D40)

    val expiredBg = if (isDark) Color(0xFF3E1F00) else Color(0xFFFFF3E0)
    val expiredBorder = if (isDark) Color(0xFFE65100) else Color(0xFFFFB74D)
    val expiredTitle = if (isDark) Color(0xFFFFB74D) else Color(0xFFBF360C)
    val expiredDesc = if (isDark) Color(0xFFFFCC80) else Color(0xFFD84315)

    DisposableEffect(Unit) {
        onDispose {
            viewModel.resetApiKeyValidation()
        }
    }

    val isFormatAcceptable = keyText.isBlank() || ApiKeyManager.validateKeyFormat(keyText.trim(), provider)
    val isBlockedState = validationState is ApiKeyValidationResult.Invalid || validationState is ApiKeyValidationResult.Expired
    val canSave = keyText.isBlank() || (isFormatAcceptable && !isBlockedState)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = true,
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
        ),
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            tonalElevation = AlertDialogDefaults.TonalElevation,
            shadowElevation = 6.dp,
            border = BorderStroke(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outlineVariant,
            ),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                // Header: Compact Centered Icon, Title & Provider Pill (100% solid, non-transparent)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.key),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(22.dp),
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                text = stringResource(R.string.ai_api_key),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                            Text(
                                text = provider,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer)
                                    .padding(horizontal = 6.dp, vertical = 2.dp),
                            )
                        }

                        // Current Saved Status Indicator (Pill)
                        val currentStatusText = when (initialStatus) {
                            ApiKeyClassification.VALID_ACTIVE.storageKey, "valid" ->
                                stringResource(R.string.ai_api_key_status_valid_active)
                            ApiKeyClassification.RENEWED_EXTENDED.storageKey, "valid_renewed" ->
                                stringResource(R.string.ai_api_key_status_renewed_extended)
                            ApiKeyClassification.LIFETIME_FREE.storageKey, "valid_free" ->
                                stringResource(R.string.ai_api_key_status_lifetime_free)
                            ApiKeyClassification.EXPIRED.storageKey, "exhausted" ->
                                stringResource(R.string.ai_api_key_status_expired)
                            ApiKeyClassification.INVALID_SPOOFED.storageKey, "invalid" ->
                                stringResource(R.string.ai_api_key_status_invalid_spoofed)
                            else -> if (initialApiKey.isNotEmpty()) stringResource(R.string.ai_api_key_status_unverified) else ""
                        }

                        if (currentStatusText.isNotEmpty()) {
                            val dotColor = when (initialStatus) {
                                ApiKeyClassification.EXPIRED.storageKey, "exhausted" -> warningColor
                                ApiKeyClassification.INVALID_SPOOFED.storageKey, "invalid" -> errorColor
                                else -> successColor
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(dotColor),
                                )
                                Text(
                                    text = currentStatusText,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 11.sp,
                                    color = dotColor,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp),
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.close),
                            contentDescription = stringResource(android.R.string.cancel),
                            modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                // Security & Privacy Notice (100% solid, non-transparent)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Icon(
                        painter = painterResource(R.drawable.security),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp),
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = stringResource(R.string.ai_api_key_note_title),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            text = stringResource(R.string.ai_api_key_security_censored_hint),
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                val isFakeOrInvalidFormat = keyText.isNotBlank() && !isFormatAcceptable

                // Input Field (Compact, Rounded, Masked, 100% Solid)
                OutlinedTextField(
                    value = keyText,
                    onValueChange = { keyText = it },
                    isError = isFakeOrInvalidFormat || isBlockedState,
                    supportingText = if (isFakeOrInvalidFormat) {
                        {
                            Text(
                                text = stringResource(R.string.ai_api_key_invalid_format),
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 11.sp,
                            )
                        }
                    } else null,
                    label = { Text(stringResource(R.string.ai_api_key)) },
                    placeholder = {
                        Text(
                            text = when (provider) {
                                "OpenRouter" -> "sk-or-v1-••••••••"
                                "OpenAI" -> "sk-••••••••"
                                "Gemini" -> "AIza••••••••"
                                "Claude" -> "sk-ant-••••••••"
                                else -> "••••••••"
                            },
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.outline,
                        )
                    },
                    visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(0.dp),
                        ) {
                            if (keyText.isNotEmpty()) {
                                IconButton(
                                    onClick = { isPasswordVisible = !isPasswordVisible },
                                    modifier = Modifier.size(36.dp),
                                ) {
                                    Icon(
                                        painter = painterResource(if (isPasswordVisible) R.drawable.lock_open else R.drawable.lock),
                                        contentDescription = if (isPasswordVisible) "Hide key" else "Show key",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp),
                                    )
                                }
                                IconButton(
                                    onClick = { keyText = "" },
                                    modifier = Modifier.size(36.dp),
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.close),
                                        contentDescription = stringResource(R.string.ai_api_key_clear),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp),
                                    )
                                }
                            } else {
                                IconButton(
                                    onClick = {
                                        val clip = clipboardManager.getText()?.text
                                        if (!clip.isNullOrBlank()) {
                                            keyText = clip.trim()
                                        }
                                    },
                                    modifier = Modifier.size(36.dp),
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.content_copy),
                                        contentDescription = stringResource(R.string.ai_api_key_paste),
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp),
                                    )
                                }
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )

                // Compact Verify Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    FilledTonalButton(
                        onClick = {
                            viewModel.validateApiKey(provider, keyText, baseUrl)
                        },
                        enabled = keyText.isNotBlank() && validationState !is ApiKeyValidationResult.Checking,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.height(34.dp),
                    ) {
                        if (validationState is ApiKeyValidationResult.Checking) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.primary,
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.ai_api_key_checking),
                                style = MaterialTheme.typography.labelSmall,
                            )
                        } else {
                            Icon(
                                painter = painterResource(R.drawable.check),
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.ai_api_key_check),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                    }
                }

                // Dynamic Validation Feedback Card (100% Solid, Non-transparent)
                AnimatedVisibility(
                    visible = validationState !is ApiKeyValidationResult.Idle,
                    enter = fadeIn(),
                    exit = fadeOut(),
                ) {
                    when (val result = validationState) {
                        is ApiKeyValidationResult.Checking -> {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                                Text(
                                    text = stringResource(R.string.ai_api_key_verifying_provider, provider),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }

                        // Rule 1, 3, 4: Valid Active, Renewed / Extended, Lifetime / Free (Solid)
                        is ApiKeyValidationResult.Valid -> {
                            val isFree = result.isFreeUnlimited || result.classification == ApiKeyClassification.LIFETIME_FREE
                            val isRenewed = result.isRenewed || result.classification == ApiKeyClassification.RENEWED_EXTENDED
                            val cardBg = if (isFree) freeBg else validBg
                            val cardBorder = if (isFree) freeBorder else validBorder
                            val textColor = if (isFree) freeText else validText

                            val titleText = when {
                                isFree -> stringResource(R.string.ai_api_key_status_lifetime_free)
                                isRenewed -> stringResource(R.string.ai_api_key_status_renewed_extended)
                                else -> stringResource(R.string.ai_api_key_status_valid_active)
                            }

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = cardBg,
                                border = BorderStroke(1.dp, cardBorder),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.check),
                                        contentDescription = null,
                                        tint = textColor,
                                        modifier = Modifier.size(16.dp),
                                    )
                                    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                                        Text(
                                            text = titleText,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = textColor,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                        if (result.usage != null || result.limit != null) {
                                            val u = String.format(Locale.US, "%.4f", result.usage ?: 0.0)
                                            val l = result.limit?.let { String.format(Locale.US, "%.2f", it) } ?: "Unlimited"
                                            Text(
                                                text = stringResource(R.string.ai_api_key_usage_limit, u, l),
                                                style = MaterialTheme.typography.labelSmall,
                                                fontSize = 10.sp,
                                                color = textColor,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Rule 2: Expired Key (Solid)
                        is ApiKeyValidationResult.Expired -> {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = expiredBg,
                                border = BorderStroke(1.dp, expiredBorder),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.warning),
                                        contentDescription = null,
                                        tint = warningColor,
                                        modifier = Modifier.size(16.dp),
                                    )
                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(1.dp),
                                    ) {
                                        Text(
                                            text = stringResource(R.string.ai_api_key_status_expired),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = expiredTitle,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                        Text(
                                            text = stringResource(R.string.ai_api_key_status_expired_desc),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontSize = 10.sp,
                                            color = expiredDesc,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    }

                                    val portalUrl = result.renewalUrl ?: ApiKeyManager.getRenewalUrl(provider)
                                    TextButton(
                                        onClick = {
                                            try {
                                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(portalUrl)))
                                            } catch (e: Exception) {
                                                // Ignore
                                            }
                                        },
                                        modifier = Modifier.height(28.dp),
                                    ) {
                                        Text(
                                            text = "${stringResource(R.string.ai_api_key_renew_action)} ↗",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = expiredTitle,
                                        )
                                    }
                                }
                            }
                        }

                        // Rule 5: Invalid / Spoofed Key (Solid)
                        is ApiKeyValidationResult.Invalid -> {
                            val invalidMsg = when {
                                result.message.isNotBlank() -> result.message
                                result.isSpoofed -> stringResource(R.string.ai_api_key_invalid_format)
                                else -> stringResource(R.string.ai_api_key_status_invalid_spoofed)
                            }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.errorContainer,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.error),
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(16.dp),
                                    )
                                    Text(
                                        text = invalidMsg,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        fontSize = 11.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        }

                        is ApiKeyValidationResult.Error -> {
                            val displayMsg = when {
                                result.message.contains("UnknownHost", ignoreCase = true) ||
                                result.message.contains("Unable to resolve", ignoreCase = true) ||
                                result.message.contains("ConnectException", ignoreCase = true) ||
                                result.message.contains("SocketTimeout", ignoreCase = true) ||
                                result.message.contains("timeout", ignoreCase = true) ->
                                    stringResource(R.string.ai_api_key_network_error)
                                result.message.isNotBlank() -> result.message
                                else -> stringResource(R.string.ai_api_key_network_error)
                            }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.error),
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.outline,
                                        modifier = Modifier.size(16.dp),
                                    )
                                    Text(
                                        text = displayMsg,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 11.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        }

                        else -> {}
                    }
                }

                // Dialog Bottom Actions (Cancel & Save)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TextButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(10.dp),
                    ) {
                        Text(stringResource(android.R.string.cancel))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        enabled = canSave,
                        shape = RoundedCornerShape(10.dp),
                        onClick = {
                            val raw = keyText.trim()
                            if (raw.isBlank()) {
                                onSaveKey("", "")
                                onDismiss()
                                return@Button
                            }
                            val status = when (val res = validationState) {
                                is ApiKeyValidationResult.Valid -> res.classification.storageKey
                                is ApiKeyValidationResult.Expired -> ApiKeyClassification.EXPIRED.storageKey
                                is ApiKeyValidationResult.Invalid -> ApiKeyClassification.INVALID_SPOOFED.storageKey
                                else -> if (raw == decryptedInitial) initialStatus else ApiKeyClassification.VALID_ACTIVE.storageKey
                            }
                            // Encrypt key for zero public disclosure at rest
                            val encryptedKey = SecureKeyStorage.encrypt(raw)
                            onSaveKey(encryptedKey, status)
                            onDismiss()
                        },
                    ) {
                        Text(stringResource(R.string.ai_api_key_save))
                    }
                }
            }
        }
    }
}

/**
 * Backward compatibility alias for ApiKeyManagementDialog
 */
@Composable
fun ApiKeyValidationDialog(
    provider: String,
    initialApiKey: String,
    initialStatus: String = "",
    baseUrl: String = "",
    onDismiss: () -> Unit,
    onSaveKey: (key: String, status: String) -> Unit,
    viewModel: ModelViewModel = hiltViewModel(),
) {
    ApiKeyManagementDialog(
        provider = provider,
        initialApiKey = initialApiKey,
        initialStatus = initialStatus,
        baseUrl = baseUrl,
        onDismiss = onDismiss,
        onSaveKey = onSaveKey,
        viewModel = viewModel,
    )
}
