/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.constants.LoginHistoryKey
import com.metrolist.music.constants.AppLockEnabledKey
import com.metrolist.music.constants.LoginAlertsEnabledKey
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import androidx.hilt.navigation.compose.hiltViewModel
import com.metrolist.innertube.utils.parseCookieString
import com.metrolist.music.constants.AccountChannelHandleKey
import com.metrolist.music.constants.AccountEmailKey
import com.metrolist.music.constants.AccountNameKey
import com.metrolist.music.constants.AccountProviderKey
import com.metrolist.music.constants.DataSyncIdKey
import com.metrolist.music.constants.InnerTubeCookieKey
import com.metrolist.music.constants.VisitorDataKey
import com.metrolist.music.ui.component.DefaultDialog
import com.metrolist.music.utils.rememberPreference
import com.metrolist.music.utils.reportException
import com.metrolist.music.viewmodels.AccountSettingsViewModel
import kotlinx.coroutines.launch
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.*

data class LocalLoginHistoryItem(val provider: String, val identifier: String, val timestamp: Long)

fun parseLocalLoginHistory(serialized: String?): List<LocalLoginHistoryItem> {
    if (serialized.isNullOrBlank()) return emptyList()
    return serialized.split(";").mapNotNull { entry ->
        val parts = entry.split("|")
        if (parts.size >= 3) {
            LocalLoginHistoryItem(parts[0], parts[1], parts[2].toLongOrNull() ?: 0L)
        } else {
            null
        }
    }
}

fun formatLocalTimestamp(context: android.content.Context, timestamp: Long): String {
    val date = Date(timestamp)
    val now = Calendar.getInstance()
    val timeCalendar = Calendar.getInstance().apply { timeInMillis = timestamp }
    
    val isToday = now.get(Calendar.YEAR) == timeCalendar.get(Calendar.YEAR) &&
            now.get(Calendar.DAY_OF_YEAR) == timeCalendar.get(Calendar.DAY_OF_YEAR)
            
    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault()).format(date)
    return if (isToday) {
        context.getString(R.string.today_prefix, timeFormat)
    } else {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(date)
        context.getString(R.string.earlier_prefix, dateFormat, timeFormat)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecuritySettingsScreen(
    navController: NavController
) {
    val context = LocalContext.current
    val (loginHistory, onLoginHistoryChange) = rememberPreference(LoginHistoryKey, "")
    val (appLockEnabled, onAppLockEnabledChange) = rememberPreference(AppLockEnabledKey, false)
    val (loginAlertsEnabled, onLoginAlertsEnabledChange) = rememberPreference(LoginAlertsEnabledKey, true)
    
    val (innerTubeCookie, onInnerTubeCookieChange) = rememberPreference(InnerTubeCookieKey, "")
    val (accountProvider, onAccountProviderChange) = rememberPreference(AccountProviderKey, "none")
    val (accountNamePref, onAccountNameChange) = rememberPreference(AccountNameKey, "")
    val (accountEmail, onAccountEmailChange) = rememberPreference(AccountEmailKey, "")
    val (accountChannelHandle, onAccountChannelHandleChange) = rememberPreference(AccountChannelHandleKey, "")
    val (visitorData, onVisitorDataChange) = rememberPreference(VisitorDataKey, "")
    val (dataSyncId, onDataSyncIdChange) = rememberPreference(DataSyncIdKey, "")

    val isLoggedIn = remember(innerTubeCookie, accountProvider) {
        "SAPISID" in parseCookieString(innerTubeCookie) || accountProvider == "discord" || accountProvider == "khách" || accountProvider == "guest"
    }

    val accountSettingsViewModel: AccountSettingsViewModel = hiltViewModel()
    val scope = rememberCoroutineScope()
    var showDeleteAccountDialog by remember { mutableStateOf(false) }

    val historyItems = remember(loginHistory) { parseLocalLoginHistory(loginHistory) }
    var showClearConfirmDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.security_and_login_history)) },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(
                            painter = painterResource(R.drawable.arrow_back),
                            contentDescription = null
                        )
                    }
                }
            )
        },
        contentWindowInsets = LocalPlayerAwareWindowInsets.current
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Security settings group
            Material3SettingsGroup(
                title = stringResource(R.string.security_options),
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.security),
                        title = { Text(stringResource(R.string.app_lock)) },
                        description = { Text(stringResource(R.string.app_lock_desc)) },
                        trailingContent = {
                            Switch(
                                checked = appLockEnabled,
                                onCheckedChange = onAppLockEnabledChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (appLockEnabled) R.drawable.check else R.drawable.close,
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                }
                            )
                        },
                        onClick = { onAppLockEnabledChange(!appLockEnabled) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.notification),
                        title = { Text(stringResource(R.string.security_alerts)) },
                        description = { Text(stringResource(R.string.security_alerts_desc)) },
                        trailingContent = {
                            Switch(
                                checked = loginAlertsEnabled,
                                onCheckedChange = onLoginAlertsEnabledChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (loginAlertsEnabled) R.drawable.check else R.drawable.close,
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                }
                            )
                        },
                        onClick = { onLoginAlertsEnabledChange(!loginAlertsEnabled) }
                    ),
                    if (isLoggedIn) {
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.delete),
                            title = {
                                Text(
                                    text = stringResource(R.string.delete_account_title),
                                    color = MaterialTheme.colorScheme.error
                                )
                            },
                            description = { Text(stringResource(R.string.delete_account_message)) },
                            trailingContent = {
                                Icon(
                                    painter = painterResource(R.drawable.navigate_next),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f)
                                )
                            },
                            onClick = { showDeleteAccountDialog = true }
                        )
                    } else {
                        null
                    }
                ).filterNotNull()
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Login History Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.login_history),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                if (historyItems.isNotEmpty()) {
                    TextButton(
                        onClick = { showClearConfirmDialog = true },
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text(stringResource(R.string.clear_history_action))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (historyItems.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                    )
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = stringResource(R.string.login_history_empty),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    historyItems.forEach { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val iconRes = when (item.provider.lowercase()) {
                                    "google" -> R.drawable.google
                                    "discord" -> R.drawable.discord
                                    else -> R.drawable.person
                                }
                                
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (item.provider.lowercase() == "discord") Color(0xFF5865F2).copy(alpha = 0.1f)
                                            else MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        painter = painterResource(id = iconRes),
                                        contentDescription = null,
                                        tint = if (item.provider.lowercase() == "discord") Color(0xFF5865F2)
                                               else MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                
                                Spacer(modifier = Modifier.width(12.dp))
                                
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${item.provider} - ${item.identifier}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = formatLocalTimestamp(context, item.timestamp),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDeleteAccountDialog) {
        DefaultDialog(
            onDismiss = { showDeleteAccountDialog = false },
            title = { Text(stringResource(R.string.delete_account_title)) },
            content = {
                Text(
                    text = stringResource(R.string.delete_account_message),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(horizontal = 18.dp)
                )
            },
            buttons = {
                TextButton(
                    onClick = {
                        showDeleteAccountDialog = false
                    }
                ) {
                    Text(stringResource(android.R.string.cancel))
                }
                TextButton(
                    onClick = {
                        Timber.d("[DELETE_ACCOUNT] User confirmed account deletion in Security Settings")
                        scope.launch {
                            try {
                                Timber.d("[DELETE_ACCOUNT] Starting deletion and clear process")
                                accountSettingsViewModel.logoutAndClearLibraryData(context)
                                Timber.d("[DELETE_ACCOUNT] Library data cleared and account forgotten")
                            } catch (e: Exception) {
                                Timber.e(e, "[DELETE_ACCOUNT] Error deleting account and library data")
                                reportException(e)
                            }
                            onInnerTubeCookieChange("")
                            onAccountProviderChange("none")
                            onAccountNameChange("")
                            onAccountEmailChange("")
                            onAccountChannelHandleChange("")
                            onVisitorDataChange("")
                            onDataSyncIdChange("")
                            Timber.d("[DELETE_ACCOUNT] Account deletion complete")
                            showDeleteAccountDialog = false
                            navController.navigateUp()
                        }
                    }
                ) {
                    Text(
                        text = stringResource(R.string.delete_account_confirm),
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        )
    }

    if (showClearConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showClearConfirmDialog = false },
            title = { Text(stringResource(R.string.clear_history_confirm_title)) },
            text = { Text(stringResource(R.string.clear_history_confirm_desc)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        onLoginHistoryChange("")
                        showClearConfirmDialog = false
                        Toast.makeText(context, R.string.login_history_cleared, Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Text(stringResource(R.string.confirm_btn))
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirmDialog = false }) {
                    Text(stringResource(R.string.dismiss_btn))
                }
            }
        )
    }
}
