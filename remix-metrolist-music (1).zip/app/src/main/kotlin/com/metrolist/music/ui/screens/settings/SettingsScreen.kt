/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import androidx.navigation.NavController
import com.metrolist.music.BuildConfig
import com.metrolist.music.LocalNavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.component.ReleaseNotesCard
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.Updater

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    navController: NavController = LocalNavController.current,
    latestVersionName: String = BuildConfig.VERSION_NAME,
) {
    val uriHandler = LocalUriHandler.current
    val context = LocalContext.current
    val isAndroid12OrLater = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val hasAndroidAuto = remember {
        try {
            context.packageManager.getPackageInfo(
                "com.google.android.projection.gearhead", 0
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    Column(
        Modifier
            .windowInsetsPadding(LocalPlayerAwareWindowInsets.current.only(WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top
                )
            )
        )

        val chevronTrailing: @Composable () -> Unit = {
            Icon(
                painter = painterResource(R.drawable.navigate_next),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }

        // 1. Account & General Section
        Material3SettingsGroup(
            title = stringResource(R.string.settings_section_account_general),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.account),
                    title = { Text(stringResource(R.string.account)) },
                    description = { Text(stringResource(R.string.account_settings_desc)) },
                    trailingContent = chevronTrailing,
                    onClick = { navController.navigate("settings/account") }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.settings),
                    title = { Text(stringResource(R.string.settings_general_restricted_title)) },
                    description = { Text(stringResource(R.string.general_restricted_desc)) },
                    trailingContent = chevronTrailing,
                    onClick = { navController.navigate("settings/general_restricted") }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.notification),
                    title = { Text(stringResource(R.string.notifications_title)) },
                    description = { Text(stringResource(R.string.notifications_desc)) },
                    trailingContent = chevronTrailing,
                    onClick = { navController.navigate("settings/notifications") }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 2. Appearance & Playback Section
        Material3SettingsGroup(
            title = stringResource(R.string.settings_section_ui_player),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.palette),
                    title = { Text(stringResource(R.string.appearance)) },
                    description = { Text(stringResource(R.string.appearance_desc)) },
                    trailingContent = chevronTrailing,
                    onClick = { navController.navigate("settings/appearance") }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.play),
                    title = { Text(stringResource(R.string.player_and_audio)) },
                    description = { Text(stringResource(R.string.player_and_audio_desc)) },
                    trailingContent = chevronTrailing,
                    onClick = { navController.navigate("settings/player") }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.lyrics),
                    title = { Text(stringResource(R.string.lyrics)) },
                    description = { Text(stringResource(R.string.lyrics_settings_desc)) },
                    trailingContent = chevronTrailing,
                    onClick = { navController.navigate("settings/lyrics") }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.translate),
                    title = { Text(stringResource(R.string.ai_lyrics_translation)) },
                    description = { Text(stringResource(R.string.ai_lyrics_desc)) },
                    trailingContent = chevronTrailing,
                    onClick = { navController.navigate("settings/ai") }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 3. Content & Discovery Section
        Material3SettingsGroup(
            title = stringResource(R.string.settings_section_content_services),
            items = buildList {
                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.discover_tune),
                        title = { Text(stringResource(R.string.recommendations_title)) },
                        description = { Text(stringResource(R.string.recommendations_desc_settings)) },
                        trailingContent = chevronTrailing,
                        onClick = { navController.navigate("settings/recommendations") }
                    )
                )
                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.queue_music),
                        title = { Text(stringResource(R.string.integrations)) },
                        description = { Text(stringResource(R.string.integrations_desc)) },
                        trailingContent = chevronTrailing,
                        onClick = { navController.navigate("settings/integrations") }
                    )
                )
                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.radio),
                        title = { Text(stringResource(R.string.stream_sources)) },
                        description = { Text(stringResource(R.string.stream_sources_desc)) },
                        trailingContent = chevronTrailing,
                        onClick = { navController.navigate("settings/stream_sources") }
                    )
                )
                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.language),
                        title = { Text(stringResource(R.string.content)) },
                        description = { Text(stringResource(R.string.content_settings_desc)) },
                        trailingContent = chevronTrailing,
                        onClick = { navController.navigate("settings/content") }
                    )
                )
                if (hasAndroidAuto) {
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.ic_android_auto),
                            title = { Text(stringResource(R.string.android_auto)) },
                            description = { Text(stringResource(R.string.android_auto_desc)) },
                            trailingContent = chevronTrailing,
                            onClick = { navController.navigate("settings/android_auto") }
                        )
                    )
                }
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 4. Security & Storage Section
        Material3SettingsGroup(
            title = stringResource(R.string.settings_section_privacy_storage),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.security),
                    title = { Text(stringResource(R.string.security_and_login_history)) },
                    description = { Text(stringResource(R.string.security_and_login_history_desc)) },
                    trailingContent = chevronTrailing,
                    onClick = { navController.navigate("settings/security_history") }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.lock),
                    title = { Text(stringResource(R.string.privacy)) },
                    description = { Text(stringResource(R.string.privacy_settings_desc)) },
                    trailingContent = chevronTrailing,
                    onClick = { navController.navigate("settings/privacy") }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.sliders),
                    title = { Text(stringResource(R.string.data_saver_mode)) },
                    description = { Text(stringResource(R.string.data_saver_desc)) },
                    trailingContent = chevronTrailing,
                    onClick = { navController.navigate("settings/data_saver") }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.storage),
                    title = { Text(stringResource(R.string.storage)) },
                    description = { Text(stringResource(R.string.storage_settings_desc)) },
                    trailingContent = chevronTrailing,
                    onClick = { navController.navigate("settings/storage") }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.restore),
                    title = { Text(stringResource(R.string.backup_restore)) },
                    description = { Text(stringResource(R.string.backup_restore_desc)) },
                    trailingContent = chevronTrailing,
                    onClick = { navController.navigate("settings/backup_restore") }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.tune),
                    title = { Text(stringResource(R.string.advanced_settings_title)) },
                    description = { Text(stringResource(R.string.advanced_settings_desc)) },
                    trailingContent = chevronTrailing,
                    onClick = { navController.navigate("settings/advanced") }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 5. System & About Section
        Material3SettingsGroup(
            title = stringResource(R.string.settings_section_system_info),
            items = buildList {
                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.update),
                        title = { Text(stringResource(R.string.updater)) },
                        description = { Text(stringResource(R.string.updater_desc)) },
                        trailingContent = chevronTrailing,
                        onClick = { navController.navigate("settings/updater") }
                    )
                )
                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.cloud),
                        title = { Text(stringResource(R.string.service_uptime)) },
                        description = { Text(stringResource(R.string.service_uptime_desc)) },
                        trailingContent = chevronTrailing,
                        onClick = { navController.navigate("settings/service_uptime") }
                    )
                )
                if (isAndroid12OrLater) {
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.link),
                            title = { Text(stringResource(R.string.default_links)) },
                            description = { Text(stringResource(R.string.default_links_desc)) },
                            trailingContent = chevronTrailing,
                            onClick = {
                                try {
                                    val intent = Intent(
                                        Settings.ACTION_APP_OPEN_BY_DEFAULT_SETTINGS,
                                        "package:${context.packageName}".toUri()
                                    )
                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(
                                        context,
                                        R.string.open_app_settings_error,
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                        )
                    )
                }
                val showChangelog = com.metrolist.music.LocalChangelogState.current
                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.newspaper),
                        title = { Text(stringResource(R.string.changelog)) },
                        description = { Text(stringResource(R.string.changelog_desc)) },
                        trailingContent = chevronTrailing,
                        onClick = { showChangelog.value = true }
                    )
                )
                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.info),
                        title = { Text(stringResource(R.string.about)) },
                        description = { Text(stringResource(R.string.about_desc)) },
                        trailingContent = chevronTrailing,
                        onClick = { navController.navigate("settings/about") }
                    )
                )
                if (BuildConfig.UPDATER_AVAILABLE && latestVersionName != BuildConfig.VERSION_NAME) {
                    val releaseInfo = Updater.getCachedLatestRelease()
                    val downloadUrl = releaseInfo?.let { Updater.getDownloadUrlForCurrentVariant(it) }

                    if (downloadUrl != null) {
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.update),
                                title = { 
                                    Text(
                                        text = stringResource(R.string.new_version_available),
                                    )
                                },
                                description = {
                                    Text(
                                        text = latestVersionName,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                },
                                showBadge = true,
                                trailingContent = chevronTrailing,
                                onClick = { uriHandler.openUri(downloadUrl) }
                            )
                        )
                    }
                }
            }
        )

        if (BuildConfig.UPDATER_AVAILABLE && latestVersionName != BuildConfig.VERSION_NAME) {
            Spacer(modifier = Modifier.height(16.dp))
            ReleaseNotesCard()
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    TopAppBar(
        title = { Text(stringResource(R.string.settings)) },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain
            ) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null
                )
            }
        }
    )
}
