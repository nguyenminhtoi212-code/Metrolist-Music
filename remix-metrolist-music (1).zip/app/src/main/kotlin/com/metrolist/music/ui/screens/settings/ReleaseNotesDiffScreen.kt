/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.metrolist.music.BuildConfig
import com.metrolist.music.LocalDatabase
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.db.entities.VersionHistoryEntity
import com.metrolist.music.db.repositories.VersionHistoryRepository
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.utils.backToMain
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class ChangeCategory(val iconRes: Int) {
    ALL(R.drawable.list),
    FEATURE(R.drawable.star),
    IMPROVEMENT(R.drawable.trending_up),
    FIX(R.drawable.bug_report),
    OTHER(R.drawable.sync)
}

data class ParsedChangeItem(
    val rawText: String,
    val cleanText: String,
    val category: ChangeCategory,
    val version: String,
    val isHighlighted: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReleaseNotesDiffScreen(
    navController: NavController,
    scrollBehavior: TopAppBarScrollBehavior = TopAppBarDefaults.pinnedScrollBehavior()
) {
    val context = LocalContext.current
    val database = LocalDatabase.current
    val repository = remember(database) { VersionHistoryRepository(database.versionHistoryDao) }
    val coroutineScope = rememberCoroutineScope()

    val versions by repository.allVersions.collectAsStateWithLifecycle(initialValue = emptyList())
    var isSyncing by remember { mutableStateOf(false) }

    // Seed database if empty
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val count = database.versionHistoryDao.getCount()
            if (count == 0) {
                isSyncing = true
                repository.syncVersionHistory(context)
                isSyncing = false
            }
        }
    }

    // Selected comparison versions
    var selectedTargetVersion by remember { mutableStateOf<String?>(null) }
    var selectedBaseVersion by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(ChangeCategory.ALL) }
    var isDiffMode by remember { mutableStateOf(true) }

    // Initialize defaults when versions list is loaded
    LaunchedEffect(versions) {
        if (versions.isNotEmpty()) {
            if (selectedTargetVersion == null) {
                selectedTargetVersion = versions.firstOrNull()?.version
            }
            if (selectedBaseVersion == null) {
                selectedBaseVersion = versions.getOrNull(1)?.version ?: versions.firstOrNull()?.version
            }
        }
    }

    val targetEntity = remember(versions, selectedTargetVersion) {
        versions.find { it.version == selectedTargetVersion } ?: versions.firstOrNull()
    }
    val baseEntity = remember(versions, selectedBaseVersion) {
        versions.find { it.version == selectedBaseVersion } ?: versions.getOrNull(1)
    }

    // Parse changes
    val targetChanges = remember(targetEntity) {
        parseReleaseChanges(targetEntity)
    }
    val baseChanges = remember(baseEntity) {
        parseReleaseChanges(baseEntity)
    }

    // Compute Diff items: changes in target vs base
    val diffItems = remember(targetChanges, baseChanges, isDiffMode, searchQuery, selectedCategory) {
        val baseTextSet = baseChanges.map { it.cleanText.lowercase().trim() }.toSet()
        val allTarget = if (isDiffMode) {
            targetChanges.map { item ->
                val isNew = !baseTextSet.contains(item.cleanText.lowercase().trim())
                item.copy(isHighlighted = isNew)
            }
        } else {
            targetChanges
        }

        allTarget.filter { item ->
            val matchCategory = selectedCategory == ChangeCategory.ALL || item.category == selectedCategory
            val matchQuery = searchQuery.isBlank() || item.cleanText.contains(searchQuery, ignoreCase = true)
            matchCategory && matchQuery
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.release_diff_title),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = stringResource(R.string.release_diff_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = navController::navigateUp,
                        onLongClick = navController::backToMain
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.arrow_back),
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            coroutineScope.launch {
                                isSyncing = true
                                val count = repository.syncVersionHistory(context)
                                isSyncing = false
                                Toast.makeText(
                                    context,
                                    context.getString(R.string.version_history_synced_toast, count),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    ) {
                        if (isSyncing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                painter = painterResource(R.drawable.sync),
                                contentDescription = stringResource(R.string.version_history_sync)
                            )
                        }
                    }
                },
                scrollBehavior = scrollBehavior
            )
        },
        contentWindowInsets = LocalPlayerAwareWindowInsets.current
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Version Comparison Selector & Highlight Card
            item {
                VersionCompareHeaderCard(
                    versions = versions,
                    targetVersion = targetEntity?.version ?: "v${BuildConfig.VERSION_NAME}",
                    baseVersion = baseEntity?.version ?: "",
                    onTargetSelected = { selectedTargetVersion = it },
                    onBaseSelected = { selectedBaseVersion = it },
                    isDiffMode = isDiffMode,
                    onToggleDiffMode = { isDiffMode = it }
                )
            }

            // 2. Search & Filter Bar
            item {
                SearchAndFilterSection(
                    searchQuery = searchQuery,
                    onSearchQueryChange = { searchQuery = it },
                    selectedCategory = selectedCategory,
                    onCategorySelected = { selectedCategory = it }
                )
            }

            // 3. Stats & Summary Bar
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val targetName = targetEntity?.version ?: BuildConfig.VERSION_NAME
                    val baseName = baseEntity?.version ?: "Previous"
                    Text(
                        text = stringResource(
                            R.string.release_diff_summary_format,
                            diffItems.size,
                            targetName,
                            baseName
                        ),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.secondaryContainer
                    ) {
                        Text(
                            text = if (isDiffMode) stringResource(R.string.release_diff_mode_diff) else stringResource(R.string.release_diff_mode_timeline),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }

            // 4. List of Changes with Visual Diff and Badges
            if (diffItems.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainer
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.info),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = stringResource(R.string.release_diff_no_changes),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(diffItems, key = { it.version + it.rawText }) { changeItem ->
                    VisualDiffChangeCard(item = changeItem)
                }
            }

            // 5. Raw Release Notes Expansion (Full Details)
            if (targetEntity != null && targetEntity.description.isNotBlank()) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    FullReleaseNotesExpander(entity = targetEntity)
                }
            }
        }
    }
}

@Composable
fun VersionCompareHeaderCard(
    versions: List<VersionHistoryEntity>,
    targetVersion: String,
    baseVersion: String,
    onTargetSelected: (String) -> Unit,
    onBaseSelected: (String) -> Unit,
    isDiffMode: Boolean,
    onToggleDiffMode: (Boolean) -> Unit
) {
    var showTargetMenu by remember { mutableStateOf(false) }
    var showBaseMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Header Row with Visual Diff Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                painter = painterResource(R.drawable.trending_up),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Text(
                        text = stringResource(R.string.release_diff_compare_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Diff Mode Toggle Segment
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHighest,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp))
                ) {
                    Row(modifier = Modifier.padding(3.dp)) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isDiffMode) MaterialTheme.colorScheme.primary else Color.Transparent,
                            modifier = Modifier
                                .clickable { onToggleDiffMode(true) }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Diff",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isDiffMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (!isDiffMode) MaterialTheme.colorScheme.primary else Color.Transparent,
                            modifier = Modifier
                                .clickable { onToggleDiffMode(false) }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "All",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (!isDiffMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Two Version Selector Badges Side by Side
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Target Version (Latest / Active)
                Box(modifier = Modifier.weight(1f)) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showTargetMenu = true }
                            .padding(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = stringResource(R.string.release_diff_latest_badge),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                                Icon(
                                    painter = painterResource(R.drawable.expand_more),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = targetVersion,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showTargetMenu,
                        onDismissRequest = { showTargetMenu = false }
                    ) {
                        versions.forEach { item ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "${item.version} ${if (item.isCurrent) "(${stringResource(R.string.version_history_current)})" else ""}",
                                        fontWeight = if (item.version == targetVersion) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    onTargetSelected(item.version)
                                    showTargetMenu = false
                                }
                            )
                        }
                    }
                }

                // VS Arrow Indicator
                Icon(
                    painter = painterResource(R.drawable.navigate_next),
                    contentDescription = "vs",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(24.dp)
                )

                // Base Version (Previous / Baseline)
                Box(modifier = Modifier.weight(1f)) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHighest,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showBaseMenu = true }
                            .padding(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = stringResource(R.string.release_diff_current_badge),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Bold
                                )
                                Icon(
                                    painter = painterResource(R.drawable.expand_more),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = baseVersion.ifBlank { "None" },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showBaseMenu,
                        onDismissRequest = { showBaseMenu = false }
                    ) {
                        versions.forEach { item ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "${item.version} ${if (item.isCurrent) "(${stringResource(R.string.version_history_current)})" else ""}",
                                        fontWeight = if (item.version == baseVersion) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    onBaseSelected(item.version)
                                    showBaseMenu = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SearchAndFilterSection(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    selectedCategory: ChangeCategory,
    onCategorySelected: (ChangeCategory) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Search TextField
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            leadingIcon = {
                Icon(
                    painter = painterResource(R.drawable.search),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            trailingIcon = {
                if (searchQuery.isNotBlank()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(
                            painter = painterResource(R.drawable.close),
                            contentDescription = "Clear",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            },
            placeholder = {
                Text(
                    text = stringResource(R.string.release_diff_search_hint),
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = Color.Transparent
            )
        )

        // Filter Category Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ChangeCategory.values().forEach { category ->
                val isSelected = selectedCategory == category
                val label = when (category) {
                    ChangeCategory.ALL -> stringResource(R.string.release_diff_category_all)
                    ChangeCategory.FEATURE -> stringResource(R.string.release_diff_category_features)
                    ChangeCategory.IMPROVEMENT -> stringResource(R.string.release_diff_category_improvements)
                    ChangeCategory.FIX -> stringResource(R.string.release_diff_category_fixes)
                    ChangeCategory.OTHER -> stringResource(R.string.release_diff_category_others)
                }

                FilterChip(
                    selected = isSelected,
                    onClick = { onCategorySelected(category) },
                    label = { Text(label) },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(category.iconRes),
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    shape = CircleShape
                )
            }
        }
    }
}

@Composable
fun VisualDiffChangeCard(
    item: ParsedChangeItem
) {
    val categoryColor = when (item.category) {
        ChangeCategory.FEATURE -> Color(0xFF10B981) // Emerald Green
        ChangeCategory.IMPROVEMENT -> Color(0xFF0EA5E9) // Cyan / Blue
        ChangeCategory.FIX -> Color(0xFFF59E0B) // Amber
        ChangeCategory.OTHER, ChangeCategory.ALL -> MaterialTheme.colorScheme.primary
    }

    val badgeLabel = when (item.category) {
        ChangeCategory.FEATURE -> stringResource(R.string.release_diff_category_features)
        ChangeCategory.IMPROVEMENT -> stringResource(R.string.release_diff_category_improvements)
        ChangeCategory.FIX -> stringResource(R.string.release_diff_category_fixes)
        ChangeCategory.OTHER, ChangeCategory.ALL -> stringResource(R.string.release_diff_category_others)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (item.isHighlighted) {
                categoryColor.copy(alpha = 0.12f)
            } else {
                MaterialTheme.colorScheme.surfaceContainer
            }
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Category Icon with Round Background
            Surface(
                shape = CircleShape,
                color = categoryColor.copy(alpha = 0.2f),
                modifier = Modifier.size(34.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        painter = painterResource(item.category.iconRes),
                        contentDescription = null,
                        tint = categoryColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Surface(
                        shape = CircleShape,
                        color = categoryColor.copy(alpha = 0.25f)
                    ) {
                        Text(
                            text = badgeLabel,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = categoryColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }

                    if (item.isHighlighted) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF10B981).copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "+ NEW",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF10B981),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = item.cleanText,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 14.5.sp,
                        lineHeight = 20.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
fun FullReleaseNotesExpander(
    entity: VersionHistoryEntity
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.newspaper),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = stringResource(R.string.changelog),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Icon(
                    painter = painterResource(if (expanded) R.drawable.expand_less else R.drawable.expand_more),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    val isVietnamese = java.util.Locale.getDefault().language.equals("vi", ignoreCase = true)
                    val noteText = if (isVietnamese) {
                        entity.descriptionVi.ifBlank { entity.description }
                    } else {
                        entity.descriptionEn.ifBlank { entity.description }
                    }
                    MarkdownText(noteText)
                }
            }
        }
    }
}

/**
 * Parses release note markdown bullet lines into categorized diff items.
 */
fun parseReleaseChanges(entity: VersionHistoryEntity?): List<ParsedChangeItem> {
    if (entity == null) return emptyList()

    val isVietnamese = java.util.Locale.getDefault().language.equals("vi", ignoreCase = true)
    val text = if (isVietnamese) {
        entity.descriptionVi.ifBlank { entity.description }
    } else {
        entity.descriptionEn.ifBlank { entity.description }
    }

    if (text.isBlank()) return emptyList()

    val lines = text.lines()
    val items = mutableListOf<ParsedChangeItem>()

    for (rawLine in lines) {
        val trimmed = rawLine.trim()
        if (trimmed.isBlank() || trimmed.startsWith("#")) continue

        val clean = trimmed
            .removePrefix("-")
            .removePrefix("*")
            .removePrefix("•")
            .trim()

        if (clean.isBlank()) continue

        val lower = clean.lowercase()
        val category = when {
            lower.contains("tính năng") || lower.contains("thêm") || lower.contains("feature") || lower.contains("add") || lower.contains("new") -> ChangeCategory.FEATURE
            lower.contains("tối ưu") || lower.contains("nâng cấp") || lower.contains("cải thiện") || lower.contains("improve") || lower.contains("optimiz") || lower.contains("enhance") || lower.contains("speed") -> ChangeCategory.IMPROVEMENT
            lower.contains("sửa lỗi") || lower.contains("vá lỗi") || lower.contains("khắc phục") || lower.contains("fix") || lower.contains("bug") || lower.contains("crash") || lower.contains("glitch") -> ChangeCategory.FIX
            else -> ChangeCategory.OTHER
        }

        items.add(
            ParsedChangeItem(
                rawText = trimmed,
                cleanText = clean,
                category = category,
                version = entity.version
            )
        )
    }

    return items
}
