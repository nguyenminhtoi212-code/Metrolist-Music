/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.metrolist.music.BuildConfig
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.constants.CheckForUpdatesKey
import com.metrolist.music.constants.UpdateNotificationsEnabledKey
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.Updater
import com.metrolist.music.utils.rememberPreference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UpdaterScreen(
    navController: NavController
) {
    val (checkForUpdates, onCheckForUpdatesChange) = rememberPreference(CheckForUpdatesKey, true)
    val (updateNotifications, onUpdateNotificationsChange) = rememberPreference(UpdateNotificationsEnabledKey, true)
    val (nightlyBuilds, onNightlyBuildsChange) = rememberPreference(com.metrolist.music.constants.NightlyBuildsKey, false)
    val (installationMethod, onInstallationMethodChange) = rememberPreference(com.metrolist.music.constants.InstallationMethodKey, "Standard")
    var showInstallationMethodDialog by remember { mutableStateOf(false) }

    val showChangelogState = com.metrolist.music.LocalChangelogState.current

    val context = LocalContext.current
    var isChecking by remember { mutableStateOf(false) }
    var updateAvailable by remember { mutableStateOf(false) }
    var latestVersion by remember { mutableStateOf<String?>(null) }
    var showChangelog by remember { mutableStateOf(false) }
    var changelogContent by remember { mutableStateOf<String?>(null) }
    var checkError by remember { mutableStateOf<String?>(null) }
    val failedToCheckUpdatesTemplate = stringResource(R.string.failed_to_check_updates)
    val githubConnError = stringResource(R.string.updater_error_github_connection)
    val unknownConnError = stringResource(R.string.updater_error_unknown_connection)

    val coroutineScope = rememberCoroutineScope()

    if (showInstallationMethodDialog) {
        com.metrolist.music.ui.component.EnumDialog(
            onDismiss = { showInstallationMethodDialog = false },
            onSelect = {
                onInstallationMethodChange(it)
                showInstallationMethodDialog = false
            },
            title = stringResource(R.string.updater_install_method_dialog_title),
            current = installationMethod,
            values = listOf("Standard", "Shizuku", "Root"),
            valueText = { it }
        )
    }

    fun performManualCheck() {
        coroutineScope.launch {
            isChecking = true
            checkError = null
            withContext(Dispatchers.IO) {
                Updater
                    .checkForUpdate(forceRefresh = true)
                    .onSuccess { (releaseInfo, hasUpdate) ->
                        if (releaseInfo != null) {
                            latestVersion = releaseInfo.versionName
                            updateAvailable = hasUpdate
                            changelogContent = releaseInfo.description
                        }
                    }.onFailure {
                        val errorDetail = when {
                            it is java.net.UnknownHostException ||
                            it.message?.contains("Unable to resolve host", ignoreCase = true) == true ||
                            it.message?.contains("api.github.com", ignoreCase = true) == true ->
                                githubConnError
                            else -> it.localizedMessage ?: it.message ?: unknownConnError
                        }
                        checkError = String.format(failedToCheckUpdatesTemplate, errorDetail)
                    }
            }
            isChecking = false
        }
    }

    Column(
        modifier =
            Modifier
                .fillMaxWidth()
                .windowInsetsPadding(
                    LocalPlayerAwareWindowInsets.current.only(
                        WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom,
                    ),
                ).verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top,
                ),
            ),
        )

        Spacer(Modifier.height(4.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.updater_group_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.check),
                    title = { Text(stringResource(R.string.updater_system_update_title)) },
                    description = { Text(stringResource(R.string.updater_up_to_date)) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.info),
                    title = { Text(stringResource(R.string.updater_version_label, BuildConfig.VERSION_NAME)) },
                    description = {
                        val variant = if (BuildConfig.CAST_AVAILABLE) "GMS" else "FOSS"
                        Text("release - $variant")
                    }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.update),
                    title = { Text(stringResource(R.string.updater_auto_check_title)) },
                    description = { Text(stringResource(R.string.updater_auto_check_desc)) },
                    trailingContent = {
                        Switch(
                            checked = checkForUpdates,
                            onCheckedChange = onCheckForUpdatesChange,
                        )
                    },
                    onClick = { onCheckForUpdatesChange(!checkForUpdates) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.notification),
                    title = { Text(stringResource(R.string.updater_notif_title)) },
                    description = { Text(stringResource(R.string.updater_notif_desc)) },
                    trailingContent = {
                        Switch(
                            checked = updateNotifications,
                            onCheckedChange = onUpdateNotificationsChange,
                        )
                    },
                    onClick = { onUpdateNotificationsChange(!updateNotifications) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.delete),
                    title = { Text(stringResource(R.string.updater_clean_apk_title)) },
                    description = { Text(stringResource(R.string.updater_clean_apk_desc)) },
                    onClick = {
                        try {
                            var deletedCount = 0
                            val dirs = listOf(context.cacheDir, context.filesDir, context.getExternalFilesDir(null))
                            dirs.filterNotNull().forEach { dir ->
                                dir.walk().forEach { file ->
                                    if (file.isFile && file.extension.lowercase() == "apk") {
                                        if (file.delete()) {
                                            deletedCount++
                                        }
                                    }
                                }
                            }
                            android.widget.Toast.makeText(context, context.getString(R.string.updater_clean_apk_toast, deletedCount), android.widget.Toast.LENGTH_SHORT).show()
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, context.getString(R.string.updater_clean_apk_error_toast, e.message ?: ""), android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.newspaper),
                    title = { Text(stringResource(R.string.changelog)) },
                    onClick = { showChangelogState.value = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.update),
                    title = { Text(stringResource(R.string.updater_nightly_builds_title)) },
                    trailingContent = {
                        Switch(
                            checked = nightlyBuilds,
                            onCheckedChange = onNightlyBuildsChange,
                        )
                    },
                    onClick = { onNightlyBuildsChange(!nightlyBuilds) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.settings),
                    title = { Text(stringResource(R.string.updater_install_method_title)) },
                    description = { Text(installationMethod) },
                    onClick = { showInstallationMethodDialog = true }
                )
            )
        )

        Spacer(Modifier.height(16.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.check_for_updates_title),
            items =
                listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.refresh),
                        title = {
                            if (isChecking) {
                                Text(stringResource(R.string.checking_for_updates))
                            } else if (latestVersion != null) {
                                Text(stringResource(R.string.latest_version_format, latestVersion!!))
                            } else {
                                Text(stringResource(R.string.check_for_updates_button))
                            }
                        },
                        trailingContent = {
                            if (isChecking) {
                                CircularProgressIndicator(
                                    modifier = Modifier.padding(end = 16.dp),
                                    strokeWidth = 2.dp,
                                )
                            } else if (updateAvailable) {
                                Icon(
                                    painter = painterResource(R.drawable.download),
                                    contentDescription = stringResource(R.string.update_available_title),
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                            }
                        },
                        onClick = { if (!isChecking) performManualCheck() },
                    ),
                ),
        )

        checkError?.let {
            Spacer(Modifier.height(12.dp))
            Text(
                text = it,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
        }

        if (updateAvailable && latestVersion != null) {
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { showChangelog = !showChangelog },
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
            ) {
                Text(if (showChangelog) stringResource(R.string.hide_changelog) else stringResource(R.string.view_changelog))
            }

            if (showChangelog && changelogContent != null) {
                Spacer(Modifier.height(12.dp))
                Text(
                    text = changelogContent!!,
                    style = MaterialTheme.typography.bodySmall,
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                )
            }
        }

        Spacer(Modifier.height(32.dp))
    }

    TopAppBar(
        title = { Text(stringResource(R.string.updater)) },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain,
            ) {
                Icon(
                    painter = painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                )
            }
        },
    )
}
